"""BlochAI terminal entry point; the legacy blockai command remains available."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from .agents import AGENTS, AgentRunner, complete_when_free, fit_messages
from .auth import PortalSession, saved_token, session_path
from .config import BlochAIError, Settings, config_home, load_settings, state_home
from .providers import Provider
from .private_models import terminal_settings, terminal_models, choose_model
from .store import RunStore, scrub
from .workspace import Workspace, clean_text
from .research import requested_urls
from .model_context import conversation_context

app = typer.Typer(help="Qentl — Quantum Entanglement by Bloch Inc.: talk, build projects, create files and review learning runs.", no_args_is_help=False)
agents = typer.Typer(help="Specialist Bloch Agents.")
runs = typer.Typer(help="Private execution history.")
learn = typer.Typer(help="Continuous learning and reviewed programming datasets.")
project_commands = typer.Typer(help="Authenticated projects shared with the Qentl Graphus workspace.")
app.add_typer(agents, name="agents")
app.add_typer(runs, name="runs")
app.add_typer(learn, name="learn")
app.add_typer(project_commands, name="projects")
console = Console(markup=False, highlight=False)


def show(value):
    console.print(clean_text(value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2)))


def approval(automatic=False):
    def decide(action, preview):
        show(preview)
        if automatic:
            show("Approved by explicit --yes for this run.")
            return True
        return typer.confirm("Allow this " + action + "?", default=False)
    return decide


def event(item):
    if item["kind"] == "inference_submitted":
        show("Inference task: " + item["task_id"])
    elif item["kind"] == "tool_result":
        show({"agent":item["agent"], "tool":item["action"], "result":item["result"]})
    elif item["kind"] == "tool_error":
        show("Tool: " + item["message"])


@app.callback(invoke_without_command=True)
def root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        folder=working_folder()
        if folder is None:
            show('Tip: run qentl inside a project folder to let it read and create files there (each change asks first).')
            _chat_session()
        else:_chat_session(folder,code=True)


def working_folder():
    """The current directory when it is one specific folder; None for HOME or a drive root."""
    try:here=Path.cwd().resolve()
    except OSError:return None
    if here.is_symlink() or not here.is_dir() or here in (Path.home().resolve(),Path(here.anchor)):return None
    return here


@app.command()
def configure(provider: str = "qentl", url: Optional[str] = None, model: str = "",
              tenant: str = "terminal-local", token_file: str = "", max_output_tokens: int = 16384,
              timeout: float = 1800.0):
    """Select native Qentl, an operator gateway, or an installed Ollama model."""
    origin = url or ("http://127.0.0.1:11434" if provider == "ollama" else "https://rednblue.space" if provider == "rednblue" else "https://qentl.ai")
    Settings(provider=provider, url=origin, model=model, tenant=tenant,
             token_file=token_file, max_output_tokens=max_output_tokens, timeout=timeout).save()
    show("Configuration saved. Use qentl login for native Qentl access. Remote projects are available with --remote.")


@app.command()
def login(email: Optional[str] = typer.Option(None, help="Invited Qentl account email.")):
    """Authenticate with native Qentl. New accounts require an invitation; passwords are never saved."""
    portal = PortalSession()
    try:
        identity = portal.login(email or typer.prompt("Qentl email"), typer.prompt("Qentl password", hide_input=True))
        portal.save(identity)
        show({"user":identity["user"], "organization":identity["organization"]})
    finally:
        portal.close()


@app.command()
def whoami():
    """Validate the native Qentl session and account workspace."""
    portal = PortalSession(saved_token())
    try:
        show(portal.identity())
    finally:
        portal.close()


@app.command()
def organization(identifier: str):
    """Check the native Qentl account workspace; external organization switching is unavailable."""
    portal = PortalSession(saved_token())
    try:
        identity = portal.switch(identifier)
        portal.save(identity)
        show(identity["organization"])
    finally:
        portal.close()


@app.command()
def logout():
    """Revoke this Qentl session and remove its local credential."""
    portal = PortalSession(saved_token())
    try:
        portal.logout()
        session_path().unlink(missing_ok=True)
        show("Signed out.")
    finally:
        portal.close()


@app.command('models')
def models(use: Optional[str]=typer.Option(None,'--use',help='Make this model the default for this computer.')):
    """List the models this computer can use; --use NAME makes one the default."""
    choices=terminal_models()
    if use:
        chosen=choose_model(use,choices);choices=[chosen]+[item for item in choices if item.model!=chosen.model]
    for item in choices:show(('* ' if item is choices[0] else '  ')+item.model+'  '+item.provider+' '+item.url)


@app.command()
def status():
    """Inspect the actual inference model, availability and context limits."""
    provider = Provider(terminal_settings())
    try:
        show(provider.status())
    finally:
        provider.close()


@app.command()
def task(identifier: str):
    """Retrieve a previously submitted inference task without resubmitting it."""
    provider = Provider(load_settings())
    try:
        show(provider.task(identifier))
    finally:
        provider.close()


@app.command()
def ask(prompt: str):
    """Ask the LLM a question; this command never executes generated text."""
    provider = Provider(terminal_settings(), on_task=lambda ident: show("Inference task: " + ident))
    try:
        result = provider.complete([{"role":"system","content":conversation_context()}, {"role":"user","content":prompt}])
        show(result.text)
    finally:
        provider.close()


@app.command('web-policy')
def web_policy():
    """List permitted public sites and the bounded, read-only retrieval policy."""
    from .safe_web import policy
    show(policy())


@app.command('web-read')
def web_read(url: str):
    """Read an explicitly requested permitted public URL, without login or scripts."""
    from .research import read_web
    show(read_web(url,explicit_url=True))


@project_commands.callback(invoke_without_command=True)
def projects_overview(ctx: typer.Context):
    """With no subcommand: your projects on qentl.ai, one per line."""
    if ctx.invoked_subcommand is not None:return
    from .remote_projects import RemoteSession
    with RemoteSession() as session:rows=[row for row in session.projects().get('projects',[]) if isinstance(row,dict)]
    if not rows:show('No projects yet. Create one: qentl projects create NAME --remote');return
    width=max(len(str(row.get('id'))) for row in rows)
    for row in rows:show(str(row.get('id')).ljust(width)+'  '+clean_text(str(row.get('name','')))[:80])
    show('\nDownload one: qentl clone '+str(rows[0].get('id')))


@project_commands.command('list')
def list_projects(projects_root: Optional[Path] = typer.Option(None,help='Project storage root; defaults to the same existing or fresh workspace as the desktop app.'),
                  remote: bool = typer.Option(False,'--remote',help='List owned projects on https://qentl.ai using the current Qentl account.')):
    """List projects for the current native Qentl account workspace."""
    if remote:
        if projects_root is not None:raise BlochAIError('--projects-root is local; omit it for qentl.ai.')
        from .remote_projects import RemoteSession
        with RemoteSession() as session:show(session.projects())
        return
    from .cli_projects import ProjectSession
    session=ProjectSession(projects_root)
    try:show({'projects':session.catalog.list()})
    finally:session.close()


@project_commands.command('create')
def create_project(name: str,description: str='',kind: str='code',remote: bool=typer.Option(False,'--remote'),
                   projects_root: Optional[Path]=typer.Option(None)):
    """Create one project in the selected local or qentl.ai account."""
    if remote:
        if projects_root is not None:raise BlochAIError('--projects-root is local; omit it for qentl.ai.')
        from .remote_projects import RemoteSession
        with RemoteSession() as session:show(session.create(name,description,kind))
        return
    from .cli_projects import ProjectSession
    session=ProjectSession(projects_root)
    try:session.check(write=True);show({'project':session.catalog.create(name,description,kind)})
    finally:session.close()


@project_commands.command('scope')
def project_scope(project: str,remote: bool=typer.Option(False,'--remote'),projects_root: Optional[Path]=typer.Option(None)):
    """Inspect scope requirements; approval remains an explicit owner action."""
    if remote:
        if projects_root is not None:raise BlochAIError('--projects-root is local; omit it for qentl.ai.')
        from .remote_projects import RemoteSession
        with RemoteSession() as session:data=session.scope(project)
    else:
        from .cli_projects import ProjectSession
        from .closed_scope import ClosedScopeStore
        session=ProjectSession(projects_root)
        try:data=ClosedScopeStore(session.catalog,project).status()
        finally:session.close()
    contract=data.get('contract') or {}
    show({**{key:data.get(key) for key in ('state','revision','version','progress')},
          'source_paths':contract.get('source_paths',[]),'requirements':contract.get('requirements',[]),'allowed_paths':contract.get('allowed_paths',[])})


@project_commands.command('path')
def project_path(project: str,projects_root: Optional[Path] = typer.Option(None,help='Project storage root; defaults to the desktop workspace.')):
    """Print the actual workspace path for an owned Graphus project."""
    from .cli_projects import ProjectSession
    session=ProjectSession(projects_root)
    try:typer.echo(str(session.folder(project).resolve()))
    finally:session.close()


@app.command()
def run(task: str, workspace: Path = typer.Option(Path(".")), agent: str = "coder",
        max_steps: int = 16, yes: bool = typer.Option(False, "--yes", help="Explicitly approve all host edits and commands in this run."),
        project: Optional[str] = None, projects_root: Optional[Path] = typer.Option(None,help='Project storage root; defaults to the desktop workspace.'),
        requirement: Optional[str] = typer.Option(None,help='Requirement ID from the owner-approved Markdown project scope.'),
        scope_revision: Optional[str] = typer.Option(None,help='Require this exact approved scope revision.'),
        remote: bool = typer.Option(False,'--remote',help='Run in the selected qentl.ai project; no local files are uploaded.'),
        model: Optional[str] = typer.Option(None,help='Hosted model ID for --remote runs only.')):
    """Let an agent inspect a project, propose edits and run approved host commands."""
    if agent not in AGENTS and not (remote and agent in ('auto','chat')):raise BlochAIError('Choose a known agent, or --agent auto/chat for a remote task.')
    if remote:
        if not project or workspace!=Path('.') or projects_root is not None:
            raise BlochAIError('Remote runs require --project and do not accept a local workspace. Use qentl sync to transfer a selected folder.')
        if max_steps!=16:raise BlochAIError('The hosted service controls its step budget; --max-steps is a local-run option.')
        from .remote_projects import RemoteSession
        with RemoteSession() as session:
            result=session.submit(project,task,agent,requirement,scope_revision,model)
            show({'job_id':result['id'],'project':project,'site':'https://qentl.ai','note':'The task runs on the server. Ctrl+C stops waiting; use remote-cancel to cancel it.'})
            result=session.follow(result['id'],project,approval(yes),show)
            show({'job_id':result['id'],'project':project,'status':result['status'],'summary':result.get('summary','')})
        return
    if model is not None:raise BlochAIError('--model on qentl run is a hosted option; configure the local provider separately.')
    if project is not None:
        if workspace!=Path('.'):
            raise BlochAIError('Choose --project or --workspace; the private project path is resolved from your account.')
        from .cli_projects import ProjectSession, ProjectProvider, ProjectRunStore
        from .task_routing import route_task
        document_routing=route_task(task,agent) if agent in ('publisher','analyst') else {'artifact_only':False}
        session=ProjectSession(projects_root);provider=None
        try:
            session.check(write=True);folder=session.folder(project)
            from .closed_scope import ClosedScopeStore
            closed_scope=None
            if not document_routing['artifact_only'] and (agent in ('coder','coordinator','tester') or requirement is not None or scope_revision is not None):
                closed_scope=ClosedScopeStore(session.catalog,project).require(requirement,scope_revision)
            settings=session.settings()
            provider=Provider(settings,private_local=settings.provider=='ollama')
            guarded=ProjectProvider(provider,session,project,closed_scope)
            prepared=session.task(project,task,guarded,agent)
            with ProjectRunStore(session.owner,project,folder,secrets=(provider.secret,session.portal.token),closed_scope=closed_scope) as store:
                guarded.run_store=store
                scoped=session.workspace(project,approval(yes),web_urls=requested_urls(task),run_guard=store.ensure_active,closed_scope=closed_scope,artifact_formats=document_routing['artifact_formats'] if document_routing['artifact_only'] else None)
                if document_routing['artifact_only']:
                    from .interactive import requested_brand
                    scoped.document_brand=requested_brand(task);scoped.required_calculation=document_routing.get('calculation_required')
                result=AgentRunner(guarded,scoped,store,notify=event).run(prepared,agent,max_steps)
            show({'run_id':result['id'],'project':project,'status':result['status'],'summary':result['summary'],
                  'workspace':str(folder.resolve()),'graphus_sync':'Files are visible in this account’s project.'})
        finally:
            if provider:provider.close()
            session.close()
        return
    if requirement is not None or scope_revision is not None:
        raise BlochAIError('Closed-scope requirement options require an authenticated --project run.')
    provider = Provider(terminal_settings())
    try:
        from .task_routing import route_task,ArtifactWorkspace
        from .task_scope import resolve_scope
        from .interactive import requested_brand
        import secrets
        document_routing=route_task(task,agent) if agent in ('publisher','analyst') else {'artifact_only':False}
        tools=(ArtifactWorkspace(workspace,approval(yes),resolve_scope({'nodes':[]}),secrets.token_hex(8),document_routing['artifact_formats'],
                                 web_urls=requested_urls(task),document_brand=requested_brand(task),calculation_required=document_routing.get('calculation_required'))
               if document_routing['artifact_only'] else Workspace(workspace,approval(yes),allow_commands=agent!='analyst',web_urls=requested_urls(task)))
        result = AgentRunner(provider,tools,notify=event).run(task,agent,max_steps)
        show({"run_id":result["id"], "status":result["status"], "summary":result["summary"]})
    finally:
        provider.close()


@app.command('remote-job')
def remote_job(identifier: str,project: str=typer.Option(...),yes: bool=typer.Option(False,'--yes')):
    """Follow a qentl.ai task and review its pending file approvals."""
    from .remote_projects import RemoteSession
    with RemoteSession() as session:
        result=session.follow(identifier,project,approval(yes),show)
        show({'job_id':identifier,'project':project,'status':result['status'],'summary':result.get('summary','')})


@app.command('remote-cancel')
def remote_cancel(identifier: str):
    """Explicitly request cancellation of an owned qentl.ai task."""
    from .remote_projects import RemoteSession
    with RemoteSession() as session:show(session.cancel(identifier))


@app.command('sync')
def sync_project(project: str=typer.Option(...),workspace: Path=typer.Option(...,help='Only this explicitly selected directory is transferred.'),
                 pull: bool=typer.Option(False,'--pull',help='Fetch remote edits into the bound local folder without overwriting local changes.'),
                 watch: bool=typer.Option(False,'--watch',help='Repeat for this directory until Ctrl+C. No deletions are propagated.'),
                 dry_run: bool=typer.Option(False,'--dry-run',help='Show changes without creating a binding or writing files.'),
                 binding: Optional[str]=typer.Option(None,help='With --pull in a new folder: which already-synced site folder to attach.'),
                 interval: float=typer.Option(3,help='Seconds between --watch passes (1..60).')):
    """Sync selected UTF-8 source files with their Graphus folder on qentl.ai."""
    import time
    from .remote_projects import FolderSync,RemoteSession
    if not 1<=interval<=60 or (watch and dry_run):raise BlochAIError('Use interval 1..60 seconds; --dry-run performs one preview only.')
    with RemoteSession() as session:
        show({'site':'https://qentl.ai','user':session.identity['user'],'organization':session.identity['organization'],
              'project':project,'workspace':str(workspace.expanduser().resolve()),'direction':'pull' if pull else 'push'})
        sync=FolderSync(session,project,workspace,binding);last=None
        while True:
            result=sync.once(pull=pull,dry_run=dry_run,notify=lambda progress:show({'sync_progress':progress}));signature=json.dumps(result,sort_keys=True)
            if signature!=last or result.get('changes'):show(result);last=signature
            if not watch:break
            time.sleep(interval)


LINK = '.qentl/project.json'


def linked_project(start=None):
    """The qentl.ai project a folder was cloned from, found like a .git folder: here or in a parent."""
    folder=Path(start or Path.cwd()).resolve()
    for candidate in (folder,*folder.parents):
        marker=candidate/LINK
        if marker.is_file() and not marker.is_symlink() and marker.stat().st_size<2000:
            try:value=json.loads(marker.read_text(encoding='utf-8')).get('project')
            except (OSError,ValueError,AttributeError):continue
            if isinstance(value,str):return value,candidate
    return None,None


def site_target(session,project,folder,*,cloning=False):
    """Resolve what the person typed (ID, name, or nothing inside a cloned folder) to (project ID, folder)."""
    if project is None:
        project,root=linked_project(folder)
        if project is None:
            raise BlochAIError('This folder is not linked to a qentl.ai project. Use: qentl clone PROJECT [FOLDER]  (see qentl projects)')
        return project,root
    rows=[row for row in session.projects().get('projects',[]) if isinstance(row,dict)]
    wanted=project.strip().casefold()
    match=[row for row in rows if str(row.get('id'))==project] or [row for row in rows if str(row.get('name','')).strip().casefold()==wanted]
    if len(match)!=1:
        names=', '.join(str(row.get('id')) for row in rows[:20]) or 'none yet'
        raise BlochAIError('No single project is called "'+project+'". Your projects: '+names)
    identifier=str(match[0]['id'])
    if folder is None:
        linked,root=linked_project()
        folder=root if linked==identifier else Path.cwd()/identifier if cloning else None
        if folder is None:raise BlochAIError('Name the folder too: qentl pull '+identifier+' FOLDER')
    return identifier,Path(folder)


def paths_line(label,paths,limit=12):
    listed=', '.join(paths[:limit])+(' and '+str(len(paths)-limit)+' more' if len(paths)>limit else '')
    return label+' ('+str(len(paths))+'): '+listed


@app.command('push')
def push_project(name: Optional[str]=typer.Argument(None,help='Project ID or name. Not needed inside a cloned folder.'),
                 folder: Optional[Path]=typer.Argument(None,help='Folder to send. Defaults to the cloned folder you are in.'),
                 project: Optional[str]=typer.Option(None,help='Same as the first argument.'),
                 workspace: Optional[Path]=typer.Option(None,help='Same as the second argument.'),
                 dry_run: bool=typer.Option(False,'--dry-run',help='Show what would be sent without changing the site.'),
                 yes: bool=typer.Option(False,'--yes',help='Send without asking for confirmation.'),
                 as_json: bool=typer.Option(False,'--json',help='Machine-readable output.')):
    """Send your local edits back to the same files on qentl.ai. Nothing is deleted on the site."""
    from .remote_clone import ProjectClone
    from .remote_projects import RemoteSession
    with RemoteSession() as session:
        identifier,root=site_target(session,project or name,workspace or folder)
        clone=ProjectClone(session,identifier,root);plan=clone.plan_push()
        updates=[row['path'] for row in plan['updates']];creates=[row['path'] for row in plan['creates']]
        if as_json:
            show({'project':identifier,'workspace':str(clone.root),'direction':'push','update':updates,'create':creates,
                  'unchanged':plan['unchanged'],'skipped':plan['skipped'],'not_sent_site_changed':plan['site_changed']})
        else:
            show('Project '+identifier+' ← '+str(clone.root))
            if updates:show(paths_line('  Changed',updates))
            if creates:show(paths_line('  New',creates))
            if plan['site_changed']:
                show(paths_line('  Not sent, also changed on the site',plan['site_changed']))
                show('  Run qentl pull, merge those files, then push again.')
        if not (updates or creates):
            if not as_json:show('Nothing to send. The site already has your files.')
            return
        if dry_run:return
        if not yes and not typer.confirm('Send '+str(len(updates)+len(creates))+' file(s) to qentl.ai?',default=True):
            show('Nothing was sent.');return
        sent=clone.push(plan)
        show({'sent':sent,'deletions':False} if as_json else 'Sent '+str(len(sent))+' file(s). Each change is a revision in the site file history.')


@app.command('pull',help='Update a cloned folder with the newer files from qentl.ai. Your local edits are kept.')
@app.command('clone')
def clone_project(name: Optional[str]=typer.Argument(None,help='Project ID or name (see qentl projects). Not needed inside a cloned folder.'),
                  folder: Optional[Path]=typer.Argument(None,help='Local folder. Defaults to ./PROJECT-ID, or the cloned folder you are in.'),
                  project: Optional[str]=typer.Option(None,help='Same as the first argument.'),
                  workspace: Optional[Path]=typer.Option(None,help='Same as the second argument.'),
                  dry_run: bool=typer.Option(False,'--dry-run',help='Show what would be downloaded without writing files.'),
                  as_json: bool=typer.Option(False,'--json',help='Machine-readable output.')):
    """Download a qentl.ai project into a local folder. The site is not changed."""
    from .remote_clone import ProjectClone
    from .remote_projects import RemoteSession
    with RemoteSession() as session:
        identifier,root=site_target(session,project or name,workspace or folder,cloning=True)
        clone=ProjectClone(session,identifier,root);report=clone.once(dry_run=dry_run)
        if not dry_run:
            marker=clone.root/LINK
            if not (clone.root/'.qentl').is_symlink() and not marker.is_symlink():
                marker.parent.mkdir(exist_ok=True);marker.write_text(json.dumps({'project':identifier,'site':'https://qentl.ai'})+'\n',encoding='utf-8')
        if as_json:show(report);return
        new=[row['path'] for row in report['changes'] if row['action']=='create'];changed=[row['path'] for row in report['changes'] if row['action']=='update']
        show('Project '+identifier+' → '+str(clone.root)+(' (preview, nothing written)' if dry_run else ''))
        if new:show(paths_line('  New',new))
        if changed:show(paths_line('  Updated',changed))
        if not report['changes']:show('  Already up to date ('+str(report['unchanged'])+' file(s)).')
        if report.get('kept_local'):show(paths_line('  Kept your version, edited here',report['kept_local']))
        if report['skipped']:show('  Skipped '+str(len(report['skipped']))+' protected or binary file(s).')
        if report.get('incomplete'):show('  '+report['incomplete'])
        if not dry_run and report['changes']:show('Next: edit the files, then run qentl push inside this folder.')


@app.command()
def analyze(question: str, workspace: Path = typer.Option(Path(".")), max_steps: int = 24):
    """Research supplied files and permitted sources, then challenge the conclusions."""
    from .analysis import investigate
    provider=Provider(terminal_settings())
    try:
        result=investigate(provider,Workspace(workspace,approval(),allow_commands=False,web_urls=requested_urls(question)),question,notify=event,max_steps=max_steps)
        show({"run_id":result["id"],"status":result["status"],"summary":result["summary"]})
    finally:
        provider.close()


@app.command('study')
def study_worker(once: bool=typer.Option(False,'--once',help='Run one pass and exit.'),
                 interval: int=typer.Option(600,help='Seconds between passes (60..86400).')):
    """Operator: keep studying the owner's topics from their public sources. Runs until stopped."""
    import time
    from .config import Settings
    from .research import read_web
    from .study import StudyStore,StudyWorker
    if not 60<=interval<=86400:raise BlochAIError('Use an interval of 60 to 86400 seconds.')
    # A dedicated model keeps study off the GPUs that answer people.
    dedicated=config_home()/'study-provider.json'
    if dedicated.exists():
        try:settings=Settings(**json.loads(dedicated.read_text(encoding='utf-8'))).validate()
        except (OSError,ValueError,TypeError) as exc:raise BlochAIError('study-provider.json is not a valid provider configuration.') from exc
    else:settings=terminal_settings()
    provider=Provider(settings,private_local=settings.provider=='ollama')
    busy=lambda reason,seconds,attempt:show('Model busy; retrying in '+str(seconds)+'s')
    worker=StudyWorker(StudyStore(),lambda messages:complete_when_free(provider,messages,json_mode=True,waiting=busy),
                       lambda url:read_web(url,explicit_url=True),settings.model)
    try:
        while True:
            show({'study_cycle':worker.cycle()})
            if once:break
            time.sleep(interval)
    finally:provider.close()


@app.command('code')
def code_here(task: Optional[str]=typer.Argument(None,help='What to do first. Leave empty to start a conversation.'),
              workspace: Path=typer.Option(Path('.'),help='Project folder. Defaults to the current directory.')):
    """Work on the code in this folder: read, edit, run tests, build and deploy. Every edit and command asks first."""
    return _chat_session(workspace,code=True,opening=task)


@app.command()
def chat(workspace: Optional[Path] = typer.Option(None,help='Explicit local read context; the default console uses isolated scratch storage.'),
         remote: bool = typer.Option(False,'--remote',help='Use a hosted Qentl.ai project without uploading a local folder.'),
         project: Optional[str] = typer.Option(None,help='Owned local or hosted project ID.'),
         projects_root: Optional[Path] = typer.Option(None),
         requirement: Optional[str] = typer.Option(None,help='Approved code requirement for project development.'),
         scope_revision: Optional[str] = typer.Option(None)):
    """Interactive auto routing: talk, analyze and generate PDF/PPTX/XLSX without /run."""
    return _chat_session(workspace,remote,project,projects_root,requirement,scope_revision)


RETRY_WORDS = {'retry', 'again', 'try again', 'continue', 'seguir', 'segue', 'continuar', 'continua', 'de novo',
               'novamente', 'tentar de novo', 'tente de novo', 'tenta de novo', 'tentar novamente', 'tente novamente'}
PASTE_LIMIT = 200_000


def wants_retry(prompt):
    """A short 'try again' message, in English or Portuguese."""
    import re, unicodedata
    plain = unicodedata.normalize('NFKD', prompt.casefold())
    plain = ' '.join(re.sub(r'[^a-z ]', ' ', ''.join(c for c in plain if not unicodedata.combining(c))).split())
    return plain in RETRY_WORDS


def pasted_rest(stream=None, wait=0.05):
    """Lines that arrived together with the first one, as when text is pasted.

    Returns '' for typed input, pipes and terminals that cannot be polled."""
    import os, select, sys
    stream = stream or sys.stdin
    try:
        if not stream.isatty():
            return ''
        fd = stream.fileno()
        chunks, size = [], 0
        while size < PASTE_LIMIT and select.select([fd], [], [], wait)[0]:
            data = os.read(fd, 65536)
            if not data:
                break
            chunks.append(data); size += len(data)
    except (AttributeError, ValueError, OSError):
        return ''
    return '\n' + b''.join(chunks).decode('utf-8', 'replace')[:PASTE_LIMIT] if chunks else ''


def read_prompt():
    """One console message; a multi-line paste arrives as one message, not one request per line."""
    return (typer.prompt('You', prompt_suffix=' > ') + pasted_rest()).strip()


def _chat_session(workspace=None,remote=False,project=None,projects_root=None,requirement=None,scope_revision=None,code=False,opening=None):
    import secrets
    from .interactive_ui import InteractiveUI
    ui=InteractiveUI(console)
    from .config import private_directory
    from .interactive import Transcript,wants_download,requested_brand
    from .document_exports import local_document,export_download,receipt_name
    from .task_routing import route_task,ArtifactWorkspace
    from .task_scope import ScopedWorkspace,resolve_scope
    if remote and (not project or workspace is not None or projects_root is not None):
        raise BlochAIError('Use chat --remote --project ID; no local workspace is uploaded.')
    if project and workspace is not None:raise BlochAIError('Choose --project or an explicit --workspace, not both.')
    if not project and (requirement or scope_revision or projects_root is not None):raise BlochAIError('Project scope options require --project.')
    if workspace is not None:
        workspace=Path(workspace).expanduser()
        if workspace.is_symlink() or not workspace.is_dir() or workspace.resolve() in (Path.home().resolve(),Path(workspace.anchor)):
            raise BlochAIError('Select a specific project directory for read context, not HOME, a drive root or a symbolic link.')
        workspace=workspace.resolve()
    transcript=Transcript();documents=[];provider=None;session=None;remote_session=None
    trace_root=state_home()/'interactive-runs'/secrets.token_hex(16)
    def scratch():
        path=state_home()/'interactive'/secrets.token_hex(16)
        private_directory(path)
        return path
    root_folder=workspace or (None if project else scratch())
    try:
        if remote:
            from .remote_projects import RemoteSession
            remote_session=RemoteSession()
            rows=remote_session.projects().get('projects',[])
            if project not in {row.get('id') for row in rows}:raise BlochAIError('Choose an owned project from qentl projects list --remote.')
            context_label='Hosted project on https://qentl.ai'
            ui.welcome(context_label,project=project)
        else:
            if project:
                from .cli_projects import ProjectSession
                session=ProjectSession(projects_root);root_folder=session.folder(project)
                settings=session.settings()
            else:settings=terminal_settings()
            provider=Provider(settings,private_local=settings.provider=='ollama')
            context_label=('Authenticated local project' if project else 'Code in '+str(workspace)+' · every edit and command asks first' if code
                           else 'Explicit local read context' if workspace else 'Private scratch conversation; no HOME or current-directory scan')
            ui.welcome(context_label,settings.model,project)
        def export_one(index):
            if not 0<=index<len(documents):raise BlochAIError('Choose a generated document number from /artifacts.')
            row=documents[index]
            document=(remote_session.artifact_document(row['job'],project,row['receipt']) if row['kind']=='remote'
                      else local_document(row['root'],row['receipt']))
            show(export_download(document,approval()))
        failed=None
        while True:
            if opening is not None:prompt,opening=opening.strip(),None
            else:
                try:prompt=read_prompt()
                except (EOFError,typer.Abort):break
            if prompt in ('/quit','/exit'):break
            if not prompt:continue
            # 'seguir' after a failed request sends that request again instead of a bare word.
            if failed and wants_retry(prompt):
                prompt=failed;show('Retrying: '+clean_text(prompt)[:160])
            failed=None;attempt=None
            try:
                if prompt=='qentl' or prompt.startswith('qentl '):
                    console_command(prompt);continue
                if prompt=='/reset':
                    transcript.clear();documents.clear()
                    if not project and workspace is None:root_folder=scratch()
                    show('Conversation reference and document selections cleared.');continue
                if prompt=='/help':ui.help();continue
                if prompt=='/skills' or prompt.startswith('/skills '):
                    from .programming_skills import programming_skills
                    ui.skills(programming_skills(prompt.partition(' ')[2].strip() or 'all'));continue
                if prompt=='/status':
                    ui.status({} if remote else provider.status(),context=context_label,project=project);continue
                if prompt=='/model' or prompt.startswith('/model '):
                    if remote or session:show('Hosted and project sessions use the model configured for them; /model works in the local console.');continue
                    choices=terminal_models();wanted=prompt.partition(' ')[2].strip()
                    if not wanted:
                        show('\n'.join(('* ' if item.model==settings.model else '  ')+item.model for item in choices)+'\nSwitch with /model NAME (a unique part of the name is enough).');continue
                    chosen=choose_model(wanted,choices)
                    if chosen.model!=settings.model:
                        provider.close();settings=chosen;provider=Provider(settings,private_local=settings.provider=='ollama')
                    show('Model: '+settings.model+' (remembered for next time)');continue
                if prompt=='/artifacts':
                    ui.artifacts([{'number':index+1,'name':receipt_name(row['receipt']),'sha256':row['receipt']['sha256']} for index,row in enumerate(documents)]);continue
                if prompt.startswith('/download'):
                    parts=prompt.split()
                    if len(parts)!=2 or not parts[1].isdigit():show('Usage: /download NUMBER (choose a generated file from /artifacts)');continue
                    export_one(int(parts[1])-1);continue
                if prompt.startswith('/requirement'):
                    parts=prompt.split()
                    if len(parts)!=2 or not project:show('Usage: /requirement ID in chat --project PROJECT [--remote]');continue
                    requirement=parts[1];scope_revision=None;show('Selected requirement: '+requirement);continue
                selected_mode='auto';question=prompt
                if prompt in ('/run','/analyze'):
                    show('Usage: /run TASK or /analyze QUESTION. Plain PDF/PPTX/Excel requests need no /run.');continue
                if prompt.startswith(('/run ','/analyze ')):
                    selected_mode='auto' if prompt.startswith('/run ') else 'analyst';question=prompt.split(' ',1)[1].strip()
                elif prompt.startswith('/'):
                    ui.help();continue
                attempt=prompt
                routing=route_task(question,selected_mode);mode=routing['effective_mode']
                if selected_mode=='auto' and mode=='chat' and not remote and console_request(provider,question,ui):continue
                # In a code folder the agent reads the files to answer and does the work it is asked for.
                if code and not routing['artifact_only']:mode='coder'
                ui.task(mode,routing.get('artifact_formats',()))
                new_documents=[]
                if remote:
                    created=remote_session.submit(project,question,selected_mode,requirement,scope_revision,reference_context=transcript.reference_context())
                    ui.text('Hosted job '+created['id']+' · Ctrl+C stops waiting; remote-cancel explicitly cancels the task.')
                    result=remote_session.follow(created['id'],project,approval(),ui.remote_event)
                    for receipt in result.get('artifacts',[]):
                        receipt_name(receipt);new_documents.append({'kind':'remote','job':created['id'],'receipt':receipt})
                    answer=result.get('summary','')
                else:
                    if mode=='coder' and not session and not code:
                        raise BlochAIError('To work on code here, leave with /quit and run qentl code inside your project folder. For a site project use chat --remote --project ID.')
                    closed_scope=None;active_provider=provider
                    if session:
                        from .closed_scope import ClosedScopeStore
                        from .cli_projects import ProjectProvider
                        session.check(write=mode!='chat')
                        if mode=='coder' or (not routing['artifact_only'] and requirement):
                            closed_scope=ClosedScopeStore(session.catalog,project).require(requirement,scope_revision)
                        active_provider=ProjectProvider(provider,session,project,closed_scope)
                    question_with_context=transcript.task(question)
                    if mode=='chat':
                        result=complete_when_free(active_provider,fit_messages(active_provider,[{'role':'system','content':conversation_context(cli=True)}, {'role':'user','content':question_with_context}]),
                            waiting=lambda reason,seconds,attempt:ui.event({'kind':'waiting','seconds':seconds}))
                        answer=result.text
                    else:
                        if session:
                            from .cli_projects import ProjectRunStore
                            store=ProjectRunStore(session.owner,project,root_folder,secrets=(provider.secret,session.portal.token),closed_scope=closed_scope)
                            active_provider.run_store=store
                            tool_workspace=session.workspace(project,approval(),web_urls=requested_urls(question),run_guard=store.ensure_active,closed_scope=closed_scope,
                                artifact_formats=routing['artifact_formats'] if routing['artifact_only'] else None)
                            prepared=session.task(project,question_with_context,active_provider,mode)
                        else:
                            store=RunStore(trace_root,secrets=(provider.secret,),training_allowed=False)
                            prepared=question_with_context
                            tool_workspace=(ArtifactWorkspace(root_folder,approval(),resolve_scope({'nodes':[]}),secrets.token_hex(8),routing['artifact_formats'],web_urls=requested_urls(question))
                                            if routing['artifact_only'] else Workspace(root_folder,approval(),command_timeout=900,web_urls=requested_urls(question)) if code else ScopedWorkspace(root_folder,approval(),resolve_scope({'nodes':[]}),web_urls=requested_urls(question),mutation_guard=lambda:(_ for _ in ()).throw(BlochAIError('This analysis is read-only.'))))
                            if not routing['artifact_only'] and not code:tool_workspace.allow_file_writes=False;tool_workspace.allow_artifacts=False
                        if not routing['artifact_only'] and not closed_scope and not code:
                            tool_workspace.allow_file_writes=False;tool_workspace.allow_artifacts=False
                        if routing['artifact_only']:
                            tool_workspace.document_brand=requested_brand(question)
                            tool_workspace.required_calculation=routing.get('calculation_required')
                        from contextlib import nullcontext
                        with store if session else nullcontext(store):
                            result=AgentRunner(active_provider,tool_workspace,store,notify=ui.event).run(prepared,mode,48 if code else 24)
                        answer=result['summary']
                        for item in result.get('events',[]):
                            if item.get('action')=='create_artifact' and item.get('result',{}).get('sha256'):
                                receipt=item['result'];receipt_name(receipt)
                                if receipt['path'] not in {row['receipt']['path'] for row in new_documents}:
                                    new_documents.append({'kind':'local','root':root_folder,'receipt':receipt})
                        ui.result(result['status'])
                ui.answer(answer);transcript.add(question,answer)
                first=len(documents);documents.extend(new_documents)
                if new_documents:
                    ui.artifacts([{'number':first+index+1,'name':receipt_name(row['receipt']),'sha256':row['receipt']['sha256']} for index,row in enumerate(new_documents)])
                    if wants_download(question):
                        for index in range(first,len(documents)):export_one(index)
                    else:show('Use /download NUMBER to copy a generated file to Downloads after confirmation.')
            except BlochAIError as exc:
                ui.error(str(exc))
                if attempt:failed=attempt;show('Type retry (or seguir) to send it again.')
    finally:
        if provider:provider.close()
        if session:session.close()
        if remote_session:remote_session.close()


@agents.command("list")
def list_agents():
    for key, value in AGENTS.items():
        show(key + ": " + value["goal"])


@runs.command("list")
def list_runs():
    for record in RunStore().list()[:50]:
        show({key:record[key] for key in ("id", "agent", "status", "task", "updated_at")})


@runs.command("show")
def show_run(identifier: str):
    show(RunStore().load(identifier))


@runs.command("resume")
def resume(identifier: str, max_steps: int = 16, yes: bool = False):
    provider = Provider(terminal_settings())
    try:
        store = RunStore(secrets=(provider.secret,))
        record = store.load(identifier)
        result = AgentRunner(provider, Workspace(Path(record["workspace"]), approval(yes)), store, event).run(
            record["task"], record["agent"], max_steps, record=record)
        show({"run_id":result["id"], "status":result["status"], "summary":result["summary"]})
    finally:
        provider.close()


@learn.command("approve")
def approve_run(identifier: str, reviewer: str, license_name: str, note: str):
    """Mark an inspected, successfully tested trace as reusable for training."""
    show(RunStore().approve(identifier, reviewer, license_name, note))


@learn.command("export")
def export_runs(destination: Path):
    show(RunStore().export(destination))


@learn.command("cycle")
def learn_cycle(directory: Path = typer.Option(None), training: bool = False):
    """Run one bounded study/evaluation cycle; --training requires an isolated GPU."""
    from .learning import cycle
    show(cycle(directory or state_home()/"learning", training=training))


@learn.command("status")
def learn_status(directory: Path = typer.Option(None)):
    path = (directory or state_home()/"learning")/"status.json"
    show(json.loads(path.read_text()) if path.exists() else {"status":"not_started"})


@app.command()
def serve(port: int = 8765, workspace: Path = typer.Option(Path.home()/"blochai-projects"),
          public_origin: Optional[str]=typer.Option(None,help='Operator-only fixed HTTPS origin behind a trusted local proxy.')):
    """Open the workbench using native Qentl login. Binds loopback only."""
    import uvicorn
    from .web import create_app
    if not 1024 <= port <= 65535:
        raise BlochAIError("Choose a port from 1024 to 65535.")
    workspace.mkdir(parents=True, exist_ok=True)
    web=create_app(workspace,port,public_origin=public_origin)
    show(f"Qentl: {public_origin or 'http://127.0.0.1:'+str(port)} · sign in with Qentl")
    uvicorn.run(web,host="127.0.0.1",port=port,log_level="warning",access_log=False,proxy_headers=False)


@app.command()
def artifact(kind: str, specification: Path, output: str, workspace: Path = typer.Option(Path(".")), yes: bool = False):
    """Generate PDF/PPTX/XLSX from an explicit JSON spec, without an LLM call."""
    root=workspace.resolve()
    try:
        relative=specification.resolve().relative_to(root).as_posix()
    except ValueError as exc:
        raise BlochAIError("The JSON specification must be inside the selected workspace.") from exc
    show(Workspace(root,approval(yes)).create_artifact(kind,output,spec_path=relative))


def console_request(provider,question,ui):
    """A plain request for a CLI action becomes one confirmed command; True when handled."""
    from .console_intent import command_line,looks_operational,suggest
    if not looks_operational(question):return False
    projects=[]
    try:
        from .remote_projects import RemoteSession
        with RemoteSession() as remote_session:
            projects=[{'id':str(row.get('id')),'name':clean_text(str(row.get('name','')))[:80]} for row in remote_session.projects().get('projects',[]) if isinstance(row,dict)]
    except BlochAIError:pass  # not signed in or offline: the model must then be given the ID
    busy=lambda reason,seconds,attempt:ui.event({'kind':'waiting','seconds':seconds})
    kind,value=suggest(provider,question,projects,lambda messages:complete_when_free(provider,messages,json_mode=True,waiting=busy))
    if kind=='none':return False
    if kind=='ask':ui.answer(value);return True
    line=command_line(value)
    if not typer.confirm('Run: '+line+' ?',default=True):
        ui.text('Not run. You can type the command yourself: '+line);return True
    console_command(line);return True


def console_command(line):
    """Run a `qentl ...` line typed in the console as the CLI command it names.

    The line comes from the person at the keyboard, never from model output, and
    is dispatched to this program's own commands without a shell.
    """
    import shlex
    try:arguments=shlex.split(line)[1:]
    except ValueError:raise BlochAIError('Close the quotes in this qentl command and try again.') from None
    if not arguments or arguments[0] in ('chat','serve','code','study'):
        raise BlochAIError('You are already in the Qentl console. Type a request, or /quit to leave.')
    if arguments[0] in ('login','logout','configure'):
        # These ask for hidden input; pasted lines after them would be read as the answer.
        raise BlochAIError('Run qentl '+arguments[0]+' in your shell: type /quit first. qentl whoami shows the current account.')
    import click
    command=typer.main.get_command(app)
    try:command.main(args=arguments,prog_name='qentl',standalone_mode=False)
    except click.exceptions.Exit:pass
    except click.Abort:show('Stopped: qentl '+arguments[0])
    except KeyboardInterrupt:show('Stopped: qentl '+arguments[0])
    except click.ClickException as exc:
        context=getattr(exc,'ctx',None)
        raise BlochAIError(exc.format_message()+' Try: '+(context.command_path if context else 'qentl')+' --help') from None


def main():
    import sys
    from .auth import SignInRequired
    try:
        try:
            app(prog_name='qentl')
        except SignInRequired:
            # Sessions last 12 hours; offer to sign in here instead of only failing.
            if not (sys.stdin.isatty() and sys.stdout.isatty()) or (len(sys.argv)>1 and sys.argv[1] in ('login','logout')):raise
            show('Your Qentl sign-in has expired.')
            if not typer.confirm('Sign in now?',default=True):raise
            login(None)
            app(prog_name='qentl')
    except SignInRequired:
        show('Qentl: your sign-in has expired. Run: qentl login')
        raise SystemExit(1)
    except BlochAIError as exc:
        show("Qentl: " + str(exc))
        raise SystemExit(1)
    except KeyboardInterrupt:
        show("Interrupted.")
        raise SystemExit(130)


if __name__ == "__main__":
    main()
