'use strict';
(() => {
  let project=null;
  function renderProject(){
    $('privacy-project-name').textContent=project?'Data for '+project.name:'Select a project';
    $('privacy-export').hidden=!project||project.shared;$('privacy-delete').disabled=!project||project.shared;$('privacy-confirm').value='';$('privacy-confirm').placeholder=project?.id||'Select a project';
    if(project)$('privacy-export').href=`/api/projects/${project.id}/export.zip`;
  }
  async function refresh(){
    try{const data=await api('/api/privacy');$('history-retention').value=String(data.history_days);$('privacy-processing').textContent=data.processing;if(data.maintenance_error)$('privacy-status').textContent='Retention maintenance encountered an error. The operator needs to check it before confirming the cleanup.';$('privacy-limitations').replaceChildren();for(const text of data.limitations){const item=document.createElement('li');item.textContent=text;$('privacy-limitations').append(item);}}
    catch(e){error(e);}
  }
  $('privacy-form').onsubmit=async event=>{
    event.preventDefault();event.submitter.disabled=true;
    try{await api('/api/privacy',{history_days:Number($('history-retention').value)});$('privacy-status').textContent='Retention updated. Expired history will be removed by local maintenance.';}
    catch(e){$('privacy-status').textContent=e.message;}finally{event.submitter.disabled=false;}
  };
  $('privacy-delete-form').onsubmit=async event=>{
    event.preventDefault();if(!project||project.shared)return;
    if($('privacy-confirm').value!==project.id){error(new Error('Type the identifier exactly as shown in the field.'));return;}
    if(!window.confirm(`Permanently delete the project “${project.name}”, its files, notes, code and history from this computer? Earlier exports, backups and remote uploads are not covered by this deletion.`))return;
    event.submitter.disabled=true;
    try{await api(`/api/projects/${project.id}/delete`,{confirm_project:$('privacy-confirm').value});await window.BlochWorkspace.deleted();$('privacy-status').textContent='Project and local records deleted.';}
    catch(e){error(e);}finally{event.submitter.disabled=!project||project.shared;}
  };
  $('privacy-audit-details').ontoggle=async()=>{
    if(!$('privacy-audit-details').open)return;
    try{const data=await api('/api/privacy/audit');$('privacy-audit').textContent=data.events.length?data.events.map(row=>`${formatDate(row.at)}  ${row.action}`).reverse().join('\n'):'No events recorded.';}
    catch(e){error(e);}
  };
  window.BlochWorkspace.onProject(event=>{project=event.detail;renderProject();});
  window.BlochPrivacy={refresh};renderProject();
})();
