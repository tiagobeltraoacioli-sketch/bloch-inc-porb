'use strict';
(() => {
  let epoch=0,authorized=false,busy=false;
  const dimensions={programming:'Programming',deduction:'Deduction',induction:'Induction',inference:'Inference',critique:'Critique'};
  const ns='http://www.w3.org/2000/svg';
  function node(tag,text,cls){const item=document.createElement(tag);if(text!==undefined)item.textContent=text;if(cls)item.className=cls;return item;}
  function svgNode(tag,attributes={}){const item=document.createElementNS(ns,tag);for(const [key,value] of Object.entries(attributes))item.setAttribute(key,String(value));return item;}
  function score(value){return typeof value==='number'&&Number.isFinite(value)&&value>=0&&value<=100?value:null;}
  function clear(){
    authorized=false;$('capability-panel').hidden=true;$('capability-open').hidden=true;
    $('capability-models').replaceChildren();$('capability-status').textContent='';$('capability-refreshed').textContent='';
  }
  function controls(){$('capability-refresh').disabled=busy||!authorized;}
  function chart(rows,model){
    const svg=svgNode('svg',{viewBox:'0 0 460 160',role:'img','aria-label':'Measured history for '+model});
    const title=svgNode('title');title.textContent='Actual observations, 0 to 100. Gaps indicate incomplete evaluations. Each point identifies the model, revision and suite.';svg.append(title);
    for(const level of [0,50,100]){
      const y=132-level*1.08;svg.append(svgNode('line',{x1:32,x2:446,y1:y,y2:y,stroke:'#30413e','stroke-width':1}));
      const label=svgNode('text',{x:1,y:y+4,fill:'#b6c9c3','font-size':11});label.textContent=String(level);svg.append(label);
    }
    let previous=null;
    for(const [index,row] of rows.entries()){
      const measured=score(row.score),x=rows.length===1?239:40+index*398/(rows.length-1);
      if(measured===null){previous=null;continue;}
      const y=132-measured*1.08;
      if(previous&&previous.suite===row.suite_version&&previous.revision===row.model_revision)svg.append(svgNode('line',{x1:previous.x,y1:previous.y,x2:x,y2:y,stroke:'#60e0c3','stroke-width':2}));
      const point=svgNode('circle',{cx:x,cy:y,r:4,fill:'#60e0c3',tabindex:0});
      const info=svgNode('title');info.textContent=`${row.evaluated_at} · ${measured}/100 · ${row.passed}/${row.cases} · ${row.suite_version} · revision ${row.model_revision}`;point.append(info);svg.append(point);
      previous={x,y,suite:row.suite_version,revision:row.model_revision};
    }
    if(rows.length){for(const [x,row,anchor] of [[32,rows[0],'start'],[446,rows[rows.length-1],'end']]){
      const label=svgNode('text',{x,y:153,fill:'#b6c9c3','font-size':10,'text-anchor':anchor});label.textContent=row.evaluated_at.slice(0,10);svg.append(label);
    }}
    return svg;
  }
  function render(data){
    const list=$('capability-models');list.replaceChildren();
    $('capability-refreshed').textContent=data.updated_at?'Report updated: '+data.updated_at:'';
    const rows=Array.isArray(data.history)?data.history.slice(-270):[];
    const models=data.latest_by_model&&typeof data.latest_by_model==='object'?Object.entries(data.latest_by_model).slice(0,12):[];
    $('capability-status').textContent=models.length?'Results from the same internal set of 20 cases. Changes of model, revision or suite do not prove progress caused by training.':'No evaluations have been recorded yet. No capability or progress is assumed.';
    for(const [name,last] of models){
      const card=node('article',undefined,'capability-model');card.append(node('h4',name));
      const value=score(last.score);card.append(node('p',value===null?'Incomplete evaluation · no score':`${value}/100 · ${last.passed}/${last.cases} correct answers`,'capability-score'));
      card.append(node('p',`${last.evaluated_at} · ${last.completed_cases}/${last.cases} cases answered · ${last.error_cases} execution failures`));
      card.append(node('p',`Suite ${last.suite_version} · revision ${String(last.model_revision).slice(0,12)}`,'capability-metadata'));
      const bars=node('div',undefined,'capability-dimensions');
      for(const [key,label] of Object.entries(dimensions)){
        const item=last.dimensions?.[key]||{},measured=score(item.score),row=node('div',undefined,'capability-dimension');
        row.append(node('span',`${label}: ${measured===null?'not measured':`${measured}/100 (${item.passed}/${item.cases})`}`));
        const track=node('div',undefined,'capability-track'),fill=node('div',undefined,'capability-fill');fill.style.width=(measured??0)+'%';track.append(fill);row.append(track);bars.append(row);
      }
      card.append(bars);const history=rows.filter(row=>row.model===name);card.append(chart(history,name));
      const details=node('details');details.append(node('summary','Observed values · UTC'));
      const table=node('table'),head=node('tr');for(const label of ['Date','Score','Answers','Revision','Suite'])head.append(node('th',label));table.append(head);
      for(const row of history.slice().reverse()){
        const tr=node('tr');for(const value of [row.evaluated_at,score(row.score)===null?'Incomplete':String(row.score),`${row.passed}/${row.cases}`,String(row.model_revision).slice(0,12),row.suite_version])tr.append(node('td',value));table.append(tr);
      }
      details.append(table);card.append(details);list.append(card);
    }
  }
  async function refresh({initial=false}={}){
    if(!initial&&(!authorized||busy))return;
    const version=++epoch;busy=true;controls();
    if(initial)clear();
    try{
      const data=await api('/api/admin/capability-evaluations');if(version!==epoch)return;
      if(data.can_view!==true){clear();return;}
      authorized=true;$('capability-panel').hidden=false;$('capability-open').hidden=false;render(data);
    }catch(error){if(version===epoch){if(initial)clear();else{$('capability-models').replaceChildren();$('capability-refreshed').textContent='';$('capability-status').textContent='Evaluation unavailable: '+error.message;}}}
    finally{if(version===epoch){busy=false;controls();}}
  }
  $('capability-refresh').onclick=()=>refresh();
  $('capability-open').onclick=()=>{if(!authorized)return;$('agents-dialog').close();window.BlochWorkspace.pane('collection');$('projects-tab').click();$('capability-panel').open=true;refresh();};
  window.addEventListener('blochai:account',()=>refresh({initial:true}));clear();controls();
  if(window.BlochWorkspace?.identity?.())refresh({initial:true});
})();
