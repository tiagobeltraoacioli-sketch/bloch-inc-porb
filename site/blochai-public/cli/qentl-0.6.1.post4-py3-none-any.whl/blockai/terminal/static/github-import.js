'use strict';
(() => {
  let project=null,busy=false,epoch=0;
  const allowed=()=>Boolean(project&&window.BlochWorkspace.access?.().write);
  const status=value=>{$('github-import-status').textContent=value;};
  const reasons={protected_path:'Private file, dependency or protected path',unsupported_type:'Format not imported',file_too_large:'File over the size limit',binary_or_invalid_utf8:'Binary or non-UTF-8 text',credential_content:'Possible credential in the content',depth_limit:'Depth over the limit',symlink:'Symbolic link',submodule:'Submodule',lfs_pointer:'Git LFS pointer'};
  function controls(){
    $('open-github-import').disabled=!allowed()||busy;
    $('github-import-submit').disabled=!allowed()||busy;
    $('github-import-url').disabled=busy;
    $('github-import-progress').hidden=!busy;
    $('github-import-form').setAttribute('aria-busy',String(busy));
  }
  function sourceUrl(value){
    if(typeof value!=='string'||value.length>2048||!/^https:\/\/github\.com\//.test(value)||/[\\\s%?#]/.test(value))return null;
    try{
      const url=new URL(value),parts=url.pathname.split('/').filter(Boolean);
      if(url.origin!=='https://github.com'||url.username||url.password||parts.length<2||parts.some(part=>part==='.'||part==='..'))return null;
      if(!parts.slice(0,2).every(part=>/^[A-Za-z0-9_.-]+$/.test(part)))return null;
      if(parts.length>2&&(parts[2]!=='tree'||parts.length<4))return null;
      return value;
    }catch{return null;}
  }
  function render(result){
    const repository=result?.repository,imported=result?.import;
    if(!repository||!imported||!Array.isArray(imported.accepted)||!Array.isArray(imported.skipped)||!sourceUrl(repository.url)||!/^[a-f0-9]{40}$/.test(repository.commit||''))throw new Error('The response did not include the expected source and commit. Refresh Graphus and check the files before repeating the import.');
    const url=new URL(repository.url),parts=url.pathname.split('/').filter(Boolean);
    $('github-import-source').href=`https://github.com/${parts[0]}/${parts[1]}/tree/${repository.commit}`;
    $('github-import-source').textContent=repository.url;
    $('github-import-commit').textContent='Commit: '+repository.commit;
    const license=repository.license?.spdx_id||repository.license?.name;
    $('github-import-summary').textContent=`${imported.files_imported} files · ${size(imported.bytes_imported)} · Folder: ${imported.path}${license?' · Reported license: '+license:'. License not identified; check the repository terms.'}`;
    const accepted=imported.accepted.slice(0,500).map(row=>'Included: '+row.path);
    const skipped=imported.skipped.slice(0,500).map(row=>'Excluded: '+row.path+' · '+(reasons[row.reason]||row.reason));
    $('github-import-files').textContent=[...accepted,...skipped,...(imported.skipped.length>500?['The displayed list of exclusions was limited to 500 items.']:[])].join('\n');
    $('github-import-result').hidden=false;
  }
  $('open-github-import').onclick=()=>{
    if(!allowed()||busy)return;
    window.BlochWorkspace.pane('collection');$('files-tab').click();$('github-import-details').open=true;$('github-import-url').focus();
  };
  $('github-import-form').onsubmit=async event=>{
    event.preventDefault();if(!allowed()||busy)return;
    if(window.BlochWorkspace.busy?.()){status('Finish the task or upload in progress before importing a repository.');return;}
    if(window.BlochCode?.hasUnsaved?.()||window.BlochKnowledge?.hasUnsaved?.()){status('Save your drafts or apply the code comparison before importing. Your content has been preserved.');return;}
    const url=sourceUrl($('github-import-url').value.trim());
    if(!url){status('Enter https://github.com/organization/repository or /tree/reference, without credentials, parameters or fragments.');return;}
    const version=epoch,id=project.id;let imported=false;busy=true;controls();window.dispatchEvent(new Event('qentl:github-import'));
    $('github-import-result').hidden=true;status('Fetching the public copy and checking the files. Wait for it to finish; the code will not be executed.');
    try{
      const result=await api(`/api/projects/${id}/github-import`,{url});
      if(version!==epoch)return;
      imported=true;render(result);status('Copy imported. Updating the Graphus files…');
      await window.BlochWorkspace.refreshFiles();if(version!==epoch)return;
      status('Import completed at the commit shown. Open the Graphus points to read the files; no AI task was started.');
    }catch(error){if(version===epoch)status(imported?'The import was received, but the interface update did not finish. Check Graphus before importing again. '+error.message:error.message);}
    finally{busy=false;controls();window.dispatchEvent(new Event('qentl:github-import'));}
  };
  window.BlochWorkspace.onProject(event=>{
    project=event.detail;epoch++;$('github-import-url').value='';$('github-import-result').hidden=true;
    $('github-import-source').removeAttribute('href');$('github-import-source').textContent='';$('github-import-commit').textContent='';$('github-import-files').textContent='';status('');controls();
  });
  window.addEventListener('beforeunload',event=>{if(busy){event.preventDefault();event.returnValue='';}});
  window.BlochGithub={busy:()=>busy,canLeave:()=>{if(busy)status('Wait for the import to finish before switching projects or leaving.');return !busy;}};
  controls();
})();
