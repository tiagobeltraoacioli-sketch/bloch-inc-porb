'use strict';
(() => {
  let project=null,status=null,preview=null,epoch=0,previewEpoch=0,refreshSequence=0,busy=false,dirty=false,sourceInputs=[],progressButtons=[];
  const selected=new Set();
  const owned=()=>Boolean(project&&!project.shared&&status?.can_approve===true);
  const base=()=>`/api/projects/${project.id}/closed-scope`;
  const lines=value=>value.split('\n').map(line=>line.trim()).filter(Boolean);
  function invalidatePreview(){
    preview=null;previewEpoch++;$('closed-scope-confirm').checked=false;$('closed-scope-confirm').disabled=true;
    $('closed-scope-preview').textContent='';$('closed-scope-preview-status').textContent='Load the full version of the selected sources to review before approving.';
  }
  function controls(){
    $('closed-scope-owner').hidden=!owned();
    $('closed-scope-refresh').disabled=!project||busy;
    $('closed-scope-review').disabled=!owned()||busy||selected.size<1||selected.size>8;
    $('closed-scope-approve').disabled=!owned()||busy||!preview;
    $('closed-scope-revoke').disabled=!owned()||busy||!status?.revision||status.state==='revoked';
    for(const id of ['closed-scope-folders','closed-scope-files','closed-scope-requirements'])$(id).disabled=!owned()||busy;
    $('closed-scope-confirm').disabled=!owned()||busy||!preview;
    for(const row of sourceInputs)row.input.disabled=!owned()||busy||(!row.eligible&&!selected.has(row.input.value));
    $('closed-scope-next-panel').hidden=!project||Boolean(project.shared);
    $('closed-scope-continue').disabled=!owned()||busy||status?.state!=='approved'||!status?.progress?.next_requirement_id||Boolean(window.BlochWorkspace?.busy?.());
    for(const button of progressButtons)button.disabled=busy||!owned()||status?.state!=='approved';
  }
  function progress(){
    const state=status?.progress,requirements=status?.contract?.requirements||[];
    const next=requirements.find(row=>row.id===state?.next_requirement_id);
    $('closed-scope-next').textContent=status?.state!=='approved'?'Approve a current version of the .md scope to continue.':state?.complete?'All requirements in this version were accepted by the owner.':next?next.id+' · '+next.text:'Checking the next pending requirement…';
    $('closed-scope-progress').replaceChildren();progressButtons=[];
    for(const requirement of requirements){
      const accepted=state?.accepted_requirement_ids?.includes(requirement.id),row=document.createElement('div'),text=document.createElement('p'),button=document.createElement('button');
      text.textContent=(accepted?'✓ Accepted · ':'Pending · ')+requirement.id+' · '+requirement.text;
      button.type='button';button.className='small-button';button.textContent='Confirm requirement completed';button.hidden=accepted||!owned();button.disabled=busy||status?.state!=='approved';
      progressButtons.push(button);
      const version=epoch,revision=status?.revision,url=project?base():'';
      button.onclick=async()=>{
        if(busy||!owned()||version!==epoch||status?.revision!==revision||status.state!=='approved')return;
        busy=true;refreshSequence++;button.disabled=true;controls();
        try{await api(url+'/requirements/'+encodeURIComponent(requirement.id)+'/accept',{expected_revision:revision,confirm:true});if(version!==epoch)return;await refresh();$('closed-scope-action-status').textContent='Requirement accepted after your confirmation. Continue will use the next pending item.';}
        catch(e){if(version===epoch)$('closed-scope-action-status').textContent=e.message;}
        finally{busy=false;progress();controls();}
      };
      row.append(text,button);$('closed-scope-progress').append(row);
    }
  }
  function requirements(){
    const previous=$('closed-scope-requirement').value;
    for(const id of ['closed-scope-requirement','code-requirement']){
      const select=$(id);select.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent='Select an approved requirement';select.append(empty);
      for(const requirement of status?.contract?.requirements||[]){const option=document.createElement('option');option.value=requirement.id;option.textContent=requirement.id+' · '+requirement.text;select.append(option);}
      select.value=(status?.contract?.requirements||[]).some(row=>row.id===previous)?previous:'';
      select.disabled=status?.state!=='approved'||!project||Boolean(project.shared);
    }
    $('code-requirement').hidden=$('code-requirement-label').hidden=Boolean(project?.shared);
  }
  function render(data,fill=false){
    if(status?.revision!==data.revision){invalidatePreview();fill=fill||!dirty;}
    status=data;
    const descriptions={missing:'No approved roadmap. Chat and analyze sources; approve the scope before starting development.',approved:'Scope approved. Development uses these requirements and paths.',stale:'A source changed or is no longer available. Review the documents and approve a new version before continuing development.',revoked:'Scope revoked. Approve a new version to resume development.'};
    $('closed-scope-status').textContent=descriptions[data.state]||'Scope status unavailable.';
    $('closed-scope-revision').textContent=data.revision?`Version ${data.version} · revision ${data.revision}`:'';
    if(fill&&!dirty){
      selected.clear();for(const path of data.contract?.source_paths||[])selected.add(path);
      $('closed-scope-folders').value=(data.contract?.allowed_paths||[]).filter(row=>row.kind==='folder').map(row=>row.path).join('\n');
      $('closed-scope-files').value=(data.contract?.allowed_paths||[]).filter(row=>row.kind==='file').map(row=>row.path).join('\n');
      $('closed-scope-requirements').value=(data.contract?.requirements||[]).map(row=>row.id+' | '+row.text).join('\n');
    }
    const candidates=[...(data.sources||data.source_candidates||[])];
    for(const path of selected)if(!candidates.some(row=>row.path===path))candidates.push({path,eligible:false});
    $('closed-scope-sources').replaceChildren();sourceInputs=[];
    if(!candidates.length)$('closed-scope-sources').textContent='No eligible .md documents. Create an idea or import the roadmap.';
    for(const source of candidates){
      const label=document.createElement('label'),input=document.createElement('input'),text=document.createElement('span');
      input.type='checkbox';input.checked=selected.has(source.path);input.disabled=source.eligible===false||busy;input.value=source.path;
      sourceInputs.push({input,eligible:source.eligible!==false});
      text.textContent=`${source.path} · ${source.chars??'?'} characters${source.eligible===false?' · not eligible':''}`;
      input.onchange=()=>{if(input.checked)selected.add(source.path);else selected.delete(source.path);dirty=true;invalidatePreview();controls();};
      label.append(input,text);$('closed-scope-sources').append(label);
    }
    // Do not silently accept an old preview after a fresh GET reports changes.
    if(preview&&preview.sources.some(source=>candidates.find(item=>item.path===source.path)?.sha256!==source.sha256))invalidatePreview();
    requirements();progress();controls();
  }
  async function refresh(fill=false){
    if(!project)return;const version=epoch,request=++refreshSequence,url=base();
    try{const data=await api(url);if(version!==epoch||request!==refreshSequence)return;render(data,fill);}
    catch(e){if(version===epoch&&request===refreshSequence){status=null;invalidatePreview();$('closed-scope-status').textContent='Could not check the scope: '+e.message;requirements();progress();controls();}}
  }
  $('closed-scope-review').onclick=async()=>{
    if(!owned()||busy||selected.size<1||selected.size>8)return;busy=true;controls();invalidatePreview();const version=epoch,review=previewEpoch,url=base();
    try{
      const data=await api(url+'/preview',{source_paths:[...selected]});if(version!==epoch||review!==previewEpoch)return;
      preview=data;$('closed-scope-preview').textContent=data.sources.map(source=>'# '+source.path+'\n\n'+source.content).join('\n\n────────────────\n\n');
      $('closed-scope-preview-status').textContent=`${data.sources.length} documents · ${data.total_chars} characters in full. Read this version before confirming.`;
      $('closed-scope-preview-details').open=true;$('closed-scope-confirm').disabled=false;
    }catch(e){if(version===epoch)$('closed-scope-preview-status').textContent=e.message;}
    finally{busy=false;controls();}
  };
  $('closed-scope-form').addEventListener('input',event=>{dirty=true;if(event.target!==$('closed-scope-confirm'))$('closed-scope-confirm').checked=false;});
  $('closed-scope-form').onsubmit=async event=>{
    event.preventDefault();if(!owned()||busy||!preview)return;
    if(!$('closed-scope-confirm').checked){$('closed-scope-action-status').textContent='Review the sources, requirements and paths, then confirm this version.';return;}
    const allowed_paths=[...lines($('closed-scope-folders').value).map(path=>({path,kind:'folder'})),...lines($('closed-scope-files').value).map(path=>({path,kind:'file'}))];
    const listed=lines($('closed-scope-requirements').value),requirements=[];
    for(const line of listed){const at=line.indexOf('|');const id=line.slice(0,at).trim(),text=line.slice(at+1).trim();if(at<1||!id||!text){$('closed-scope-action-status').textContent='Use ID | description on each requirement line.';return;}requirements.push({id,text});}
    if(!allowed_paths.length||allowed_paths.length>64){$('closed-scope-action-status').textContent='Set 1 to 64 allowed files or folders.';return;}
    busy=true;refreshSequence++;controls();$('closed-scope-action-status').textContent='Recording this approval…';const version=epoch,url=base();
    try{
      await api(url+'/approve',{source_paths:[...selected],source_digests:preview.source_digests,allowed_paths,...(requirements.length?{requirements}:{}),expected_revision:status?.revision??null,confirm:true});
      if(version!==epoch)return;dirty=false;invalidatePreview();await refresh(true);$('closed-scope-action-status').textContent='Version approved. Explicitly select the requirement for the next task.';
    }catch(e){if(version===epoch)$('closed-scope-action-status').textContent='Approval not confirmed: '+e.message;}
    finally{busy=false;controls();}
  };
  $('closed-scope-revoke').onclick=async()=>{
    if(!owned()||busy||!status?.revision)return;busy=true;refreshSequence++;controls();const version=epoch,url=base();
    try{await api(url+'/revoke',{expected_revision:status.revision,confirm:true});if(version!==epoch)return;dirty=false;invalidatePreview();await refresh(true);$('closed-scope-action-status').textContent='Version revoked. New development actions need an updated approval.';}
    catch(e){if(version===epoch)$('closed-scope-action-status').textContent=e.message;}
    finally{busy=false;controls();}
  };
  $('closed-scope-refresh').onclick=()=>refresh(!dirty);
  $('closed-scope-continue').onclick=async()=>{
    if(busy||!owned()||status?.state!=='approved'||!status.progress?.next_requirement_id)return;
    const requirement=status.progress.next_requirement_id,revision=status.revision,version=epoch;
    for(const id of ['closed-scope-requirement','code-requirement'])$(id).value=requirement;
    busy=true;controls();$('closed-scope-action-status').textContent='Starting a task for '+requirement+'…';
    try{await window.BlochWorkspace.continueScope(requirement,revision);if(version===epoch)$('closed-scope-action-status').textContent='Task started. Follow the actions and review the result before confirming the requirement.';}
    catch(e){if(version===epoch)$('closed-scope-action-status').textContent=e.message;}
    finally{busy=false;controls();}
  };
  for(const id of ['closed-scope-requirement','code-requirement'])$(id).onchange=()=>{for(const other of ['closed-scope-requirement','code-requirement'])$(other).value=$(id).value;};
  window.BlochWorkspace.onProject(event=>{
    project=event.detail;epoch++;dirty=false;status=null;selected.clear();invalidatePreview();
    $('closed-scope-status').textContent=project?'Checking scope…':'Select a project.';$('closed-scope-revision').textContent='';$('closed-scope-action-status').textContent='';
    $('closed-scope-folders').value=$('closed-scope-files').value=$('closed-scope-requirements').value='';$('closed-scope-sources').replaceChildren();
    for(const id of ['closed-scope-requirement','code-requirement'])$(id).value='';requirements();progress();controls();if(project)refresh(true);
  });
  window.addEventListener('blochai:files',()=>{if(project&&!busy)refresh();});
  window.BlochClosedScope={
    canLeave:()=>!busy&&(!dirty||window.confirm('The scope has unapproved changes. Discard them?')),
    payload:(required=false)=>{
      const id=$('closed-scope-requirement').value;
      if(!required&&(!id||status?.state!=='approved'))return {};
      if(status?.state!=='approved'||!status.revision)throw new Error('Approve a current version of the .md scope before this development task.');
      if(!id||!(status.contract?.requirements||[]).some(row=>row.id===id))throw new Error('Select the approved requirement this task will address.');
      return {requirement_id:id,scope_revision:status.revision};
    },refresh,update:controls
  };
  controls();requirements();
})();
