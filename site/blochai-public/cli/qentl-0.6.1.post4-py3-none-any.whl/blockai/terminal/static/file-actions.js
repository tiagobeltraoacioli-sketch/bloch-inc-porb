'use strict';
(() => {
  let project=null,selected=null,inspected=null,restoreEntry=null,epoch=0,requestVersion=0,busy=false,reading=false,mode='',createDirty=false;
  const textTypes=new Set(['py','js','mjs','cjs','ts','tsx','jsx','rs','go','java','kt','swift','c','h','cpp','hpp','cs','sol','html','css','scss','json','toml','yaml','yml','md','txt','sh','sql','graphql','proto','vue','svelte']);
  const privateName=/(^\.|(^|[._-])(secrets?|credentials?|passwords?|tokens?)([._-]|$)|\.(key|pem|p12|pfx|keychain)$|^id_(rsa|ed25519))/i;
  const access=()=>window.BlochWorkspace.access?.()||{write:false};
  const writable=()=>Boolean(project&&access().write);
  const itemId=item=>item?.node_id||item?.id;
  const supported=item=>Boolean(itemId(item)&&(['code','note','pdf','image','document','upload'].includes(item.kind)||item.upload_id));
  const base=()=>`/api/projects/${project.id}/file-actions`;
  const dialog=()=>$('file-actions-dialog');
  function status(value){$('file-action-status').textContent=value;}
  function hasDrafts(){return Boolean(window.BlochCode?.hasUnsaved?.()||window.BlochKnowledge?.hasUnsaved?.());}
  function ready(){
    if(!writable()||busy||reading)return false;
    if(window.BlochWorkspace.busy?.()){status('Finish or cancel the task and uploads before organizing files.');return false;}
    if(hasDrafts()){status('Save your idea or apply the code comparison before organizing files. Your drafts were preserved.');return false;}
    return true;
  }
  function controls(){
    $('graph-new-file').disabled=!writable()||busy;
    $('graph-file-actions').disabled=!project||!supported(selected)||busy;
    $('graph-trash').disabled=!project||busy;
    $('file-action-move-submit').disabled=busy||reading||!writable()||inspected?.capabilities?.move!==true;
    $('file-action-trash-submit').disabled=busy||reading||!writable()||inspected?.capabilities?.trash!==true;
    $('file-create-submit').disabled=$('file-create-pick').disabled=busy||reading||!writable();
    $('file-restore-submit').disabled=busy||!writable()||!restoreEntry;
    $('file-actions-close').disabled=busy||reading;
  }
  function select(item){
    selected=supported(item)?{...item}:null;
    $('file-selection-summary').textContent=selected?'Selected: '+(selected.path||selected.title||selected.name):'Click a file in Graphus to organize it.';
    $('graph-file-actions').title=selected?'Move or remove '+(selected.title||selected.path):'Select a file';controls();
  }
  function show(next,title){
    mode=next;inspected=null;restoreEntry=null;requestVersion++;
    for(const name of ['manage','create','trash','restore'])$('file-action-'+name).hidden=name!==next;
    $('file-actions-title').textContent=title;status('');
    $('file-trash-confirm').checked=false;$('file-trash-linked-confirm').checked=false;$('file-restore-confirm').checked=false;
    if(!dialog().open)dialog().showModal();controls();
  }
  function canLeave(){return !createDirty||window.confirm('There is content for a new file that has not been created yet. Discard it?');}
  function clearDraft(){createDirty=false;$('file-create-content').value='';$('file-create-path').value='';}
  function close(){if(busy||reading||!canLeave())return false;clearDraft();dialog().close();return true;}
  async function manage(item=selected){
    if(!project||!supported(item)||busy||reading)return;
    if(createDirty&&!canLeave())return;
    clearDraft();select(item);show('manage','Organize file');
    $('file-action-name').textContent=item.path||item.title||item.name||itemId(item);
    $('file-action-detail').textContent='Loading the current version…';
    const version=epoch,serial=requestVersion,url=base(),id=itemId(item);
    try{
      const data=await api(url+'/item?node_id='+encodeURIComponent(id));
      if(version!==epoch||serial!==requestVersion)return;
      inspected=data;const current=data.item;
      $('file-action-name').textContent=current.path||current.title;
      $('file-action-detail').textContent=current.kind==='note'?'Move the Markdown file within knowledge/. The idea title and its [[title]] links stay the same.':current.kind==='code'?'Move or rename the file in the project. Imports, paths used by other files and the approved scope may need review.':'Move or rename the original within this attachment\'s folder. The source identifier and its type stay the same.';
      $('file-move-destination').value=current.destination_hint||current.path||'';
      $('file-move-destination').placeholder=current.destination_hint||'folder/file.ext';
      const notes=data.linked_notes||[];
      $('file-linked-notes').textContent=notes.map(note=>'• '+note.title).join('\n');
      $('file-linked-notes-area').hidden=notes.length===0;
      $('file-trash-target').textContent='Send '+current.title+' to the project trash.';
      status(access().write?'The file changes only after you confirm. No existing file will be replaced.':'Project shared as read-only. These actions are available only to editors.');controls();
    }catch(error){if(version===epoch&&serial===requestVersion){status(error.message);$('file-action-detail').textContent='Could not check the current version. No action was taken.';}}
  }
  async function refresh(action,previous,item,linkedNotes=[]){
    window.dispatchEvent(new CustomEvent('qentl:file-action',{detail:{project:project.id,action,previous_node_id:previous,item,linked_notes:linkedNotes}}));
    if(item)select(item);else select(null);
    await window.BlochWorkspace.refreshFiles();
  }
  async function openItem(item){
    if(hasDrafts())return;
    if(item.kind==='code')await window.BlochCode?.open(item.node_id);
    else if(item.kind==='note')await window.BlochKnowledge?.open(item.node_id);
  }
  $('file-move-form').onsubmit=async event=>{
    event.preventDefault();if(!ready()||!inspected||inspected.capabilities.move!==true)return;
    const target=$('file-move-destination').value.trim();if(!target){status('Enter the destination path.');return;}
    busy=true;controls();const version=epoch,url=base(),item=inspected.item;status('Moving the file…');
    try{
      const result=await api(url+'/move',{node_id:item.node_id,destination:target,expected_revision:item.revision});
      if(version!==epoch)return;
      await refresh('move',item.node_id,result.item);if(version!==epoch)return;
      createDirty=false;dialog().close();await openItem(result.item);
    }catch(error){if(version===epoch)status(error.message);}
    finally{busy=false;controls();}
  };
  $('file-trash-form').onsubmit=async event=>{
    event.preventDefault();if(!ready()||!inspected||inspected.capabilities.trash!==true)return;
    if(!$('file-trash-confirm').checked){status('Confirm the file to be sent to the trash.');return;}
    const notes=inspected.linked_notes||[];
    if(notes.length&&!$('file-trash-linked-confirm').checked){status('This attachment has derived notes. Review the list and confirm removing those notes along with the source.');return;}
    busy=true;controls();const version=epoch,url=base(),item=inspected.item;status('Sending to the trash…');
    try{
      await api(url+'/trash',{node_id:item.node_id,expected_revision:item.revision,confirm:true,include_linked_notes:notes.length>0&&$('file-trash-linked-confirm').checked});
      if(version!==epoch)return;
      await refresh('trash',item.node_id,null,notes);if(version!==epoch)return;
      show('trash','Project trash');await loadTrash();
    }catch(error){if(version===epoch)status(error.message);}
    finally{busy=false;controls();}
  };
  async function loadTrash(){
    const version=epoch,serial=requestVersion,url=base();$('file-trash-list').replaceChildren();status('Loading the trash…');
    try{
      const data=await api(url+'/trash');if(version!==epoch||serial!==requestVersion)return;
      if(!data.entries.length)$('file-trash-list').textContent='This project\'s trash is empty.';
      for(const entry of data.entries){
        const row=document.createElement('div'),text=document.createElement('p'),button=document.createElement('button');
        row.className='file-trash-row';text.textContent=`${entry.title} · ${entry.path} · ${size(entry.bytes)} · ${formatDate(entry.created_at)}${entry.linked_notes?.length?' · '+entry.linked_notes.length+' linked notes':''}`;
        button.type='button';button.className='small-button';button.textContent='Restore…';button.disabled=!writable();
        button.onclick=()=>{if(version!==epoch||busy||!writable())return;show('restore','Restore file');restoreEntry=entry;$('file-restore-target').textContent=`${entry.title}\nOriginal location: ${entry.path}`;$('file-restore-notes').textContent=(entry.linked_notes||[]).map(note=>'• '+(note.title||note)).join('\n');controls();};
        row.append(text,button);$('file-trash-list').append(row);
      }
      status(`The trash keeps up to ${data.limits.entries} items and ${size(data.limits.bytes)} per project. Restoring does not replace existing files.`);
    }catch(error){if(version===epoch&&serial===requestVersion)status(error.message);}
  }
  $('file-restore-form').onsubmit=async event=>{
    event.preventDefault();if(!ready()||!restoreEntry)return;
    if(!$('file-restore-confirm').checked){status('Confirm restoring to the original path.');return;}
    const version=epoch,url=base(),entry=restoreEntry;busy=true;controls();status('Restoring…');
    try{
      const result=await api(url+'/trash/'+encodeURIComponent(entry.id)+'/restore',{confirm:true});
      if(version!==epoch)return;
      await refresh('restore',null,result.item,entry.linked_notes||[]);if(version!==epoch)return;
      dialog().close();await openItem(result.item);
    }catch(error){if(version===epoch)status(error.message);}
    finally{busy=false;controls();}
  };
  function create(){
    if(!writable()||busy||reading)return;
    show('create','New file in Graphus');$('file-create-path').focus();
  }
  $('file-create-form').oninput=()=>{createDirty=Boolean($('file-create-path').value||$('file-create-content').value);};
  $('file-create-pick').onclick=()=>{if(!busy&&!reading)$('file-create-input').click();};
  $('file-create-input').onchange=async()=>{
    const source=$('file-create-input').files?.[0];$('file-create-input').value='';if(!source||busy||reading)return;
    if(privateName.test(source.name)){status('Private files and credentials cannot be imported here. Nothing was read or uploaded.');return;}
    const extension=source.name.split('.').pop().toLowerCase();
    if((!textTypes.has(extension)&&!['Dockerfile','Makefile'].includes(source.name))||source.size>200000){status('Choose a UTF-8 code or Markdown file up to 200 KB. For PDFs, use Add PDF / source.');return;}
    if(createDirty&&!window.confirm('Replace the not-yet-created content with the selected file?'))return;
    const version=epoch;reading=true;controls();
    try{
      const raw=await source.arrayBuffer();if(version!==epoch)return;
      if(raw.byteLength>200000)throw new Error('The file exceeds 200 KB.');
      const text=new TextDecoder('utf-8',{fatal:true}).decode(raw);
      if(/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(text))throw new Error('This file contains binary data.');
      $('file-create-path').value=source.name;$('file-create-content').value=text;createDirty=true;
      status('Local preview loaded. Review the path and content; nothing has been uploaded yet.');
    }catch{if(version===epoch)status('Could not read the file as UTF-8 text up to 200 KB. Nothing was uploaded.');}
    finally{reading=false;controls();}
  };
  $('file-create-form').onsubmit=async event=>{
    event.preventDefault();if(!ready())return;
    const path=$('file-create-path').value.trim(),content=$('file-create-content').value;
    if(!path){status('Enter the file name and its extension.');return;}
    if(new TextEncoder().encode(content).length>200000){status('The content exceeds 200 KB in UTF-8.');return;}
    const version=epoch,url=base();busy=true;controls();status('Creating the file…');
    try{
      const result=await api(url+'/create',{path,content});if(version!==epoch)return;
      createDirty=false;$('file-create-content').value='';$('file-create-path').value='';
      await refresh('create',null,result.item);if(version!==epoch)return;
      dialog().close();await openItem(result.item);
    }catch(error){if(version===epoch)status(error.message);}
    finally{busy=false;controls();}
  };
  $('graph-new-file').onclick=create;
  $('graph-file-actions').onclick=()=>manage();
  $('graph-trash').onclick=()=>{if(!project||busy||reading||!canLeave())return;clearDraft();show('trash','Project trash');loadTrash();};
  $('file-trash-refresh').onclick=()=>{if(!busy&&project)loadTrash();};
  $('file-restore-back').onclick=()=>{if(!busy){show('trash','Project trash');loadTrash();}};
  $('file-actions-close').onclick=close;
  dialog().addEventListener('cancel',event=>{event.preventDefault();close();});
  window.BlochWorkspace.onProject(event=>{
    project=event.detail;epoch++;requestVersion++;selected=inspected=restoreEntry=null;createDirty=false;
    $('file-create-path').value='';$('file-create-content').value='';dialog().close();select(null);
  });
  window.addEventListener('beforeunload',event=>{if(createDirty){event.preventDefault();event.returnValue='';}});
  window.BlochFiles={select,manage,create,canLeave};controls();
})();
