'use strict';
(() => {
  let project=null,nodes=[],selected=new Set(),loading=0,saved='',dirty=false;
  const eligible=node=>!['task','model'].includes(node.kind);
  function render(){
    const scoped=$('scope-mode').value==='selection';
    $('scope-selection').hidden=!scoped;$('scope-selection').replaceChildren();
    for(const id of selected){const node=nodes.find(n=>n.id===id);if(!node)continue;const button=document.createElement('button');button.type='button';button.className='scope-chip';button.textContent=node.title+' ×';button.setAttribute('aria-label','Remove '+node.title+' from scope');button.onclick=()=>toggle(node);$('scope-selection').append(button);}
    $('scope-hint').textContent=scoped?`${selected.size} points · Shift/Ctrl/⌘ + click on the map to select. Functions limit editing to their own lines; folders include new files.`:'The model may work on the files in this project. Context is limited to the capacity of the model.';
    $('scope-clear').hidden=!scoped||!selected.size;
    $('graph-select').setAttribute('aria-pressed',String(scoped));
    $('graph-select').textContent=scoped?'✓ Select points':'◎ Task scope';
    window.BlochKnowledge?.draw();
  }
  function toggle(node){
    if(!eligible(node)||project?.shared)return;
    if(selected.has(node.id))selected.delete(node.id);
    else{if(selected.size>=30){error(new Error('Select up to 30 points per task.'));return;}selected.add(node.id);}
    $('scope-mode').value='selection';render();
  }
  function reset(){selected.clear();$('scope-mode').value='project';render();}
  $('scope-mode').onchange=render;$('scope-clear').onclick=()=>{selected.clear();render();};
  $('graph-select').onclick=()=>{$('scope-mode').value=$('scope-mode').value==='project'?'selection':'project';window.BlochWorkspace.pane('work');render();};
  $('global-prompt').oninput=()=>{dirty=$('global-prompt').value!==saved;$('global-prompt-status').textContent=dirty?'Changes not saved yet.':'Instructions saved for upcoming tasks.';};
  $('save-global-prompt').onclick=async()=>{
    if(!project||project.shared)return;const id=project.id,value=$('global-prompt').value;$('save-global-prompt').disabled=true;
    try{const data=await api(`/api/projects/${id}/instructions`,{global_prompt:value});if(project?.id!==id)return;saved=data.global_prompt;dirty=$('global-prompt').value.trim()!==saved;$('global-prompt-status').textContent=dirty?'There are later changes not saved yet.':'Global prompt saved for this project.';}
    catch(e){$('global-prompt-status').textContent=e.message;}finally{$('save-global-prompt').disabled=!project;}
  };
  window.addEventListener('blochai:graph',event=>{nodes=event.detail.nodes;selected=new Set([...selected].filter(id=>nodes.some(n=>n.id===id&&eligible(n))));render();});
  window.BlochWorkspace.onProject(async event=>{
    project=event.detail;const version=++loading;nodes=[];dirty=false;saved='';reset();$('global-prompt').value='';$('global-prompt-status').textContent='';$('save-global-prompt').disabled=!project;
    if(!project||project.shared)return;
    try{const data=await api(`/api/projects/${project.id}/instructions`);if(version!==loading)return;saved=data.global_prompt;$('global-prompt').value=saved;}
    catch(e){if(version===loading)$('global-prompt-status').textContent=e.message;}
  });
  window.BlochScope={toggle,reset,selected:id=>$('scope-mode').value==='selection'&&selected.has(id),selecting:()=>$('scope-mode').value==='selection',
    canLeave:()=>!dirty||window.confirm('The global prompt has unsaved changes. Discard them?'),
    payload:()=>{if(dirty)throw new Error('Save the global prompt before starting the task.');return {scope_mode:$('scope-mode').value,scope_nodes:$('scope-mode').value==='selection'?[...selected]:[]};}};
  render();
})();
