'use strict';
(() => {
  let project=null,epoch=0,busy=false;
  const owned=()=>Boolean(project&&!project.shared);
  const base=()=>`/api/projects/${project.id}/collaborators`;
  function resetCode(){
    $('project-invite-result').hidden=true;$('project-invite-code').value='';$('project-invite-expiry').textContent='';
  }
  function controls(){
    $('collaboration-owner').hidden=!owned();
    $('create-project-invite-button').disabled=busy||!owned();
    $('accept-project-invite-button').disabled=busy;
    $('refresh-collaborators').disabled=busy||!owned();
  }
  async function refresh(){
    if(!owned())return;const version=epoch,url=base();
    try{
      const data=await api(url);if(version!==epoch)return;
      $('collaborator-list').replaceChildren();
      const rows=[...(data.members||[]).map(row=>({...row,pending:false})),...(data.invitations||[]).map(row=>({...row,pending:true}))];
      if(!rows.length)$('collaborator-list').textContent='No collaborators or pending invitations.';
      for(const row of rows){
        const item=document.createElement('div'),label=document.createElement('p'),button=document.createElement('button');
        item.className='connection-row';label.textContent=`${row.email} · ${row.role==='editor'?'Can edit':'Read only'} · ${row.pending?'Invitation valid until '+formatDate(row.expires_at):'Active access'}`;
        button.type='button';button.className='text-button';button.textContent=row.pending?'Cancel invitation':'Revoke access';
        button.onclick=async()=>{
          if(busy||version!==epoch)return;busy=true;button.disabled=true;controls();
          try{await api(url+'/'+encodeURIComponent(row.id)+'/revoke',{});if(version===epoch){$('collaboration-status').textContent='Permission revoked. New access attempts will be refused; copies already obtained cannot be recalled.';await refresh();}}
          catch(e){if(version===epoch)$('collaboration-status').textContent=e.message;}
          finally{busy=false;button.disabled=false;controls();}
        };
        item.append(label,button);$('collaborator-list').append(item);
      }
    }catch(e){if(version===epoch)$('collaboration-status').textContent='Could not load permissions: '+e.message;}
  }
  $('create-project-invite').onsubmit=async event=>{
    event.preventDefault();if(busy||!owned())return;busy=true;controls();resetCode();const version=epoch,url=base();
    try{
      const data=await api(url,{email:$('collaborator-email').value.trim(),role:$('collaborator-role').value});
      if(version!==epoch)return;
      const invitation=data.invitation;
      $('project-invite-code').value=invitation.token;$('project-invite-result').hidden=false;
      $('project-invite-expiry').textContent=`For ${invitation.email} · valid until ${formatDate(invitation.expires_at)} · single use.`;
      $('collaboration-status').textContent='Code created. Share it directly with the person; no email was sent. They must sign in to the same Qentl installation.';
      await refresh();
    }catch(e){if(version===epoch)$('collaboration-status').textContent=e.message;}
    finally{busy=false;controls();}
  };
  $('accept-project-invite').onsubmit=async event=>{
    event.preventDefault();if(busy)return;busy=true;controls();
    try{
      const data=await api('/api/project-invitations/accept',{token:$('project-invite-token').value.trim()});
      $('project-invite-token').value='';await window.BlochWorkspace.reloadProjects();await window.BlochWorkspace.selectProject(data.project.id);
      $('collaboration-status').textContent='Invitation accepted on this installation. The shared project appears in the list.';
    }catch(e){$('collaboration-status').textContent=e.message;}
    finally{busy=false;controls();}
  };
  $('copy-project-invite').onclick=async()=>{
    const code=$('project-invite-code');if(!code.value)return;
    try{await navigator.clipboard.writeText(code.value);$('collaboration-status').textContent='Code copied. Send it only to the person named in the invitation.';}
    catch{code.focus();code.select();$('collaboration-status').textContent='Code selected. Press ⌘C or Ctrl+C to copy.';}
  };
  $('refresh-collaborators').onclick=refresh;
  $('open-collaborators').onclick=()=>{window.BlochWorkspace.pane('collection');$('projects-tab').click();$('collaboration-panel').open=true;refresh();};
  $('collaboration-panel').ontoggle=()=>{if($('collaboration-panel').open)refresh();};
  window.BlochWorkspace.onProject(event=>{
    project=event.detail;epoch++;resetCode();$('collaborator-list').replaceChildren();$('collaboration-status').textContent='';
    $('collaboration-project-title').textContent=project?'Permissions for '+project.name:'Select your project';controls();
    if(owned()&&$('collaboration-panel').open)refresh();
  });
  controls();
})();
