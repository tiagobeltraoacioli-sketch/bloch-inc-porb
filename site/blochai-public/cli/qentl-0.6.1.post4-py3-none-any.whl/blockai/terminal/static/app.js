'use strict';
const $ = id => document.getElementById(id);
const activeStatuses = new Set(['RUNNING', 'AWAITING_APPROVAL']);
const statuses = {RUNNING:'In progress', AWAITING_APPROVAL:'Awaiting your approval', COMPLETED:'Completed', PAUSED:'Paused for review', FAILED:'Not completed', CANCELLED:'Canceled', INTERRUPTED:'Interrupted'};
const modes = {auto:'Automatic', chat:'Chat', coder:'Coding', analyst:'Analysis', publisher:'Creation'};
const hints = {auto:'Describe the result you want. Qentl chooses chat, analysis, file creation or coding; code changes still require an approved scope.',chat:'Chat and explore ideas with QENTL.', coder:'Review changes before applying them. Command execution is waiting on per-account isolation.', analyst:'Sources, data and critical review. Check the evidence and limitations.', publisher:'Generate a PDF, PPTX or Excel file to download. Review and approve the preview; this task does not change the project code.'};
const kinds = {general:'General', code:'Coding', research:'Research', documents:'Documents'};
const tabs = ['tasks','files','projects'];
const accepted = new Set(['png','jpg','jpeg','webp','gif','pdf','docx','pptx','xlsx','txt','md','csv','json']);
let selectedJob=null, pending=null, poll=null, rows=[], activeJob=null;
let projects=[], uploads=[], currentProject='', projectVersion=0, previewVersion=0, activeTab='tasks';
let selectedUploads=new Set(), uploading=false, uploadRequest=null, uploadCancelled=false;
let previewingUpload=null, knowledgeNoteIds=[], completedNotification=null;
let graphJobVersion='';
let folderPlan=null, folderImporting=false;
const standardIngest={profile:'standard',max_source_files:500,source_file_bytes:200000,batch_files:500,batch_decoded_bytes:20*1024*1024,batch_request_bytes:30*1024*1024,resumable_folder_batches:false,graph_source_files:500};
let ingestPolicy={...standardIngest};
function checkedIngest(data){
  if(!data||!['standard','internal'].includes(data.profile))throw new Error('Invalid import policy.');
  const result={...standardIngest,profile:data.profile};
  for(const [key,max] of Object.entries({max_source_files:data.profile==='internal'?10000:500,source_file_bytes:200000,batch_files:500,batch_decoded_bytes:20*1024*1024,batch_request_bytes:30*1024*1024,graph_source_files:500})){
    if(!Number.isInteger(data[key])||data[key]<1||data[key]>max)throw new Error('Invalid import limits.');result[key]=data[key];
  }
  result.resumable_folder_batches=data.profile==='internal'&&data.resumable_folder_batches===true;
  if(data.profile==='internal'&&!result.resumable_folder_batches)throw new Error('Internal import requires resumable batches.');
  return result;
}
async function loadIngestPolicy(identity){
  ingestPolicy={...standardIngest};
  try{const data=checkedIngest(await api('/api/ingest-policy'));if(accountIdentity===identity)ingestPolicy=data;}
  catch{ /* Older/offline deployments retain conservative transfer limits. */ }
}
let projectPoll=null,projectPolling=false,projectRevision=null,projectFileStamps=new Map(),cliRunStamp='';
let accountIdentity=null,publishedProject=null;
let workspaceDeployment={mode:'unknown',local_cli:false};
let selectedArtifactFormat='';
const folderExtensions=new Set(['py','js','mjs','cjs','ts','tsx','jsx','rs','go','java','kt','swift','c','h','cpp','hpp','cs','sol','html','css','scss','json','toml','yaml','yml','md','txt','sh','sql','graphql','proto','vue','svelte']);
const folderExcluded=new Set(['.git','.ssh','.aws','.gnupg','.codex','.agents','.config','.deployment','.venv','venv','env','node_modules','__pycache__','target','.blochai','dist','build','vendor','.next','.nuxt','coverage','.cache','.tox']);
const folderPrivate=/(^\.env($|\.)|(^|[._-])(secrets?|credentials?|passwords?|tokens?)([._-]|$)|\.(key|pem|p12|pfx|keychain)$|^id_(rsa|ed25519))/i;
const folderSkipReasons={protected_path:'Credential, private directory or dependency',unsupported_type:'Format not accepted in this import',file_too_large:'Over 200 KB per file',binary_or_invalid_utf8:'Binary content or text not encoded as UTF-8',credential_content:'Possible credential detected in the content',depth_limit:'Folders beyond the allowed depth'};

async function api(path,body) {
  const response=await fetch(path,{credentials:'same-origin',cache:'no-store',headers:body===undefined?{}:{'Content-Type':'application/json','X-BlochAI-Action':'1'},method:body===undefined?'GET':'POST',body:body===undefined?undefined:JSON.stringify(body)});
  const data=await response.json();
  if(!response.ok) throw new Error(data.error || (typeof data.detail==='string'?data.detail:null) || `HTTP ${response.status}`);
  return data;
}
function error(e){$('error').textContent=e.message||String(e);$('login-error').textContent=$('error').textContent;}
function state(text,busy=false){$('state').textContent=text;$('task-dot').classList.toggle('ready',busy);}
function formatDate(value){return new Date(value*1000).toLocaleString('en-US',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});}
function size(bytes){return bytes<1048576?`${Math.max(1,Math.round(bytes/1024))} KB`:`${(bytes/1048576).toFixed(1)} MB`;}
function renderFormat(){
  $('artifact-format-selection').textContent=selectedArtifactFormat?'Selected format: '+{pdf:'PDF',pptx:'PPTX',xlsx:'Excel (.xlsx)'}[selectedArtifactFormat]+'. Describe the file contents below.':'';
  for(const button of document.querySelectorAll('[data-format]'))button.setAttribute('aria-pressed',String(button.dataset.format===selectedArtifactFormat));
}
function modeChanged(){selectedArtifactFormat='';renderFormat();$('mode-hint').textContent=hints[$('mode').value];}
function setPane(name){
  if(name==='globe'){window.BlochKnowledge?.draw();return;}
  sidebar(true);
  const panes={work:'task-workspace',collection:'activity',editor:'editor-workspace',privacy:'privacy-workspace',training:'training-workspace'};
  for(const [tab,panel] of Object.entries(panes)){$(panel).hidden=tab!==name;$(tab+'-tab').setAttribute('aria-selected',String(tab===name));$(tab+'-tab').tabIndex=tab===name?0:-1;}
  if(name==='privacy')window.BlochPrivacy?.refresh();
  if(name==='training')window.BlochStudy?.refresh();
  document.body.classList.toggle('editor-open',name==='editor');
  window.dispatchEvent(new Event('blochai:layout'));
}
function sidebar(open){document.body.classList.toggle('side-collapsed',!open);$('expand-sidebar').hidden=open;$('expand-sidebar').setAttribute('aria-expanded',String(open));window.BlochKnowledge?.draw();}
function inspect(kind){setPane('editor');$('editor-empty').hidden=true;$('code-create').hidden=true;$('note-editor').hidden=kind!=='note';$('code-editor').hidden=kind!=='code';}
function uploadUrl(file,action=''){return `/api/projects/${currentProject}/uploads/${file.id}${action?'/'+action:''}`;}
function projectAccess(){
  const project=projects.find(item=>item.id===currentProject);
  return project?.shared?project.capabilities||{read:true,write:false,manage:false,ai:false,cli:false,export:false}:{read:true,write:true,manage:true,ai:true,cli:true,export:true};
}
function setBusy(){
  const access=projectAccess();
  const importing=Boolean(window.BlochGithub?.busy());
  $('submit').disabled=Boolean(activeJob)||uploading||importing||!currentProject||!access.ai;
  $('cancel').hidden=!activeJob||activeJob!==selectedJob;
  $('view-active').hidden=!activeJob||activeJob===selectedJob;
  $('attach-button').disabled=uploading||!currentProject||!access.write;
  $('folder-upload-button').disabled=uploading||!currentProject||!access.write;
  $('shared-upload').disabled=$('shared-folder').disabled=$('shared-code').disabled=uploading||!access.write;
  $('project').disabled=uploading||importing;$('open-projects').disabled=uploading||importing;
  $('create-project-toggle').disabled=uploading||importing;$('new-task').disabled=uploading||importing;
  window.BlochClosedScope?.update();
}
function showTab(name){
  activeTab=name;
  for(const tab of tabs){const selected=tab===name;$(tab+'-tab').setAttribute('aria-selected',String(selected));$(tab+'-tab').tabIndex=selected?0:-1;$(tab+'-panel').hidden=!selected;}
  $('search').placeholder={tasks:'Search tasks…',files:'Search files…',projects:'Search projects…'}[name];
  const label={tasks:'New task',files:'Upload files',projects:'Create project'}[name];
  $('new-task').title=label;$('new-task').setAttribute('aria-label',label);
}
function toggleAttachment(file){
  if(selectedUploads.has(file.id))selectedUploads.delete(file.id);
  else if(selectedUploads.size<6)selectedUploads.add(file.id);
  else{error(new Error('Select up to 6 attachments per task.'));return;}
  renderAttachments();renderSidebar();
}
function renderAttachments(){
  $('selected-files').replaceChildren();
  const selected=uploads.filter(file=>selectedUploads.has(file.id));
  for(const file of selected){
    const chip=document.createElement('div');chip.className='attachment-chip';
    const view=document.createElement('button');view.type='button';view.className='chip-view';view.title=`View ${file.name}`;
    if(file.kind==='image'){const img=document.createElement('img');img.src=uploadUrl(file,'preview');img.alt='';view.append(img);}
    else{const mark=document.createElement('span');mark.className='chip-extension';mark.textContent=file.name.split('.').pop().toUpperCase();view.append(mark);}
    const name=document.createElement('span');name.textContent=file.name;view.append(name);view.onclick=()=>previewFile(file);
    const remove=document.createElement('button');remove.type='button';remove.className='chip-remove';remove.textContent='×';remove.setAttribute('aria-label',`Remove ${file.name} from this task`);remove.onclick=()=>toggleAttachment(file);
    chip.append(view,remove);$('selected-files').append(chip);
  }
  $('attachment-hint').hidden=selected.length===0;
  $('attachment-hint').textContent=selected.some(file=>file.kind==='image')?
    `${selected.length}/6 attachments · Images are available for reference. Visual analysis is not enabled yet.`:
    `${selected.length}/6 attachments · Agents will receive excerpts of the text. Removing an attachment here keeps the file in the project.`;
}
function renderSidebar(){
  const query=$('search').value.toLocaleLowerCase('pt-BR');
  const projectRows=rows.filter(row=>row.project===currentProject);
  $('task-count').textContent=String(projectRows.length).padStart(2,'0');
  for(const id of ['task-list','file-list','project-list'])$(id).replaceChildren();
  let taskCount=0,fileCount=0,projectCount=0;
  for(const row of projectRows){
    if(row.title.toLocaleLowerCase('pt-BR').includes(query)){
      const button=document.createElement('button');button.className='task-item';button.type='button';button.disabled=uploading;
      button.setAttribute('aria-current',String(row.id===selectedJob));
      const title=document.createElement('strong');title.textContent=row.title;
      const meta=document.createElement('small');meta.textContent=`${statuses[row.status]||row.status} · ${formatDate(row.created_at)}\n${modes[row.mode]||row.mode}`;
      if(activeStatuses.has(row.status))meta.className='running';
      button.append(title,meta);button.onclick=()=>selectJob(row.id);$('task-list').append(button);taskCount++;
    }
    for(const file of row.artifacts||[]){
      if(!file.path.toLocaleLowerCase('pt-BR').includes(query))continue;
      const link=document.createElement('a');link.className='file-item';link.href=`/api/jobs/${row.id}/artifacts/${file.id}`;link.download='';
      const extension=document.createElement('span');extension.className='file-extension';extension.textContent=file.path.split('.').pop().toUpperCase();
      const info=document.createElement('div'),title=document.createElement('strong'),meta=document.createElement('small'),arrow=document.createElement('span');
      title.textContent=file.path.split('/').pop();meta.textContent=`Generated · ${formatDate(row.created_at)}`;arrow.textContent='↓';
      info.append(title,meta);link.append(extension,info,arrow);$('file-list').append(link);fileCount++;
    }
  }
  for(const file of uploads){
    if(!file.name.toLocaleLowerCase('pt-BR').includes(query))continue;
    const row=document.createElement('div');row.className='uploaded-file';
    const view=document.createElement('button');view.type='button';view.className='uploaded-view';view.onclick=()=>previewFile(file);
    if(file.kind==='image'){const img=document.createElement('img');img.src=uploadUrl(file,'preview');img.alt='';img.loading='lazy';view.append(img);}
    else{const extension=document.createElement('span');extension.className='file-extension';extension.textContent=file.name.split('.').pop().toUpperCase();view.append(extension);}
    const info=document.createElement('span'),title=document.createElement('strong'),meta=document.createElement('small');
    title.textContent=file.name;meta.textContent=`Uploaded · ${size(file.size)}${file.truncated?' · partially read':''}`;info.append(title,meta);view.append(info);
    const use=document.createElement('button');use.className='use-file';use.type='button';use.textContent=selectedUploads.has(file.id)?'✓ Attached':'+ Use';use.setAttribute('aria-pressed',String(selectedUploads.has(file.id)));use.setAttribute('aria-label',`${selectedUploads.has(file.id)?'Remove':'Use'} ${file.name} ${selectedUploads.has(file.id)?'from':'in'} the task`);use.onclick=()=>toggleAttachment(file);
    use.hidden=!projectAccess().ai;row.append(view,use);$('file-list').append(row);fileCount++;
  }
  for(const project of projects){
    if(!`${project.name} ${project.description}`.toLocaleLowerCase('pt-BR').includes(query))continue;
    const button=document.createElement('button');button.type='button';button.className='task-item project-item';button.disabled=uploading;button.setAttribute('aria-current',String(project.id===currentProject));
    const title=document.createElement('strong'),description=document.createElement('p'),meta=document.createElement('small');title.textContent=project.name;description.textContent=project.description;description.hidden=!project.description;
    meta.textContent=project.shared?`Shared · ${project.role==='editor'?'Can edit':'Read-only'}`:`${kinds[project.kind]||'General'} · ${project.upload_count} files · ${rows.filter(row=>row.project===project.id).length} tasks`;
    button.append(title,description,meta);button.onclick=()=>selectProject(project.id).catch(error);$('project-list').append(button);projectCount++;
  }
  $('tasks-empty').hidden=taskCount>0;$('files-empty').hidden=fileCount>0;$('projects-empty').hidden=projectCount>0;
  $('tasks-empty').textContent=!projectAccess().ai?'Private task history is not shared. Open Files to explore this project.':query?'No tasks found.':currentProject?'Tasks for this project will appear here.':'Create or select a project to get started.';
  $('files-empty').textContent=query?'No files found.':currentProject?'Upload images and documents or generate a new file.':'Choose a project to organize your files.';
  $('projects-empty').textContent=query?'No projects found.':'Give your next idea a home. Create your first project.';
}
async function loadProjects(){
  const [data,shared]=await Promise.all([api('/api/projects'),api('/api/shared-projects')]);projects=[...data.projects,...(shared.projects||[])];
  $('project').replaceChildren();const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='Select a project';$('project').append(placeholder);
  for(const project of projects){const option=document.createElement('option');option.value=project.id;option.textContent=project.name+(project.shared?' · shared':'');$('project').append(option);}
  $('project').value=currentProject;renderSidebar();
}
function clearTask(){
  selectedJob=null;pending=null;$('approval').hidden=true;$('downloads').replaceChildren();
  $('answer').textContent='The next step starts with your idea. Your answers will appear here.';$('answer').classList.add('empty');
  $('event-details').hidden=true;$('result-meta').textContent='QENTL / OUTPUT';state(activeJob?'A task is in progress.':'Ready for a new idea',Boolean(activeJob));setBusy();
  $('answer-to-note').hidden=true;$('knowledge-evidence').replaceChildren();
}
async function loadUploads(){
  const project=currentProject,version=projectVersion;
  const data=project?await api(`/api/projects/${project}/uploads`):{uploads:[]};
  if(version!==projectVersion)return;
  uploads=data.uploads;selectedUploads=new Set([...selectedUploads].filter(id=>uploads.some(file=>file.id===id)));
  renderAttachments();renderSidebar();
  window.dispatchEvent(new CustomEvent('blochai:files'));
}
async function selectProject(id,keepTask=false){
  if(uploading)return false;
  if(id===currentProject)return true;
  if((window.BlochGithub&&!window.BlochGithub.canLeave())||(window.BlochKnowledge&&!window.BlochKnowledge.canLeave())||(window.BlochCode&&!window.BlochCode.canLeave())||(window.BlochScope&&!window.BlochScope.canLeave())||(window.BlochClosedScope&&!window.BlochClosedScope.canLeave())||(window.BlochFiles&&!window.BlochFiles.canLeave())){$('project').value=currentProject;return false;}
  currentProject=id;const selectionVersion=++projectVersion;publishedProject=null;selectedUploads.clear();uploads=[];$('project').value=id;
  folderPlan=null;$('folder-preview').close();$('folder-input').value='';$('web-source-status').textContent='';
  projectRevision=null;projectFileStamps=new Map();cliRunStamp='';clearTimeout(projectPoll);
  $('project-cli-command').value='';$('project-cli-path').textContent='';$('project-cli-status').textContent='';$('project-cli-runs').replaceChildren();
  const project=projects.find(item=>item.id===id);
  const access=projectAccess();
  $('shared-project-notice').hidden=!project?.shared;$('request').hidden=Boolean(project?.shared);
  $('shared-project-role').textContent=access.write?'You can read and edit files and notes.':'You have read-only access.';
  $('open-project-cli').hidden=$('project-cli-details').hidden=!access.cli;
  $('graph-select').hidden=!access.ai;
  $('open-web-source').hidden=$('web-source-details').hidden=!access.write;
  $('open-github-import').hidden=$('github-import-details').hidden=!access.write;
  $('connect-nodes').disabled=!access.write;$('connection-form').hidden=!access.write;
  $('map-project-title').textContent=project?.name||'Your universe of ideas.';
  $('project-context').textContent=project?.description||'';$('project-context').hidden=!project?.description;
  if(!keepTask){clearTask();$('prompt').value='';$('mode').value='auto';modeChanged();}
  renderAttachments();renderSidebar();setBusy();await loadUploads();
  if(selectionVersion!==projectVersion||id!==currentProject)return false;
  knowledgeNoteIds=[];$('use-knowledge').checked=false;
  publishedProject=project||null;
  window.dispatchEvent(new CustomEvent('blochai:project',{detail:project||null}));
  if(project){if(access.cli)loadProjectCli(id,projectVersion);pollProjectFiles();}
  return true;
}

async function loadProjectCli(id,version){
  if(workspaceDeployment.mode==='hosted'){
    if(version!==projectVersion||id!==currentProject)return;
    $('project-cli-command').value=`qentl login\nqentl projects list --remote\nqentl projects scope ${id} --remote\nqentl run 'Implement the selected requirement' --remote --project ${id} --requirement REQ-ID\n\nqentl sync --project ${id} --workspace '/path/to/chosen-folder' --dry-run\nqentl sync --project ${id} --workspace '/path/to/chosen-folder' --watch`;
    $('project-cli-path').textContent='Project hosted on Qentl.ai. Explicitly choose the local folder you want to sync.';
    $('project-cli-status').textContent='Replace REQ-ID with an approved requirement and the path with your chosen folder. Review the --dry-run preview before uploading. To bring in changes from the site, use qentl sync with --pull. Conflicts preserve both versions; omitted files are not deleted.';
    $('project-cli-progress').textContent='Tasks started from the remote CLI appear in the Tasks tab. Synced changes appear in Graphus.';
    $('project-cli-runs').replaceChildren();return;
  }
  if(!workspaceDeployment.local_cli){$('project-cli-status').textContent='Could not confirm the terminal configuration for this installation.';return;}
  try{const data=await api(`/api/projects/${id}/cli-info`);if(version!==projectVersion||id!==currentProject)return;
    $('project-cli-command').value=data.command;$('project-cli-path').textContent=data.workspace;
    $('project-cli-status').textContent=data.launcher_available?'Replace the task description before running. File changes ask for approval in the terminal; system commands remain blocked in this mode.':'Install the CLI or use the launcher included in the app before running this command.';
    if(data.closed_scope){
      $('project-cli-status').textContent+=data.closed_scope.state==='approved'?' Use --requirement with one of the approved requirements: '+(data.closed_scope.requirements||[]).map(row=>row.id).join(', ')+'.':' Approve a current version of the .md scope and select a requirement before running development in the CLI.';
    }
  }catch(e){if(version===projectVersion)$('project-cli-status').textContent=e.message;}
}

function renderCliRuns(runs){
  const stamp=JSON.stringify(runs.map(run=>[run.id,run.status,run.updated_at,run.steps,run.heartbeat_current]));
  if(stamp===cliRunStamp)return;cliRunStamp=stamp;
  const opened=new Set([...$('project-cli-runs').querySelectorAll('details[open]')].map(item=>item.dataset.run));
  $('project-cli-runs').replaceChildren();
  const active=runs.find(run=>['RUNNING','AWAITING_APPROVAL'].includes(run.status)&&run.heartbeat_current);
  $('project-cli-progress').textContent=active?`CLI in progress · ${active.steps||0} steps recorded`:(runs.length?'Recent terminal runs in this project.':'No CLI runs recorded in this project.');
  for(const run of runs.slice(0,5)){
    const details=document.createElement('details'),summary=document.createElement('summary'),content=document.createElement('pre');
    details.dataset.run=run.id;details.open=opened.has(run.id);
    const stale=['RUNNING','AWAITING_APPROVAL'].includes(run.status)&&!run.heartbeat_current;
    summary.textContent=`${stale?'No recent update':statuses[run.status]||run.status} · ${run.agent} · ${run.steps||0} steps`;
    const lines=[run.task||'',run.summary||'',`Last recorded update: ${run.updated_at||''}`];
    for(const event of run.events||[]){const result=event.result||{};lines.push(`${event.action||event.kind}${result.path?' · '+result.path:''}${result.changed?' · changed':''}${result.denied?' · denied':''}${Number.isInteger(result.exit_code)?' · exit '+result.exit_code:''}`);}
    content.textContent=lines.filter(Boolean).join('\n');details.append(summary,content);$('project-cli-runs').append(details);
  }
}

async function pollProjectFiles(){
  clearTimeout(projectPoll);
  if(!currentProject||document.visibilityState==='hidden')return;
  if(projectPolling){projectPoll=setTimeout(pollProjectFiles,3000);return;}
  projectPolling=true;const id=currentProject,version=projectVersion;
  try{const [snapshot,history]=await Promise.all([api(`/api/projects/${id}/revision`),projectAccess().cli&&workspaceDeployment.local_cli?api(`/api/projects/${id}/cli-runs`):Promise.resolve({runs:[]})]);
    if(version!==projectVersion||id!==currentProject||document.visibilityState==='hidden')return;
    if(workspaceDeployment.local_cli)renderCliRuns(history.runs||[]);
    if(snapshot.revision!==projectRevision){
      const next=new Map(snapshot.files.map(file=>[file.id,JSON.stringify([file.path,file.size,file.mtime_ns,file.ctime_ns])]));
      const changed=[...next].filter(([key,value])=>projectFileStamps.get(key)!==value).map(([key])=>key);
      for(const key of projectFileStamps.keys())if(!next.has(key))changed.push(key);
      projectRevision=snapshot.revision;projectFileStamps=next;
      window.dispatchEvent(new CustomEvent('blochai:revision',{detail:{project:id,files:snapshot.files,changed_ids:changed}}));
      window.dispatchEvent(new CustomEvent('blochai:files'));
    }
  }catch(e){if(version===projectVersion)$('project-cli-progress').textContent='Terminal sync unavailable: '+e.message;}
  finally{projectPolling=false;if(currentProject&&document.visibilityState!=='hidden')projectPoll=setTimeout(pollProjectFiles,3000);}
}

document.addEventListener('visibilitychange',()=>{clearTimeout(projectPoll);if(document.visibilityState!=='hidden')pollProjectFiles();});
async function history(){const data=await api('/api/jobs');rows=data.jobs;activeJob=rows.find(row=>activeStatuses.has(row.status))?.id||null;setBusy();renderSidebar();}
async function account(data){
  accountIdentity=data;
  const ingestion=loadIngestPolicy(data);
  document.body.classList.add('signed-in');$('login').hidden=true;$('welcome').hidden=true;$('workbench').hidden=false;$('activity').hidden=false;$('logout').hidden=false;
  $('account').textContent=`${data.user.email} · ${data.organization.name}`;$('account').title=$('account').textContent;
  $('workspace-dock').hidden=false;setPane('work');
  window.dispatchEvent(new CustomEvent('blochai:account',{detail:data}));
  try{workspaceDeployment=await api('/api/deployment');}catch{workspaceDeployment={mode:'unknown',local_cli:false};}
  window.dispatchEvent(new CustomEvent('qentl:deployment',{detail:workspaceDeployment}));
  if(workspaceDeployment.mode==='hosted'){
    $('collaboration-scope').textContent='Project invitations work in this Qentl.ai workspace. The person needs an active Qentl account and a specific permission for the project.';
    $('privacy-delete').textContent='Delete project from this server';
  }
  loadModels();
  api('/api/web-policy').then(data=>{$('web-source-policy').textContent=(data.allowed_sites||[]).map(site=>site.host+(site.path_prefixes?.length?' · '+site.path_prefixes.join(', '):'')).join('\n')||'See the operator policy.';}).catch(()=>{$('web-source-policy').textContent='Could not load the access policy.';});
  await ingestion;
  try{await loadProjects();if(projects.length)await selectProject(projects[0].id);else openProjectForm();await tick();if(activeJob)await selectJob(activeJob);}catch(e){error(e);}
}
async function refresh(){
  try{const choice=$('model-choice').value;const data=await api('/api/status'+(choice?'?model='+encodeURIComponent(choice):''));
    if(choice!==$('model-choice').value)return;
    const limits=data.limits||{},number=value=>Number(value).toLocaleString('en-US');
    const parts=[];
    if(Number.isInteger(limits.context_tokens))parts.push(`Context: ${number(limits.context_tokens)} tokens`);
    if(Number.isInteger(limits.max_prompt_tokens))parts.push(`Input: up to ${number(limits.max_prompt_tokens)} tokens`);
    const output=limits.effective_output_tokens??limits.max_new_tokens;
    if(Number.isInteger(output)&&output>0)parts.push(`Output: up to ${number(output)} tokens`);
    $('model-limits').textContent=parts.join(' · ')+(parts.length?' · The request, guidelines and attachments share the context.':'');
    if(limits.token_counting==='utf8_upper_bound')$('model-limits').textContent+=' Input uses a conservative limit based on UTF-8 bytes.';
    $('model').textContent=data.ready?'Model available':'AI waiting for a model';$('model').title=data.reason||`${data.model} · ${parts.join(' · ')}${data.processing_region?' · '+data.processing_region:''}`;$('model-dot').classList.toggle('ready',data.ready);if(data.processing_region)$('privacy-processing').textContent=data.processing_region+' · no content is stored on the inference server';}
  catch(e){$('model').textContent='Could not verify';$('model-limits').textContent='Model limits unavailable.';$('model-dot').classList.remove('ready');error(e);}
}
async function loadModels(){
  try{const data=await api('/api/models'),selected=$('model-choice').value;$('model-choice').replaceChildren();
    if(!data.models.some(model=>model.enabled)){const empty=document.createElement('option');empty.value='';empty.textContent='No model configured';$('model-choice').append(empty);}
    for(const model of data.models){const option=document.createElement('option');option.value=model.id;option.textContent=model.label;option.disabled=!model.enabled;$('model-choice').append(option);}
    if(data.models.some(model=>model.id===selected&&model.enabled))$('model-choice').value=selected;
    $('model-policy').textContent=data.note;await refresh();
  }catch(e){error(e);}
}
function renderJob(data){
  state(statuses[data.status]||data.status,activeStatuses.has(data.status));
  $('answer').textContent=data.summary||(activeStatuses.has(data.status)?'The agents are working. Follow their actions below.':'This task did not record a response.');
  $('answer').classList.toggle('empty',!data.summary);$('result-meta').textContent=`${modes[data.mode]||'QENTL'} / ${data.project}${data.attachments?.length?' · '+data.attachments.length+' attachments':''}`;
  $('events').textContent=data.events.map(event=>JSON.stringify(event,null,2)).join('\n\n');$('event-details').hidden=data.events.length===0;
  pending=data.approval||null;$('approval').hidden=!pending;if(pending)$('preview').textContent=pending.preview;
  $('downloads').replaceChildren();
  for(const file of data.artifacts){const link=document.createElement('a');link.className='download-link';link.textContent=`↓ ${file.path.split('/').pop()}`;link.href=`/api/jobs/${data.id}/artifacts/${file.id}`;link.download='';$('downloads').append(link);}
  $('answer-to-note').hidden=!data.summary||data.status!=='COMPLETED';
  $('knowledge-evidence').replaceChildren();
  for(const note of data.knowledge_notes||[]){const button=document.createElement('button');button.type='button';button.className='text-button';button.textContent='Source: '+note.title;button.onclick=()=>window.BlochKnowledge?.open(note.id);$('knowledge-evidence').append(button);}
  if(data.status==='COMPLETED'&&completedNotification!==data.id){completedNotification=data.id;window.dispatchEvent(new CustomEvent('blochai:files'));}
  const graphVersion=[data.id,data.status,...(data.changed_files||[])].join('|');
  if(graphVersion!==graphJobVersion){graphJobVersion=graphVersion;window.dispatchEvent(new CustomEvent('blochai:files'));}
  const scope=data.scope?.mode==='selection'?data.scope.nodes.map(node=>node.title).join(', '):'Entire project';
  const routing=data.routing?' · '+(modes[data.routing.effective_mode]||data.mode)+(data.routing.artifact_formats?.length?' / '+data.routing.artifact_formats.join(', ').toUpperCase():''):'';
  $('task-provenance').textContent=`${data.model_choice||'Model not recorded'} · ${scope}${routing}${data.changed_files?.length?' · '+data.changed_files.length+' files changed':''}`;
  if(data.code_review)window.dispatchEvent(new CustomEvent('blochai:review',{detail:data}));
}
async function selectJob(id){
  try{const row=rows.find(item=>item.id===id);if(row&&row.project!==currentProject&&!await selectProject(row.project,true))return;setPane('work');selectedJob=id;pending=null;$('approval').hidden=true;await tick();}catch(e){error(e);}
}
async function tick(){
  clearTimeout(poll);
  try{await history();if(selectedJob){const id=selectedJob;const data=await api(`/api/jobs/${id}`);if(id===selectedJob)renderJob(data);}else if(activeJob)state('A task is in progress.',true);}
  catch(e){error(e);}
  if(activeJob)poll=setTimeout(tick,2500);
}
function openProjectForm(){
  setPane('collection');showTab('projects');$('search').value='';renderSidebar();$('project-create').hidden=false;$('project-error').textContent='';$('project-name').focus();
}
$('project-create').addEventListener('submit',async event=>{
  event.preventDefault();$('save-project').disabled=true;$('project-error').textContent='';
  try{const data=await api('/api/projects',{name:$('project-name').value,description:$('project-description').value,kind:$('project-kind').value});await loadProjects();await selectProject(data.project.id);$('project-create').reset();$('project-create').hidden=true;setPane('work');$('prompt').focus();}
  catch(e){$('project-error').textContent=e.message;}finally{$('save-project').disabled=false;}
});
function sendFile(project,file,index,total){
  return new Promise((resolve,reject)=>{
    const xhr=new XMLHttpRequest();uploadRequest=xhr;xhr.open('POST',`/api/projects/${project}/uploads`);xhr.timeout=45000;
    xhr.setRequestHeader('Content-Type','application/octet-stream');xhr.setRequestHeader('X-BlochAI-Action','1');xhr.setRequestHeader('X-BlochAI-Filename',encodeURIComponent(file.name));
    xhr.upload.onprogress=event=>{if(event.lengthComputable){const value=Math.round(event.loaded/event.total*100);$('upload-progress').value=value;$('upload-label').textContent=value===100?`Reading ${file.name}…`:`Uploading ${index}/${total}: ${file.name} · ${value}%`;}};
    xhr.onload=()=>{try{const data=JSON.parse(xhr.responseText);if(xhr.status>=200&&xhr.status<300)resolve(data.upload);else reject(new Error(data.error||data.detail||'Upload failed.'));}catch(e){reject(e);}};
    xhr.onerror=()=>reject(new Error('Could not upload. Check your connection and the file list before trying again.'));
    xhr.ontimeout=()=>reject(new Error('The upload timed out. Check the file list before retrying.'));
    xhr.onabort=()=>reject(new Error('Upload canceled. Files already received remain in the project.'));
    xhr.send(file);
  });
}
async function uploadFiles(files){
  if(uploading||!projectAccess().write)return;
  if(!currentProject){openProjectForm();error(new Error('Create or select a project before uploading files.'));return;}
  const list=Array.from(files);if(!list.length)return;
  if(list.length>10){error(new Error('Upload up to 10 files at a time.'));return;}
  for(const file of list){if(file.size>10*1024*1024||!file.size){error(new Error(`${file.name}: use a non-empty file of up to 10 MB.`));return;}if(!accepted.has(file.name.split('.').pop().toLowerCase())){error(new Error(`${file.name}: format not accepted. Use images, PDF, DOCX, PPTX, XLSX or text.`));return;}}
  const project=currentProject;uploading=true;uploadCancelled=false;$('error').textContent='';$('upload-status').hidden=false;setBusy();renderSidebar();
  try{
    for(let index=0;index<list.length&&!uploadCancelled;index++){
      $('upload-progress').value=0;$('upload-label').textContent=`Uploading ${index+1}/${list.length}: ${list[index].name}`;
      try{const item=await sendFile(project,list[index],index+1,list.length);if(selectedUploads.size<6)selectedUploads.add(item.id);await loadUploads();}
      catch(e){error(e);break;}
    }
  }finally{uploading=false;uploadRequest=null;$('upload-status').hidden=true;$('file-input').value='';setBusy();try{await loadProjects();await loadUploads();}catch(e){error(e);}}
}

function folderExclusions(plan){
  $('folder-skipped').textContent=plan.skipped.slice(0,300).map(item=>item.path+' — '+(folderSkipReasons[item.reason]||item.reason)).join('\n')+(plan.skipped.length>300?`\n… ${plan.skipped.length-300} more files excluded.`:'')||'No files excluded.';
}
function prepareFolder(files){
  if(uploading||!currentProject||!projectAccess().write)return;
  const accepted=[],skipped=[],policy={...ingestPolicy};let bytes=0;
  for(const file of files){
    const path=file.webkitRelativePath||file.name,parts=path.split('/'),name=parts.at(-1);
    let reason='';
    if(!file.webkitRelativePath||parts.length<2||path.length>500||parts.some(part=>!part||part==='.'||part==='..'||/[\\:\x00-\x1f]/.test(part)||/[. ]$/.test(part)||/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part)))reason='Unsupported path';
    else if(parts.some(part=>folderExcluded.has(part.toLowerCase())||folderPrivate.test(part)))reason='Credential, private directory or dependency';
    else if(parts.some(part=>part.startsWith('.')))reason='Hidden file or folder';
    else if(parts.length>6)reason='Folders beyond the allowed depth';
    else if(!folderExtensions.has(name.split('.').pop().toLowerCase())&&!['Dockerfile','Makefile'].includes(name))reason='Use attachments for this format; this import accepts text and code';
    else if(file.size>policy.source_file_bytes)reason='Over 200 KB per file';
    if(reason)skipped.push({path,reason});else{accepted.push({path,file});bytes+=file.size;}
  }
  const batches=[];let batch=[],batchBytes=0;
  for(const item of accepted){
    if(batch.length&&(batch.length>=policy.batch_files||batchBytes+item.file.size>policy.batch_decoded_bytes)){batches.push(batch);batch=[];batchBytes=0;}
    batch.push(item);batchBytes+=item.file.size;
  }
  if(batch.length)batches.push(batch);
  folderPlan={project:currentProject,version:projectVersion,owner:accountIdentity,policy,accepted,skipped,bytes,batches,next:0,pending:null,importId:null,confirmed:0,confirmedBytes:0,confirmedPaths:[]};
  const internal=policy.resumable_folder_batches;
  $('folder-summary').textContent=`${accepted.length} files prepared · ${size(bytes)} · ${skipped.length} excluded. `+(internal?`${batches.length} batches of up to ${policy.batch_files} files / ${size(policy.batch_decoded_bytes)}; no fixed byte quota per project, subject to available disk space.`:`Limits: ${policy.batch_files} files and 20 MiB per folder.`);
  $('folder-accepted').textContent=accepted.slice(0,500).map(item=>item.path+' · '+size(item.file.size)).join('\n')+(accepted.length>500?`\n… ${accepted.length-500} more files prepared.`:'')||'No eligible files.';
  folderExclusions(folderPlan);
  const oversized=accepted.length>policy.max_source_files||(!internal&&(accepted.length>policy.batch_files||bytes>policy.batch_decoded_bytes));
  folderPlan.oversized=oversized;
  $('folder-status').textContent=oversized?`Select a smaller subfolder: up to ${policy.max_source_files} eligible files in this profile.`:`Final check happens on receipt. Graphus shows up to ${policy.graph_source_files} code files; attachments and AI context have their own limits. The entire project is not automatically included in a prompt.`;
  $('folder-import-confirm').disabled=oversized||!accepted.length;$('folder-import-confirm').hidden=false;$('folder-import-confirm').textContent='Import this folder ↗';
  $('folder-progress').hidden=true;$('folder-import-cancel').hidden=true;$('folder-import-new').hidden=true;$('folder-preview-close').disabled=false;
  if(!$('folder-preview').open)$('folder-preview').showModal();
}

function sendFolder(project,payload,label=''){
  return new Promise((resolve,reject)=>{
    const xhr=new XMLHttpRequest();uploadRequest=xhr;xhr.open('POST',`/api/projects/${project}/folder-import`);xhr.timeout=120000;
    xhr.setRequestHeader('Content-Type','application/json');xhr.setRequestHeader('X-BlochAI-Action','1');
    xhr.upload.onprogress=event=>{if(event.lengthComputable){const percent=Math.round(event.loaded/event.total*100);$('folder-progress').value=percent;$('folder-status').textContent=label+' · '+(percent===100?'Checking the files and updating Graphus…':`Uploading · ${percent}%`);}};
    xhr.onload=()=>{try{const data=JSON.parse(xhr.responseText);if(xhr.status>=200&&xhr.status<300)resolve(data);else reject(new Error(data.error||(typeof data.detail==='string'?data.detail:null)||'The folder could not be imported.'));}catch(e){reject(e);}};
    xhr.onerror=()=>reject(new Error('Connection failed; the last batch may have been received.'));
    xhr.ontimeout=()=>reject(new Error('Timed out; the last batch may have been received.'));
    xhr.onabort=()=>reject(new Error('Upload canceled; the last batch may have been received.'));
    xhr.send(JSON.stringify(payload));
  });
}
function guardFolder(plan){
  if(plan!==folderPlan||plan.project!==currentProject||plan.version!==projectVersion||plan.owner!==accountIdentity)throw new Error('The project or account changed; no further parts will be sent.');
  if(uploadCancelled)throw new Error('Upload stopped by the user.');
}
async function importFolder(){
  const plan=folderPlan;
  if(!plan||plan.oversized||!plan.accepted.length||uploading||plan.project!==currentProject||plan.version!==projectVersion||plan.owner!==accountIdentity)return;
  uploading=folderImporting=true;uploadCancelled=false;setBusy();
  $('folder-import-confirm').disabled=true;$('folder-import-new').hidden=true;$('folder-preview-close').disabled=true;$('folder-import-cancel').hidden=false;$('folder-progress').hidden=false;$('folder-progress').value=0;
  try{
    guardFolder(plan);
    if(plan.policy.resumable_folder_batches&&!plan.importId){
      $('folder-status').textContent='Reserving the import identifier; no files have been sent…';
      const reservation=await api(`/api/projects/${plan.project}/folder-imports`,{name:plan.accepted[0].path.split('/')[0]});
      guardFolder(plan);
      if(typeof reservation.import_id!=='string'||!/^[a-f0-9]{16}$/.test(reservation.import_id))throw new Error('Invalid import reservation. No files were sent.');
      plan.importId=reservation.import_id;plan.destination=reservation.path;
    }
    while(plan.next<plan.batches.length){
      guardFolder(plan);
      if(!plan.pending){
        const files=[];
        for(const item of plan.batches[plan.next]){
          guardFolder(plan);const bytes=new Uint8Array(await item.file.arrayBuffer());guardFolder(plan);
          if(bytes.length!==item.file.size||bytes.length>plan.policy.source_file_bytes)throw new Error('A file changed during preparation; select the folder again.');
          let binary='';for(let offset=0;offset<bytes.length;offset+=32768)binary+=String.fromCharCode(...bytes.subarray(offset,offset+32768));
          files.push({path:item.path,content_base64:btoa(binary)});
          $('folder-status').textContent=`Preparing batch ${plan.next+1}/${plan.batches.length}: ${item.path}`;
        }
        const pending={files,...(plan.importId?{import_id:plan.importId}:{})};
        if(new TextEncoder().encode(JSON.stringify(pending)).length>plan.policy.batch_request_bytes)throw new Error('The batch exceeds the safe request size.');
        plan.pending=pending;
      }
      guardFolder(plan);
      if(plan.lastBatchAt){const pause=1050-(Date.now()-plan.lastBatchAt);if(pause>0)await new Promise(resolve=>setTimeout(resolve,pause));guardFolder(plan);}
      plan.lastBatchAt=Date.now();
      const result=await sendFolder(plan.project,plan.pending,`Batch ${plan.next+1}/${plan.batches.length} · ${plan.confirmed} files confirmed`);
      guardFolder(plan);
      if(plan.importId&&result.import_id!==plan.importId)throw new Error('The identifier received changed. The import was stopped.');
      const acceptedRows=result.accepted||[],replayed=(result.skipped||[]).filter(item=>item.reason==='already_imported');
      plan.confirmed+=acceptedRows.length+replayed.length;
      plan.confirmedBytes+=plan.batches[plan.next].filter(item=>acceptedRows.some(row=>(row.source_path||row.path)===item.path||row.path?.endsWith('/'+item.path))||replayed.some(row=>row.path===item.path)).reduce((sum,item)=>sum+item.file.size,0);
      plan.confirmedPaths.push(...acceptedRows.map(item=>item.path),...replayed.map(item=>item.path));
      plan.skipped.push(...(result.skipped||[]).filter(item=>item.reason!=='already_imported'));
      plan.destination=result.path||plan.destination;plan.next++;plan.pending=null;
      $('folder-summary').textContent=`${plan.confirmed} files imported/confirmed · ${size(plan.confirmedBytes)} · ${plan.next}/${plan.batches.length} batches · ${plan.destination||''}`;
      folderExclusions(plan);
    }
    $('folder-accepted').textContent=plan.confirmedPaths.slice(0,500).join('\n')+(plan.confirmedPaths.length>500?`\n… ${plan.confirmedPaths.length-500} more files confirmed.`:'');
    $('folder-status').textContent=`Import complete. Graphus shows up to ${plan.policy.graph_source_files} code files; the rest remain stored. Analysis uses selections and limited context.`;
    $('folder-import-confirm').hidden=true;folderPlan=null;
  }catch(e){
    $('folder-status').textContent=e.message+` ${plan.confirmed} files confirmed in ${plan.next}/${plan.batches.length} batches.`+(plan.importId?' Use Resume in this window to safely resend the unconfirmed batch; completed batches are preserved.':' Check Graphus before repeating an upload that has no resume identifier.');
    $('folder-import-confirm').textContent=plan.importId?'Resume import ↗':'Try again ↗';$('folder-import-confirm').disabled=false;$('folder-import-new').hidden=!plan.importId;
  }
  finally{uploading=folderImporting=false;uploadRequest=null;$('folder-import-cancel').hidden=true;$('folder-preview-close').disabled=false;$('folder-progress').hidden=true;$('folder-input').value='';setBusy();try{await loadProjects();await loadUploads();}catch(e){error(e);}}
}
async function previewFile(file){
  previewingUpload=file;
  window.BlochFiles?.select({id:'source:'+file.id,upload_id:file.id,title:file.name,path:file.path,kind:file.mime==='application/pdf'?'pdf':file.kind==='image'?'image':'document'});
  $('preview-to-note').hidden=!projectAccess().write;
  const version=++previewVersion;const url=uploadUrl(file);
  $('preview-title').textContent=file.name;$('preview-info').textContent='Loading preview…';$('preview-image').hidden=true;$('preview-image').removeAttribute('src');$('preview-text').hidden=true;
  $('preview-download').href=url+'/download';if(!$('file-preview').open)$('file-preview').showModal();
  $('preview-open').hidden=file.mime!=='application/pdf';$('preview-open').href=url+'/view';
  try{const data=await api(url);if(version!==previewVersion)return;
    $('preview-info').textContent=`${size(file.size)}${data.upload.note?' · '+data.upload.note:''}${data.upload.truncated||data.preview_truncated?' · Partial preview of the document.':''}`;
    if(file.kind==='image'){$('preview-image').src=url+'/preview';$('preview-image').alt=file.name;$('preview-image').hidden=false;}
    if(data.text){$('preview-text').textContent=data.text;$('preview-text').hidden=false;}
  }catch(e){$('preview-info').textContent=e.message;}
}
$('logout').onclick=async()=>{try{if((window.BlochGithub&&!window.BlochGithub.canLeave())||!window.BlochKnowledge?.canLeave()||!window.BlochCode?.canLeave()||(window.BlochFiles&&!window.BlochFiles.canLeave()))return;if(uploadRequest)uploadRequest.abort();await api('/api/logout',{});location.reload();}catch(e){error(e);}};
$('refresh').onclick=loadModels;$('model-choice').onchange=refresh;$('mode').onchange=modeChanged;$('project').onchange=()=>selectProject($('project').value).catch(error);
$('open-projects').onclick=openProjectForm;$('create-project-toggle').onclick=openProjectForm;$('close-project-form').onclick=()=>{$('project-create').hidden=true;};
$('request').addEventListener('submit',async event=>{
  event.preventDefault();if(activeJob||uploading||window.BlochGithub?.busy()||!currentProject||!projectAccess().ai)return;$('error').textContent='';$('submit').disabled=true;
  try{const data=await api('/api/jobs',{prompt:$('prompt').value,mode:$('mode').value,project:currentProject,attachments:[...selectedUploads],use_knowledge:$('use-knowledge').checked,note_ids:knowledgeNoteIds,model:$('model-choice').value||null,...(selectedArtifactFormat?{artifact_format:selectedArtifactFormat}:{}),...window.BlochScope.payload(),...window.BlochClosedScope?.payload($('mode').value==='coder')});activeJob=data.id;await selectJob(data.id);}catch(e){error(e);}finally{setBusy();}
});
$('prompt').addEventListener('keydown',event=>{if((event.metaKey||event.ctrlKey)&&event.key==='Enter'){event.preventDefault();if(!$('submit').disabled)$('request').requestSubmit($('submit'));}});
for(const button of document.querySelectorAll('[data-prompt]'))button.onclick=()=>{$('mode').value=button.dataset.mode;$('prompt').value=button.dataset.prompt;modeChanged();$('prompt').focus();};
for(const button of document.querySelectorAll('[data-format]'))button.onclick=()=>{
  const format=button.dataset.format;if(!['pdf','pptx','xlsx'].includes(format))return;
  $('mode').value='publisher';modeChanged();selectedArtifactFormat=format;renderFormat();
  if(!$('prompt').value.trim())$('prompt').value={pdf:'Create a PDF with an analysis of the project information. Show the sources and the points that need confirmation.',pptx:'Create a PPTX presentation about the project: vision, problem, solution, evidence and next steps.',xlsx:'Create an Excel spreadsheet to organize and analyze the data available in the project. Explain the fields and formulas used.'}[format];
  setPane('work');$('prompt').focus();
};
window.addEventListener('qentl:github-import',setBusy);
async function decide(allow){
  if(!pending)return;const id=selectedJob,approval=pending.id;$('allow').disabled=true;$('deny').disabled=true;
  try{await api(`/api/jobs/${id}/approval`,{id:approval,allow});if(selectedJob===id){$('approval').hidden=true;pending=null;await tick();}}catch(e){error(e);}finally{$('allow').disabled=false;$('deny').disabled=false;}
}
$('allow').onclick=()=>decide(true);$('deny').onclick=()=>decide(false);
$('cancel').onclick=async()=>{try{await api(`/api/jobs/${selectedJob}/cancel`,{});state('Cancellation requested');}catch(e){error(e);}};
$('view-active').onclick=()=>selectJob(activeJob);
$('new-task').onclick=()=>{if(activeTab==='projects'){openProjectForm();return;}if(activeTab==='files'){$('attach-button').click();return;}if(activeJob){selectJob(activeJob);return;}clearTask();$('prompt').value='';selectedUploads.clear();knowledgeNoteIds=[];renderAttachments();renderSidebar();setPane('work');$('prompt').focus();};
$('search').oninput=renderSidebar;
for(const name of tabs){$(name+'-tab').onclick=()=>showTab(name);$(name+'-tab').onkeydown=event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();const next=event.key==='Home'?tabs[0]:event.key==='End'?tabs[2]:tabs[(tabs.indexOf(name)+(event.key==='ArrowRight'?1:2))%3];showTab(next);$(next+'-tab').focus();}};}
$('attach-button').onclick=()=>$('file-input').click();$('file-input').onchange=()=>uploadFiles($('file-input').files);
$('folder-upload-button').onclick=()=>{
  if(folderPlan?.importId&&folderPlan.project===currentProject&&folderPlan.owner===accountIdentity){if(!$('folder-preview').open)$('folder-preview').showModal();return;}
  $('folder-input').click();
};$('folder-input').onchange=()=>prepareFolder($('folder-input').files);
$('shared-upload').onclick=()=>$('attach-button').click();$('shared-folder').onclick=()=>$('folder-upload-button').click();$('shared-code').onclick=()=>window.BlochCode?.create();
$('folder-import-confirm').onclick=importFolder;
$('folder-import-new').onclick=()=>{if(folderImporting)return;folderPlan=null;$('folder-preview').close();$('folder-input').click();};
$('folder-preview-close').onclick=()=>{if(!folderImporting)$('folder-preview').close();};
$('folder-preview').addEventListener('cancel',event=>{if(folderImporting)event.preventDefault();});
$('folder-import-cancel').onclick=()=>{uploadCancelled=true;if(uploadRequest)uploadRequest.abort();};
$('cancel-upload').onclick=()=>{uploadCancelled=true;if(uploadRequest)uploadRequest.abort();};
let dragDepth=0;
$('request').addEventListener('dragenter',event=>{if(event.dataTransfer.types.includes('Files')){event.preventDefault();dragDepth++;$('request').classList.add('is-dragover');}});
$('request').addEventListener('dragover',event=>{if(event.dataTransfer.types.includes('Files'))event.preventDefault();});
$('request').addEventListener('dragleave',()=>{dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)$('request').classList.remove('is-dragover');});
$('request').addEventListener('drop',event=>{event.preventDefault();dragDepth=0;$('request').classList.remove('is-dragover');uploadFiles(event.dataTransfer.files);});
for(const type of ['dragover','drop'])document.addEventListener(type,event=>{if(event.dataTransfer.types.includes('Files'))event.preventDefault();});
$('prompt').addEventListener('paste',event=>{if(event.clipboardData.files.length){event.preventDefault();uploadFiles(event.clipboardData.files);}});
$('show-agents').onclick=()=>$('agents-dialog').showModal();$('close-agents').onclick=()=>$('agents-dialog').close();
$('close-preview').onclick=()=>{$('file-preview').close();previewVersion++;};
$('preview-file-actions').onclick=()=>{if(!previewingUpload)return;$('file-preview').close();window.BlochFiles?.manage({id:'source:'+previewingUpload.id,upload_id:previewingUpload.id,title:previewingUpload.name,path:previewingUpload.path,kind:'document'});};
$('preview-to-note').onclick=async()=>{
  if(!previewingUpload||!projectAccess().write)return;
  const selection=window.getSelection();const excerpt=selection?.anchorNode&&$('preview-text').contains(selection.anchorNode)&&$('preview-text').contains(selection.focusNode)?selection.toString():null;
  $('preview-to-note').disabled=true;
  try{await window.BlochKnowledge.convert(previewingUpload.id,excerpt||null);$('file-preview').close();}catch(e){error(e);$('preview-info').textContent=e.message;}finally{$('preview-to-note').disabled=false;}
};
$('globe-tab').onclick=()=>$('knowledge-globe').focus();
const dockTabs=['work','collection','editor','privacy','training'];
for(const tab of dockTabs){$(tab+'-tab').onclick=()=>setPane(tab);$(tab+'-tab').onkeydown=event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();const shown=dockTabs.filter(name=>!$(name+'-tab').hidden);const next=event.key==='Home'?shown[0]:event.key==='End'?shown[shown.length-1]:shown[(shown.indexOf(tab)+(event.key==='ArrowRight'?1:shown.length-1))%shown.length];setPane(next);$(next+'-tab').focus();}};}
$('collapse-sidebar').onclick=()=>{sidebar(false);$('expand-sidebar').focus();};$('expand-sidebar').onclick=()=>{sidebar(true);$('collapse-sidebar').focus();};
$('fullscreen-map').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch(e){error(new Error('This browser did not allow full screen. The map already fills the available window area.'));}};
$('error').onclick=()=>{$('error').textContent='';};
$('prompt-to-idea').onclick=()=>window.BlochKnowledge?.draft($('prompt').value);
$('prompt-new-code').onclick=()=>window.BlochCode?.create();
$('connect-nodes').onclick=()=>{setPane('collection');showTab('files');$('connection-details').open=true;$('connection-source').focus();};
$('open-web-source').onclick=()=>{setPane('collection');showTab('files');$('web-source-details').open=true;$('web-source-url').focus();};
$('open-project-cli').onclick=()=>{setPane('collection');showTab('files');$('project-cli-details').open=true;if(currentProject)loadProjectCli(currentProject,projectVersion);};
$('copy-project-cli').onclick=async()=>{const value=$('project-cli-command').value;if(!value)return;try{await navigator.clipboard.writeText(value);$('project-cli-status').textContent='Command copied. Replace the task description before running it in the terminal.';}catch{$('project-cli-command').focus();$('project-cli-command').select();$('project-cli-status').textContent='The command is selected. Use ⌘C or Ctrl+C to copy.';}};
$('web-source-form').onsubmit=async event=>{
  event.preventDefault();
  if(!currentProject){openProjectForm();return;}
  if(!projectAccess().write)return;
  const project=currentProject,version=projectVersion;
  $('web-source-submit').disabled=true;$('web-source-status').textContent='Reading the requested public page…';
  try{const data=await api(`/api/projects/${project}/web-source`,{url:$('web-source-url').value.trim()});
    if(version!==projectVersion)return;
    $('web-source-status').textContent='Source saved to Graphus: '+data.note.title+'. '+data.source.url;
    $('web-source-url').value='';window.dispatchEvent(new CustomEvent('blochai:files'));
  }catch(e){if(version===projectVersion)$('web-source-status').textContent=e.message;}
  finally{$('web-source-submit').disabled=false;}
};
$('answer-to-note').onclick=()=>window.BlochKnowledge?.draft($('answer').textContent);
window.BlochWorkspace={
  project:()=>projects.find(item=>item.id===currentProject),pane:setPane,inspect,
  identity:()=>accountIdentity,
  onProject:listener=>{window.addEventListener('blochai:project',listener);if(publishedProject?.id===currentProject)listener({detail:publishedProject});},
  busy:()=>Boolean(activeJob)||uploading||Boolean(window.BlochGithub?.busy()),
  access:projectAccess,
  reloadProjects:loadProjects,selectProject,
  refreshFiles:async()=>{const id=currentProject;await loadProjects();if(id!==currentProject)return;await loadUploads();if(id!==currentProject)return;window.dispatchEvent(new CustomEvent('blochai:files'));projectRevision=null;pollProjectFiles();},
  continueScope:async(requirement_id,scope_revision)=>{
    if(!currentProject||!projectAccess().ai)throw new Error('Select one of your own projects with an approved scope.');
    if(activeJob||uploading||window.BlochGithub?.busy())throw new Error('Finish the task or upload in progress before continuing.');
    const data=await api('/api/jobs',{project:currentProject,mode:'coder',continuation:true,requirement_id,scope_revision,model:$('model-choice').value||null,...window.BlochScope.payload()});
    activeJob=data.id;await selectJob(data.id);setPane('work');
  },
  selectJob,
  chooseModel:choice=>{if([...$('model-choice').options].some(option=>option.value===choice&&!option.disabled)){$('model-choice').value=choice;refresh();setPane('work');}else error(new Error('This previously used model is not available right now.'));},
  deleted:async()=>{currentProject='';publishedProject=null;projectVersion++;selectedJob=null;activeJob=null;uploads=[];selectedUploads.clear();knowledgeNoteIds=[];clearTask();window.dispatchEvent(new CustomEvent('blochai:project',{detail:null}));await loadProjects();if(projects.length)await selectProject(projects[0].id);else{renderAttachments();$('map-project-title').textContent='Your universe of ideas.';openProjectForm();}await history();},
  preview:async id=>{let file=uploads.find(item=>item.id===id);if(!file){await loadUploads();file=uploads.find(item=>item.id===id);}if(file)await previewFile(file);},
  upload:()=>{if(!currentProject)openProjectForm();else $('file-input').click();},
  ask:(question,noteIds=[])=>{if(!projectAccess().ai)return;if(activeJob){error(new Error('Finish the current task before querying the knowledge base.'));return;}setPane('work');clearTask();window.BlochScope.reset();$('prompt').value=question;$('mode').value='chat';modeChanged();$('use-knowledge').checked=true;knowledgeNoteIds=noteIds;selectedUploads.clear();renderAttachments();$('request').requestSubmit($('submit'));},
  reviewCode:async(file,content,prompt,start,action='review')=>{if(!projectAccess().ai)throw new Error('AI review is available only in your own projects.');if(activeJob)throw new Error('Finish the current task before requesting a review.');const data=await api('/api/jobs',{project:currentProject,mode:'chat',prompt,model:$('model-choice').value||null,code_id:file.id,code_revision:file.sha256,code_draft:content,code_start_line:start,code_action:action,scope_mode:'selection',scope_nodes:[file.id],...window.BlochClosedScope?.payload(action==='patch')});selectedJob=data.id;activeJob=data.id;await tick();setPane('editor');return data.id;}
};
modeChanged();setBusy();if(!window.QentlAccess?.claimPending())api('/api/session').then(account).catch(()=>{});
