'use strict';
(() => {
  let permitted=false,available=false,busy=false,epoch=0;
  const actions=['training-start','training-pause','training-resume','training-save'];
  function controls(){
    $('training-admin-panel').hidden=!permitted;
    $('training-open').hidden=!permitted;
    for(const id of actions)$(id).disabled=busy||!permitted||!available;
    $('training-refresh').disabled=busy||!permitted;
  }
  function dailyProgress(data){
    const daily=data?.daily_progress,latest=daily?.latest;
    $('training-daily-roles').replaceChildren();$('training-daily-history').replaceChildren();
    $('training-daily-sources').textContent='';$('training-daily-benchmark').textContent='';
    $('training-daily-comparison').replaceChildren();$('training-daily-feedback').textContent='';
    if(!latest){$('training-daily-summary').textContent='The controller has not published daily evidence yet. This does not confirm a new training run or an improvement.';return;}
    $('training-daily-summary').textContent=`${latest.date_utc} UTC · ${latest.study_rounds} cycles observed · ${latest.failed_rounds} failures · ${latest.verified_exercise_observations} observations of verified exercises · ${latest.candidate_attempts} candidates · ${latest.completed_training_steps} isolated training steps. Daily records: ${daily.retained_days}/${daily.retention_days}.`;
    for(const role of (latest.roles||[]).slice(0,8)){
      const row=document.createElement('p');row.textContent=`${role.name}: ${role.completed} tasks completed, ${role.failed} failures. ${(role.skills||[]).join('; ')}.`;
      $('training-daily-roles').append(row);
    }
    const feedback=latest.feedback;
    if(feedback&&typeof feedback==='object'){
      const count=key=>Number.isInteger(feedback[key])&&feedback[key]>=0?feedback[key]:'—';
      $('training-daily-feedback').textContent=`Isolated 0.5B pilot · ${count('tasks')} tasks · ${count('attempts')} attempts · ${count('revisions')} revisions · ${count('visible_failures')} visible failures · ${count('verified_solutions')} verified solutions · ${count('repaired_solutions')} repaired after feedback · ${count('confirmation_rejections')} rejections at confirmation · ${count('duplicate_solutions')} duplicates · ${count('budget_exhausted_rounds')} cycles with no budget remaining. These are limited checks of synthetic expressions; they do not measure IQ or demonstrate progress of the 9B model.`;
    }
    const evaluation=latest.latest_evaluation;
    if(evaluation){
      const label={regressed:'Regression observed',unchanged:'Result unchanged',improved_small_benchmark:'Gain on the small benchmark only'}[evaluation.outcome]||'Result not classified';
      for(const split of ['validation','test'])for(const version of ['baseline','candidate']){
        const metric=evaluation[version]?.[split];
        if(!metric||!Number.isInteger(metric.passed)||!Number.isInteger(metric.cases)||metric.cases<=0||metric.passed<0||metric.passed>metric.cases)continue;
        const row=document.createElement('div');row.className='training-comparison-row';
        const label=document.createElement('span');label.textContent=`Isolated pilot · ${split==='test'?'test':'validation'} · ${version==='baseline'?'baseline':'candidate'}: ${metric.passed}/${metric.cases}`;
        const track=document.createElement('div');track.className='capability-track';const fill=document.createElement('div');fill.className='capability-fill';fill.style.width=String(100*metric.passed/metric.cases)+'%';track.append(fill);row.append(label,track);$('training-daily-comparison').append(row);
      }
      $('training-daily-benchmark').textContent=label+'. '+['validation','test'].map(split=>`${split==='validation'?'Validation':'Test'}: baseline ${evaluation.baseline[split].passed}/${evaluation.baseline[split].cases}; candidate ${evaluation.candidate[split].passed}/${evaluation.candidate[split].cases}`).join(' · ')+'. Qwen weights in production were not changed; no automatic promotion.';
    }else $('training-daily-benchmark').textContent='No candidate evaluation was completed on this day. Studying sources does not prove an improvement in the model weights.';
    for(const day of (daily.recent_days||[]).slice(0,7)){
      const row=document.createElement('p');row.textContent=`${day.date_utc}: ${day.successful_rounds}/${day.study_rounds} cycles without failures; ${day.evaluated_candidates} candidates evaluated; ${day.improved_candidates} benchmark gains and ${day.regressed_candidates} regressions.`;
      $('training-daily-history').append(row);
    }
    $('training-daily-sources').textContent=(daily.source_receipts||[]).map(source=>`${source.repository} · ${source.license}\nCommit ${source.commit}\nSHA-256 receipt ${source.receipt_sha256}`).join('\n\n');
  }
  function display(data){
    // Only the controller's returned facts are displayed; starting a service
    // does not establish a finished training run or a promoted model.
    $('training-admin-result').textContent=JSON.stringify(data,null,2).slice(0,60000);
    const status=data.status||{},controller=status.controller||{},study=status.study||{},candidate=status.candidate||{},schedule=status.schedule||{};
    if(Number.isInteger(controller.max_workers))$('training-workers').value=String(controller.max_workers);
    if(Array.isArray(controller.curriculum_families))for(const name of ['sum','length','sort'])$('training-'+name).checked=controller.curriculum_families.includes(name);
    const facts=[];
    if(status.observed_at_utc)facts.push('Observed: '+status.observed_at_utc);
    if(typeof schedule.enabled==='boolean')facts.push('Schedule: '+(schedule.enabled?'enabled':'paused'));
    if(study.stage)facts.push('Study: '+study.stage);
    if(Number.isInteger(study.fleet?.jobs_completed))facts.push(study.fleet.jobs_completed+' studies completed');
    if(Number.isInteger(study.fleet?.jobs_failed))facts.push(study.fleet.jobs_failed+' failures recorded');
    if(candidate.status)facts.push('Candidate: '+candidate.status);
    if(Number.isInteger(candidate.completed_steps))facts.push(`${candidate.completed_steps}/${candidate.requested_steps??'?'} training steps`);
    $('training-admin-summary').textContent=facts.join(' · ')||'The controller has not recorded any study or training metrics yet.';
    dailyProgress(status);
  }
  async function refresh(){
    if(!permitted||busy)return;busy=true;controls();const version=epoch;
    try{const data=await api('/api/admin/training/status');if(version!==epoch)return;display(data);$('training-admin-status').textContent='Status retrieved from the controller. Check the records and results below.';}
    catch(e){if(version===epoch)$('training-admin-status').textContent='Status unavailable: '+e.message;}
    finally{busy=false;controls();}
  }
  async function capabilities(){
    const version=++epoch;permitted=false;available=false;controls();$('training-admin-result').textContent='';dailyProgress(null);
    try{
      const data=await api('/api/admin/training/capabilities');if(version!==epoch)return;
      permitted=data.can_control===true;available=data.available===true;controls();
      if(!permitted)return;
      $('training-admin-status').textContent=available?'Control authorized. Refresh to check the status of the agents.':(data.readiness_note||data.reason||'Control authorized, but the controller is not yet configured or available.');
      if(available)await refresh();
    }catch{if(version===epoch){permitted=false;controls();}}
  }
  async function control(action,values={}){
    if(!permitted||!available||busy)return;busy=true;controls();const version=epoch;
    $('training-admin-status').textContent='Sending the authorized command to the controller…';
    try{
      const data=await api('/api/admin/training/control',{action,...values});if(version!==epoch)return;
      display(data);$('training-admin-status').textContent='The controller responded to the command. Check the status to follow the run; no model was promoted by this action.';
    }catch(e){if(version===epoch)$('training-admin-status').textContent='Command not confirmed: '+e.message;}
    finally{busy=false;controls();}
  }
  $('training-refresh').onclick=refresh;
  $('training-open').onclick=()=>{$('agents-dialog').close();window.BlochWorkspace.pane('collection');$('projects-tab').click();$('training-admin-panel').open=true;refresh();};
  $('training-start').onclick=()=>control('start');$('training-pause').onclick=()=>control('pause');$('training-resume').onclick=()=>control('resume');
  $('training-configure').onsubmit=event=>{
    event.preventDefault();const workers=Number($('training-workers').value),families=['sum','length','sort'].filter(name=>$('training-'+name).checked);
    if(!Number.isInteger(workers)||workers<1||workers>8||!families.length){$('training-admin-status').textContent='Choose 1 to 8 agents and at least one curriculum family.';return;}
    control('configure',{max_workers:workers,curriculum_families:families});
  };
  window.addEventListener('blochai:account',capabilities);controls();
  if(window.BlochWorkspace?.identity?.())capabilities();
})();
