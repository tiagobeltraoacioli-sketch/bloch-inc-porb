'use strict';
// Training tab: the master account chooses what Qentl studies and reads what it kept.
(() => {
  let permitted=false,busy=false,epoch=0;
  const say=text=>{$('study-status').textContent=text;};
  function when(seconds){return seconds?new Date(seconds*1000).toLocaleString('en-US'):'not yet';}
  function line(tag,text,className){const node=document.createElement(tag);node.textContent=text;if(className)node.className=className;return node;}
  function render(data){
    const list=$('study-list');list.replaceChildren();
    const cycle=data.worker?.last_cycle;
    $('study-worker').textContent=data.worker?.last_cycle_at
      ?`Last study pass: ${when(data.worker.last_cycle_at)} · ${cycle.studied} page(s) studied, ${cycle.unchanged} unchanged, ${cycle.failed} failed · ${cycle.kept} note(s) kept, ${cycle.rejected} rejected`+(data.worker.model?` · model ${data.worker.model}`:'')
      :'The study agent has not completed a pass yet.';
    $('study-effect').textContent=data.effect||'';
    if(!data.directives.length){list.append(line('p','No topics yet. Add the first one above.'));return;}
    for(const item of data.directives){
      const card=document.createElement('article');card.className='study-topic';
      card.append(line('h3',item.topic),line('p',`${item.status==='active'?'Studying':'Paused'} · ${item.notes} note(s) kept`,'study-meta'));
      if(item.guidance)card.append(line('p',item.guidance));
      const sources=document.createElement('ul');
      for(const source of item.sources){
        const state=source.error?`could not be read: ${source.error}`:source.studied_at?`${source.kept} kept, ${source.rejected} rejected · ${when(source.studied_at)}`:'waiting for the study agent';
        sources.append(line('li',`${source.url} — ${state}`));
      }
      card.append(sources);
      const row=document.createElement('div');row.className='button-row';
      const button=(label,action,style)=>{const node=line('button',label,style||'small-button');node.type='button';node.onclick=()=>change(item,action);return node;};
      const notes=line('button','Read notes','small-button');notes.type='button';notes.onclick=()=>showNotes(item,card);
      row.append(notes,button(item.status==='active'?'Pause':'Resume',item.status==='active'?'pause':'resume'),button('Study again','restudy'),button('Remove','delete','text-button'));
      card.append(row);list.append(card);
    }
  }
  async function refresh(){
    if(!permitted||busy)return;const version=epoch;
    try{const data=await api('/api/admin/study');if(version===epoch)render(data);}
    catch(e){if(version===epoch)say('Study list unavailable: '+e.message);}
  }
  async function change(item,action){
    if(busy)return;
    if(action==='delete'&&!confirm(`Remove "${item.topic}" and the notes kept for it?`))return;
    busy=true;
    try{await api('/api/admin/study/directives/'+item.id,{action});say(action==='delete'?'Topic removed.':action==='restudy'?'The study agent will read these pages again on its next pass.':'Saved.');}
    catch(e){say('Not saved: '+e.message);}
    finally{busy=false;await refresh();}
  }
  async function showNotes(item,card){
    card.querySelector('.study-notes')?.remove();
    const box=document.createElement('div');box.className='study-notes';card.append(box);
    try{
      const data=await api('/api/admin/study/directives/'+item.id+'/notes');
      if(!data.notes.length){box.append(line('p','No notes kept yet.'));return;}
      for(const note of data.notes){
        const entry=document.createElement('p');entry.append(line('strong',note.fact),document.createElement('br'),line('span',`“${note.quote}” — ${note.source_title||note.url}`,'study-meta'));
        box.append(entry);
      }
    }catch(e){box.append(line('p','Notes unavailable: '+e.message));}
  }
  $('study-form').onsubmit=async event=>{
    event.preventDefault();if(busy)return;
    const urls=$('study-urls').value.split(/\s+/).filter(Boolean);
    if(!urls.length||urls.length>8){say('Add 1 to 8 page addresses, one per line.');return;}
    busy=true;say('Saving…');
    try{
      await api('/api/admin/study/directives',{topic:$('study-topic').value,guidance:$('study-guidance').value,urls});
      $('study-form').reset();say('Topic added. The study agent reads it on its next pass.');
    }catch(e){say('Not added: '+e.message);}
    finally{busy=false;await refresh();}
  };
  $('study-refresh').onclick=refresh;
  async function access(){
    const version=++epoch;permitted=false;$('training-tab').hidden=true;
    try{const data=await api('/api/admin/study');if(version!==epoch)return;permitted=true;$('training-tab').hidden=false;render(data);}
    catch{if(version===epoch&&!$('training-workspace').hidden)window.BlochWorkspace.pane('work');}
  }
  window.BlochStudy={refresh};
  window.addEventListener('blochai:account',access);
  if(window.BlochWorkspace?.identity?.())access();
})();
