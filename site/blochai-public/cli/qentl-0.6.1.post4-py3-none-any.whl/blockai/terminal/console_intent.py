"""Turn a plain console request into one Qentl CLI command for the person to confirm.

The model only proposes. Every proposal is checked against a fixed grammar, known
project IDs and the words the person actually typed, and nothing runs unconfirmed.
"""
from __future__ import annotations

import json
import re
import shlex
import unicodedata

from .config import BlochAIError

OPERATIONAL = re.compile(
    r'\b(?:sincroniz\w*|sync\w*|clon\w*|baix\w*|download\w*|pull|push|envi\w*|upload\w*|subir|suba)\b'
    r'|\b(?:list\w*|mostr\w*|show|quais|which|ver|meus|my)\b.{0,30}\b(?:projetos?|projects?|repositorios?|repositor(?:y|ies))\b'
    r'|\b(?:cri\w*|create|novo|new)\b.{0,20}\b(?:projeto|project|repositorio|repository)\b'
    r'|\b(?:whoami|quem sou eu|minha conta|my account)\b')
FLAGS = {
    ('projects', 'list'): {'--remote': 0},
    ('projects', 'create'): {'--remote': 0},
    ('sync',): {'--project': 1, '--workspace': 1, '--dry-run': 0, '--pull': 0, '--watch': 0, '--binding': 1},
    ('clone',): {'--project': 1, '--workspace': 1, '--dry-run': 0},
    ('pull',): {'--project': 1, '--workspace': 1, '--dry-run': 0},
    ('push',): {'--project': 1, '--workspace': 1, '--dry-run': 0},
    ('whoami',): {}, ('status',): {},
}
GRAMMAR = (
    'projects list --remote | projects create NAME --remote | '
    'clone --project ID --workspace PATH [--dry-run]  (first download of the site project files into a local folder) | '
    'pull --project ID --workspace PATH [--dry-run]  (update that folder with newer site files) | '
    'push --project ID --workspace PATH [--dry-run]  (send local edits of that folder back to the same site files; asks before sending) | '
    'sync --project ID --workspace PATH [--dry-run] [--watch]  (upload a new local folder that the site does not have yet, into its own area) | '
    'whoami | status')


def plain(value):
    text = unicodedata.normalize('NFKD', value.casefold())
    return ''.join(char for char in text if not unicodedata.combining(char))


def looks_operational(prompt):
    return bool(OPERATIONAL.search(plain(prompt)))


def instructions(projects):
    known = '; '.join(row['id'] + ' = ' + row['name'] for row in projects[:50]) or 'unknown (not listed)'
    return ('You translate one request into one Qentl CLI command. Reply with exactly one JSON object and nothing else.\n'
            'Commands: ' + GRAMMAR + '\n'
            'The person\'s projects (ID = name): ' + known + '\n'
            'Rules: use a project ID from that list, matched by the name or ID the person wrote. Use only a folder path the '
            'person wrote. Site to computer is clone (first time) or pull; edits back to the site is push; sync is only for uploading a folder the site does not have. If the person did not ask to only preview, '
            'do not add --dry-run. Never invent flags, IDs or paths.\n'
            'Answer {"argv":["sync","--project","ID","--workspace","/path"]} for a command, '
            '{"ask":"one short question in the person\'s language"} when the project or folder is missing or ambiguous, '
            'or {"none":true} when the request is not one of these commands.')


def validate(argv, prompt, projects):
    if not isinstance(argv, list) or not 1 <= len(argv) <= 12 or any(not isinstance(item, str) or not 0 < len(item) <= 400 or '\n' in item for item in argv):
        raise BlochAIError('The suggested command was not valid.')
    head = tuple(argv[:2]) if argv[0] == 'projects' else (argv[0],)
    if head not in FLAGS:
        raise BlochAIError('The suggested command is not available from the console.')
    allowed, rest, values, positional = FLAGS[head], argv[len(head):], {}, []
    index = 0
    while index < len(rest):
        item = rest[index]
        if item.startswith('-'):
            if item not in allowed or item in values:
                raise BlochAIError('The suggested command used an unknown option.')
            if allowed[item]:
                if index + 1 >= len(rest) or rest[index + 1].startswith('-'):
                    raise BlochAIError('The suggested command is missing a value.')
                values[item] = rest[index + 1]; index += 1
            else:
                values[item] = True
        else:
            positional.append(item)
        index += 1
    if positional and head != ('projects', 'create') or (head == ('projects', 'create') and len(positional) != 1):
        raise BlochAIError('The suggested command has unexpected arguments.')
    if head[0] == 'projects' and '--remote' not in values:
        raise BlochAIError('The suggested command must name the site with --remote.')
    typed = plain(prompt)
    if head in (('sync',), ('clone',), ('pull',), ('push',)):
        if '--project' not in values or '--workspace' not in values:
            raise BlochAIError('The suggested command is missing the project or the folder.')
        known = {row['id'] for row in projects}
        if (known and values['--project'] not in known) or (not known and plain(values['--project']) not in typed):
            raise BlochAIError('The suggested project is not one of yours. Run: qentl projects list --remote')
        folder = values['--workspace']
        # A path is only trusted when the person wrote it; the model may not supply one.
        if plain(folder.rstrip('/')) not in typed and plain(folder.replace('~', '', 1).rstrip('/')) not in typed:
            raise BlochAIError('Tell me the folder path to use, for example: sincronize a pasta ~/trading com o projeto NOME')
    if head == ('projects', 'create') and plain(positional[0]) not in typed:
        raise BlochAIError('Tell me the name for the new project.')
    return list(argv)


def suggest(provider, prompt, projects, complete=None):
    """Return ('run', argv), ('ask', question) or ('none', None)."""
    complete = complete or (lambda messages: provider.complete(messages, json_mode=True))
    reply = complete([{'role': 'system', 'content': instructions(projects)},
                      {'role': 'user', 'content': prompt[:2000]}]).text.strip()
    if reply.startswith('```'):
        reply = reply.strip('`').removeprefix('json').strip()
    try:
        data = json.loads(reply)
    except ValueError:
        return 'none', None
    if not isinstance(data, dict):
        return 'none', None
    if isinstance(data.get('argv'), list):
        return 'run', validate(data['argv'], prompt, projects)
    if isinstance(data.get('ask'), str) and data['ask'].strip():
        return 'ask', data['ask'].strip()[:400]
    return 'none', None


def command_line(argv):
    return 'qentl ' + ' '.join(shlex.quote(item) for item in argv)
