"""Master-only routes for owner-directed study topics."""
from __future__ import annotations

from fastapi import HTTPException, Request

from .config import BlochAIError
from .study import StudyStore
from .training_control import MASTER_EMAIL


def install_study_routes(app, session, body, store_factory=StudyStore):
    from starlette.concurrency import run_in_threadpool

    def master(request):
        # write=True refreshes the account identity on every request, as the training panel does.
        record = session(request, True)
        identity = record.get('identity', {})
        user, organization = identity.get('user', {}), identity.get('organization', {})
        if (not isinstance(user, dict) or not isinstance(user.get('email'), str)
                or user['email'].casefold() != MASTER_EMAIL or not isinstance(organization, dict)
                or organization.get('role') not in ('owner', 'admin')):
            raise HTTPException(403, 'Master study access is required.')
        return store_factory()

    def guarded(action):
        try:
            return action()
        except BlochAIError as exc:
            raise HTTPException(422, str(exc)) from None

    @app.get('/api/admin/study')
    async def overview(request: Request):
        store = await run_in_threadpool(master, request)
        return await run_in_threadpool(lambda: guarded(store.overview))

    @app.post('/api/admin/study/directives')
    async def add(request: Request):
        store = await run_in_threadpool(master, request)
        data = await body(request, 20000)
        row = await run_in_threadpool(lambda: guarded(lambda: store.add(data.get('topic'), data.get('guidance', ''), data.get('urls'))))
        return {'directive': {key: row[key] for key in ('id', 'topic', 'guidance', 'urls', 'status')}}

    @app.post('/api/admin/study/directives/{identifier}')
    async def update(identifier: str, request: Request):
        store = await run_in_threadpool(master, request)
        data = await body(request, 2000)
        await run_in_threadpool(lambda: guarded(lambda: store.update(identifier, data.get('action'))))
        return {'ok': True}

    @app.get('/api/admin/study/directives/{identifier}/notes')
    async def notes(identifier: str, request: Request):
        store = await run_in_threadpool(master, request)
        rows = await run_in_threadpool(lambda: guarded(lambda: store.notes(identifier)))
        return {'notes': [{key: note.get(key) for key in ('id', 'fact', 'quote', 'url', 'source_title', 'at')} for note in rows[-400:]]}
