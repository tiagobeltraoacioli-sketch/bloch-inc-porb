"""Readable terminal presentation without changing tool or approval authority."""
from __future__ import annotations

import os
import json
from pathlib import PurePosixPath

from rich import box
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .workspace import clean_text

COMMANDS = (
    ('A plain request', 'Talk, analyze a URL, or create PDF / PPTX / Excel.'),
    ('Sync in plain words', 'e.g. "sincronize a pasta ~/app com o projeto Trading" — confirms before running.'),
    ('/help', 'Show this guide.'),
    ('/status', 'Check the selected model and context.'),
    ('/model [NAME]', 'List the available models or switch to one; the choice is remembered.'),
    ('/skills [language]', 'Browse read-only coding references and document recipes.'),
    ('/artifacts', 'List generated files from this conversation.'),
    ('/download N', 'Copy a verified generated file to Downloads after confirmation.'),
    ('/run TASK', 'Route a task automatically; code still needs project scope.'),
    ('/analyze QUESTION', 'Investigate the current question with available evidence.'),
    ('/requirement ID', 'Select an approved requirement in the current project.'),
    ('qentl COMMAND', 'Run a CLI command here, e.g. qentl projects, qentl pull, qentl push.'),
    ('Code in a folder', 'Leave with /quit, cd to your project and run: qentl code'),
    ('/reset', 'Clear conversation references and selected documents.'),
    ('/quit', 'Leave the console. /exit also works.'),
)


class InteractiveUI:
    def __init__(self, console):
        self.console = console
        self.rich = bool(console.is_terminal and getattr(console.file, 'isatty', lambda: False)()
                         and 'NO_COLOR' not in os.environ and os.environ.get('TERM') != 'dumb')
        self.steps = 0
        self.seen_remote = set()

    def text(self, value, style=None):
        self.console.print(Text(clean_text(str(value)), style=style if self.rich else None))

    def welcome(self, context, model=None, project=None):
        model = clean_text(str(model or 'Selected by the hosted project'))[:160]
        description = clean_text(context)
        body = Text()
        body.append('QENTL', style='bold bright_cyan' if self.rich else None)
        body.append('  by Bloch Inc.\n\n')
        body.append('Model   ', style='dim' if self.rich else None);body.append(model+'\n')
        body.append('Context ', style='dim' if self.rich else None);body.append(description)
        if project:
            body.append('\nProject ', style='dim' if self.rich else None);body.append(clean_text(str(project))[:160])
        body.append('\n\nTalk naturally. Create PDF, PPTX or Excel. Review each proposed write.')
        body.append('\n/help  shortcuts    /artifacts  generated files    /quit  exit')
        if self.rich:
            self.console.print(Panel(body, box=box.ROUNDED, border_style='cyan', padding=(1, 2)))
        else:
            self.console.print(body)

    def help(self):
        self.text('Conversation guide', 'bold cyan')
        if self.rich:
            table=Table(show_header=False,box=None,padding=(0,2))
            for command,description in COMMANDS:table.add_row(Text(command,style='cyan'),Text(description))
            self.console.print(table)
        else:
            for command,description in COMMANDS:self.text(command+' — '+description)

    def task(self, mode, formats=()):
        self.steps=0;self.seen_remote.clear()
        self.text('Working · '+mode+(' · '+', '.join(formats).upper() if formats else ''), 'cyan')

    def event(self, item):
        kind=item.get('kind')
        if kind=='inference_submitted':self.text('  Model request submitted', 'dim')
        elif kind=='waiting':self.text('  Model busy · retrying in '+str(int(item.get('seconds',0)))+'s', 'dim')
        elif kind=='generation':
            self.steps+=1;self.text('  Step '+str(self.steps)+' · model response received', 'dim')
        elif kind=='tool_result':
            action=clean_text(str(item.get('action','tool')))[:64]
            result=item.get('result')
            if isinstance(result,dict) and result.get('denied'):
                self.text('  Tool not approved · '+action, 'yellow');return
            if action=='create_artifact' and isinstance(result,dict) and result.get('sha256'):
                name=PurePosixPath(str(result.get('path','document'))).name
                self.text('  File ready · '+name, 'green')
            elif action=='simulate_forecast':self.text('  Calculation completed · simulate_forecast', 'green')
            else:self.text('  Tool completed · '+action, 'dim')
        elif kind=='tool_error':self.text('  Tool needs attention · '+str(item.get('message','Unavailable')), 'yellow')

    def remote_event(self, item):
        self.text('  Hosted task · '+str(item.get('status','pending')), 'dim')
        for event in item.get('events',[]):
            # Event metadata identifies observations; raw arguments, source text
            # and model responses are never dumped to the console as progress.
            key=(event.get('kind'),event.get('at'),event.get('action'),event.get('task_id'))
            if key not in self.seen_remote:
                self.seen_remote.add(key);self.event(event)

    def answer(self, value):
        body=Text(clean_text(str(value)))
        if self.rich:self.console.print(Panel(body,title=Text('Qentl',style='bold cyan'),border_style='bright_black',box=box.ROUNDED,padding=(1,2)))
        else:
            self.text('\nQentl');self.console.print(body);self.text('')

    def status(self, value, *, context, project=None):
        # Status may contain operator endpoints or credential-related fields.
        # Present only selected non-sensitive operational facts.
        value=value if isinstance(value,dict) else {}
        limits=value.get('limits') if isinstance(value.get('limits'),dict) else {}
        self.text('Context · '+context+(' · '+str(project) if project else ''), 'cyan')
        self.text('Model · '+(value['model'] if isinstance(value.get('model'),str) and value['model'] else 'Selected by the hosted project'))
        if type(value.get('ready')) is bool:self.text('Ready · '+('yes' if value['ready'] else 'no'))
        for label,item in [('Context tokens',limits.get('context_tokens',value.get('context_tokens'))),
                           ('Output token limit',limits.get('effective_output_tokens',limits.get('max_new_tokens')))]:
            if type(item) is int and item>=0:self.text(label+' · '+str(item))

    def artifacts(self, rows):
        if not rows:self.text('No generated files in this conversation yet. Ask for a PDF, PPTX or Excel file.');return
        self.text('Generated files · /download NUMBER', 'bold cyan')
        for row in rows:
            self.text(str(row['number'])+'. '+str(row['name'])+'  SHA-256 '+str(row['sha256'])[:12])

    def skills(self, report):
        self.text('Programming references · '+str(report['topic']), 'bold cyan')
        self.text('Read-only recipes. Retrieval does not update weights or execute a compiler.')
        rows=report['records']
        if not rows:
            self.text('No verified recipe for this language; showing the general workflow.', 'yellow')
            for index,step in enumerate(report['workflow'],1):self.text(str(index)+'. '+step['action'])
            return
        for row in rows:
            verification=row['verification']
            status={'verified_tiny_interpreter':'Three bounded cases verified by the tiny interpreter',
                    'not_executed':'Reference only; compiler/runtime not executed',
                    'reference_only':'Reference only; no document created'}.get(verification['status'],verification['status'])
            self.text(row['id']+' · '+status, 'cyan')
            if report['topic']=='all':continue
            self.text(row['requirement'])
            example=row.get('solution') or json.dumps(row.get('tool_example'),ensure_ascii=False,indent=2)
            if self.rich:
                from rich.syntax import Syntax
                language={'cpp':'cpp','csharp':'csharp','artifacts':'json','shell':'bash'}.get(row['topic'],row['topic'])
                self.console.print(Syntax(clean_text(example),language,theme='monokai',word_wrap=True,padding=1))
            else:self.text(example)
            for error in row.get('common_errors',[]):self.text('Review · '+error['correction'])
            self.text(verification['reason'])
        if report['topic']=='all':self.text('Use /skills python, /skills rust, /skills c++ or /skills artifacts for an example.')

    def result(self, status):
        self.text('Task · '+str(status), 'green' if status=='COMPLETED' else 'yellow')

    def error(self, value):self.text('Request needs attention · '+str(value), 'yellow')
