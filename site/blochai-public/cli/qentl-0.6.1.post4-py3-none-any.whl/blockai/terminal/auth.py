"""Native, invite-only Qentl authentication at one fixed HTTPS origin."""
from __future__ import annotations

import json
import re
import time

import httpx

from .config import BlochAIError, config_home, save_json
from .file_permissions import is_private

ORIGIN = 'https://qentl.ai'
COOKIE = '__Host-qentl_session'
TOKEN = re.compile(r'[a-f0-9]{64}')


def session_path():
    return config_home() / 'qentl-session.json'


def _identity(data):
    if (not isinstance(data,dict) or not data.get('authenticated')
            or not isinstance(data.get('organization'),dict) or not isinstance(data.get('user'),dict)
            or not isinstance(data['user'].get('id'),str) or not data['user']['id']
            or not isinstance(data['organization'].get('id'),str) or not data['organization']['id']):
        raise BlochAIError('The Qentl session expired. Run qentl login.')
    return data



class SignInRequired(BlochAIError):
    """The saved session is missing, expired or no longer accepted; signing in again fixes it."""

class QentlSession:
    def __init__(self, token='', transport=None):
        if not isinstance(token,str) or token and not TOKEN.fullmatch(token):
            raise BlochAIError('Invalid Qentl session. Run qentl login.')
        self._token=token
        self.http=httpx.Client(base_url=ORIGIN,follow_redirects=False,trust_env=False,timeout=20,
                               transport=transport,headers={'Origin':ORIGIN,'X-BlochAI-Action':'1'})
        if token:self.http.headers['Authorization']='Bearer '+token

    def close(self):self.http.close()

    @property
    def token(self):return self._token

    def request(self,method,path,**kwargs):
        allowed={'/api/cli/login','/api/cli/invitations/accept','/api/auth/session','/api/auth/logout',
                 '/api/accounts/capabilities','/api/account-invitations','/api/account-resets','/api/accounts/revoke'}
        if method not in ('GET','POST') or not isinstance(path,str) or (path not in allowed and not re.fullmatch(r'/api/account-invitations/[a-f0-9]{32}/revoke',path)):
            raise BlochAIError('Invalid Qentl authentication request.')
        try:
            with self.http.stream(method,path,**kwargs) as response:
                if response.status_code==429:raise BlochAIError('Qentl sign-in rate limit reached. Wait before trying again.')
                if response.status_code in (401,403):raise SignInRequired('Your Qentl sign-in has expired or was rejected.')
                if response.status_code>=300:raise BlochAIError(f'Qentl request failed (HTTP {response.status_code}).')
                raw=bytearray()
                for chunk in response.iter_bytes():
                    if len(raw)+len(chunk)>65536:raise BlochAIError('Unexpected Qentl authentication response size.')
                    raw.extend(chunk)
                data=json.loads(raw)
                if not isinstance(data,dict):raise ValueError('object required')
                return data
        except (httpx.HTTPError,ValueError,UnicodeError) as exc:
            raise BlochAIError('Cannot reach or validate the Qentl authentication service.') from exc

    def login(self,email,password):
        if not isinstance(email,str) or not 3<=len(email)<=254 or not isinstance(password,str) or not 14<=len(password)<=128:
            raise BlochAIError('Use your Qentl email and 14..128-character password. New accounts require an invitation.')
        result=self.request('POST','/api/cli/login',json={'email':email.strip(),'password':password})
        return self._establish(result)

    def accept_invitation(self,email,password,token):
        if (not isinstance(email,str) or not 3<=len(email)<=254 or not isinstance(password,str)
                or not 14<=len(password)<=128 or not isinstance(token,str) or not TOKEN.fullmatch(token)):
            raise BlochAIError('Provide the invited Qentl email, 14..128-character password and valid one-time invitation code.')
        return self._establish(self.request('POST','/api/cli/invitations/accept',json={'email':email.strip(),'password':password,'token':token}))

    def _establish(self,result):
        token=result.get('token')
        if not isinstance(token,str) or not TOKEN.fullmatch(token):raise BlochAIError('Qentl did not establish a session.')
        identity=_identity(result.get('identity'))
        self._token=token;self.http.headers['Authorization']='Bearer '+token
        return identity

    def identity(self):return _identity(self.request('GET','/api/auth/session'))

    def switch(self,organization):
        identity=self.identity()
        if organization!=identity['organization']['id']:
            raise BlochAIError('Qentl projects use your native account workspace; external organizations cannot be selected.')
        return identity

    def logout(self):return self.request('POST','/api/auth/logout',json={})

    def save(self,identity):
        _identity(identity)
        if not TOKEN.fullmatch(self.token):raise BlochAIError('No authenticated Qentl session to save.')
        save_json(session_path(),{'schema':'qentl-native-session-v1','token':self.token,
                                 'origin':ORIGIN,'saved_at':time.time()})


# Existing application adapters inject this name. It now always uses Qentl.
PortalSession=QentlSession


def saved_token():
    path=session_path()
    try:
        if not is_private(path) or path.stat().st_size>4096:
            raise BlochAIError('Sign in with qentl login. The session file must be private (mode 600).')
        data=json.loads(path.read_text(encoding='utf-8'))
        if (not isinstance(data,dict) or data.get('schema')!='qentl-native-session-v1'
                or data.get('origin')!=ORIGIN or not isinstance(data.get('token'),str)
                or not TOKEN.fullmatch(data['token'])):raise ValueError('invalid session')
        return data['token']
    except (OSError,ValueError,TypeError) as exc:
        raise BlochAIError('No valid Qentl session. Run qentl login.') from exc
