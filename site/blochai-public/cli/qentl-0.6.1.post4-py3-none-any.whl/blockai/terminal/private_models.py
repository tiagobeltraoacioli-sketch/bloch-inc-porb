"""Operator configuration, never accepted from project files or HTTP inputs."""
from __future__ import annotations

import json
import hashlib

from .config import BlochAIError, Settings, config_home
from .file_permissions import is_private


def private_model(owner, path=None):
    path = path or config_home() / 'private-provider.json'
    if not path.exists():
        return None
    try:
        if not is_private(path) or path.stat().st_size > 8192:
            raise ValueError('Private operator configuration required.')
        data = json.loads(path.read_text(encoding='utf-8'))
        allowed = {'url', 'model', 'model_digest', 'token_file', 'max_output_tokens', 'timeout'}
        if set(data) - allowed:
            raise ValueError('Unsupported private provider option.')
        settings = Settings(provider='private', tenant=owner, token_env='BLOCHAI_PRIVATE_SERVICE_TOKEN', **data).validate()
        return settings
    except (OSError, ValueError, TypeError) as exc:
        raise BlochAIError('Configuração do servidor privado inválida; o operador precisa revisar private-provider.json.') from exc


def terminal_models():
    """Every model this computer may use, the chosen default first."""
    from .config import load_settings
    from .auth import PortalSession, saved_token
    settings = load_settings()
    if settings.provider not in ('qentl','rednblue'):
        return [settings]
    if not (config_home() / 'private-provider.json').exists():
        if settings.provider=='rednblue' and (settings.token_file or settings.token()):return [settings]
        raise BlochAIError('Use qentl run TASK --remote --project ID --requirement ID for hosted development, or configure a private model/local Ollama for this computer.')
    portal = PortalSession(saved_token())
    try:
        identity = portal.identity()
        user = identity.get('user', {}).get('id') or identity.get('user', {}).get('email')
        organization = identity.get('organization', {}).get('id')
        if not isinstance(user, str) or not user or not isinstance(organization, str) or not organization:
            raise BlochAIError('Qentl did not confirm the account workspace.')
        owner = hashlib.sha256((user + '\0' + organization).encode()).hexdigest()[:24]
        choices = private_models(owner)
    finally:
        portal.close()
    chosen = chosen_model()
    return sorted(choices, key=lambda item: item.model != chosen)


def terminal_settings():
    """Use the operator GPU with the freshly verified native Qentl account."""
    return terminal_models()[0]


def chosen_model():
    """The model name picked with /model, if it was ever picked on this computer."""
    path = config_home() / 'model-choice'
    try:
        return path.read_text(encoding='utf-8').strip()[:120] if path.is_file() and not path.is_symlink() else ''
    except OSError:
        return ''


def choose_model(name, choices):
    """Resolve a typed name against the available models and remember it."""
    from .config import private_directory
    wanted = name.strip().casefold()
    exact = [item for item in choices if item.model.casefold() == wanted]
    partial = exact or [item for item in choices if wanted and wanted in item.model.casefold()]
    if len(partial) != 1:
        raise BlochAIError('Choose one of: ' + ', '.join(item.model for item in choices))
    private_directory(config_home())
    (config_home() / 'model-choice').write_text(partial[0].model + '\n', encoding='utf-8')
    return partial[0]


def private_models(owner):
    primary = private_model(owner)
    choices = [primary] if primary else []
    directory = config_home() / 'private-providers'
    if directory.is_symlink():
        raise BlochAIError('Diretório de modelos privados inválido.')
    for path in sorted(directory.glob('*.json'))[:8]:
        item = private_model(owner, path)
        if item.model in {row.model for row in choices}:
            raise BlochAIError('Cada modelo privado precisa ter um identificador único.')
        choices.append(item)
    return choices
