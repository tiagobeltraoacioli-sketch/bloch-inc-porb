"""Download a qentl.ai project's source files into one chosen local folder.

Read-only on the site. A file edited locally since its last download is never
overwritten: it is reported as a conflict and the local version is kept.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import tempfile
import time
from pathlib import Path

from .config import BlochAIError, save_json, state_home
from .file_permissions import is_private
from .project_lock import project_write_lock
from .projects import CODE_EXTENSIONS
from .remote_projects import HEX16, HEX64, ORIGIN, _CREDENTIAL, local_hash, project_id, relative_path, scan_folder
from .store import scrub
from .workspace import Workspace

CODE_ID = re.compile(r'code:[a-f0-9]{16}')
BINDING_PATH = re.compile(r'sync/([a-f0-9]{16})/([^/]+)/')


def source_nodes(session, project):
    """The site's own list of this project's source files, validated before use."""
    graph = session.request('GET', f'/api/projects/{project_id(project)}/knowledge').get('graph')
    nodes = graph.get('nodes') if isinstance(graph, dict) else None
    if not isinstance(nodes, list) or len(nodes) > 200000:
        raise BlochAIError('Qentl.ai returned an invalid project file list.')
    rows = {}
    for node in nodes:
        if not isinstance(node, dict) or node.get('kind') != 'code':
            continue
        identifier, path = node.get('id'), node.get('path')
        try:
            valid = isinstance(identifier, str) and CODE_ID.fullmatch(identifier) and relative_path(path) == path
        except BlochAIError:
            valid = False
        if valid:
            rows[path] = identifier
    stored, shown = graph.get('stored_source_files'), graph.get('displayed_source_files')
    truncated = type(stored) is int and type(shown) is int and stored > shown
    return rows, truncated


def sync_bindings(session, project):
    """Folders this project already syncs with a terminal: {binding id: folder name}."""
    rows, _ = source_nodes(session, project)
    found = {}
    for path in rows:
        match = BINDING_PATH.match(path)
        if match:
            found[match.group(1)] = match.group(2)
    return found


class ProjectClone:
    def __init__(self, session, project, root):
        self.session = session; self.project = project_id(project); selected = Path(root).expanduser()
        if selected.is_symlink() or (selected.exists() and not selected.is_dir()):
            raise BlochAIError('Choose a local directory for --workspace, not a file or symbolic link.')
        if not selected.exists():
            if not selected.parent.is_dir():
                raise BlochAIError('Create the parent folder first: ' + str(selected.parent))
            selected.mkdir(mode=0o755)
        self.root = selected.resolve(); self.workspace = Workspace(self.root, lambda *_: True, allow_commands=False)
        key = hashlib.sha256((self.project + '\0' + str(self.root)).encode()).hexdigest()
        self.path = state_home() / 'remote-projects' / session.owner / ('clone-' + key + '.json')
        self.baseline = self._load()

    def _load(self):
        if not self.path.exists():
            return {}
        if not is_private(self.path) or self.path.stat().st_size > 16 * 1024 * 1024:
            raise BlochAIError('The local download record must be a private regular file.')
        try:
            data = json.loads(self.path.read_text(encoding='utf-8'))
        except (OSError, ValueError) as exc:
            raise BlochAIError('The local download record is invalid.') from exc
        files = data.get('files') if isinstance(data, dict) else None
        if (not isinstance(data, dict) or data.get('schema') != 'qentl-project-clone-v1' or data.get('origin') != ORIGIN
                or data.get('owner') != self.session.owner or data.get('project') != self.project
                or data.get('workspace') != str(self.root) or not isinstance(files, dict)
                or any(not isinstance(path, str) or not HEX64.fullmatch(str(digest)) for path, digest in files.items())):
            raise BlochAIError('The download record does not match this account, project and directory.')
        return files

    def _fetch(self, identifier, path):
        file = self.session.request('GET', f'/api/projects/{self.project}/code/{identifier}').get('file')
        content = file.get('content') if isinstance(file, dict) else None
        if not isinstance(content, str) or file.get('path') != path:
            raise BlochAIError('Qentl.ai returned an invalid file. No further files were written.')
        raw = content.encode('utf-8')
        if len(raw) > 1_000_000 or hashlib.sha256(raw).hexdigest() != file.get('sha256'):
            raise BlochAIError('A downloaded file did not match its checksum. No further files were written.')
        return raw, content

    def _write(self, path, raw):
        file = self.workspace.path(path); file.parent.mkdir(parents=True, exist_ok=True); self.workspace.path(path)
        mode = stat.S_IMODE(file.stat().st_mode) if file.exists() else 0o644
        fd, temporary = tempfile.mkstemp(prefix='.qentl-clone-', dir=file.parent)
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(raw)
            os.chmod(temporary, mode); os.replace(temporary, file)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def once(self, *, dry_run=False, notify=lambda _row: None):
        rows, truncated = source_nodes(self.session, self.project)
        changes, conflicts, skipped, unchanged = [], [], [], 0
        baseline = dict(self.baseline)
        with project_write_lock(self.root):
            for index, (path, identifier) in enumerate(sorted(rows.items()), 1):
                raw, content = self._fetch(identifier, path)
                digest = hashlib.sha256(raw).hexdigest()
                if any(ord(char) < 32 and char not in '\t\r\n' for char in content) or _CREDENTIAL.search(content) \
                        or scrub(content, self.session.secrets) != content:
                    skipped.append({'path': path, 'reason': 'protected_or_binary_content'}); continue
                current = local_hash(self.workspace.path(path))
                if current == digest:
                    baseline[path] = digest; unchanged += 1
                elif current is None or current == baseline.get(path):
                    changes.append({'path': path, 'action': 'create' if current is None else 'update'})
                    if not dry_run:
                        self._write(path, raw); baseline[path] = digest
                else:
                    conflicts.append(path)
                if index % 25 == 0 or index == len(rows):
                    notify({'checked_files': index, 'total_files': len(rows)})
            if not dry_run:
                self._save(baseline)
        report = {'direction': 'clone', 'dry_run': dry_run, 'project': self.project, 'workspace': str(self.root),
                  'changes': changes, 'unchanged': unchanged, 'skipped': skipped, 'site_modified': False}
        if conflicts:
            report['kept_local'] = conflicts
            report['note'] = 'Files listed in kept_local were edited here and were not overwritten.'
        if truncated:
            report['incomplete'] = 'The site lists only part of this project; some files were not downloaded.'
        return report

    def _save(self, baseline):
        self.baseline = baseline
        save_json(self.path, {'schema': 'qentl-project-clone-v1', 'origin': ORIGIN, 'owner': self.session.owner,
                              'project': self.project, 'workspace': str(self.root), 'files': baseline,
                              'updated_at': time.time()})

    def plan_push(self):
        """Compare this folder with the site without changing either."""
        rows, _ = source_nodes(self.session, self.project)
        local, skipped = scan_folder(self.root, self.session.secrets, retain_content=True)
        updates, creates, site_changed, unchanged = [], [], [], 0
        baseline = dict(self.baseline)
        for path, row in sorted(local.items()):
            name = Path(path)
            if path.split('/')[0] in ('uploads', 'knowledge', 'artifacts', 'sync') or (
                    name.suffix.lower() not in CODE_EXTENSIONS and name.name not in ('Dockerfile', 'Makefile')):
                skipped.append({'path': path, 'reason': 'not_a_site_source_file'}); continue
            if row['bytes'] > 100000:
                skipped.append({'path': path, 'reason': 'over_100_kb_site_edit_limit'}); continue
            content = row['raw'].decode('utf-8')
            if path not in rows:
                creates.append({'path': path, 'content': content, 'sha256': row['sha256']}); continue
            site_raw, _ = self._fetch(rows[path], path)
            site_digest = hashlib.sha256(site_raw).hexdigest()
            if site_digest == row['sha256']:
                baseline[path] = site_digest; unchanged += 1
            elif site_digest == baseline.get(path):
                updates.append({'path': path, 'id': rows[path], 'content': content, 'sha256': row['sha256'], 'revision': site_digest})
            else:
                site_changed.append(path)
        return {'updates': updates, 'creates': creates, 'site_changed': site_changed, 'unchanged': unchanged,
                'skipped': skipped, 'baseline': baseline}

    def push(self, plan, *, notify=lambda _row: None):
        """Publish reviewed changes; each one is a revision in the site's file history."""
        baseline, sent = plan['baseline'], []
        base = f'/api/projects/{self.project}/code'
        try:
            for row in plan['creates'] + plan['updates']:
                identifier, revision = row.get('id'), row.get('revision')
                if identifier is None:
                    created = self.session.request('POST', base, {'path': row['path']}).get('file')
                    if not isinstance(created, dict) or created.get('path') != row['path'] or not CODE_ID.fullmatch(str(created.get('id'))) \
                            or not HEX64.fullmatch(str(created.get('sha256'))):
                        raise BlochAIError('Qentl.ai did not confirm the new file. Check the project before retrying.')
                    identifier, revision = created['id'], created['sha256']
                    if not row['content']:
                        baseline[row['path']] = revision; sent.append({'path': row['path'], 'action': 'create'}); continue
                proposal = self.session.request('POST', f'{base}/{identifier}/preview', {'content': row['content'], 'revision': revision}).get('proposal')
                if not isinstance(proposal, dict) or not HEX16.fullmatch(str(proposal.get('id'))) or proposal.get('path') != row['path']:
                    raise BlochAIError('Qentl.ai did not return a valid comparison. Nothing more was sent.')
                self.session.request('POST', f'{base}/{identifier}/apply', {'proposal_id': proposal['id'], 'approved': True})
                baseline[row['path']] = row['sha256']
                sent.append({'path': row['path'], 'action': 'update' if row.get('revision') else 'create'})
                notify({'sent_files': len(sent), 'total_files': len(plan['creates']) + len(plan['updates'])})
        finally:
            self._save(baseline)  # what was confirmed stays recorded even if a later file fails
        return sent
