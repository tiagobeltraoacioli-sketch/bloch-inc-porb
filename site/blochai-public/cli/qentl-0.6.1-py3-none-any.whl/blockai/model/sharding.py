"""Plano de particionamento (pipeline-parallel) de um modelo entre nós de GPU.

v0 executa o modelo inteiro em cada nó. Este módulo calcula como as camadas
de um modelo maior seriam distribuídas pela VRAM disponível na rede — base
para o roadmap de inferência fragmentada.
"""
from __future__ import annotations

from typing import Dict, List

from pydantic import BaseModel, Field

from ..chain.state import NodeInfo

# aproximações (fp16) para modelos Qwen2.5
MODEL_PROFILES: Dict[str, Dict[str, float]] = {
    "Qwen/Qwen2.5-0.5B-Instruct": {"layers": 24, "layer_mb": 30, "embed_mb": 300},
    "Qwen/Qwen2.5-1.5B-Instruct": {"layers": 28, "layer_mb": 90, "embed_mb": 600},
    "Qwen/Qwen2.5-7B-Instruct": {"layers": 28, "layer_mb": 480, "embed_mb": 1100},
    "Qwen/Qwen2.5-14B-Instruct": {"layers": 48, "layer_mb": 560, "embed_mb": 1400},
    "Qwen/Qwen2.5-72B-Instruct": {"layers": 80, "layer_mb": 1700, "embed_mb": 3000},
}


class Shard(BaseModel):
    node: str
    layer_start: int
    layer_end: int  # exclusivo
    est_mb: float


class ShardPlan(BaseModel):
    model: str
    total_layers: int
    shards: List[Shard] = Field(default_factory=list)
    feasible: bool = True
    reason: str = ""


def plan_shards(model: str, nodes: List[NodeInfo], headroom: float = 0.85) -> ShardPlan:
    profile = MODEL_PROFILES.get(model)
    if profile is None:
        return ShardPlan(model=model, total_layers=0, feasible=False, reason="perfil de modelo desconhecido")
    layers = int(profile["layers"])
    plan = ShardPlan(model=model, total_layers=layers)
    ranked = sorted(nodes, key=lambda n: -n.gpu.memory_mb)
    next_layer = 0
    for i, node in enumerate(ranked):
        if next_layer >= layers:
            break
        budget = node.gpu.memory_mb * node.gpu.count * headroom
        if i == 0:
            budget -= profile["embed_mb"]
        fit = int(budget // profile["layer_mb"])
        if fit <= 0:
            continue
        end = min(layers, next_layer + fit)
        plan.shards.append(Shard(node=node.address, layer_start=next_layer, layer_end=end,
                                 est_mb=(end - next_layer) * profile["layer_mb"]))
        next_layer = end
    if next_layer < layers:
        plan.feasible = False
        plan.reason = f"VRAM insuficiente na rede: {next_layer}/{layers} camadas alocadas"
    return plan
