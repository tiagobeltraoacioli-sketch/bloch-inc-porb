"""Backends de inferência executados pelos nós de GPU.

- `QwenBackend`: modelos Qwen via `transformers` (decodificação gulosa para que
  nós distintos produzam a mesma saída e alcancem consenso).
- `MockBackend`: gerador determinístico sem dependências, para desenvolvimento
  e testes sem GPU.
"""
from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from typing import List, Optional

import httpx

from ..chain.crypto import sha256


@dataclass
class GenerationResult:
    text: str
    output_hash: str
    tokens_generated: int
    latency_ms: float


def hash_tokens(token_ids: List[int]) -> str:
    """Hash canônico da saída: sobre os ids dos tokens, robusto a detalhes de detokenização."""
    return sha256(",".join(str(t) for t in token_ids).encode())


class InferenceBackend:
    name = "base"

    def load(self) -> None:  # pragma: no cover - interface
        pass

    def generate(self, prompt: str, max_new_tokens: int) -> GenerationResult:  # pragma: no cover
        raise NotImplementedError

    def gpu_inference(self) -> bool:
        return False

    def is_ready(self) -> bool:
        return True

    def prepare(self) -> None:
        """Refresh recoverable runtime state before polling for another task."""
        pass


class MockBackend(InferenceBackend):
    """Gera texto pseudoaleatório determinístico a partir do prompt."""

    name = "mock"
    _VOCAB = ("block", "chain", "gpu", "tensor", "token", "node", "stake", "hash", "model", "layer",
              "attention", "compute", "proof", "reward", "consensus", "qwen", "inference", "shard",
              "latency", "epoch")

    def __init__(self, delay_s: float = 0.0, corrupt: bool = False):
        self.delay_s = delay_s
        self.corrupt = corrupt  # simula um nó malicioso/defeituoso

    def generate(self, prompt: str, max_new_tokens: int) -> GenerationResult:
        start = time.time()
        if self.delay_s:
            time.sleep(self.delay_s)
        seed = hashlib.sha256(prompt.encode()).digest()
        n = min(max_new_tokens, 24)
        ids: List[int] = []
        for i in range(n):
            b = hashlib.sha256(seed + i.to_bytes(4, "big")).digest()
            ids.append(b[0] % len(self._VOCAB))
        if self.corrupt:
            ids = [(t + 7) % len(self._VOCAB) for t in ids]
        text = " ".join(self._VOCAB[t] for t in ids)
        return GenerationResult(text=text, output_hash=hash_tokens(ids), tokens_generated=len(ids),
                                latency_ms=(time.time() - start) * 1000)


#: uso aproximado de VRAM (fp16, contexto curto) por modelo Qwen2.5 — usado
#: para orientar a escolha de modelo/quantização em GPUs de VRAM limitada.
QWEN_VRAM_GB = {
    "Qwen/Qwen2.5-0.5B-Instruct": 1.2,
    "Qwen/Qwen2.5-1.5B-Instruct": 3.5,
    "Qwen/Qwen2.5-3B-Instruct": 6.5,
    "Qwen/Qwen2.5-7B-Instruct": 15.0,
    "Qwen/Qwen2.5-14B-Instruct": 29.0,
    "Qwen/Qwen2.5-32B-Instruct": 65.0,
    "Qwen/Qwen2.5-72B-Instruct": 145.0,
}
#: fator aproximado de redução de VRAM por modo de quantização, sobre o valor fp16 acima
QUANT_FACTOR = {None: 1.0, "8bit": 0.55, "4bit": 0.32}


def fits_in_vram(model_id: str, vram_gb: float, quantization: Optional[str] = None, headroom: float = 0.85) -> bool:
    """Estimativa grosseira de que `model_id` cabe em `vram_gb` de VRAM com a
    quantização dada (deixa margem para o contexto/ativações)."""
    base = QWEN_VRAM_GB.get(model_id)
    if base is None:
        return True  # modelo desconhecido: não bloqueia, apenas não orienta
    return base * QUANT_FACTOR.get(quantization, 1.0) <= vram_gb * headroom


def recommend_model(vram_gb: float, quantization: Optional[str] = None) -> str:
    """Maior modelo Qwen2.5 (na quantização dada) que cabe na VRAM informada."""
    best = "Qwen/Qwen2.5-0.5B-Instruct"
    for model_id, base in sorted(QWEN_VRAM_GB.items(), key=lambda kv: kv[1]):
        if fits_in_vram(model_id, vram_gb, quantization):
            best = model_id
    return best


class QwenBackend(InferenceBackend):
    name = "qwen"

    def __init__(self, model_id: str = "Qwen/Qwen2.5-0.5B-Instruct", device: Optional[str] = None,
                quantization: Optional[str] = None, revision: Optional[str] = None):
        """`device`: string do torch, ex. "cuda", "cuda:2", "mps", "cpu"; None autodetecta.
        `quantization`: None (fp16/fp32), "8bit" ou "4bit" (via bitsandbytes) —
        essencial para caber modelos maiores (ex. Qwen2.5-7B) em GPUs de 8 GB."""
        if quantization not in (None, "4bit", "8bit"):
            raise ValueError("quantization deve ser None, '4bit' ou '8bit'")
        self.model_id = model_id
        self.device = device
        self.quantization = quantization
        self.revision = revision
        self.model = None
        self.tokenizer = None

    def load(self) -> None:
        # validação barata que não exige torch instalado: se o dispositivo já foi
        # dado explicitamente e não é CUDA, falha cedo antes de qualquer import pesado.
        if self.quantization and self.device is not None and not self.device.startswith("cuda"):
            raise RuntimeError(f"quantization='{self.quantization}' exige uma GPU CUDA (dispositivo atual: {self.device})")

        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("instale as dependências: pip install 'blockai[qwen]'") from exc

        if self.device is None:
            if torch.cuda.is_available():
                self.device = "cuda"
            elif getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
                self.device = "mps"
            else:
                self.device = "cpu"
        dtype = torch.float16 if self.device.startswith(("cuda", "mps")) else torch.float32
        # The fleet's offline cache can contain a pinned snapshot without a
        # mutable refs/main file. Resolve tokenizer and weights identically.
        load_options = {"revision": self.revision} if self.revision else {}
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_id, **load_options)

        quant_config = None
        if self.quantization:
            if not self.device.startswith("cuda"):
                raise RuntimeError(f"quantization='{self.quantization}' exige uma GPU CUDA (dispositivo atual: {self.device})")
            try:
                from transformers import BitsAndBytesConfig
            except ImportError as exc:  # pragma: no cover
                raise RuntimeError("instale bitsandbytes: pip install 'blockai[qwen]' (inclui bitsandbytes)") from exc
            if self.quantization == "4bit":
                quant_config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.float16,
                                                  bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True)
            else:
                quant_config = BitsAndBytesConfig(load_in_8bit=True)

        if quant_config is not None:
            # com bitsandbytes, o device_map fixa o modelo inteiro no dispositivo indicado
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_id, quantization_config=quant_config, device_map={"": self.device}, **load_options)
        else:
            self.model = AutoModelForCausalLM.from_pretrained(self.model_id, torch_dtype=dtype, **load_options).to(self.device)
        self.model.eval()

    def gpu_inference(self) -> bool:
        if self.model is None:
            return False
        # Inspect the tensors actually loaded, not merely the requested device.
        return any(parameter.device.type in ("cuda", "mps") for parameter in self.model.parameters())

    def is_ready(self) -> bool:
        return self.model is not None and self.tokenizer is not None

    def generate(self, prompt: str, max_new_tokens: int) -> GenerationResult:
        if self.model is None:
            self.load()
        import torch

        messages = [{"role": "system", "content": "You are BlockAI, a helpful decentralized assistant."},
                    {"role": "user", "content": prompt}]
        text = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = self.tokenizer([text], return_tensors="pt")
        # Bound KV-cache allocation on the audited 2 GiB GPUs. Reject rather
        # than silently truncate a user's prompt.
        if inputs.input_ids.shape[1] + max_new_tokens > 2048:
            raise ValueError("Prompt and output exceed the 2048-token context budget")
        inputs = inputs.to(self.device)
        start = time.time()
        with torch.no_grad():
            out = self.model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False,
                                      temperature=None, top_p=None, top_k=None)
        new_ids = out[0][inputs.input_ids.shape[1]:].tolist()
        completion = self.tokenizer.decode(new_ids, skip_special_tokens=True)
        return GenerationResult(text=completion, output_hash=hash_tokens(new_ids), tokens_generated=len(new_ids),
                                latency_ms=(time.time() - start) * 1000)


class OllamaBackend(InferenceBackend):
    """Use an installed local Ollama model; never pull weights implicitly.

    Ollama exposes decoded text rather than output token IDs, so this backend
    hashes UTF-8 output. A private gateway schedules a single backend/model pair.
    """

    name = "ollama"

    def __init__(self, model_id: str = "qwen2.5:0.5b", url: str = "http://127.0.0.1:11434",
                 client: Optional[httpx.Client] = None):
        self.model_id = model_id
        self.http = client or httpx.Client(base_url=url.rstrip("/"), timeout=110.0)
        self.loaded = False

    def load(self) -> None:
        response = self.http.post("/api/show", json={"model": self.model_id}, timeout=5.0)
        response.raise_for_status()
        response = self.http.post("/api/generate", json={
            "model": self.model_id, "prompt": "", "stream": False, "keep_alive": -1,
            "options": {"num_ctx": 2048},
        })
        response.raise_for_status()
        if response.json().get("done") is not True:
            raise RuntimeError("Ollama model warmup did not complete")
        self.loaded = True

    def prepare(self) -> None:
        if not self.loaded:
            self.load()

    def is_ready(self) -> bool:
        if not self.loaded:
            return False
        try:
            response = self.http.get("/api/tags", timeout=5.0)
            response.raise_for_status()
            return any(m.get("model") == self.model_id or m.get("name") == self.model_id
                       for m in response.json().get("models", []))
        except (httpx.HTTPError, ValueError, TypeError):
            self.loaded = False
            return False

    def gpu_inference(self) -> bool:
        try:
            response = self.http.get("/api/ps", timeout=5.0)
            response.raise_for_status()
            matches = [m for m in response.json().get("models", [])
                       if m.get("model") == self.model_id or m.get("name") == self.model_id]
            if not matches:
                self.loaded = False  # The next idle poll warms up after a runtime restart.
            return any(int(m.get("size_vram", 0)) > 0 for m in matches)
        except (httpx.HTTPError, ValueError, TypeError):
            self.loaded = False
            return False

    def generate(self, prompt: str, max_new_tokens: int) -> GenerationResult:
        if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 4000:
            raise ValueError("Ollama prompt must contain 1..4000 nonblank characters")
        if type(max_new_tokens) is not int or not 1 <= max_new_tokens <= 256:
            raise ValueError("Ollama output is limited to 1..256 tokens")
        if not self.loaded:
            self.load()
        start = time.monotonic()
        response = self.http.post("/api/generate", json={
            "model": self.model_id, "prompt": prompt, "stream": False, "keep_alive": -1,
            "system": "You are BlochAI, a helpful assistant. Respond in the user's language.",
            "options": {"temperature": 0, "seed": 0, "num_predict": max_new_tokens, "num_ctx": 2048},
        })
        response.raise_for_status()
        data = response.json()
        output = data.get("response")
        if data.get("done") is not True or not isinstance(output, str) or not output.strip():
            raise RuntimeError("Ollama returned an incomplete or empty inference result")
        tokens = int(data.get("eval_count", 0))
        if tokens < 1 or tokens > max_new_tokens:
            raise RuntimeError("Ollama returned invalid output token accounting")
        return GenerationResult(text=output, output_hash=sha256(output.encode()), tokens_generated=tokens,
                                latency_ms=(time.monotonic() - start) * 1000)


def get_backend(name: str, model_id: Optional[str] = None, quantization: Optional[str] = None, **kwargs) -> InferenceBackend:
    if name == "mock":
        return MockBackend(**kwargs)
    if name == "qwen":
        return QwenBackend(model_id=model_id or "Qwen/Qwen2.5-0.5B-Instruct", quantization=quantization, **kwargs)
    if name == "ollama":
        if quantization:
            raise ValueError("Ollama quantization belongs to its installed model tag")
        return OllamaBackend(model_id=model_id or "qwen2.5:0.5b", **kwargs)
    raise ValueError(f"backend desconhecido: {name}")
