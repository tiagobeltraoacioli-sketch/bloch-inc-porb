"""Proof-of-Compute: consenso sobre o resultado de uma tarefa de inferência.

Cada tarefa é executada por `replication` nós. O resultado vencedor é o hash
de saída com maioria; se não houver maioria exata (ex.: diferenças numéricas
entre GPUs), agrupamos por similaridade textual. Nós no grupo vencedor
recebem a taxa (menos o corte do protocolo) + subsídio; nós divergentes têm
parte do stake cortada (slashing). Sem consenso, o usuário é reembolsado.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from difflib import SequenceMatcher
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from .state import State, TaskRecord, TaskResult

SIMILARITY_THRESHOLD = 0.92


class Settlement(BaseModel):
    task_id: str
    success: bool = False
    winner_hash: Optional[str] = None
    output: Optional[str] = None
    agreeing: List[str] = Field(default_factory=list)
    disagreeing: List[str] = Field(default_factory=list)
    missing: List[str] = Field(default_factory=list)
    rewards: Dict[str, int] = Field(default_factory=dict)
    slashes: Dict[str, int] = Field(default_factory=dict)
    treasury_cut: int = 0
    subsidy: int = 0
    refund: int = 0

    def to_payload(self) -> dict:
        return self.model_dump(mode="json")


def _similar(a: str, b: str) -> bool:
    if a == b:
        return True
    return SequenceMatcher(None, a, b).ratio() >= SIMILARITY_THRESHOLD


def cluster_results(results: List[TaskResult]) -> List[List[TaskResult]]:
    """Agrupa resultados: primeiro por hash exato, depois funde grupos com texto similar."""
    by_hash: Dict[str, List[TaskResult]] = defaultdict(list)
    for r in results:
        by_hash[r.output_hash].append(r)
    groups = list(by_hash.values())
    merged: List[List[TaskResult]] = []
    for g in groups:
        for m in merged:
            if _similar(m[0].output, g[0].output):
                m.extend(g)
                break
        else:
            merged.append(list(g))
    merged.sort(key=lambda g: (-len(g), min(r.submitted_at for r in g)))
    return merged


def settle_task(state: State, task: TaskRecord, *, force: bool = False) -> Settlement:
    """Decide o vencedor. `force=True` liquida mesmo com resultados faltando (timeout)."""
    results = list(task.results.values())
    missing = [n for n in task.assigned if n not in task.results]
    if missing and not force:
        raise ValueError("resultados incompletos")

    s = Settlement(task_id=task.task_id, missing=missing)
    params = state.params
    quorum = len(task.assigned) // 2 + 1  # maioria dos designados

    groups = cluster_results(results) if results else []
    winner = groups[0] if groups else []
    has_consensus = len(winner) >= quorum or (len(task.assigned) == 1 and len(winner) == 1)

    if not has_consensus:
        s.success = False
        s.refund = task.fee
        # quem não entregou perde reputação/stake como quem divergiu
        for n in missing:
            s.slashes[n] = state.nodes[n].stake * params.slash_bps // 10_000
            s.disagreeing.append(n)
        return s

    s.success = True
    s.winner_hash = winner[0].output_hash
    s.output = winner[0].output
    s.agreeing = [r.node for r in winner]
    losers = [r.node for g in groups[1:] for r in g] + missing
    s.disagreeing = losers

    s.treasury_cut = task.fee * params.protocol_cut_bps // 10_000
    s.subsidy = min(params.block_subsidy, state.balance(params.treasury))
    pool = task.fee - s.treasury_cut + s.subsidy
    # recompensa proporcional aos tokens gerados (mínimo 1 para evitar divisão por zero)
    weights = {r.node: max(r.tokens_generated, 1) for r in winner}
    total_w = sum(weights.values())
    distributed = 0
    for i, (node, w) in enumerate(weights.items()):
        amt = pool * w // total_w if i < len(weights) - 1 else pool - distributed
        s.rewards[node] = amt
        distributed += amt
    for n in losers:
        s.slashes[n] = state.nodes[n].stake * params.slash_bps // 10_000
    return s
