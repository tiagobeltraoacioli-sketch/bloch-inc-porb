"""Blocos: cabeçalho assinado pelo proponente + lista de transações."""
from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .crypto import KeyPair, canonical_json, sha256, verify_signature
from .transaction import Transaction


def merkle_root(hashes: List[str]) -> str:
    if not hashes:
        return sha256(b"")
    layer = list(hashes)
    while len(layer) > 1:
        if len(layer) % 2 == 1:
            layer.append(layer[-1])
        layer = [sha256((layer[i] + layer[i + 1]).encode()) for i in range(0, len(layer), 2)]
    return layer[0]


class Block(BaseModel):
    index: int
    prev_hash: str
    timestamp: float = Field(default_factory=lambda: time.time())
    transactions: List[Transaction] = Field(default_factory=list)
    proposer: str
    proposer_pubkey: str
    merkle_root: str = ""
    signature: Optional[str] = None

    def header(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "prev_hash": self.prev_hash,
            "timestamp": self.timestamp,
            "merkle_root": self.merkle_root,
            "proposer": self.proposer,
            "proposer_pubkey": self.proposer_pubkey,
            "tx_count": len(self.transactions),
        }

    def compute_merkle(self) -> str:
        self.merkle_root = merkle_root([tx.hash for tx in self.transactions])
        return self.merkle_root

    @property
    def hash(self) -> str:
        return sha256(canonical_json(self.header()))

    def sign(self, kp: KeyPair) -> "Block":
        self.compute_merkle()
        self.signature = kp.sign(canonical_json(self.header()))
        return self

    def verify_signature(self) -> bool:
        if not self.signature:
            return False
        if merkle_root([tx.hash for tx in self.transactions]) != self.merkle_root:
            return False
        return verify_signature(self.proposer_pubkey, canonical_json(self.header()), self.signature)
