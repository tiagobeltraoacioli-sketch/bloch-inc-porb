"""Blockchain: gênesis, mempool, produção de blocos, validação e persistência.

v0 usa um único proponente (a autoridade/coordenador) — Proof-of-Authority
para a ordenação de blocos, Proof-of-Compute para a validação do trabalho
das GPUs. Múltiplos proponentes estão no roadmap (ver docs/ARCHITECTURE.md).
"""
from __future__ import annotations

import json
import os
import threading
import time
from typing import Dict, List, Optional

from .block import Block
from .crypto import KeyPair
from .state import ChainParams, State, StateError, TaskRecord, TaskStatus
from .transaction import Transaction, TxType
from . import consensus


class Blockchain:
    def __init__(self, authority: KeyPair, params: Optional[ChainParams] = None, path: Optional[str] = None):
        self.authority = authority
        self.path = path
        self.lock = threading.RLock()
        params = params or ChainParams()
        params.authority = authority.address
        params.authority_pubkey = authority.public_hex
        self.params = params
        self.blocks: List[Block] = []
        self.mempool: List[Transaction] = []
        self.state = State(params=params)
        self.tx_index: Dict[str, int] = {}  # tx hash -> índice do bloco

        if path and os.path.exists(path):
            self.load(path)
        else:
            self._create_genesis()

    # ----- gênesis -----------------------------------------------------------------
    def _create_genesis(self) -> None:
        self.state = State(params=self.params)
        self.state.balances[self.params.treasury] = self.params.genesis_supply
        genesis = Block(index=0, prev_hash="0" * 64, timestamp=0.0, proposer=self.authority.address,
                        proposer_pubkey=self.authority.public_hex)
        genesis.sign(self.authority)
        self.blocks = [genesis]

    # ----- consultas ---------------------------------------------------------------
    @property
    def head(self) -> Block:
        return self.blocks[-1]

    @property
    def height(self) -> int:
        return self.head.index

    def pending_nonce(self, addr: str) -> int:
        """Nonce que a próxima tx de `addr` deve usar (estado já inclui a mempool)."""
        return self.state.next_nonce(addr)

    # ----- transações --------------------------------------------------------------
    def submit_tx(self, tx: Transaction) -> str:
        """Valida e aplica ao estado pendente; a tx entra no próximo bloco."""
        with self.lock:
            if tx.hash in self.tx_index or any(t.hash == tx.hash for t in self.mempool):
                raise StateError("transação já conhecida")
            self.state.apply_tx(tx)
            self.mempool.append(tx)
            return tx.hash

    def system_tx(self, tx_type: TxType, payload: dict) -> Transaction:
        with self.lock:
            tx = Transaction.build(self.authority, tx_type, self.pending_nonce(self.authority.address), payload)
            self.submit_tx(tx)
            return tx

    # ----- tarefas -----------------------------------------------------------------
    def assign_task(self, task_id: str, nodes: List[str]) -> Transaction:
        return self.system_tx(TxType.TASK_ASSIGN, {"task_id": task_id, "nodes": nodes})

    def settle_ready_tasks(self, *, timeout_s: float = 0.0, now: Optional[float] = None) -> List[consensus.Settlement]:
        """Liquida tarefas READY; com `timeout_s`, também as ASSIGNED vencidas (força consenso parcial)."""
        now = now or time.time()
        out: List[consensus.Settlement] = []
        with self.lock:
            for task in list(self.state.tasks.values()):
                force = False
                if task.status == TaskStatus.READY:
                    pass
                elif task.status in (TaskStatus.PENDING, TaskStatus.ASSIGNED) and timeout_s and now - task.created_at > timeout_s:
                    force = True
                else:
                    continue
                s = consensus.settle_task(self.state, task, force=force)
                self.system_tx(TxType.TASK_SETTLE, s.to_payload())
                out.append(s)
        return out

    # ----- blocos ------------------------------------------------------------------
    def produce_block(self) -> Optional[Block]:
        with self.lock:
            if not self.mempool:
                return None
            block = Block(index=self.height + 1, prev_hash=self.head.hash, transactions=list(self.mempool),
                          proposer=self.authority.address, proposer_pubkey=self.authority.public_hex)
            block.sign(self.authority)
            self.blocks.append(block)
            for tx in block.transactions:
                self.tx_index[tx.hash] = block.index
            self.mempool = []
            if self.path:
                self.save(self.path)
            return block

    @staticmethod
    def validate_chain(blocks: List[Block], params: ChainParams) -> State:
        """Revalida blocos e reconstrói o estado do zero. Lança em qualquer inconsistência."""
        if not blocks or blocks[0].index != 0:
            raise ValueError("gênesis ausente")
        state = State(params=params)
        state.balances[params.treasury] = params.genesis_supply
        prev = blocks[0]
        if not prev.verify_signature() or prev.proposer != params.authority:
            raise ValueError("gênesis inválido")
        for b in blocks[1:]:
            if b.index != prev.index + 1 or b.prev_hash != prev.hash:
                raise ValueError(f"encadeamento quebrado no bloco {b.index}")
            if b.proposer != params.authority or not b.verify_signature():
                raise ValueError(f"assinatura inválida no bloco {b.index}")
            for tx in b.transactions:
                state.apply_tx(tx)
            prev = b
        return state

    # ----- persistência ------------------------------------------------------------
    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        data = {"params": self.params.model_dump(mode="json"), "blocks": [b.model_dump(mode="json") for b in self.blocks]}
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, path)

    def load(self, path: str) -> None:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        params = ChainParams(**data["params"])
        if params.authority != self.authority.address:
            raise ValueError("a chave do coordenador não corresponde à autoridade da cadeia salva")
        blocks = [Block(**b) for b in data["blocks"]]
        self.state = self.validate_chain(blocks, params)
        self.params = params
        self.blocks = blocks
        self.mempool = []
        self.tx_index = {tx.hash: b.index for b in blocks for tx in b.transactions}
