"""Primitivas criptográficas: hashing SHA-256, chaves Ed25519 e endereços."""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

ADDRESS_PREFIX = "bai"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_json(obj: Any) -> bytes:
    """Serialização determinística usada em hashes e assinaturas."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def hash_obj(obj: Any) -> str:
    return sha256(canonical_json(obj))


def address_from_pubkey(pubkey_hex: str) -> str:
    return ADDRESS_PREFIX + sha256(bytes.fromhex(pubkey_hex))[:40]


def verify_signature(pubkey_hex: str, data: bytes, signature_hex: str) -> bool:
    try:
        pub = Ed25519PublicKey.from_public_bytes(bytes.fromhex(pubkey_hex))
        pub.verify(bytes.fromhex(signature_hex), data)
        return True
    except (InvalidSignature, ValueError):
        return False


@dataclass
class KeyPair:
    """Par de chaves Ed25519 de uma conta (usuário, nó de GPU ou coordenador)."""

    private_key: Ed25519PrivateKey

    @classmethod
    def generate(cls) -> "KeyPair":
        return cls(Ed25519PrivateKey.generate())

    @classmethod
    def from_seed_hex(cls, seed_hex: str) -> "KeyPair":
        return cls(Ed25519PrivateKey.from_private_bytes(bytes.fromhex(seed_hex)))

    @property
    def seed_hex(self) -> str:
        raw = self.private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        return raw.hex()

    @property
    def public_hex(self) -> str:
        raw = self.private_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        return raw.hex()

    @property
    def address(self) -> str:
        return address_from_pubkey(self.public_hex)

    def sign(self, data: bytes) -> str:
        return self.private_key.sign(data).hex()

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump({"seed": self.seed_hex, "public": self.public_hex, "address": self.address}, fh, indent=2)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass

    @classmethod
    def load(cls, path: str) -> "KeyPair":
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return cls.from_seed_hex(data["seed"])

    @classmethod
    def load_or_create(cls, path: str) -> "KeyPair":
        if os.path.exists(path):
            return cls.load(path)
        kp = cls.generate()
        kp.save(path)
        return kp
