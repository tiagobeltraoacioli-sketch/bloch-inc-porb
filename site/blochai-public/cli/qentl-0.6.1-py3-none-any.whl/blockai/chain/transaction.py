"""Transações da BlockAI.

Transações de usuário/nó são assinadas pela chave do remetente.
Transações de sistema (TASK_ASSIGN, TASK_SETTLE, FAUCET) são assinadas pela
autoridade da cadeia (o coordenador) — ver `ChainParams.authority`.
"""
from __future__ import annotations

import time
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field

from .crypto import KeyPair, address_from_pubkey, canonical_json, sha256, verify_signature


class TxType(str, Enum):
    NODE_REGISTER = "NODE_REGISTER"   # nó de GPU entra na rede
    STAKE = "STAKE"                   # nó deposita garantia (stake)
    UNSTAKE = "UNSTAKE"
    TRANSFER = "TRANSFER"
    TASK_SUBMIT = "TASK_SUBMIT"       # usuário pede inferência e paga a taxa
    TASK_ASSIGN = "TASK_ASSIGN"       # [sistema] escalonador atribui a tarefa a N nós
    TASK_RESULT = "TASK_RESULT"       # nó devolve o resultado (com hash de saída)
    TASK_SETTLE = "TASK_SETTLE"       # [sistema] consenso: recompensas e slashing
    FAUCET = "FAUCET"                 # [sistema] só em modo dev

    @property
    def is_system(self) -> bool:
        return self in (TxType.TASK_ASSIGN, TxType.TASK_SETTLE, TxType.FAUCET)


class Transaction(BaseModel):
    type: TxType
    sender: str
    pubkey: str
    nonce: int
    payload: Dict[str, Any] = Field(default_factory=dict)
    timestamp: float = Field(default_factory=lambda: time.time())
    signature: Optional[str] = None

    # ----- hashing / assinatura -------------------------------------------------
    def signing_payload(self) -> Dict[str, Any]:
        return {
            "type": self.type.value,
            "sender": self.sender,
            "pubkey": self.pubkey,
            "nonce": self.nonce,
            "payload": self.payload,
            "timestamp": self.timestamp,
        }

    def signing_bytes(self) -> bytes:
        return canonical_json(self.signing_payload())

    @property
    def hash(self) -> str:
        return sha256(self.signing_bytes())

    def sign(self, kp: KeyPair) -> "Transaction":
        if kp.address != self.sender or kp.public_hex != self.pubkey:
            raise ValueError("chave não corresponde ao remetente da transação")
        self.signature = kp.sign(self.signing_bytes())
        return self

    def verify_signature(self) -> bool:
        if not self.signature:
            return False
        if address_from_pubkey(self.pubkey) != self.sender:
            return False
        return verify_signature(self.pubkey, self.signing_bytes(), self.signature)

    @classmethod
    def build(cls, kp: KeyPair, tx_type: TxType, nonce: int, payload: Dict[str, Any]) -> "Transaction":
        tx = cls(type=tx_type, sender=kp.address, pubkey=kp.public_hex, nonce=nonce, payload=payload)
        return tx.sign(kp)
