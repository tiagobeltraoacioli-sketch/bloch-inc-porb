"""Estado da cadeia: saldos, nós de GPU, tarefas e regras de transição.

Toda mutação de estado passa por `State.apply_tx`, que valida e aplica uma
transação. O estado é totalmente reconstruível reaplicando os blocos desde o
gênesis (ver `Blockchain.replay`).
"""
from __future__ import annotations

import time
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .crypto import hash_obj
from .transaction import Transaction, TxType

UNIT = 1_000_000  # 1 BAI = 1_000_000 unidades (inteiros evitam erros de ponto flutuante)


def bai(amount: float) -> int:
    return int(round(amount * UNIT))


def fmt_bai(units: int) -> str:
    return f"{units / UNIT:,.6f} BAI"


class ChainParams(BaseModel):
    chain_id: str = "blockai-local"
    authority: str = ""               # endereço do coordenador (assina blocos e tx de sistema)
    authority_pubkey: str = ""
    treasury: str = "bai" + "0" * 40  # tesouro do protocolo
    genesis_supply: int = bai(1_000_000_000)
    min_stake: int = bai(100)         # stake mínimo para um nó receber tarefas
    base_fee: int = bai(0.01)         # taxa fixa por tarefa
    price_per_token: int = bai(0.0005)  # taxa por token gerado (max_new_tokens)
    protocol_cut_bps: int = 500       # 5% da taxa vai ao tesouro
    block_subsidy: int = bai(1)       # emissão por tarefa liquidada, dividida entre os nós corretos
    slash_bps: int = 1000             # 10% do stake é cortado num resultado divergente
    replication: int = 2              # nº de nós que executam cada tarefa (consenso)
    default_model: str = "Qwen/Qwen2.5-0.5B-Instruct"
    dev_faucet: bool = True


class GpuInfo(BaseModel):
    name: str = "unknown"
    memory_mb: int = 0
    count: int = 1
    backend: str = "cpu"   # cuda | mps | rocm | cpu


class NodeInfo(BaseModel):
    address: str
    gpu: GpuInfo = Field(default_factory=GpuInfo)
    models: List[str] = Field(default_factory=list)
    operator: str = ""  # identifica o operador humano/entidade por trás do nó (ver escalonador)
    stake: int = 0
    reputation: float = 1.0       # 0..2; cresce com resultados corretos, cai com divergências
    tasks_completed: int = 0
    tasks_failed: int = 0
    earned: int = 0
    registered_at: float = 0.0

    @property
    def score(self) -> float:
        """Pontuação usada pelo escalonador: stake ponderado pela reputação e VRAM."""
        vram = max(self.gpu.memory_mb, 1) / 1024.0
        return (self.stake / UNIT + 1.0) * self.reputation * (1.0 + vram / 16.0)


class TaskStatus(str, Enum):
    PENDING = "PENDING"
    ASSIGNED = "ASSIGNED"
    READY = "READY"          # todos os resultados chegaram; aguarda liquidação
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"        # sem consenso; taxa reembolsada


class TaskResult(BaseModel):
    node: str
    output_hash: str
    output: str
    tokens_generated: int
    latency_ms: float
    submitted_at: float


class TaskRecord(BaseModel):
    task_id: str
    submitter: str
    prompt: str
    model: str
    max_new_tokens: int
    replication: int
    fee: int
    tenant_id: str = ""  # Set only by the authenticated portal gateway.
    guide: Optional[dict] = None  # Bounded observation snapshot, scoped like its task.
    status: TaskStatus = TaskStatus.PENDING
    assigned: List[str] = Field(default_factory=list)
    results: Dict[str, TaskResult] = Field(default_factory=dict)
    output: Optional[str] = None
    winner_hash: Optional[str] = None
    created_at: float = 0.0
    settled_at: Optional[float] = None


class StateError(ValueError):
    """Transação inválida para o estado atual."""


class State(BaseModel):
    params: ChainParams = Field(default_factory=ChainParams)
    balances: Dict[str, int] = Field(default_factory=dict)
    nonces: Dict[str, int] = Field(default_factory=dict)
    nodes: Dict[str, NodeInfo] = Field(default_factory=dict)
    tasks: Dict[str, TaskRecord] = Field(default_factory=dict)
    total_burned: int = 0

    # ----- helpers ---------------------------------------------------------------
    def balance(self, addr: str) -> int:
        return self.balances.get(addr, 0)

    def next_nonce(self, addr: str) -> int:
        return self.nonces.get(addr, 0)

    def _debit(self, addr: str, amount: int) -> None:
        if amount < 0:
            raise StateError("valor negativo")
        if self.balance(addr) < amount:
            raise StateError(f"saldo insuficiente em {addr}: tem {self.balance(addr)}, precisa {amount}")
        self.balances[addr] = self.balance(addr) - amount

    def _credit(self, addr: str, amount: int) -> None:
        if amount < 0:
            raise StateError("valor negativo")
        self.balances[addr] = self.balance(addr) + amount

    def task_fee(self, max_new_tokens: int) -> int:
        return self.params.base_fee + self.params.price_per_token * max_new_tokens

    def eligible_nodes(self) -> List[NodeInfo]:
        return [n for n in self.nodes.values() if n.stake >= self.params.min_stake and n.reputation > 0.2]

    # ----- transição de estado ---------------------------------------------------
    def apply_tx(self, tx: Transaction, *, check_signature: bool = True) -> None:
        if check_signature and not tx.verify_signature():
            raise StateError("assinatura inválida")
        if tx.type.is_system:
            if tx.sender != self.params.authority:
                raise StateError(f"transação de sistema {tx.type.value} exige a autoridade da cadeia")
        expected = self.next_nonce(tx.sender)
        if tx.nonce != expected:
            raise StateError(f"nonce inválido para {tx.sender}: esperado {expected}, recebido {tx.nonce}")

        handler = getattr(self, f"_apply_{tx.type.value.lower()}")
        handler(tx)
        self.nonces[tx.sender] = expected + 1

    # cada handler valida ANTES de mutar, para que uma tx inválida não deixe estado parcial.
    def _apply_node_register(self, tx: Transaction) -> None:
        p = tx.payload
        gpu = GpuInfo(**p.get("gpu", {}))
        models = list(p.get("models", []))
        node = self.nodes.get(tx.sender)
        if node is None:
            node = NodeInfo(address=tx.sender, registered_at=tx.timestamp)
        node.gpu = gpu
        node.models = models
        node.operator = str(p.get("operator", node.operator))
        self.nodes[tx.sender] = node

    def _apply_stake(self, tx: Transaction) -> None:
        amount = int(tx.payload.get("amount", 0))
        if amount <= 0:
            raise StateError("stake deve ser positivo")
        if tx.sender not in self.nodes:
            raise StateError("registre o nó antes de fazer stake")
        self._debit(tx.sender, amount)
        self.nodes[tx.sender].stake += amount

    def _apply_unstake(self, tx: Transaction) -> None:
        amount = int(tx.payload.get("amount", 0))
        node = self.nodes.get(tx.sender)
        if node is None or amount <= 0 or node.stake < amount:
            raise StateError("unstake inválido")
        active = [t for t in self.tasks.values() if tx.sender in t.assigned and t.status in (TaskStatus.ASSIGNED, TaskStatus.READY)]
        if active:
            raise StateError("nó tem tarefas em andamento; aguarde a liquidação")
        node.stake -= amount
        self._credit(tx.sender, amount)

    def _apply_transfer(self, tx: Transaction) -> None:
        to = tx.payload.get("to")
        amount = int(tx.payload.get("amount", 0))
        if not to or amount <= 0:
            raise StateError("transferência inválida")
        self._debit(tx.sender, amount)
        self._credit(to, amount)

    def _apply_faucet(self, tx: Transaction) -> None:
        if not self.params.dev_faucet:
            raise StateError("faucet desativado")
        to = tx.payload.get("to")
        amount = int(tx.payload.get("amount", 0))
        if not to or amount <= 0:
            raise StateError("faucet inválido")
        self._debit(self.params.treasury, amount)
        self._credit(to, amount)

    def _apply_task_submit(self, tx: Transaction) -> None:
        p = tx.payload
        prompt = p.get("prompt", "")
        max_new_tokens = int(p.get("max_new_tokens", 128))
        if not prompt or max_new_tokens <= 0 or max_new_tokens > 4096:
            raise StateError("tarefa inválida (prompt vazio ou max_new_tokens fora de 1..4096)")
        replication = int(p.get("replication", self.params.replication))
        if replication < 1 or replication > 7:
            raise StateError("replication deve estar em 1..7")
        fee = self.task_fee(max_new_tokens)
        task_id = tx.hash
        if task_id in self.tasks:
            raise StateError("tarefa duplicada")
        self._debit(tx.sender, fee)  # taxa fica em custódia até a liquidação
        self.tasks[task_id] = TaskRecord(
            task_id=task_id,
            submitter=tx.sender,
            prompt=prompt,
            model=p.get("model") or self.params.default_model,
            max_new_tokens=max_new_tokens,
            replication=replication,
            fee=fee,
            tenant_id=str(p.get("tenant_id", "")),
            guide=p.get("guide"),
            created_at=tx.timestamp,
        )

    def _apply_task_assign(self, tx: Transaction) -> None:
        task = self.tasks.get(tx.payload.get("task_id", ""))
        nodes = list(tx.payload.get("nodes", []))
        if task is None or task.status != TaskStatus.PENDING:
            raise StateError("tarefa inexistente ou já atribuída")
        if len(nodes) != len(set(nodes)) or not nodes:
            raise StateError("lista de nós inválida")
        for n in nodes:
            if n not in self.nodes or self.nodes[n].stake < self.params.min_stake:
                raise StateError(f"nó {n} não é elegível")
        task.assigned = nodes
        task.status = TaskStatus.ASSIGNED

    def _apply_task_result(self, tx: Transaction) -> None:
        p = tx.payload
        task = self.tasks.get(p.get("task_id", ""))
        if task is None or task.status != TaskStatus.ASSIGNED:
            raise StateError("tarefa não está aguardando resultados")
        if tx.sender not in task.assigned:
            raise StateError("nó não foi designado para esta tarefa")
        if tx.sender in task.results:
            raise StateError("resultado duplicado")
        output = str(p.get("output", ""))
        output_hash = str(p.get("output_hash", ""))
        if not output_hash:
            raise StateError("output_hash obrigatório")
        task.results[tx.sender] = TaskResult(
            node=tx.sender,
            output_hash=output_hash,
            output=output,
            tokens_generated=int(p.get("tokens_generated", 0)),
            latency_ms=float(p.get("latency_ms", 0.0)),
            submitted_at=tx.timestamp,
        )
        if len(task.results) >= len(task.assigned):
            task.status = TaskStatus.READY

    def _apply_task_settle(self, tx: Transaction) -> None:
        p = tx.payload
        task = self.tasks.get(p.get("task_id", ""))
        if task is None or task.status not in (TaskStatus.PENDING, TaskStatus.ASSIGNED, TaskStatus.READY):
            raise StateError("tarefa não pode ser liquidada")
        if task.status == TaskStatus.PENDING and (p.get("success") or p.get("rewards") or p.get("slashes")):
            raise StateError("an unassigned task can only be refunded")
        rewards: Dict[str, int] = {k: int(v) for k, v in p.get("rewards", {}).items()}
        slashes: Dict[str, int] = {k: int(v) for k, v in p.get("slashes", {}).items()}
        refund = int(p.get("refund", 0))
        treasury_cut = int(p.get("treasury_cut", 0))
        subsidy = int(p.get("subsidy", 0))

        # conservação: taxa em custódia + subsídio (do tesouro) == recompensas + corte + reembolso
        if sum(rewards.values()) + treasury_cut + refund != task.fee + subsidy:
            raise StateError("liquidação não conserva valores")
        for n in list(rewards) + list(slashes):
            if n not in task.assigned:
                raise StateError(f"nó {n} não participou da tarefa")
        for n, amt in slashes.items():
            if amt > self.nodes[n].stake:
                raise StateError("slash maior que o stake")
        if subsidy > self.balance(self.params.treasury):
            raise StateError("tesouro sem fundos para o subsídio")

        # aplica
        self._debit(self.params.treasury, subsidy)
        self._credit(self.params.treasury, treasury_cut)
        for n, amt in rewards.items():
            self._credit(n, amt)
            node = self.nodes[n]
            node.earned += amt
            node.tasks_completed += 1
            node.reputation = min(2.0, node.reputation + 0.05)
        for n, amt in slashes.items():
            node = self.nodes[n]
            node.stake -= amt
            node.tasks_failed += 1
            node.reputation = max(0.0, node.reputation - 0.25)
            self.total_burned += amt
        if refund:
            self._credit(task.submitter, refund)

        task.winner_hash = p.get("winner_hash")
        task.output = p.get("output")
        task.settled_at = tx.timestamp
        task.status = TaskStatus.COMPLETED if p.get("success") else TaskStatus.FAILED

    # ----- snapshot ---------------------------------------------------------------
    def digest(self) -> str:
        return hash_obj(self.model_dump(mode="json"))
