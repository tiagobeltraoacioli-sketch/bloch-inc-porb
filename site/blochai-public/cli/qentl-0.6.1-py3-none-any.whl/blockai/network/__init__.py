__all__ = ["Coordinator", "create_app"]


def __getattr__(name):
    # Private inference must not load chain/coordinator dependencies on startup.
    if name in __all__:
        from .coordinator import Coordinator, create_app
        return {"Coordinator": Coordinator, "create_app": create_app}[name]
    raise AttributeError(name)
