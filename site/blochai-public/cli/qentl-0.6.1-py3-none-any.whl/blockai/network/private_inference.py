"""Stateless, authenticated inference outside the chain for a trusted broker.

Bind to loopback through SSH/TLS. No ledger, prompt log or training dataset.
"""
from __future__ import annotations

import hmac
import threading
import time
import uuid
import re
from collections import deque
from typing import Literal

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, ValidationError

PRIVACY = {'off_ledger': True, 'prompt_persistence': False, 'training': False, 'stateless': True}
# UTF-8 bytes conservatively bound content tokens for the installed Qwen tokenizers.
# Reserve output (including thinking) and additional space for model chat templates.
TEMPLATE_RESERVE = 4096
MAX_REQUEST_BYTES = 1_000_000


class ContextLimitError(ValueError):
    """A bounded request cannot fit without dropping supplied context."""


class InferenceAdmission:
    """One engine invocation, with a bounded FIFO for interactive callers."""
    def __init__(self, max_waiting=0, timeout=120):
        self.max_waiting=max_waiting;self.timeout=timeout
        self.condition=threading.Condition();self.active=False;self.waiting=deque()

    def snapshot(self):
        with self.condition:return {'busy':self.active,'waiting':len(self.waiting)}

    def acquire(self, background=False):
        with self.condition:
            if not self.active and not self.waiting:
                self.active=True;return None
            if background:return 'gpu_busy'
            if len(self.waiting)>=self.max_waiting:return 'queue_full'
            ticket=object();self.waiting.append(ticket);deadline=time.monotonic()+self.timeout
            try:
                while self.active or self.waiting[0] is not ticket:
                    remaining=deadline-time.monotonic()
                    if remaining<=0:return 'queue_timeout'
                    self.condition.wait(remaining)
                self.waiting.popleft();self.active=True;return None
            finally:
                if ticket in self.waiting:self.waiting.remove(ticket)
                self.condition.notify_all()

    def release(self):
        with self.condition:
            self.active=False;self.condition.notify_all()


def validate_limits(context_tokens, max_prompt_chars, max_prompt_bytes, max_new_tokens):
    for name, value, low, high in (
            ('context_tokens', context_tokens, 8192, 131072),
            ('max_prompt_chars', max_prompt_chars, 1, 120000),
            ('max_prompt_bytes', max_prompt_bytes, 1, 480000),
            ('max_new_tokens', max_new_tokens, 1, 32768)):
        if type(value) is not int or not low <= value <= high:
            raise ValueError(f'Invalid {name} setting.')
    input_tokens = context_tokens - max_new_tokens - TEMPLATE_RESERVE
    if input_tokens < 1:
        raise ValueError('Context must accommodate output and template reserves.')
    return {'context_tokens': context_tokens, 'max_prompt_chars': max_prompt_chars,
            'max_prompt_bytes': min(max_prompt_bytes, input_tokens),
            'max_new_tokens': max_new_tokens, 'max_prompt_tokens': input_tokens, 'max_messages': 32,
            'token_counting': 'utf8_upper_bound'}


def prompt_size(messages):
    prompt = '\n\n'.join(m['role'].upper() + ': ' + m['content'] for m in messages)
    return len(prompt), len(prompt.encode('utf-8'))


def token_count(value):
    return value if type(value) is int and 0 <= value <= 131072 else None


class Message(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    role: Literal['system', 'user', 'assistant']
    content: str = Field(min_length=1, max_length=120000)


class Completion(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    tenant_id: str = Field(pattern=r'^[a-f0-9]{24}$')
    model: str = Field(min_length=1, max_length=150)
    messages: list[Message] = Field(min_length=1, max_length=32)
    max_new_tokens: int = Field(ge=1, le=32768)
    json_mode: bool = False


def create_private_app(engine, token, region, max_prompt_chars=6000,
                       max_prompt_bytes=12000, max_new_tokens=2048, context_tokens=None,
                       requests_per_minute=12, max_waiting=0, queue_timeout=120):
    if not isinstance(token, str) or not re.fullmatch(r'[a-f0-9]{64}', token):
        raise ValueError('Use a private 256-bit service credential.')
    if not isinstance(region, str) or not region.strip():
        raise ValueError('Describe the processing location, including any uncertainty.')
    context_tokens = (getattr(engine, 'context_tokens', 16384)
                      if context_tokens is None else context_tokens)
    limits = validate_limits(context_tokens, max_prompt_chars, max_prompt_bytes, max_new_tokens)
    if (type(requests_per_minute) is not int or not 0<=requests_per_minute<=10000
            or type(max_waiting) is not int or not 0<=max_waiting<=16
            or type(queue_timeout) not in (int,float) or not 1<=queue_timeout<=600):
        raise ValueError('Invalid private admission policy.')
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
    guard, slot, attempts = threading.Lock(), InferenceAdmission(max_waiting,queue_timeout), {}

    def error(message, status, code=None):
        headers={'Cache-Control':'no-store'}
        if status==429:headers['Retry-After']='5' if code!='rate_limited' else '60'
        return JSONResponse({'error': message,**({'code':code} if code else {})}, status_code=status, headers=headers)

    @app.middleware('http')
    async def boundary(request, next_handler):
        supplied = request.headers.get('authorization', '')
        if not hmac.compare_digest(supplied.encode(), ('Bearer ' + token).encode()):
            return error('Unauthorized.', 401)
        if request.headers.get('origin'):
            return error('Broker access required.', 403)
        response = await next_handler(request)
        response.headers.update({'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
                                 'Referrer-Policy': 'no-referrer'})
        return response

    @app.get('/v1/private/status')
    def status():
        return {**engine.status(), 'service': 'BlochAI private inference',
                'processing_region': region, 'privacy': PRIVACY,
                'context_tokens': context_tokens, 'limits': limits,
                'admission':{**slot.snapshot(),'requests_per_minute':requests_per_minute or None,
                             'max_waiting':max_waiting,'queue_timeout_seconds':queue_timeout,
                             'background_priority':'idle_only','token_usage_quota':None}}

    @app.post('/v1/private/completions')
    async def complete(request: Request):
        from starlette.concurrency import run_in_threadpool
        if request.headers.get('content-type', '').split(';', 1)[0].strip() != 'application/json':
            return error('JSON required.', 415)
        raw = bytearray()
        async for chunk in request.stream():
            raw.extend(chunk)
            if len(raw) > MAX_REQUEST_BYTES:
                return error('Request too large.', 413)
        try:
            payload = Completion.model_validate_json(raw)
        except ValidationError:
            return error('Invalid inference request.', 422)
        raw.clear()
        messages = [m.model_dump() for m in payload.messages]
        chars, byte_count = prompt_size(messages)
        if payload.model != engine.model:
            return error('Requested model is unavailable.', 422)
        if (chars > limits['max_prompt_chars'] or byte_count > limits['max_prompt_bytes']
                or payload.max_new_tokens > limits['max_new_tokens']):
            return error('Context limit exceeded. Reduce input or the requested output budget.', 422)
        admission=await run_in_threadpool(slot.acquire,request.headers.get('x-qentl-priority')=='background')
        if admission:
            messages.clear()
            return error('Private GPU runtime is busy.' if admission=='gpu_busy' else
                         'Private GPU queue is full.' if admission=='queue_full' else
                         'Private GPU queue wait expired. No generation was started.',429,admission)
        try:
            if requests_per_minute:
                with guard:
                    now = time.monotonic()
                    for tenant in list(attempts):
                        attempts[tenant] = [stamp for stamp in attempts[tenant] if stamp > now - 60]
                        if not attempts[tenant]:attempts.pop(tenant)
                    if len(attempts.get(payload.tenant_id, [])) >= requests_per_minute or (payload.tenant_id not in attempts and len(attempts)>=1000):
                        return error('Request rate exceeded.',429,'rate_limited')
                    attempts.setdefault(payload.tenant_id, []).append(now)
            if await request.is_disconnected():
                return error('Caller disconnected before generation. No generation was started.',499)
            result = await run_in_threadpool(engine.complete,
                                            messages, payload.max_new_tokens, payload.json_mode)
            output = result.get('output')
            if (not isinstance(output, str) or not output.strip() or len(output) > 200000
                    or result.get('finish_reason') != 'stop'):
                return error('Model output was empty or incomplete. Request a smaller result.', 502)
            output_tokens = token_count(result.get('output_tokens'))
            prompt_tokens = token_count(result.get('prompt_tokens'))
            if ((result.get('output_tokens') is not None and output_tokens is None)
                    or (result.get('prompt_tokens') is not None and prompt_tokens is None)
                    or (output_tokens is not None and output_tokens > payload.max_new_tokens)
                    or (prompt_tokens is not None and prompt_tokens > context_tokens - max_new_tokens)
                    or (prompt_tokens is not None and output_tokens is not None
                        and prompt_tokens + output_tokens > context_tokens)):
                return error('Model exceeded its context or output budget. No partial result was accepted.', 502)
            response = {'id': uuid.uuid4().hex, 'model': engine.model, 'model_digest': engine.digest,
                        'output': output, 'output_tokens': output_tokens,
                        'finish_reason': 'stop', 'tenant_id': payload.tenant_id,
                        'privacy': PRIVACY, 'processing_region': region}
            if prompt_tokens is not None:
                response.update(prompt_tokens=prompt_tokens, prompt_eval_count=prompt_tokens)
            if output_tokens is not None:
                response['eval_count'] = output_tokens
            return response
        except ContextLimitError:
            return error('Context limit exceeded. Reduce input or the requested output budget.', 422)
        except Exception:
            # Never log exception text, request payloads, model output or stack traces.
            return error('Private inference failed. No content was saved by this API.', 502)
        finally:
            slot.release()

    return app
