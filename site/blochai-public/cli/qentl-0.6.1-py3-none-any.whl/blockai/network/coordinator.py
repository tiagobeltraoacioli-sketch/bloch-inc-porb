"""Coordenador BlockAI: expõe a cadeia via HTTP, escalona tarefas para os nós
de GPU, liquida o consenso e produz blocos periodicamente."""
from __future__ import annotations

import asyncio
import logging
import time
from contextlib import asynccontextmanager
from typing import Dict, List, Optional

from fastapi import FastAPI, HTTPException, Query, Response
from fastapi.responses import JSONResponse

from ..chain import Blockchain, ChainParams, KeyPair, Transaction, TxType
from ..chain.crypto import verify_signature
from ..chain.state import StateError, TaskStatus
from ..model.sharding import plan_shards
from . import scheduler
from .protocol import ChainInfo, FaucetRequest, HeartbeatRequest, NodeView, RuntimeReport, TxSubmitResponse, WorkItem, heartbeat_message

log = logging.getLogger("blockai.coordinator")


class Coordinator:
    def __init__(self, authority: KeyPair, *, chain_path: Optional[str] = None, params: Optional[ChainParams] = None,
                 block_interval: float = 5.0, heartbeat_timeout: float = 30.0, task_timeout: float = 120.0):
        self.chain = Blockchain(authority, params=params, path=chain_path)
        self.block_interval = block_interval
        self.heartbeat_timeout = heartbeat_timeout
        self.task_timeout = task_timeout
        self.presence: Dict[str, float] = {}  # endereço -> último heartbeat (off-chain)
        self.runtime: Dict[str, RuntimeReport] = {}
        self.gateway = None
        self._stop = False

    # ----- presença ---------------------------------------------------------------
    def online_nodes(self, now: Optional[float] = None) -> List[str]:
        now = now or time.time()
        with self.chain.lock:
            return [a for a, t in self.presence.items() if now - t <= self.heartbeat_timeout]

    def runtime_ready_nodes(self, model: str, *, gpu_only: bool = False, idle_only: bool = False) -> List[str]:
        """Real, loaded runtimes with fresh signed heartbeats and eligible stake."""
        with self.chain.lock:
            eligible = {n.address for n in self.chain.state.eligible_nodes() if model in n.models}
            backend = self.gateway.backend if self.gateway else None
            return [a for a in self.online_nodes() if a in eligible and a in self.runtime
                    and self.runtime[a].ready and self.runtime[a].model == model
                    and self.runtime[a].backend in ("qwen", "ollama")
                    and (not gpu_only or self.runtime[a].gpu_inference)
                    and (not idle_only or not self.runtime[a].busy)
                    and (backend is None or self.runtime[a].backend == backend)]

    # ----- ciclo de bloco ----------------------------------------------------------
    def tick(self) -> Optional[str]:
        """Um passo do produtor: escalona pendentes, liquida prontas, produz bloco."""
        with self.chain.lock:
            self.schedule_pending()
            settled = self.chain.settle_ready_tasks(timeout_s=self.task_timeout)
            for s in settled:
                log.info("liquidada %s success=%s vencedores=%s slashes=%s", s.task_id[:8], s.success, s.agreeing, s.slashes)
            block = self.chain.produce_block()
            if block:
                log.info("bloco #%d com %d tx (%s)", block.index, len(block.transactions), block.hash[:12])
                return block.hash
            return None

    def schedule_pending(self) -> int:
        online = self.online_nodes()
        n = 0
        for task in list(self.chain.state.tasks.values()):
            if task.status != TaskStatus.PENDING:
                continue
            # Do not assign an expired queue entry and then slash a worker that
            # had no opportunity to execute it. The next tick refunds it.
            if self.task_timeout and time.time() - task.created_at >= self.task_timeout:
                continue
            available = self.runtime_ready_nodes(task.model, gpu_only=True, idle_only=True) if self.gateway else online
            nodes = scheduler.choose_nodes(self.chain.state, task, available, max_load=1 if self.gateway else 4)
            if nodes:
                self.chain.assign_task(task.task_id, nodes)
                n += 1
        return n

    async def run_forever(self) -> None:
        while not self._stop:
            try:
                await asyncio.to_thread(self.tick)
            except Exception:  # pragma: no cover
                log.exception("erro no ciclo de bloco")
            await asyncio.sleep(self.block_interval)


def create_app(coord: Coordinator, *, gateway=None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        coord._stop = False
        task = asyncio.create_task(coord.run_forever()) if coord.block_interval > 0 else None
        try:
            yield
        finally:
            coord._stop = True
            if task:
                task.cancel()

    app = FastAPI(title="BlockAI Coordinator", version="0.1.0", lifespan=lifespan)
    app.state.coordinator = coord
    chain = coord.chain
    if gateway is not None:
        from .gateway import configure_gateway
        configure_gateway(app, coord, gateway)

    @app.get("/", response_model=ChainInfo)
    def info():
        st = chain.state
        return ChainInfo(chain_id=chain.params.chain_id, height=chain.height, head_hash=chain.head.hash,
                         authority=chain.params.authority, treasury_balance=st.balance(chain.params.treasury),
                         nodes_registered=len(st.nodes), nodes_online=len(coord.online_nodes()),
                         tasks_total=len(st.tasks), mempool=len(chain.mempool),
                         params=chain.params.model_dump(mode="json"))

    # ----- transações --------------------------------------------------------------
    @app.post("/tx", response_model=TxSubmitResponse)
    def submit_tx(tx: Transaction):
        if gateway is not None and tx.type not in (TxType.NODE_REGISTER, TxType.STAKE, TxType.UNSTAKE, TxType.TASK_RESULT):
            raise HTTPException(403, "Worker credential cannot submit this transaction type")
        if tx.type.is_system:
            raise HTTPException(403, "transações de sistema não são aceitas via API")
        try:
            with chain.lock:
                h = chain.submit_tx(tx)
                if gateway is not None:
                    # Acknowledged registration/results must survive a restart,
                    # including one before the periodic producer's next tick.
                    chain.produce_block()
        except StateError as e:
            raise HTTPException(400, str(e))
        return TxSubmitResponse(hash=h)

    @app.get("/nonce/{address}")
    def nonce(address: str):
        return {"address": address, "nonce": chain.pending_nonce(address)}

    @app.post("/faucet", response_model=TxSubmitResponse)
    def faucet(req: FaucetRequest):
        if not chain.params.dev_faucet:
            raise HTTPException(403, "faucet desativado")
        try:
            tx = chain.system_tx(TxType.FAUCET, {"to": req.address, "amount": req.amount})
        except StateError as e:
            raise HTTPException(400, str(e))
        return TxSubmitResponse(hash=tx.hash)

    # ----- nós de GPU --------------------------------------------------------------
    @app.post("/nodes/heartbeat")
    def heartbeat(req: HeartbeatRequest):
        msg = heartbeat_message(req.timestamp, req.runtime)
        from ..chain.crypto import address_from_pubkey
        try:
            valid = address_from_pubkey(req.pubkey) == req.address and verify_signature(req.pubkey, msg, req.signature)
        except ValueError:
            valid = False
        if not valid:
            raise HTTPException(401, "heartbeat inválido")
        if abs(time.time() - req.timestamp) > 120:
            raise HTTPException(400, "relógio fora de sincronia")
        with chain.lock:
            if req.address not in chain.state.nodes:
                raise HTTPException(404, "nó não registrado; envie NODE_REGISTER primeiro")
            coord.presence[req.address] = time.time()
            if req.runtime is not None:
                coord.runtime[req.address] = req.runtime
            else:
                coord.runtime.pop(req.address, None)
            node = chain.state.nodes[req.address]
            return {"ok": True, "stake": node.stake, "min_stake": chain.params.min_stake,
                    "eligible": node.stake >= chain.params.min_stake}

    @app.get("/nodes", response_model=List[NodeView])
    def nodes():
        online = set(coord.online_nodes())
        return [NodeView(address=n.address, gpu=n.gpu.model_dump(), models=n.models, operator=n.operator, stake=n.stake,
                         reputation=n.reputation, tasks_completed=n.tasks_completed, tasks_failed=n.tasks_failed,
                         earned=n.earned, online=n.address in online, last_seen=coord.presence.get(n.address))
                for n in chain.state.nodes.values()]

    @app.get("/work")
    def work(node: str = Query(...), timestamp: Optional[float] = None, pubkey: str = "", signature: str = ""):
        """Devolve a próxima tarefa designada ao nó (escalonando pendentes se preciso)."""
        if node not in chain.state.nodes:
            raise HTTPException(404, "nó não registrado")
        if gateway is not None:
            from ..chain.crypto import address_from_pubkey
            try:
                valid = (timestamp is not None and abs(time.time() - timestamp) < 30
                         and address_from_pubkey(pubkey) == node
                         and verify_signature(pubkey, f"work:{node}:{timestamp}".encode(), signature))
            except ValueError:
                valid = False
            if not valid:
                raise HTTPException(401, "Signed work request required")
        else:
            with chain.lock:
                coord.presence[node] = time.time()
        with chain.lock:
            coord.schedule_pending()
            for t in chain.state.tasks.values():
                if t.status == TaskStatus.ASSIGNED and node in t.assigned and node not in t.results:
                    if gateway is not None:
                        chain.produce_block()
                    return WorkItem(task_id=t.task_id, prompt=t.prompt, model=t.model,
                                    max_new_tokens=t.max_new_tokens, replicas=t.assigned)
        return Response(status_code=204)

    # ----- tarefas -----------------------------------------------------------------
    @app.get("/tasks")
    def tasks(status: Optional[str] = None, limit: int = 50):
        items = list(chain.state.tasks.values())
        if status:
            items = [t for t in items if t.status.value == status.upper()]
        items.sort(key=lambda t: -t.created_at)
        return [t.model_dump(mode="json") for t in items[:limit]]

    @app.get("/tasks/{task_id}")
    def task(task_id: str):
        t = chain.state.tasks.get(task_id)
        if t is None:
            raise HTTPException(404, "tarefa não encontrada")
        return t.model_dump(mode="json")

    @app.get("/fee")
    def fee(max_new_tokens: int = 128):
        return {"max_new_tokens": max_new_tokens, "fee": chain.state.task_fee(max_new_tokens)}

    # ----- cadeia ------------------------------------------------------------------
    @app.get("/chain/head")
    def head():
        b = chain.head
        return {**b.header(), "hash": b.hash}

    @app.get("/chain/blocks")
    def blocks(start: int = 0, limit: int = 20):
        out = []
        for b in chain.blocks[start:start + limit]:
            out.append({**b.header(), "hash": b.hash, "transactions": [
                {"hash": tx.hash, "type": tx.type.value, "sender": tx.sender} for tx in b.transactions]})
        return out

    @app.get("/chain/blocks/{index}")
    def block(index: int):
        if index < 0 or index > chain.height:
            raise HTTPException(404, "bloco inexistente")
        b = chain.blocks[index]
        return {**b.model_dump(mode="json"), "hash": b.hash}

    @app.get("/chain/tx/{tx_hash}")
    def tx_lookup(tx_hash: str):
        idx = chain.tx_index.get(tx_hash)
        if idx is None:
            for tx in chain.mempool:
                if tx.hash == tx_hash:
                    return {"status": "pending", "tx": tx.model_dump(mode="json")}
            raise HTTPException(404, "transação não encontrada")
        tx = next(t for t in chain.blocks[idx].transactions if t.hash == tx_hash)
        return {"status": "confirmed", "block": idx, "tx": tx.model_dump(mode="json")}

    @app.get("/balance/{address}")
    def balance(address: str):
        return {"address": address, "balance": chain.state.balance(address)}

    @app.get("/shards/plan")
    def shards(model: Optional[str] = None):
        model = model or chain.params.default_model
        return plan_shards(model, chain.state.eligible_nodes()).model_dump(mode="json")

    @app.post("/admin/tick")
    def admin_tick():
        """Força um ciclo (útil em testes e demos)."""
        return {"block": coord.tick(), "height": chain.height}

    return app
