"""Portal-specific chain knowledge and bounded, server-normalized observations.

Typed topic selection occurs in the browser. The public inference API receives
only catalog identifiers and normalized public chain evidence from its trusted
edge service. It never accepts raw user prompts, private memory or arbitrary URLs.
"""
import json
from pathlib import Path
from typing import Literal, Optional
from pydantic import BaseModel, ConfigDict, Field, model_validator
from .research_context import Network, Mode, ObservationContext

Portal = Literal['graphus', 'space', 'explorer']
PUBLIC_TENANT_PREFIX = 'public:'
PUBLIC_MAX_NEW_TOKENS = 256
KNOWLEDGE = json.loads(Path(__file__).with_name('chain_knowledge.json').read_text())
PUBLIC_CATALOG = {portal:{'purpose':entry['purpose'], 'questions':{id:t['question'] for id,t in entry['topics'].items()}} for portal,entry in KNOWLEDGE.items()}

class PublicTaskRequest(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    portal: Portal
    question_id: str = Field(min_length=1, max_length=32)
    mode: Mode = 'explain'
    network: Network = 'bloch'
    observations: Optional[ObservationContext] = None

    @model_validator(mode='after')
    def approved_question(self):
        if self.question_id not in KNOWLEDGE[self.portal]['topics']:
            raise ValueError('Question is not approved for this portal')
        topic=KNOWLEDGE[self.portal]['topics'][self.question_id]
        if self.network not in topic.get('networks',['bitcoin','ethereum','bloch']):
            raise ValueError('Question is not approved for this network')
        if self.portal=='explorer' and self.network!='bloch':
            raise ValueError('The Bloch explorer covers Bloch only')
        if self.observations and self.observations.network!=self.network:
            raise ValueError('Observation network must match the requested chain')
        return self

def public_guide(request: PublicTaskRequest) -> dict:
    topic=KNOWLEDGE[request.portal]['topics'][request.question_id]
    observations=request.observations.snapshot() if request.observations else {
        'network':request.network,'subject':None,'sources':[],'facts':[],'transactions':[],
        'graph':{'nodes':[],'edges':[]},'status':'unavailable','coverage':'No live observation was supplied.','observed_at':None}
    refs=[{**s,'retrieved_at':None,'observed_at':None,'status':'reference','coverage':'Curated protocol reference, reviewed 2026-09-28; not a live network measurement.'} for s in topic['sources']]
    return {**observations,'portal':request.portal,'question_id':request.question_id,'title':topic['title'],
            'question':topic['question'],'mode':request.mode,'knowledge':[{'text':n,'source_ids':[source['id'] for source in topic['sources']],'reference_scope':'topic'} for n in topic['notes']],
            'sources':observations['sources']+refs}

def public_prompt(request: PublicTaskRequest) -> str:
    topic=KNOWLEDGE[request.portal]['topics'][request.question_id]
    styles={'summary':'Give a concise summary in up to 4 sentences.',
            'explain':'Explain the evidence in a few short paragraphs, at most 170 words.',
            'checklist':'Give a practical checklist of up to 6 short checks.',
            'example':'Give a clearly hypothetical example. Never present invented example values as observed records.'}
    lines=[];size=0
    if request.observations:
        o=request.observations
        for fact in o.facts:
            line=f'{fact.label}: {fact.value}'+(f' {fact.unit}' if fact.unit else '')+(f' [source: {fact.source_id}]' if fact.source_id else '')
            if size+len(line)>900:break
            lines.append(line);size+=len(line)+1
        anchors='; '.join(f'{s.id}: {s.status}, observed {s.observed_at or "unknown"}, retrieved {s.retrieved_at or "unknown"}' for s in o.sources)[:550]
        evidence=f'Source status: {o.status}. Coverage: {o.coverage[:1000]}\nSource times: {anchors}\n'+'\n'.join(lines)
        if o.subject:evidence+=f'\nRequested public {o.subject.kind}: {o.subject.value}'
    else:evidence='No current chain or address observations were supplied. Do not invent any.'
    return (
        'You are BlochAI, specialized in blockchain research. Answer in English, only about the requested portal and chain. '
        'Use the curated notes and supplied public observations below. Numbers are source observations, not predictions. '
        'If evidence is missing, say so. Do not infer real-world identity, wallet ownership, intent, wrongdoing or risk scores. '
        'You cannot access private AML records or other conversations. Never request keys or seed phrases. '
        'Do not invent sources, balances, transactions, feature activation, audits or finality. Do not give investment advice. '
        +styles[request.mode]+'\n'
        +f"Portal: {KNOWLEDGE[request.portal]['purpose']}\nNetwork: {request.network}\n"
        +'Curated notes: '+' '.join(topic['notes'])+'\n'
        +'Public observations:\n'+evidence+'\n'
        +'Question: '+topic['question']+'\nAnswer:'
    )
