"""Bounded public-chain observations supplied by the authenticated portal service."""
from typing import Literal, Optional
from urllib.parse import urlsplit
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator, model_serializer

Network = Literal['bitcoin', 'ethereum', 'bloch']
Mode = Literal['summary', 'explain', 'checklist', 'example']

class StrictRecord(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)

class Subject(StrictRecord):
    kind: Literal['address', 'transaction']
    value: str = Field(min_length=1, max_length=160, pattern=r'^[a-zA-Z0-9:_-]+$')

class Source(StrictRecord):
    id: str = Field(min_length=1, max_length=64, pattern=r'^[a-zA-Z0-9_-]+$')
    title: str = Field(min_length=1, max_length=160)
    url: str = Field(min_length=1, max_length=700)
    retrieved_at: Optional[str] = Field(default=None, max_length=40)
    observed_at: Optional[str] = Field(default=None, max_length=40)
    status: Literal['available','partial','unavailable','reference']
    coverage: str = Field(max_length=600)

    @field_validator('url')
    @classmethod
    def public_source(cls, value):
        u=urlsplit(value)
        if u.scheme!='https' or u.username or u.password or u.port or u.fragment:
            raise ValueError('Only canonical HTTPS public sources are allowed')
        if u.hostname not in {'bloch-graphus.xyz','bloch.space','blochl1.com','developer.bitcoin.org','ethereum.org','github.com'}:
            raise ValueError('Source host is not approved')
        if u.path.startswith(('/api/porb/','/account','/portal')):
            raise ValueError('Private source paths are not allowed')
        return value

class Fact(StrictRecord):
    label: str = Field(min_length=1, max_length=96)
    value: str = Field(min_length=1, max_length=256)
    unit: Optional[str] = Field(default=None, max_length=48)
    source_id: Optional[str] = Field(default=None, min_length=1, max_length=64, pattern=r'^[a-zA-Z0-9_-]+$')

    @model_serializer(mode='wrap')
    def serialize(self, handler):
        result = handler(self)
        if self.source_id is None:
            result.pop('source_id', None)
        return result

class TransactionEndpoint(StrictRecord):
    reference: Optional[str] = Field(default=None, min_length=1, max_length=160)
    address: Optional[str] = Field(default=None, min_length=1, max_length=160)
    amount: Optional[str] = Field(default=None, min_length=1, max_length=78, pattern=r'^[0-9]+$')

    @model_serializer(mode='wrap')
    def serialize(self, handler):
        return {key: value for key, value in handler(self).items() if value is not None}

class PublicTransaction(StrictRecord):
    hash: str = Field(min_length=1, max_length=160)
    from_: Optional[str] = Field(default=None, alias='from', max_length=320)
    to: Optional[str] = Field(default=None, max_length=320)
    amount: Optional[str] = Field(default=None, max_length=100)
    asset: Optional[str] = Field(default=None, max_length=24)
    timestamp: Optional[str] = Field(default=None, max_length=40)
    status: Optional[str] = Field(default=None, max_length=64)
    record_type: Optional[Literal['utxo', 'account']] = None
    block_height: Optional[str] = Field(default=None, min_length=1, max_length=78, pattern=r'^[0-9]+$')
    slot: Optional[str] = Field(default=None, min_length=1, max_length=78, pattern=r'^[0-9]+$')
    block_hash: Optional[str] = Field(default=None, min_length=64, max_length=66, pattern=r'^(?:0x)?[a-fA-F0-9]{64}$')
    inputs: Optional[list[TransactionEndpoint]] = Field(default=None, max_length=24)
    outputs: Optional[list[TransactionEndpoint]] = Field(default=None, max_length=24)
    coverage: Optional[str] = Field(default=None, max_length=600)
    source_id: Optional[str] = Field(default=None, min_length=1, max_length=64, pattern=r'^[a-zA-Z0-9_-]+$')

    @model_serializer(mode='wrap')
    def serialize(self, handler):
        result = handler(self)
        for key in ('record_type', 'block_height', 'slot', 'block_hash', 'inputs', 'outputs', 'coverage', 'source_id'):
            if getattr(self, key) is None:
                result.pop(key, None)
        return result

class GraphNode(StrictRecord):
    id: str = Field(min_length=1, max_length=180)
    label: str = Field(min_length=1, max_length=180)
    kind: str = Field(min_length=1, max_length=40)

class GraphEdge(StrictRecord):
    source: str = Field(min_length=1, max_length=180)
    target: str = Field(min_length=1, max_length=180)
    label: Optional[str] = Field(default=None, max_length=96)

class PublicGraph(StrictRecord):
    nodes: list[GraphNode] = Field(default_factory=list, max_length=40)
    edges: list[GraphEdge] = Field(default_factory=list, max_length=80)

    @model_validator(mode='after')
    def known_nodes(self):
        ids={n.id for n in self.nodes}
        if len(ids)!=len(self.nodes) or any(e.source not in ids or e.target not in ids for e in self.edges):
            raise ValueError('Graph requires unique nodes and known edge endpoints')
        return self

class ObservationContext(StrictRecord):
    network: Network
    subject: Optional[Subject] = None
    sources: list[Source] = Field(default_factory=list, max_length=6)
    facts: list[Fact] = Field(default_factory=list, max_length=48)
    transactions: list[PublicTransaction] = Field(default_factory=list, max_length=20)
    graph: PublicGraph = Field(default_factory=PublicGraph)
    status: Literal['available','partial','unavailable']
    coverage: str = Field(max_length=1600)
    observed_at: Optional[str] = Field(default=None, max_length=40)

    @model_validator(mode='after')
    def bound_fact_sources(self):
        sources = {source.id: source for source in self.sources}
        if len(sources) != len(self.sources):
            raise ValueError('Observation source identifiers must be unique')
        for record in [*self.facts, *self.transactions]:
            if record.source_id is not None:
                source = sources.get(record.source_id)
                if source is None or source.status not in {'available', 'partial'}:
                    raise ValueError('Observed records require a known available or partial source')
        if sum(len(tx.inputs or []) + len(tx.outputs or []) for tx in self.transactions) > 80:
            raise ValueError('Transaction inputs and outputs exceed the shared 80-record limit')
        return self

    def snapshot(self):
        return self.model_dump(mode='json', by_alias=True)
