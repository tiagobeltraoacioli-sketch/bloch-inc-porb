"""Dedicated local Ollama adapter. No chain or training imports."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import re

import httpx

from .private_inference import (ContextLimitError, TEMPLATE_RESERVE, create_private_app,
                                prompt_size, token_count, validate_limits)


class PrivateOllama:
    def __init__(self, model, digest, transport=None, *, context_tokens=16384,
                 request_timeout=180, max_new_tokens=2048):
        if not model or not re.fullmatch(r'[a-f0-9]{64}', digest):
            raise ValueError('Pin an installed model and its full manifest SHA-256.')
        validate_limits(context_tokens, 120000, 480000, max_new_tokens)
        if (type(request_timeout) not in (int, float) or not math.isfinite(request_timeout)
                or not 1 <= request_timeout <= 1800):
            raise ValueError('Invalid request_timeout setting.')
        self.model, self.digest = model, digest
        self.context_tokens, self.max_new_tokens = context_tokens, max_new_tokens
        self.request_timeout = request_timeout
        self.http = httpx.Client(base_url='http://127.0.0.1:11434', timeout=request_timeout,
                                 follow_redirects=False, trust_env=False, transport=transport)

    def request(self, method, path, **kwargs):
        with self.http.stream(method, path, **kwargs) as response:
            response.raise_for_status()
            chunks, size = [], 0
            for chunk in response.iter_bytes():
                size += len(chunk)
                if size > 2_000_000:
                    raise ValueError('Runtime response too large.')
                chunks.append(chunk)
            data = json.loads(b''.join(chunks))
            if not isinstance(data, dict):
                raise ValueError('Invalid runtime response.')
            return data

    def verify(self):
        models = self.request('GET', '/api/tags', timeout=3).get('models', [])
        if not any(m.get('name') == self.model and m.get('digest') == self.digest for m in models):
            raise ValueError('Installed model differs from the operator pin.')
        data = self.request('POST', '/api/show', json={'model': self.model}, timeout=3)
        if data.get('remote_host') or data.get('remote_model') or not data.get('model_info'):
            raise ValueError('Model must have local weights without cloud routing.')

    def status(self):
        try:
            self.verify()
            loaded = self.request('GET', '/api/ps', timeout=3).get('models', [])
            active = next((m for m in loaded if isinstance(m, dict)
                           and m.get('name') == self.model and m.get('digest') == self.digest), {})
            vram, size = active.get('size_vram'), active.get('size')
            gpu = type(vram) is int and vram > 0
            fully_on_gpu = gpu and type(size) is int and size > 0 and vram >= size
            state = {'ready': True, 'model': self.model, 'model_digest': self.digest,
                     'gpu_inference': gpu, 'fully_on_gpu': fully_on_gpu,
                     'context_tokens': self.context_tokens}
            if 'context_length' in active:
                actual_context = active['context_length']
                if type(actual_context) is not int or not 1 <= actual_context <= 2**31 - 1:
                    raise ValueError('Invalid loaded context evidence.')
                state['loaded_context_tokens'] = actual_context
            return state
        except Exception:
            return {'ready': False, 'model': self.model, 'model_digest': self.digest,
                    'gpu_inference': False, 'fully_on_gpu': False,
                    'context_tokens': self.context_tokens,
                    'reason': 'Private runtime unavailable or model verification failed.'}

    def complete(self, messages, max_tokens, json_mode=False):
        input_budget = self.context_tokens - self.max_new_tokens - TEMPLATE_RESERVE
        if (type(max_tokens) is not int or not 1 <= max_tokens <= self.max_new_tokens
                or prompt_size(messages)[1] > input_budget):
            raise ContextLimitError('Context or output budget exceeded.')
        self.verify()
        payload = {'model': self.model, 'messages': messages, 'stream': False, 'think': True,
                   'truncate': False, 'shift': False, 'keep_alive': -1,
                   'options': {'temperature': 0, 'num_predict': max_tokens,
                               'num_ctx': self.context_tokens}}
        if json_mode:
            payload['format'] = 'json'
        try:
            result = self.request('POST', '/api/chat', json=payload)
        except httpx.HTTPStatusError as exc:
            # Never expose the private backend error body (which may contain input).
            # Ollama rejects oversized prompts with HTTP 400 when truncation is disabled.
            if exc.response.status_code in (400, 413, 422):
                raise ContextLimitError('Runtime rejected the supplied context or options.') from None
            raise
        prompt_tokens = token_count(result.get('prompt_eval_count'))
        output_tokens = token_count(result.get('eval_count'))
        if ((result.get('prompt_eval_count') is not None and prompt_tokens is None)
                or (result.get('eval_count') is not None and output_tokens is None)
                or (prompt_tokens is not None and prompt_tokens > self.context_tokens - self.max_new_tokens)
                or (output_tokens is not None and output_tokens > max_tokens)
                or (prompt_tokens is not None and output_tokens is not None
                    and prompt_tokens + output_tokens > self.context_tokens)):
            raise ValueError('Runtime exceeded the requested token budget.')
        if (result.get('model') != self.model or result.get('done') is not True
                or result.get('done_reason') != 'stop'):
            raise ValueError('Incomplete model output.')
        residency = self.status()
        if not residency.get('gpu_inference'):
            raise ValueError('The selected model was not running on the GPU.')
        if ('loaded_context_tokens' in residency
                and residency['loaded_context_tokens'] != self.context_tokens):
            raise ValueError('Loaded context does not match the configured capacity.')
        return {'output': result.get('message', {}).get('content'),
                'output_tokens': output_tokens, 'prompt_tokens': prompt_tokens, 'finish_reason': 'stop'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    token = Path(config['token_file']).read_text().strip()
    context_tokens = config.get('context_tokens', 16384)
    max_new_tokens = config.get('max_new_tokens', 2048)
    engine = PrivateOllama(config['model'], config['model_digest'],
                           context_tokens=context_tokens, max_new_tokens=max_new_tokens,
                           request_timeout=config.get('request_timeout', 180))
    app = create_private_app(engine, token, config['processing_region'],
                             max_prompt_chars=config.get('max_prompt_chars', 6000),
                             max_prompt_bytes=config.get('max_prompt_bytes', 12000),
                             max_new_tokens=max_new_tokens, context_tokens=context_tokens,
                             requests_per_minute=config.get('requests_per_minute',12),
                             max_waiting=config.get('max_waiting',0),
                             queue_timeout=config.get('queue_timeout',120))
    import uvicorn
    uvicorn.run(app, host='127.0.0.1', port=9008, access_log=False, log_level='critical')


if __name__ == '__main__':
    main()
