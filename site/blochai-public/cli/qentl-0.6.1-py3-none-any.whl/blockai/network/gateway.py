"""Private, tenant-scoped inference API for the BlochAI portal.

The portal credential is held by its server, never by a browser. Worker
credentials are separate and cannot access portal jobs or administrative APIs.
"""
from __future__ import annotations

import secrets
import re
import time
from dataclasses import dataclass, field
from typing import Optional

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, field_validator

from ..chain import KeyPair, Transaction, TxType
from ..chain.state import StateError, TaskRecord, TaskStatus
from .public_catalog import PUBLIC_MAX_NEW_TOKENS, PUBLIC_TENANT_PREFIX, Portal, PublicTaskRequest, public_prompt, public_guide
from .research_context import ObservationContext

ACTIVE = (TaskStatus.PENDING, TaskStatus.ASSIGNED, TaskStatus.READY)


@dataclass
class GatewayConfig:
    portal_token: str = field(repr=False)
    worker_token: str = field(repr=False)
    wallet: KeyPair = field(repr=False)
    model: str = "qwen2.5:0.5b"
    backend: str = "ollama"
    target_nodes: int = 13
    target_vram_gb: int = 2
    max_prompt_chars: int = 4000
    max_new_tokens: int = 256
    max_active: int = 16
    max_active_per_tenant: int = 2
    requests_per_minute: int = 10
    max_total_tasks: int = 10000
    public_token: Optional[str] = field(default=None, repr=False)
    public_wallet: Optional[KeyPair] = field(default=None, repr=False)
    public_max_active: int = 4
    public_max_active_per_portal: int = 2
    public_requests_per_minute: int = 30
    public_max_total_tasks: int = 10000

    def __post_init__(self):
        if min(len(self.portal_token), len(self.worker_token)) < 32:
            raise ValueError("Private API tokens must contain at least 32 characters")
        if secrets.compare_digest(self.portal_token, self.worker_token):
            raise ValueError("Portal and worker credentials must be different")
        if self.public_token is not None:
            if len(self.public_token) < 32:
                raise ValueError("Public API token must contain at least 32 characters")
            if any(secrets.compare_digest(self.public_token, token)
                   for token in (self.portal_token, self.worker_token)):
                raise ValueError("Public, portal and worker credentials must be different")
            if self.public_wallet is None or self.public_wallet.address == self.wallet.address:
                raise ValueError("Public API requires a separate public service wallet")
        if self.backend not in ("qwen", "ollama"):
            raise ValueError("The portal requires a real qwen or ollama backend")


class TaskRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    tenant_id: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z0-9_.:@-]+$")
    prompt: str = Field(min_length=1, max_length=4000)
    model: Optional[str] = Field(default=None, max_length=200)
    max_new_tokens: int = Field(default=128, ge=1, le=256)
    observations: Optional[ObservationContext] = None

    @field_validator("prompt")
    @classmethod
    def meaningful_prompt(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Prompt must not be blank")
        return value

    @field_validator("tenant_id")
    @classmethod
    def private_namespace(cls, value: str) -> str:
        if value.lower().startswith(PUBLIC_TENANT_PREFIX):
            raise ValueError("Public tenant namespace is reserved")
        return value


def task_view(task: TaskRecord) -> dict:
    return {
        "task_id": task.task_id, "status": task.status.value, "model": task.model,
        "created_at": task.created_at, "completed_at": task.settled_at,
        "output": task.output if task.status == TaskStatus.COMPLETED else None,
        "failure_reason": "No consensus or task deadline exceeded" if task.status == TaskStatus.FAILED else None,
        "poll_after_ms": 1500,
        **({"guide": task.guide} if task.guide is not None else {}),
    }


def configure_gateway(app: FastAPI, coord, config: GatewayConfig) -> None:
    chain = coord.chain
    if chain.params.dev_faucet:
        raise ValueError("Private gateway refuses a chain with dev_faucet enabled")
    if config.public_wallet is not None and config.public_wallet.address == chain.authority.address:
        raise ValueError("Public service wallet must not be the chain authority")
    coord.gateway = config

    @app.middleware("http")
    async def private_api(request: Request, call_next):
        path = request.url.path
        portal = path.startswith("/v1/")
        public = path.startswith("/public/")
        if public and config.public_token is None:
            return JSONResponse({"detail": "Not found"}, status_code=404, headers={"Cache-Control": "no-store"})
        expected = config.public_token if public else (config.portal_token if portal else config.worker_token)
        supplied = request.headers.get("authorization", "")
        if not secrets.compare_digest(supplied.encode(), ("Bearer " + expected).encode()):
            return JSONResponse({"detail": "Unauthorized"}, status_code=401,
                                headers={"WWW-Authenticate": "Bearer", "Cache-Control": "no-store"})
        if public:
            allowed_post = request.method == "POST" and path == "/public/v1/tasks"
            allowed_get = request.method == "GET" and re.fullmatch(r"/public/v1/tasks/[a-f0-9]{64}", path)
            if not (allowed_post or allowed_get):
                return JSONResponse({"detail": "Forbidden"}, status_code=403, headers={"Cache-Control": "no-store"})
            queries = list(request.query_params.multi_items())
            if (allowed_post and queries) or (allowed_get and (len(queries) != 1 or queries[0][0] != "portal")):
                return JSONResponse({"detail": "Only the portal query parameter is accepted for task reads"},
                                    status_code=422, headers={"Cache-Control": "no-store"})
        elif not portal:
            allowed_get = path in ("/", "/nodes", "/work") or path.startswith(("/nonce/", "/balance/"))
            allowed_post = path in ("/tx", "/nodes/heartbeat")
            if not ((request.method == "GET" and allowed_get) or (request.method == "POST" and allowed_post)):
                return JSONResponse({"detail": "Forbidden"}, status_code=403)
        # Bound bytes before JSON parsing, including requests without Content-Length.
        body = bytearray()
        async for chunk in request.stream():
            body.extend(chunk)
            if len(body) > 65536:
                return JSONResponse({"detail": "Request body too large"}, status_code=413)
        if request.method == "GET" and body:
            return JSONResponse({"detail": "GET requests must not include a body"}, status_code=400)
        request._body = bytes(body)
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/v1/status")
    def status():
        with chain.lock:
            online = coord.online_nodes()
            ready = coord.runtime_ready_nodes(config.model)
            gpu_ready = [a for a in ready if coord.runtime[a].gpu_inference]
            funded = chain.state.balance(config.wallet.address) >= chain.state.task_fee(128)
            accepting = len(gpu_ready) >= chain.params.replication and funded
            return {
                "service": "BlochAI", "ready": accepting, "model": config.model, "backend": config.backend,
                "nodes": {"registered": len(chain.state.nodes), "online": len(online),
                          "ready": len(ready), "gpu_ready": len(gpu_ready)},
                "fleet": {"target_nodes": config.target_nodes, "target_vram_gb": config.target_vram_gb},
                "reason": None if accepting else ("Insufficient ready GPU inference workers" if len(gpu_ready) < chain.params.replication
                                                   else "Service inference budget exhausted"),
                "limits": {"max_prompt_chars": config.max_prompt_chars, "max_new_tokens": config.max_new_tokens},
                "replication": chain.params.replication,
                "hardware_source": "Signed worker reports; GPU inference means runtime GPU use, not host RAM",
            }

    def accept_task(*, wallet: KeyPair, tenant_id: str, prompt: str, max_new_tokens: int,
                    max_active: int, max_active_per_tenant: int, requests_per_minute: int,
                    max_total_tasks: int, guide: Optional[dict] = None):
        if len(prompt) > config.max_prompt_chars or max_new_tokens > config.max_new_tokens:
            raise HTTPException(422, "Request exceeds the configured inference limits")
        with chain.lock:
            now = time.time()
            # Derive quota from the durable chain, so restart does not reset it.
            owned = [t for t in chain.state.tasks.values() if t.submitter == wallet.address]
            tenant = [t for t in owned if t.tenant_id == tenant_id]
            if len(owned) >= max_total_tasks:
                raise HTTPException(503, "Service ledger capacity reached")
            if sum(t.status in ACTIVE for t in owned) >= max_active:
                raise HTTPException(429, "Inference queue is full", headers={"Retry-After": "15"})
            if (sum(t.status in ACTIVE for t in tenant) >= max_active_per_tenant
                    or sum(now - t.created_at < 60 for t in tenant) >= requests_per_minute):
                raise HTTPException(429, "Tenant inference quota reached", headers={"Retry-After": "60"})
            if len(coord.runtime_ready_nodes(config.model, gpu_only=True)) < chain.params.replication:
                raise HTTPException(503, "Insufficient ready GPU inference workers", headers={"Retry-After": "15"})
            fee = chain.state.task_fee(max_new_tokens)
            if chain.state.balance(wallet.address) < fee:
                raise HTTPException(503, "Service inference budget exhausted")
            tx = Transaction.build(wallet, TxType.TASK_SUBMIT, chain.pending_nonce(wallet.address), {
                "tenant_id": tenant_id, "prompt": prompt, "model": config.model,
                "max_new_tokens": max_new_tokens, "replication": chain.params.replication,
                **({"guide": guide} if guide is not None else {}),
            })
            try:
                chain.submit_tx(tx)
                # Persist accepted work before returning its tracking ID.
                chain.produce_block()
            except StateError as exc:
                raise HTTPException(409, "Task could not be accepted") from exc
            return task_view(chain.state.tasks[tx.hash])

    @app.post("/v1/tasks", status_code=202)
    def submit(req: TaskRequest):
        if req.model is not None and req.model != config.model:
            raise HTTPException(422, "Model is not enabled for this service")
        return accept_task(wallet=config.wallet, tenant_id=req.tenant_id, prompt=req.prompt,
                           max_new_tokens=req.max_new_tokens, max_active=config.max_active,
                           max_active_per_tenant=config.max_active_per_tenant,
                           requests_per_minute=config.requests_per_minute, max_total_tasks=config.max_total_tasks,
                           guide=req.observations.snapshot() if req.observations else None)

    @app.post("/public/v1/tasks", status_code=202)
    def public_submit(req: PublicTaskRequest):
        return accept_task(wallet=config.public_wallet, tenant_id=PUBLIC_TENANT_PREFIX + req.portal,
                           prompt=public_prompt(req), max_new_tokens=PUBLIC_MAX_NEW_TOKENS,
                           max_active=config.public_max_active,
                           max_active_per_tenant=config.public_max_active_per_portal,
                           requests_per_minute=config.public_requests_per_minute,
                           max_total_tasks=config.public_max_total_tasks, guide=public_guide(req))

    @app.get("/public/v1/tasks/{task_id}")
    def public_task(task_id: str, portal: Portal = Query(...)):
        with chain.lock:
            record = chain.state.tasks.get(task_id)
            if (record is None or record.submitter != config.public_wallet.address
                    or record.tenant_id != PUBLIC_TENANT_PREFIX + portal):
                raise HTTPException(404, "Task not found")
            return task_view(record)

    @app.get("/v1/tasks/{task_id}")
    def task(task_id: str, tenant_id: str = Query(..., min_length=1, max_length=128)):
        with chain.lock:
            record = chain.state.tasks.get(task_id)
            if record is None or record.submitter != config.wallet.address or record.tenant_id != tenant_id:
                raise HTTPException(404, "Task not found")
            return task_view(record)
