"""Escalonador: escolhe quais nós de GPU executam cada tarefa pendente.

Critérios: nó online (heartbeat recente), stake ≥ mínimo, reputação, modelo
suportado, e carga atual (nº de tarefas designadas ainda abertas). A escolha
é ponderada por `NodeInfo.score` (stake × reputação × VRAM).

Diversidade de operador: o Proof-of-Compute só é uma verificação independente
de fato quando as réplicas de uma tarefa rodam sob operadores diferentes —
duas GPUs do mesmo dono que "concordam" não provam nada além de que o
hardware desse dono é consistente consigo mesmo. Por isso, ao escolher as
réplicas, o escalonador evita repetir `operator` sempre que há candidatos de
operadores distintos suficientes; só cai para o mesmo operador quando não há
alternativa (ex.: rede pequena, hoje dominada por uma única frota).
"""
from __future__ import annotations

import random
from typing import Dict, List, Optional

from ..chain.state import NodeInfo, State, TaskRecord, TaskStatus


def open_load(state: State) -> Dict[str, int]:
    load: Dict[str, int] = {}
    for t in state.tasks.values():
        if t.status == TaskStatus.ASSIGNED:
            for n in t.assigned:
                if n not in t.results:
                    load[n] = load.get(n, 0) + 1
    return load


def choose_nodes(state: State, task: TaskRecord, online: List[str], *, max_load: int = 4,
                 rng: Optional[random.Random] = None) -> List[str]:
    rng = rng or random.Random()
    load = open_load(state)
    candidates: List[NodeInfo] = [
        n for n in state.eligible_nodes()
        if n.address in online
        and load.get(n.address, 0) < max_load
        and (not n.models or task.model in n.models)
        and n.address != task.submitter
    ]
    if len(candidates) < task.replication:
        return []
    chosen: List[str] = []
    chosen_operators: set = set()
    pool = list(candidates)
    while len(chosen) < task.replication and pool:
        # prioriza operadores ainda não usados nesta tarefa, se existir opção
        fresh = [n for n in pool if not n.operator or n.operator not in chosen_operators]
        eligible = fresh if fresh else pool
        weights = [max(n.score, 1e-6) / (1 + load.get(n.address, 0)) for n in eligible]
        pick = rng.choices(eligible, weights=weights, k=1)[0]
        chosen.append(pick.address)
        chosen_operators.add(pick.operator)
        pool.remove(pick)
    return chosen
