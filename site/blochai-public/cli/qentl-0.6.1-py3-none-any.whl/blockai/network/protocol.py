"""Schemas HTTP entre clientes, nós de GPU e o coordenador."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from ..chain.crypto import canonical_json


class RuntimeReport(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    backend: str = Field(max_length=32)
    model: str = Field(max_length=200)
    ready: bool = False
    gpu_inference: bool = False
    busy: bool = False


def heartbeat_message(timestamp: float, runtime: Optional[RuntimeReport] = None) -> bytes:
    if runtime is None:
        return f"heartbeat:{timestamp}".encode()
    return b"heartbeat-v2:" + canonical_json({"timestamp": timestamp, "runtime": runtime.model_dump()})


class ChainInfo(BaseModel):
    chain_id: str
    height: int
    head_hash: str
    authority: str
    treasury_balance: int
    nodes_registered: int
    nodes_online: int
    tasks_total: int
    mempool: int
    params: Dict[str, Any]


class TxSubmitResponse(BaseModel):
    hash: str
    accepted: bool = True


class FaucetRequest(BaseModel):
    address: str
    amount: int = Field(gt=0)


class HeartbeatRequest(BaseModel):
    address: str
    pubkey: str
    timestamp: float = Field(allow_inf_nan=False)
    signature: str  # assinatura de f"heartbeat:{timestamp}"
    queue_depth: int = 0
    runtime: Optional[RuntimeReport] = None


class WorkItem(BaseModel):
    task_id: str
    prompt: str
    model: str
    max_new_tokens: int
    replicas: List[str]


class NodeView(BaseModel):
    address: str
    gpu: Dict[str, Any]
    models: List[str]
    operator: str = ""
    stake: int
    reputation: float
    tasks_completed: int
    tasks_failed: int
    earned: int
    online: bool
    last_seen: Optional[float] = None
