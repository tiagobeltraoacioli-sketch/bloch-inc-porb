"""Isolated public/synthetic training tools; never imported by inference services."""
