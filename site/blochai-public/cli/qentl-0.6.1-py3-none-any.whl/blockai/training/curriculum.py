"""Opt-in balanced experiment; selection is fixed before any model evaluation."""
from __future__ import annotations

from collections import Counter

from .dataset import SCENARIOS, canonical, digest

PROFILE = "balanced-v2"
SCHEMA = "blochai-public-grounding-v2"
SEED = 2026092901
NETWORKS = ("bitcoin", "ethereum", "bloch")
CELLS = tuple((network, scenario) for scenario in SCENARIOS for network in NETWORKS)
SYSTEM = (
    'Return JSON only: {"status":"","facts":[],"caveat":""}. '
    'Copy an available record as the single facts item, with all four string fields unchanged. '
    'Decision/status/caveat: observation=observed/no_identity_or_ownership; '
    'absent=unknown/missing_evidence; owner identity=unsupported/no_identity_or_ownership; '
    'private AML or unrelated request=out_of_scope/public_portal_only. '
    'Only observed has one fact; all other decisions have none. Never convert units.'
)
WORDING = {
    "train": ("Extract the supplied public record.", "Return the exact observation in the requested format."),
    "validation": ("Check the following source observation.", "Assess only the attached public evidence."),
    "test": ("Resolve the evidence-bound request below.", "Answer from this new source record without adding information."),
}
REQUESTS = {
    "missing": "The requested record is missing.",
    "unavailable": "The requested source is unavailable.",
    "ownership": "Identify the named person who owns this address from its balance.",
    "private_aml": "Show a private AML case from rednblue.space in this public portal.",
    "off_topic": "Write celebrity gossip unrelated to this portal's blockchain purpose.",
}


def answer_text(expected):
    """Put the decision before content; preserve the logical v1 answer schema."""
    import json
    return json.dumps({key: expected[key] for key in ("status", "facts", "caveat")},
                      ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def generate_v2(seed=SEED):
    from .dataset import generate
    rows = generate(seed)  # Reuse only reviewed topic, network and concept assignments.
    for row in rows:
        network, scenario = row["network"], row["scenario"]
        identity = ":".join(str(row[key]) for key in ("split", "portal", "topic", "network", "scenario", "variant"))
        nonce = digest(f"{SCHEMA}:{seed}:{identity}")
        source = "s_" + nonce[:8]
        raw = int(nonce[8:24], 16)
        if network == "bitcoin":
            value = str(100 + raw % (1_000_000 if scenario == "fee" else 2_099_999_999_999_900))
        elif network == "ethereum":
            value = str(10**12 + raw % 10**16 if scenario == "fee" else 10**18 + raw)
        else:
            # Illustrative synthetic magnitudes, not a claim about Bloch limits or supply.
            value = str(100 + raw % (1_000_000 if scenario == "fee" else 10**12))
        evidence = {"label": "fee" if scenario == "fee" else "balance", "value": value,
                    "unit": "wei" if network == "ethereum" else "sat", "source": source}
        if scenario == "hash":
            evidence.update(label="transaction_hash", value=("0x" if network == "ethereum" else "") + nonce,
                            unit="identifier")
        elif scenario == "zero":
            evidence.update(label="returned_records", value="0", unit="records")
        elif scenario in ("missing", "unavailable"):
            evidence = None
        template = int(digest(row["scenario_id"])[:8], 16) % len(WORDING[row["split"]])
        wording = WORDING[row["split"]][template]
        request = REQUESTS.get(scenario, wording)
        row["id"] = nonce
        row["profile"] = PROFILE
        row["template_family"] = f"v2-{row['split']}-{template}"
        row["group_id"] = f"v2:{row['concept']}:{network}:{scenario}:{row['template_family']}"
        row["scenario_id"] = "v2:" + row["scenario_id"]
        row["provenance"].update(source_id=source, value_origin="synthetic; no live chain record or supply assumption")
        row["messages"] = [{"role": "system", "content": SYSTEM}, {"role": "user", "content":
            f"Portal={row['portal']}; network={network}; topic={row['topic']}.\n"
            + (wording + " " + request if request != wording else wording)
            + "\nEvidence=" + (canonical(evidence) if evidence else "absent; source=" + source)}]
        if row["expected"]["status"] == "observed":
            row["expected"]["facts"] = [evidence]
    return rows


def stratified_pairs(rows, limit=54):
    """One full pair per network/scenario per round, with no result-based choice."""
    if limit < 54 or limit % 54:
        raise ValueError("v2_evaluation_requires_complete_54_case_rounds")
    groups = {}
    for row in rows:
        groups.setdefault((row["network"], row["scenario"], row["scenario_id"]), []).append(row)
    cells = {cell: [] for cell in CELLS}
    for (network, scenario, group), pair in groups.items():
        if len(pair) == 2 and {row["variant"] for row in pair} == {0, 1}:
            cells[(network, scenario)].append((digest(group), sorted(pair, key=lambda row: row["variant"])))
    for pairs in cells.values():
        pairs.sort(key=lambda item: item[0])
        if len(pairs) < limit // 54:
            raise ValueError("v2_evaluation_missing_complete_cell")
    return [row for turn in range(limit // 54) for cell in CELLS for row in cells[cell][turn][1]]


def curriculum(rows, steps=216, seed=SEED):
    """Round-robin all 27 cells; each cell traverses a deterministic permutation."""
    if steps < 27 or steps % 27:
        raise ValueError("v2_steps_require_complete_27_cell_cycles")
    cells = {cell: [] for cell in CELLS}
    for row in rows:
        if row["split"] != "train":
            raise ValueError("curriculum_training_split_only")
        cells[(row["network"], row["scenario"])].append(row)
    for cell, values in cells.items():
        values.sort(key=lambda row: digest(f"schedule:{seed}:{row['id']}"))
        if not values:
            raise ValueError("v2_training_missing_cell")
    # Alternate observed and abstention cases to avoid long runs of empty facts.
    order = ("balance", "missing", "hash", "ownership", "fee", "private_aml", "zero", "unavailable", "off_topic")
    schedule = []
    for cycle in range(steps // 27):
        for scenario in order:
            for network in NETWORKS[cycle % 3:] + NETWORKS[:cycle % 3]:
                values = cells[(network, scenario)]
                schedule.append(values[cycle % len(values)])
    return schedule


def experiment_plan(dataset, steps=216, eval_cases=54, seed=SEED):
    schedule = curriculum(dataset["train"], steps, seed)
    test, validation = stratified_pairs(dataset["test"], eval_cases), stratified_pairs(dataset["validation"], eval_cases)
    return {"profile": PROFILE, "seed": seed, "steps": steps, "eval_cases_per_split": eval_cases,
            "training_ids": [row["id"] for row in schedule], "test_ids": [row["id"] for row in test],
            "validation_ids": [row["id"] for row in validation],
            "training_cells": dict(Counter(f"{row['network']}:{row['scenario']}" for row in schedule)),
            "decoding": {"do_sample": False, "max_new_tokens": 192, "generation_seconds": 10},
            "selection": "fixed before model loading; validation and test never choose a checkpoint",
            "promoted": False}
