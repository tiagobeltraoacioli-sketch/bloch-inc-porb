"""Optional CUDA training runtime. No inference imports, service control or promotion."""
from __future__ import annotations

import gc
import importlib.metadata
import json
import os
import random
import sys
import time
from collections import Counter
from pathlib import Path

from .dataset import MODEL, REVISION, canonical, evaluation_sample, load_verified_dataset
from .metrics import comparison, evaluate_answer, summarize
from .curriculum import PROFILE, answer_text, curriculum, experiment_plan, stratified_pairs

PINS = {"torch": "2.10.0", "transformers": "4.57.1", "peft": "0.17.1", "accelerate": "1.10.1", "bitsandbytes": "0.48.1"}
MIN_FREE_CUDA_BYTES = 1536 * 1024 * 1024


def validate_cuda_reservation(free_bytes):
    # The operator separately requires 1,600 MiB before CUDA initialization.
    # Driver/context allocations consumed ~54 MiB on the reviewed A16-2Q host.
    if free_bytes < MIN_FREE_CUDA_BYTES:
        raise RuntimeError("gpu_not_reserved_or_insufficient_free_memory")


def cast_frozen_embeddings(model, dtype):
    """Undo only the frozen large embedding/head FP32 upcast, retaining ties."""
    input_module, output_module = model.get_input_embeddings(), model.get_output_embeddings()
    if input_module is None or output_module is None:
        raise RuntimeError("embedding_modules_required")
    parameters = {id(parameter): parameter for module in (input_module, output_module) for parameter in module.parameters()}
    if any(parameter.requires_grad for parameter in parameters.values()):
        raise RuntimeError("embedding_cast_requires_frozen_parameters")
    input_weight, output_weight = input_module.weight, output_module.weight
    tied = input_weight.data_ptr() == output_weight.data_ptr()
    if getattr(model.config, "tie_word_embeddings", False) and not tied:
        raise RuntimeError("expected_embedding_tie_missing")
    before = {"input": str(input_weight.dtype), "output": str(output_weight.dtype)}
    before_bytes = sum(parameter.numel() * parameter.element_size() for parameter in parameters.values())
    for parameter in parameters.values():
        parameter.data = parameter.data.to(dtype=dtype)
    if tied and input_weight.data_ptr() != output_weight.data_ptr():
        output_weight.data = input_weight.data  # Preserve an existing shared-storage tie.
    if tied and input_weight.data_ptr() != output_weight.data_ptr():
        raise RuntimeError("embedding_tie_changed")
    after_bytes = sum(parameter.numel() * parameter.element_size() for parameter in parameters.values())
    return {"before": before, "after": {"input": str(input_weight.dtype), "output": str(output_weight.dtype)},
            "tied": tied, "frozen": all(not parameter.requires_grad for parameter in parameters.values()),
            "parameter_bytes_saved": before_bytes - after_bytes,
            "layer_norms_unchanged": True}


def encode_example(tokenizer, row, max_length):
    prompt = tokenizer.apply_chat_template(row["messages"], tokenize=True, add_generation_prompt=True)
    answer = answer_text(row["expected"]) if row.get("profile") == PROFILE else canonical(row["expected"])
    full = tokenizer.apply_chat_template(row["messages"] + [{"role": "assistant", "content": answer}], tokenize=True, add_generation_prompt=False)
    if full[:len(prompt)] != prompt:
        raise ValueError("chat_template_prefix_mismatch")
    if len(full) > max_length:
        return None  # Never truncate the expected answer or silently change the task.
    return {"input_ids": full, "labels": [-100] * len(prompt) + full[len(prompt):]}


def inspect_tokenization(args):
    """CPU-only tokenizer preflight; loads no model and does not reserve a GPU."""
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1")
    from transformers import AutoTokenizer
    dataset, _ = load_verified_dataset(args.dataset)
    tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, cache_dir=args.cache_dir,
                                              local_files_only=True, trust_remote_code=False)
    report = {}
    for split, rows in dataset.items():
        lengths, retained = [], []
        for row in rows:
            encoded = encode_example(tokenizer, row, 100000)
            lengths.append(len(encoded["input_ids"]))
            if lengths[-1] <= args.sequence_length:
                retained.append(row)
        report[split] = {"examples": len(rows), "min_tokens": min(lengths), "max_tokens": max(lengths),
                         "complete_within_limit": len(retained), "by_scenario": dict(Counter(row["scenario"] for row in retained)),
                         "by_cell": dict(Counter(f"{row['network']}:{row['scenario']}" for row in retained))}
    return report


def runtime_versions(device):
    if sys.prefix == sys.base_prefix:
        raise ValueError("training_requires_a_separate_virtual_environment")
    prefix = str(Path(sys.prefix).resolve())
    if prefix.startswith(("/opt/blockai/.venv", "/opt/blochai/.venv")):
        raise ValueError("inference_environment_is_forbidden")
    versions = {}
    for name, expected in PINS.items():
        if device == "cpu" and name == "bitsandbytes":
            continue
        actual = importlib.metadata.version(name)
        if actual.split("+")[0] != expected:
            raise ValueError(f"runtime_version_mismatch:{name}:{actual}:expected:{expected}")
        versions[name] = actual
    return versions


def run_pilot(args):
    started = time.monotonic()
    deadline = started + args.wall_seconds
    output = Path(args.output).resolve()
    if output.exists():
        raise ValueError("output_directory_must_be_new")
    output.mkdir(parents=True, mode=0o700)
    report = {"status": "initializing", "model": MODEL, "revision": REVISION, "promoted": False,
              "device": args.device, "requested_steps": args.steps, "completed_steps": 0,
              "sequence_length": args.sequence_length, "wall_budget_seconds": args.wall_seconds}

    def save_report():
        report["elapsed_seconds"] = round(time.monotonic() - started, 2)
        (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")

    def remaining():
        return deadline - time.monotonic()

    try:
        dataset, manifest = load_verified_dataset(args.dataset)
        report["dataset_manifest"] = manifest
        v2 = manifest.get("profile") == PROFILE
        if v2:
            plan = experiment_plan(dataset, seed=manifest["seed"])
            if (args.steps != plan["steps"] or args.eval_cases != plan["eval_cases_per_split"]
                    or args.seed != plan["seed"] or args.max_new_tokens != plan["decoding"]["max_new_tokens"]
                    or args.generation_seconds != plan["decoding"]["generation_seconds"]):
                raise ValueError("runtime_does_not_match_frozen_v2_experiment_plan")
            if args.wall_seconds < 2 * args.eval_cases * 2 * args.generation_seconds + 120:
                raise ValueError("wall_budget_cannot_cover_planned_evaluations")
            report["experiment_plan"] = plan
            report["completed_training_cells"] = {}
            # Persist the complete schedule and held-out identities before model loading.
            (output / "experiment-plan.json").write_text(canonical(plan) + "\n")
        report["versions"] = runtime_versions(args.device)
        # Loading is offline, from a pre-existing reviewed immutable model snapshot.
        os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1",
                          WANDB_DISABLED="true", TOKENIZERS_PARALLELISM="false")
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

        torch.set_num_threads(2)
        torch.manual_seed(args.seed)
        random.seed(args.seed)
        cuda = args.device == "cuda"
        if cuda:
            if not torch.cuda.is_available():
                raise RuntimeError("cuda_unavailable")
            free, total = torch.cuda.mem_get_info()
            report["hardware"] = {"gpu": torch.cuda.get_device_name(0), "free_vram_bytes": free, "total_vram_bytes": total,
                                  "cuda": torch.version.cuda}
            report["hardware"]["required_free_after_cuda_bytes"] = MIN_FREE_CUDA_BYTES
            validate_cuda_reservation(free)
            torch.cuda.reset_peak_memory_stats()
        else:
            report["hardware"] = {"cpu_threads": 2, "cpu_fallback_explicitly_requested": True}
        tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, cache_dir=args.cache_dir,
                                                  local_files_only=True, trust_remote_code=False)
        tokenizer.pad_token_id = tokenizer.eos_token_id
        encoded = [encode_example(tokenizer, row, args.sequence_length) for row in dataset["train"]]
        training = [row for row in encoded if row]
        report["tokenization"] = {"train_examples": len(training), "overlength_skipped": len(encoded) - len(training), "truncated": 0,
                                  "retained_by_scenario": dict(Counter(row["scenario"] for row, item in zip(dataset["train"], encoded) if item)),
                                  "skipped_by_scenario": dict(Counter(row["scenario"] for row, item in zip(dataset["train"], encoded) if not item))}
        if len(training) < 8:
            raise RuntimeError("too_few_complete_examples_for_sequence_limit")
        retained_scenarios = {row["scenario"] for row, encoded_row in zip(dataset["train"], encoded) if encoded_row}
        if retained_scenarios != {row["scenario"] for row in dataset["train"]}:
            raise RuntimeError("sequence_limit_dropped_entire_scenario")
        if v2:
            schedule = curriculum(dataset["train"], args.steps, args.seed)
            encoding_by_id = {row["id"]: item for row, item in zip(dataset["train"], encoded)}
            if any(encoding_by_id[row["id"]] is None for row in schedule):
                raise RuntimeError("sequence_limit_dropped_planned_curriculum_example")
            training_schedule = [encoding_by_id[row["id"]] for row in schedule]
            test_rows = stratified_pairs(dataset["test"], args.eval_cases)
            validation_rows = stratified_pairs(dataset["validation"], args.eval_cases)
        else:
            test_rows = evaluation_sample(dataset["test"], args.eval_cases)
            validation_rows = evaluation_sample(dataset["validation"], min(4, args.eval_cases))
        report["test_ids"] = [row["id"] for row in test_rows]
        report["validation_ids"] = [row["id"] for row in validation_rows]
        report["decoding"] = {"do_sample": False, "max_new_tokens": args.max_new_tokens,
                              "generation_seconds": args.generation_seconds, "same_baseline_and_candidate": True,
                              "schema_constrained_decoding": False}
        dtype = torch.bfloat16 if cuda and torch.cuda.is_bf16_supported() else torch.float16 if cuda else torch.float32
        config = {"revision": REVISION, "cache_dir": args.cache_dir, "local_files_only": True,
                  "trust_remote_code": False, "torch_dtype": dtype, "attn_implementation": "sdpa"}
        if cuda:
            config.update(quantization_config=BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                          bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=dtype), device_map={"": 0})
        model = AutoModelForCausalLM.from_pretrained(MODEL, **config)
        model.config.use_cache = False
        if cuda:
            model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=True,
                                                    gradient_checkpointing_kwargs={"use_reentrant": False})
        else:
            for parameter in model.parameters():
                parameter.requires_grad = False
            model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        # Both baseline and candidate use this same frozen-base representation.
        # Leave normalization and all subsequently created LoRA parameters FP32.
        report["frozen_embedding_precision"] = cast_frozen_embeddings(model, dtype)
        model = get_peft_model(model, LoraConfig(r=4, lora_alpha=8, target_modules=["q_proj", "v_proj"],
                              lora_dropout=.05, bias="none", task_type="CAUSAL_LM"))
        model.enable_input_require_grads()
        device = torch.device("cuda:0" if cuda else "cpu")
        report["trainable_parameters"] = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
        report["trainable_parameter_dtypes"] = sorted({str(parameter.dtype) for parameter in model.parameters() if parameter.requires_grad})
        if any(parameter.dtype != torch.float32 for parameter in model.parameters() if parameter.requires_grad):
            raise RuntimeError("adapter_parameters_must_remain_fp32")
        report["total_parameters"] = sum(parameter.numel() for parameter in model.parameters())
        save_report()

        def evaluate(rows, name):
            model.eval()
            results, answers = [], []
            for row in rows:
                if remaining() < 5:
                    raise TimeoutError("pilot_wall_budget_exhausted")
                tokens = tokenizer.apply_chat_template(row["messages"], tokenize=True, add_generation_prompt=True, return_tensors="pt").to(device)
                if tokens.shape[1] > args.sequence_length:
                    answer = ""  # Count as failure, never truncate held-out evidence.
                else:
                    # FP32 normalization can emit FP32 hidden states while the
                    # frozen output head is BF16/FP16. Match training autocast
                    # for both sides of the paired evaluation.
                    with torch.inference_mode(), torch.autocast(device_type="cuda" if cuda else "cpu", dtype=dtype, enabled=cuda):
                        generated = model.generate(input_ids=tokens, attention_mask=torch.ones_like(tokens), do_sample=False,
                                                   max_new_tokens=args.max_new_tokens, max_time=min(args.generation_seconds, remaining()-2),
                                                   use_cache=True, pad_token_id=tokenizer.eos_token_id)
                    answer = tokenizer.decode(generated[0, tokens.shape[1]:], skip_special_tokens=True)
                results.append(evaluate_answer(row, answer))
                answers.append({"id": row["id"], "answer": answer})
                (output / (name + "-answers.json")).write_text(json.dumps(answers, indent=2) + "\n")
            (output / (name + "-results.json")).write_text(json.dumps(results, indent=2) + "\n")
            return summarize(results)

        # Baseline uses identical quantization/tokenization with the adapter disabled.
        with model.disable_adapter():
            report["baseline_test"] = evaluate(test_rows, "baseline-test")
            if v2:
                report["baseline_validation"] = evaluate(validation_rows, "baseline-validation")
        save_report()
        optimizer = torch.optim.AdamW([parameter for parameter in model.parameters() if parameter.requires_grad], lr=2e-4)
        scaler = torch.amp.GradScaler("cuda", enabled=cuda and dtype == torch.float16)
        losses, randomizer = [], random.Random(args.seed)
        model.train()
        model.config.use_cache = False
        for step in range(args.steps):
            # Reserve time for the paired held-out evaluation; no partial evaluation gets promoted.
            if remaining() < (len(test_rows) + len(validation_rows)) * args.generation_seconds + 20:
                if v2:
                    raise TimeoutError("planned_curriculum_cannot_finish_with_evaluation_reserve")
                report["stopped_early"] = "evaluation_time_reserved"
                break
            row = training_schedule[step] if v2 else training[randomizer.randrange(len(training))]
            ids = torch.tensor([row["input_ids"]], dtype=torch.long, device=device)
            labels = torch.tensor([row["labels"]], dtype=torch.long, device=device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type="cuda" if cuda else "cpu", dtype=dtype, enabled=cuda):
                loss = model(input_ids=ids, attention_mask=torch.ones_like(ids), labels=labels).loss
            if not torch.isfinite(loss):
                raise RuntimeError("nonfinite_training_loss")
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
            scaler.step(optimizer)
            scaler.update()
            losses.append(float(loss.detach().cpu()))
            report["completed_steps"] = step + 1
            if v2:
                selected = schedule[step]
                cell = f"{selected['network']}:{selected['scenario']}"
                report["completed_training_cells"][cell] = report["completed_training_cells"].get(cell, 0) + 1
            if step % 5 == 0:
                print(json.dumps({"step": step+1, "loss": round(losses[-1], 6), "remaining_seconds": round(remaining())}), flush=True)
                save_report()
        if not losses:
            raise TimeoutError("no_training_steps_completed")
        del optimizer, loss, ids, labels
        gc.collect()
        if cuda:
            torch.cuda.empty_cache()
        adapter = output / "adapter-candidate"
        model.save_pretrained(adapter, safe_serialization=True)
        tokenizer.save_pretrained(adapter)
        report["training_loss"] = {"first": losses[0], "last": losses[-1], "mean": sum(losses)/len(losses)}
        report["candidate_validation"] = evaluate(validation_rows, "candidate-validation")
        report["candidate_test"] = evaluate(test_rows, "candidate-test")
        report["comparison"] = comparison(report["baseline_test"], report["candidate_test"])
        if v2:
            report["validation_comparison"] = comparison(report["baseline_validation"], report["candidate_validation"])
        report["status"] = "completed"
        if cuda:
            report["peak_vram_allocated_bytes"] = torch.cuda.max_memory_allocated()
            report["peak_vram_reserved_bytes"] = torch.cuda.max_memory_reserved()
    except Exception as error:
        report["status"] = "oom" if "out of memory" in str(error).lower() else "incomplete"
        report["error"] = type(error).__name__ + ": " + str(error)[:500]
        report["automatic_cpu_retry"] = False
        report["promoted"] = False
    finally:
        save_report()
    return report
