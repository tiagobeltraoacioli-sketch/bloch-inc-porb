"""Strict whole-answer checks, not keyword overlap or evaluator-model opinion."""
import json
import hashlib
from collections import Counter


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate_json_key")
        result[key] = value
    return result


def _nonfinite(value):
    raise ValueError("nonfinite_json_constant")


def _shape(actual):
    if (not isinstance(actual, dict) or set(actual) != {"status", "facts", "caveat"}
            or not isinstance(actual["status"], str) or not isinstance(actual["facts"], list)):
        return False
    shapes = {"observed": (1, "no_identity_or_ownership"), "unknown": (0, "missing_evidence"),
              "unsupported": (0, "no_identity_or_ownership"), "out_of_scope": (0, "public_portal_only")}
    if actual["status"] not in shapes:
        return False
    size, caveat = shapes[actual["status"]]
    return (len(actual["facts"]) == size and actual["caveat"] == caveat
            and all(isinstance(fact, dict) and set(fact) == {"label", "value", "unit", "source"}
                    and all(isinstance(value, str) and bool(value) for value in fact.values())
                    for fact in actual["facts"]))


def evaluate_answer(example, answer):
    expected = example["expected"]
    try:
        actual = json.loads(answer.strip(), object_pairs_hook=_unique, parse_constant=_nonfinite)
        valid = _shape(actual)
    except (ValueError, TypeError, AttributeError, RecursionError):
        actual, valid = {}, False
    fact_exact = valid and actual.get("facts") == expected["facts"]
    status_exact = valid and actual.get("status") == expected["status"]
    caveat_exact = valid and actual.get("caveat") == expected["caveat"]
    target = json.dumps(expected, sort_keys=True, separators=(",", ":"), allow_nan=False)
    prompt = json.dumps(example.get("messages", []), sort_keys=True, separators=(",", ":"), allow_nan=False)
    return {"id": example["id"], "scenario": example["scenario"], "scenario_id": example["scenario_id"],
            "network": example.get("network", "unspecified"), "variant": example.get("variant"),
            "expected_sha256": hashlib.sha256(target.encode()).hexdigest(),
            "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
            "valid_json": valid, "whole_answer_exact": bool(valid and actual == expected),
            "facts_units_sources_exact": bool(fact_exact), "status_exact": bool(status_exact),
            "caveat_exact": bool(caveat_exact), "requires_abstention": expected["status"] != "observed",
            "abstention_correct": bool(status_exact and fact_exact and caveat_exact) if expected["status"] != "observed" else None}


def summarize(results):
    if len({row["id"] for row in results}) != len(results):
        raise ValueError("duplicate_evaluation_id")
    total = len(results)
    abstentions = [row for row in results if row["requires_abstention"]]
    pairs = {}
    for row in results:
        pairs.setdefault(row["scenario_id"], []).append(row)
    complete_pairs = [rows for rows in pairs.values() if len(rows) == 2 and {row.get("variant") for row in rows} == {0, 1}]
    ratio = lambda key, rows: sum(bool(row[key]) for row in rows) / len(rows) if rows else 0.0
    def counts(rows):
        observed = [row for row in rows if not row["requires_abstention"]]
        abstained = [row for row in rows if row["requires_abstention"]]
        return {"examples": len(rows), "whole_answer_correct": sum(row["whole_answer_exact"] for row in rows),
                "facts_units_sources_correct": sum(row["facts_units_sources_exact"] for row in rows),
                "observed_examples": len(observed), "observed_answers_correct": sum(row["whole_answer_exact"] for row in observed),
                "observed_facts_correct": sum(row["facts_units_sources_exact"] for row in observed),
                "abstention_examples": len(abstained), "abstentions_correct": sum(bool(row["abstention_correct"]) for row in abstained)}
    fingerprint = json.dumps(sorted((row["id"], row["expected_sha256"], row["prompt_sha256"], row["network"], row["scenario_id"], row["variant"]) for row in results), separators=(",", ":"))
    observed = [row for row in results if not row["requires_abstention"]]
    cells = Counter(f"{row['network']}:{row['scenario']}" for row in results)
    return {"examples": total, "whole_answer_exact": ratio("whole_answer_exact", results),
            "facts_units_sources_exact": ratio("facts_units_sources_exact", results),
            "valid_json": ratio("valid_json", results), "abstention_examples": len(abstentions),
            "abstention_accuracy": ratio("abstention_correct", abstentions),
            "counterfactual_pairs": len(complete_pairs),
            "counterfactual_pair_accuracy": sum(all(row["whole_answer_exact"] for row in pair) for pair in complete_pairs) / len(complete_pairs) if complete_pairs else 0.0,
            "benchmark_sha256": hashlib.sha256(fingerprint.encode()).hexdigest(),
            "observed_answer_accuracy": ratio("whole_answer_exact", observed),
            "observed_facts_accuracy": ratio("facts_units_sources_exact", observed),
            "counts": counts(results), "cells": dict(cells),
            "by_network": {value: counts([row for row in results if row["network"] == value]) for value in sorted({row["network"] for row in results})},
            "by_scenario": {value: counts([row for row in results if row["scenario"] == value]) for value in sorted({row["scenario"] for row in results})}}


def comparison(baseline, candidate):
    """Even a perfect small pilot is insufficient for deployment approval."""
    comparable = (baseline["examples"] == candidate["examples"] and baseline["examples"] > 0
                  and bool(baseline.get("benchmark_sha256"))
                  and baseline.get("benchmark_sha256") == candidate.get("benchmark_sha256"))
    from .curriculum import CELLS
    coverage = all(candidate.get("cells", {}).get(f"{network}:{scenario}", 0) >= 2 for network, scenario in CELLS)
    return {"comparable": comparable,
            "whole_answer_delta": candidate["whole_answer_exact"] - baseline["whole_answer_exact"] if comparable else None,
            "observed_facts_delta": candidate.get("observed_facts_accuracy", 0) - baseline.get("observed_facts_accuracy", 0) if comparable else None,
            "pilot_improvement_observed": comparable and candidate["whole_answer_exact"] > baseline["whole_answer_exact"] and candidate["abstention_accuracy"] >= baseline["abstention_accuracy"] and candidate.get("observed_facts_accuracy", 0) >= baseline.get("observed_facts_accuracy", 0),
            "eligible_for_manual_review": comparable and coverage and candidate["counterfactual_pairs"] * 2 == candidate["examples"] and candidate["examples"] >= 54 and candidate["abstention_examples"] >= 10 and candidate["whole_answer_exact"] >= .98 and candidate["abstention_accuracy"] == 1.0 and candidate.get("observed_facts_accuracy") == 1.0 and candidate["whole_answer_exact"] >= baseline["whole_answer_exact"],
            "promoted": False, "limitation": "Synthetic closed-schema copying and abstention only; not validation of open-ended analysis."}
