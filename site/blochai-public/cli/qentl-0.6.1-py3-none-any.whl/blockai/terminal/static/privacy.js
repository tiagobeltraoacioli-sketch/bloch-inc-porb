'use strict';
(() => {
  let project=null;
  function renderProject(){
    $('privacy-project-name').textContent=project?'Dados de '+project.name:'Selecione um projeto';
    $('privacy-export').hidden=!project||project.shared;$('privacy-delete').disabled=!project||project.shared;$('privacy-confirm').value='';$('privacy-confirm').placeholder=project?.id||'Selecione um projeto';
    if(project)$('privacy-export').href=`/api/projects/${project.id}/export.zip`;
  }
  async function refresh(){
    try{const data=await api('/api/privacy');$('history-retention').value=String(data.history_days);$('privacy-processing').textContent=data.processing;if(data.maintenance_error)$('privacy-status').textContent='A manutenção de retenção encontrou um erro. O operador precisa verificar antes de confirmar a limpeza.';$('privacy-limitations').replaceChildren();for(const text of data.limitations){const item=document.createElement('li');item.textContent=text;$('privacy-limitations').append(item);}}
    catch(e){error(e);}
  }
  $('privacy-form').onsubmit=async event=>{
    event.preventDefault();event.submitter.disabled=true;
    try{await api('/api/privacy',{history_days:Number($('history-retention').value)});$('privacy-status').textContent='Retenção atualizada. Históricos vencidos serão removidos pela manutenção local.';}
    catch(e){$('privacy-status').textContent=e.message;}finally{event.submitter.disabled=false;}
  };
  $('privacy-delete-form').onsubmit=async event=>{
    event.preventDefault();if(!project||project.shared)return;
    if($('privacy-confirm').value!==project.id){error(new Error('Digite exatamente o identificador mostrado no campo.'));return;}
    if(!window.confirm(`Excluir definitivamente o projeto “${project.name}”, seus arquivos, notas, código e histórico deste computador? Exportações, backups e envios remotos anteriores permanecem fora desta exclusão.`))return;
    event.submitter.disabled=true;
    try{await api(`/api/projects/${project.id}/delete`,{confirm_project:$('privacy-confirm').value});await window.BlochWorkspace.deleted();$('privacy-status').textContent='Projeto e registros locais excluídos.';}
    catch(e){error(e);}finally{event.submitter.disabled=!project||project.shared;}
  };
  $('privacy-audit-details').ontoggle=async()=>{
    if(!$('privacy-audit-details').open)return;
    try{const data=await api('/api/privacy/audit');$('privacy-audit').textContent=data.events.length?data.events.map(row=>`${formatDate(row.at)}  ${row.action}`).reverse().join('\n'):'Nenhum evento registrado.';}
    catch(e){error(e);}
  };
  window.BlochWorkspace.onProject(event=>{project=event.detail;renderProject();});
  window.BlochPrivacy={refresh};renderProject();
})();
