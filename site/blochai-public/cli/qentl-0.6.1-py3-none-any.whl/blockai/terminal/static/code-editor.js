'use strict';
(() => {
  let file=null,dirty=false,proposal=null,epoch=0,busy=false;
  let editor=null,disposeDiff=null,loadedSuggestion=null,externalStale=false;
  const access=()=>window.BlochWorkspace.access?.()||{write:true,ai:true};
  const content=()=>editor?editor.value():$('code-content').value;
  function changed(value){if(!file)return;$('code-content').value=value;dirty=value!==file.content;clearProposal();$('code-status').textContent=externalStale?'O arquivo mudou no disco. Seu rascunho foi preservado; copie-o antes de reabrir.':dirty?'Rascunho local. Revise antes de aplicar.':'Sem alterações.';lines();}
  function mount(){if(!file||!window.BlochMonaco)return;if(editor)editor.dispose();editor=window.BlochMonaco.create($('monaco-editor'),file.path,$('code-content').value,changed);editor.readonly($('code-content').readOnly);$('monaco-editor').hidden=false;document.querySelector('.code-surface').hidden=true;}
  function diff(text){$('code-diff').replaceChildren();for(const line of text.split('\n')){const row=document.createElement('span');row.className=line.startsWith('+')?'diff-add':line.startsWith('-')?'diff-remove':'diff-context';row.textContent=line+'\n';$('code-diff').append(row);}}
  async function showProposal(value){proposal=value;diff(value.diff);$('code-diff-panel').hidden=false;
    if(window.BlochMonaco&&!project()?.shared){const version=epoch;const response=await api(base()+'/'+file.id+'/history/'+value.id);if(version!==epoch||proposal?.id!==value.id)return;if(disposeDiff)disposeDiff();$('monaco-diff').hidden=false;disposeDiff=window.BlochMonaco.diff($('monaco-diff'),file.path,response.change.before,response.change.after);$('code-diff').hidden=true;}
    $('code-status').textContent=externalStale?'O arquivo mudou no disco. A comparação foi preservada, mas precisa ser refeita com a versão atual.':'Verde: adições. Vermelho: retiradas. O arquivo será alterado somente ao aplicar.';
    $('code-apply').disabled=externalStale||!access().write;
  }
  const project=()=>window.BlochWorkspace.project();
  function base(){if(!project())throw new Error('Selecione um projeto.');return `/api/projects/${project().id}/code`;}
  function canLeave(){return !dirty||window.confirm('Há código com alterações não aplicadas. Deseja descartá-las?');}
  function lines(){const count=$('code-content').value.split('\n').length;$('code-lines').textContent=Array.from({length:count},(_,i)=>i+1).join('\n');$('code-lines').scrollTop=$('code-content').scrollTop;}
  function clearProposal(){proposal=null;$('code-diff-panel').hidden=true;if(disposeDiff){disposeDiff();disposeDiff=null;}$('monaco-diff').hidden=true;$('code-diff').hidden=false;}
  function render(data,external=false){
    file=data;dirty=false;externalStale=false;clearProposal();$('code-apply').disabled=false;if(!external)window.BlochWorkspace.inspect('code');
    window.BlochFiles?.select({...file,kind:'code',title:file.path});
    $('code-path').textContent=file.path;$('code-content').value=file.content;$('code-content').readOnly=!access().write||new TextEncoder().encode(file.content).length>100000;$('code-review-form').hidden=!access().ai;$('code-check').disabled=!access().write;
    $('code-preview').disabled=$('code-content').readOnly;$('code-start').value='1';$('code-question').value='Revise este código. Aponte problemas e sugira correções, citando as linhas. Não afirme que testes foram executados.';
    $('code-meta').textContent=`${size(file.size)} · revisão ${file.sha256.slice(0,12)} · ${file.partition}`;
    $('code-status').textContent=!access().write?'Projeto compartilhado para leitura.':$('code-content').readOnly?'Arquivo acima de 100 KB: edição disponível apenas para arquivos menores.':'Arquivo atual. Altere o texto e confira a comparação antes de aplicar.';
    $('code-suggestions').hidden=true;loadedSuggestion=null;$('code-check-result').textContent='';lines();mount();loadHistory();
  }
  async function open(id,line=1){
    if(!canLeave())return;const version=++epoch,url=base();
    try{const data=await api(url+'/'+id);if(version===epoch&&url===base()){render(data.file);$('code-start').value=String(line);if(editor)editor.reveal(line);else{const position=data.file.content.split('\n').slice(0,line-1).join('\n').length;$('code-content').focus();$('code-content').setSelectionRange(position,position);}}}catch(e){error(e);}
  }
  async function loadHistory(){
    if(!file)return;const id=file.id,url=base();$('code-history-list').replaceChildren();$('code-history-diff').hidden=true;
    if(project()?.shared){$('code-history-list').textContent='O histórico privado não é compartilhado.';return;}
    try{const data=await api(url+'/'+id+'/history');if(file?.id!==id||url!==base())return;
      if(!data.changes.length){$('code-history-list').textContent='As alterações aplicadas por este editor aparecerão aqui.';return;}
      const names={proposed:'Comparação proposta',applied:'Alteração aplicada',applying:'Aplicação interrompida',not_applied:'Não aplicada'};
      for(const change of data.changes){const button=document.createElement('button');button.type='button';button.textContent=`${names[change.status]||change.status} · ${formatDate(change.created_at)} · ${change.after_sha256.slice(0,8)}`;
        button.onclick=async()=>{try{const result=await api(url+'/'+id+'/history/'+change.id);if(file?.id!==id||url!==base())return;$('code-history-diff').hidden=false;$('code-history-diff').textContent=result.change.diff||'Sem diferenças.';}catch(e){error(e);}};
        $('code-history-list').append(button);
      }
    }catch(e){error(e);}
  }
  $('code-content').addEventListener('input',()=>changed($('code-content').value));
  $('code-content').addEventListener('scroll',()=>{$('code-lines').scrollTop=$('code-content').scrollTop;});
  $('code-content').addEventListener('keydown',event=>{
    if(event.key==='Tab'&&!$('code-content').readOnly){event.preventDefault();const field=$('code-content');field.setRangeText('  ',field.selectionStart,field.selectionEnd,'end');field.dispatchEvent(new Event('input'));}
    if((event.metaKey||event.ctrlKey)&&event.key==='s'){event.preventDefault();$('code-preview').click();}
  });
  $('code-preview').onclick=async()=>{
    if(!file||busy||externalStale||!access().write)return;busy=true;const version=epoch,url=base()+'/'+file.id;
    try{const data=await api(url+'/preview',{content:content(),revision:file.sha256});if(version!==epoch)return;await showProposal(data.proposal);$('code-diff-panel').scrollIntoView({block:'nearest'});}
    catch(e){$('code-status').textContent=e.message;}finally{busy=false;}
  };
  $('code-apply').onclick=async()=>{
    if(!file||!proposal||busy||externalStale||!access().write)return;busy=true;$('code-apply').disabled=true;const version=epoch,url=base()+'/'+file.id;
    try{const data=await api(url+'/apply',{proposal_id:proposal.id,approved:true});if(version!==epoch)return;render(data.file);$('code-status').textContent='Alteração aplicada e versão registrada. Testes não executados.';window.dispatchEvent(new CustomEvent('blochai:files'));}
    catch(e){$('code-status').textContent=e.message;}finally{busy=false;$('code-apply').disabled=externalStale||!access().write;}
  };
  $('code-reload').onclick=()=>{if(file)open(file.id);};
  $('organize-code-file').onclick=()=>{if(file)window.BlochFiles?.manage({...file,kind:'code',title:file.path});};
  $('close-code').onclick=()=>{if(canLeave()){file=null;dirty=false;epoch++;$('code-editor').hidden=true;$('editor-empty').hidden=false;}};
  $('code-review-form').onsubmit=async event=>{
    event.preventDefault();if(!file||!access().ai)return;const version=epoch;$('code-suggestions').hidden=false;$('code-suggestions').textContent='Solicitando sugestões…';
    try{await window.BlochWorkspace.reviewCode(file,content(),$('code-question').value,Number($('code-start').value),$('code-action').value);}
    catch(e){if(epoch===version)$('code-suggestions').textContent=e.message;}
  };
  $('code-create').onsubmit=async event=>{
    event.preventDefault();if(busy||!access().write)return;busy=true;const version=++epoch;event.submitter.disabled=true;
    try{const data=await api(base(),{path:$('code-new-path').value});if(version!==epoch)return;render(data.file);$('code-create').reset();window.dispatchEvent(new CustomEvent('blochai:files'));}
    catch(e){error(e);}finally{busy=false;event.submitter.disabled=false;}
  };
  function create(){if(!access().write)return;if(!project()){error(new Error('Crie um projeto antes de adicionar código.'));return;}if(!canLeave())return;dirty=false;file=null;epoch++;window.BlochWorkspace.inspect('new-code');$('code-create').hidden=false;$('code-new-path').focus();}
  window.addEventListener('blochai:project',()=>{file=null;dirty=false;epoch++;clearProposal();$('code-editor').hidden=true;$('code-create').hidden=true;$('editor-empty').hidden=false;});
  window.addEventListener('blochai:revision',async event=>{
    if(!file||event.detail.project!==project()?.id||!event.detail.changed_ids.includes(file.id))return;
    const version=epoch,id=file.id,url=base();
    try{
      if(!event.detail.files.some(item=>item.id===id))throw new Error('O arquivo foi removido ou movido no disco. Seu conteúdo local foi preservado.');
      const data=await api(url+'/'+id);if(version!==epoch||file?.id!==id||url!==base()||data.file.sha256===file.sha256)return;
      if(dirty||proposal||busy){externalStale=true;$('code-apply').disabled=true;$('code-preview').disabled=true;$('code-status').textContent='O arquivo mudou no disco. Seu rascunho ou comparação foi preservado. Copie o que precisa e reabra a versão atual antes de aplicar.';return;}
      const question=$('code-question').value,start=$('code-start').value,position=$('code-content').selectionStart;
      render(data.file,true);$('code-question').value=question;$('code-start').value=start;
      if(editor)editor.reveal(Number(start)||1);else $('code-content').setSelectionRange(Math.min(position,data.file.content.length),Math.min(position,data.file.content.length));
      $('code-status').textContent='Arquivo atualizado a partir do disco. O Graphus também foi sincronizado.';
    }catch(e){if(version===epoch&&file?.id===id){externalStale=true;$('code-apply').disabled=true;$('code-preview').disabled=true;$('code-status').textContent=e.message;}}
  });
  window.addEventListener('blochai:review',event=>{const job=event.detail;if(file?.id!==job.code_review?.id||project()?.id!==job.project)return;$('code-suggestions').hidden=false;$('code-suggestions').textContent=job.summary||'O modelo está revisando o trecho solicitado…';if(job.suggestion&&job.suggestion.id!==loadedSuggestion){loadedSuggestion=job.suggestion.id;showProposal(job.suggestion).catch(error);}});
  $('code-check').onclick=async()=>{if(!file||!access().write)return;const version=epoch,text=content();$('code-check').disabled=true;$('code-check-result').textContent='Verificando sintaxe…';
    try{const data=await api(base()+'/'+file.id+'/check',{content:text});if(version!==epoch||text!==content())return;
      if(editor)editor.check(data.diagnostics);$('code-check-result').textContent=!data.supported?data.reason:data.diagnostics.length?data.diagnostics.map(d=>`L${d.line}:${d.column} · ${d.message}`).join('\n'):(data.check==='python_compile'?'Compilação Python aprovada.':'Sintaxe aprovada.')+' Nenhum teste de execução foi realizado.';
    }catch(e){$('code-check-result').textContent=e.message;}finally{$('code-check').disabled=!access().write;}};
  window.addEventListener('blochai:editor-ready',mount);
  window.addEventListener('qentl:file-action',event=>{
    const action=event.detail;
    if(!file||action.project!==project()?.id||action.previous_node_id!==file.id||!['move','trash'].includes(action.action))return;
    if(dirty||proposal||busy){externalStale=true;$('code-apply').disabled=true;$('code-preview').disabled=true;$('code-status').textContent='O arquivo foi movido ou enviado à lixeira. Seu rascunho foi preservado; copie-o antes de abrir outra versão.';return;}
    file=null;dirty=false;epoch++;clearProposal();$('code-editor').hidden=true;$('editor-empty').hidden=false;
  });
  window.addEventListener('beforeunload',event=>{if(dirty){event.preventDefault();event.returnValue='';}});
  window.BlochCode={open,create,canLeave,hasUnsaved:()=>dirty||Boolean(proposal)||busy};
})();
