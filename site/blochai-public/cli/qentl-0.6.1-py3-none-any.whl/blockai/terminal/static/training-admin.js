'use strict';
(() => {
  let permitted=false,available=false,busy=false,epoch=0;
  const actions=['training-start','training-pause','training-resume','training-save'];
  function controls(){
    $('training-admin-panel').hidden=!permitted;
    $('training-open').hidden=!permitted;
    for(const id of actions)$(id).disabled=busy||!permitted||!available;
    $('training-refresh').disabled=busy||!permitted;
  }
  function dailyProgress(data){
    const daily=data?.daily_progress,latest=daily?.latest;
    $('training-daily-roles').replaceChildren();$('training-daily-history').replaceChildren();
    $('training-daily-sources').textContent='';$('training-daily-benchmark').textContent='';
    $('training-daily-comparison').replaceChildren();$('training-daily-feedback').textContent='';
    if(!latest){$('training-daily-summary').textContent='O controlador ainda não publicou evidência diária. Isso não confirma um novo treinamento ou melhoria.';return;}
    $('training-daily-summary').textContent=`${latest.date_utc} UTC · ${latest.study_rounds} ciclos observados · ${latest.failed_rounds} falhas · ${latest.verified_exercise_observations} observações de exercícios verificados · ${latest.candidate_attempts} candidatos · ${latest.completed_training_steps} etapas de treinamento isolado. Registros diários: ${daily.retained_days}/${daily.retention_days}.`;
    for(const role of (latest.roles||[]).slice(0,8)){
      const row=document.createElement('p');row.textContent=`${role.name}: ${role.completed} tarefas concluídas, ${role.failed} falhas. ${(role.skills||[]).join('; ')}.`;
      $('training-daily-roles').append(row);
    }
    const feedback=latest.feedback;
    if(feedback&&typeof feedback==='object'){
      const count=key=>Number.isInteger(feedback[key])&&feedback[key]>=0?feedback[key]:'—';
      $('training-daily-feedback').textContent=`Piloto isolado de 0,5B · ${count('tasks')} tarefas · ${count('attempts')} tentativas · ${count('revisions')} revisões · ${count('visible_failures')} falhas visíveis · ${count('verified_solutions')} soluções verificadas · ${count('repaired_solutions')} corrigidas após retorno · ${count('confirmation_rejections')} rejeições na confirmação · ${count('duplicate_solutions')} repetições · ${count('budget_exhausted_rounds')} ciclos sem orçamento restante. São verificações limitadas de expressões sintéticas; não medem QI nem demonstram evolução do modelo 9B.`;
    }
    const evaluation=latest.latest_evaluation;
    if(evaluation){
      const label={regressed:'Regressão observada',unchanged:'Resultado inalterado',improved_small_benchmark:'Ganho apenas no pequeno benchmark'}[evaluation.outcome]||'Resultado não classificado';
      for(const split of ['validation','test'])for(const version of ['baseline','candidate']){
        const metric=evaluation[version]?.[split];
        if(!metric||!Number.isInteger(metric.passed)||!Number.isInteger(metric.cases)||metric.cases<=0||metric.passed<0||metric.passed>metric.cases)continue;
        const row=document.createElement('div');row.className='training-comparison-row';
        const label=document.createElement('span');label.textContent=`Piloto isolado · ${split==='test'?'teste':'validação'} · ${version==='baseline'?'base':'candidato'}: ${metric.passed}/${metric.cases}`;
        const track=document.createElement('div');track.className='capability-track';const fill=document.createElement('div');fill.className='capability-fill';fill.style.width=String(100*metric.passed/metric.cases)+'%';track.append(fill);row.append(label,track);$('training-daily-comparison').append(row);
      }
      $('training-daily-benchmark').textContent=label+'. '+['validation','test'].map(split=>`${split==='validation'?'Validação':'Teste'}: base ${evaluation.baseline[split].passed}/${evaluation.baseline[split].cases}; candidato ${evaluation.candidate[split].passed}/${evaluation.candidate[split].cases}`).join(' · ')+'. Pesos do Qwen em produção não foram alterados; nenhuma promoção automática.';
    }else $('training-daily-benchmark').textContent='Nenhuma avaliação de candidato concluída neste dia. Estudo de fontes não comprova melhoria dos pesos do modelo.';
    for(const day of (daily.recent_days||[]).slice(0,7)){
      const row=document.createElement('p');row.textContent=`${day.date_utc}: ${day.successful_rounds}/${day.study_rounds} ciclos sem falhas; ${day.evaluated_candidates} candidatos avaliados; ${day.improved_candidates} ganhos no benchmark e ${day.regressed_candidates} regressões.`;
      $('training-daily-history').append(row);
    }
    $('training-daily-sources').textContent=(daily.source_receipts||[]).map(source=>`${source.repository} · ${source.license}\nCommit ${source.commit}\nRecibo SHA-256 ${source.receipt_sha256}`).join('\n\n');
  }
  function display(data){
    // Only the controller's returned facts are displayed; starting a service
    // does not establish a finished training run or a promoted model.
    $('training-admin-result').textContent=JSON.stringify(data,null,2).slice(0,60000);
    const status=data.status||{},controller=status.controller||{},study=status.study||{},candidate=status.candidate||{},schedule=status.schedule||{};
    if(Number.isInteger(controller.max_workers))$('training-workers').value=String(controller.max_workers);
    if(Array.isArray(controller.curriculum_families))for(const name of ['sum','length','sort'])$('training-'+name).checked=controller.curriculum_families.includes(name);
    const facts=[];
    if(status.observed_at_utc)facts.push('Observado: '+status.observed_at_utc);
    if(typeof schedule.enabled==='boolean')facts.push('Agendamento: '+(schedule.enabled?'habilitado':'pausado'));
    if(study.stage)facts.push('Estudo: '+study.stage);
    if(Number.isInteger(study.fleet?.jobs_completed))facts.push(study.fleet.jobs_completed+' estudos concluídos');
    if(Number.isInteger(study.fleet?.jobs_failed))facts.push(study.fleet.jobs_failed+' falhas registradas');
    if(candidate.status)facts.push('Candidato: '+candidate.status);
    if(Number.isInteger(candidate.completed_steps))facts.push(`${candidate.completed_steps}/${candidate.requested_steps??'?'} etapas de treinamento`);
    $('training-admin-summary').textContent=facts.join(' · ')||'O controlador ainda não registrou métricas de estudo ou treinamento.';
    dailyProgress(status);
  }
  async function refresh(){
    if(!permitted||busy)return;busy=true;controls();const version=epoch;
    try{const data=await api('/api/admin/training/status');if(version!==epoch)return;display(data);$('training-admin-status').textContent='Estado consultado no controlador. Confira os registros e resultados abaixo.';}
    catch(e){if(version===epoch)$('training-admin-status').textContent='Estado indisponível: '+e.message;}
    finally{busy=false;controls();}
  }
  async function capabilities(){
    const version=++epoch;permitted=false;available=false;controls();$('training-admin-result').textContent='';dailyProgress(null);
    try{
      const data=await api('/api/admin/training/capabilities');if(version!==epoch)return;
      permitted=data.can_control===true;available=data.available===true;controls();
      if(!permitted)return;
      $('training-admin-status').textContent=available?'Controle autorizado. Atualize para consultar o estado dos agentes.':(data.readiness_note||data.reason||'Controle autorizado, mas o controlador ainda não está configurado ou disponível.');
      if(available)await refresh();
    }catch{if(version===epoch){permitted=false;controls();}}
  }
  async function control(action,values={}){
    if(!permitted||!available||busy)return;busy=true;controls();const version=epoch;
    $('training-admin-status').textContent='Enviando comando autorizado ao controlador…';
    try{
      const data=await api('/api/admin/training/control',{action,...values});if(version!==epoch)return;
      display(data);$('training-admin-status').textContent='Controlador respondeu ao comando. Consulte o estado para acompanhar a execução; nenhum modelo foi promovido por esta ação.';
    }catch(e){if(version===epoch)$('training-admin-status').textContent='Comando não confirmado: '+e.message;}
    finally{busy=false;controls();}
  }
  $('training-refresh').onclick=refresh;
  $('training-open').onclick=()=>{$('agents-dialog').close();window.BlochWorkspace.pane('collection');$('projects-tab').click();$('training-admin-panel').open=true;refresh();};
  $('training-start').onclick=()=>control('start');$('training-pause').onclick=()=>control('pause');$('training-resume').onclick=()=>control('resume');
  $('training-configure').onsubmit=event=>{
    event.preventDefault();const workers=Number($('training-workers').value),families=['sum','length','sort'].filter(name=>$('training-'+name).checked);
    if(!Number.isInteger(workers)||workers<1||workers>8||!families.length){$('training-admin-status').textContent='Escolha de 1 a 8 agentes e ao menos uma família do currículo.';return;}
    control('configure',{max_workers:workers,curriculum_families:families});
  };
  window.addEventListener('blochai:account',capabilities);controls();
  if(window.BlochWorkspace?.identity?.())capabilities();
})();
