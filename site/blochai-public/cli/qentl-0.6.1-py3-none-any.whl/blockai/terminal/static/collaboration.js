'use strict';
(() => {
  let project=null,epoch=0,busy=false;
  const owned=()=>Boolean(project&&!project.shared);
  const base=()=>`/api/projects/${project.id}/collaborators`;
  function resetCode(){
    $('project-invite-result').hidden=true;$('project-invite-code').value='';$('project-invite-expiry').textContent='';
  }
  function controls(){
    $('collaboration-owner').hidden=!owned();
    $('create-project-invite-button').disabled=busy||!owned();
    $('accept-project-invite-button').disabled=busy;
    $('refresh-collaborators').disabled=busy||!owned();
  }
  async function refresh(){
    if(!owned())return;const version=epoch,url=base();
    try{
      const data=await api(url);if(version!==epoch)return;
      $('collaborator-list').replaceChildren();
      const rows=[...(data.members||[]).map(row=>({...row,pending:false})),...(data.invitations||[]).map(row=>({...row,pending:true}))];
      if(!rows.length)$('collaborator-list').textContent='Nenhum colaborador ou convite pendente.';
      for(const row of rows){
        const item=document.createElement('div'),label=document.createElement('p'),button=document.createElement('button');
        item.className='connection-row';label.textContent=`${row.email} · ${row.role==='editor'?'Edição':'Leitura'} · ${row.pending?'Convite até '+formatDate(row.expires_at):'Acesso ativo'}`;
        button.type='button';button.className='text-button';button.textContent=row.pending?'Cancelar convite':'Revogar acesso';
        button.onclick=async()=>{
          if(busy||version!==epoch)return;busy=true;button.disabled=true;controls();
          try{await api(url+'/'+encodeURIComponent(row.id)+'/revoke',{});if(version===epoch){$('collaboration-status').textContent='Permissão revogada. Novos acessos serão recusados; cópias já obtidas não podem ser recolhidas.';await refresh();}}
          catch(e){if(version===epoch)$('collaboration-status').textContent=e.message;}
          finally{busy=false;button.disabled=false;controls();}
        };
        item.append(label,button);$('collaborator-list').append(item);
      }
    }catch(e){if(version===epoch)$('collaboration-status').textContent='Não foi possível consultar as permissões: '+e.message;}
  }
  $('create-project-invite').onsubmit=async event=>{
    event.preventDefault();if(busy||!owned())return;busy=true;controls();resetCode();const version=epoch,url=base();
    try{
      const data=await api(url,{email:$('collaborator-email').value.trim(),role:$('collaborator-role').value});
      if(version!==epoch)return;
      const invitation=data.invitation;
      $('project-invite-code').value=invitation.token;$('project-invite-result').hidden=false;
      $('project-invite-expiry').textContent=`Para ${invitation.email} · válido até ${formatDate(invitation.expires_at)} · uso único.`;
      $('collaboration-status').textContent='Código gerado. Compartilhe-o diretamente com a pessoa; nenhum e-mail foi enviado. É preciso acessar a mesma instalação Qentl.';
      await refresh();
    }catch(e){if(version===epoch)$('collaboration-status').textContent=e.message;}
    finally{busy=false;controls();}
  };
  $('accept-project-invite').onsubmit=async event=>{
    event.preventDefault();if(busy)return;busy=true;controls();
    try{
      const data=await api('/api/project-invitations/accept',{token:$('project-invite-token').value.trim()});
      $('project-invite-token').value='';await window.BlochWorkspace.reloadProjects();await window.BlochWorkspace.selectProject(data.project.id);
      $('collaboration-status').textContent='Convite aceito nesta instalação. O projeto compartilhado aparece na lista.';
    }catch(e){$('collaboration-status').textContent=e.message;}
    finally{busy=false;controls();}
  };
  $('copy-project-invite').onclick=async()=>{
    const code=$('project-invite-code');if(!code.value)return;
    try{await navigator.clipboard.writeText(code.value);$('collaboration-status').textContent='Código copiado. Envie apenas à pessoa indicada no convite.';}
    catch{code.focus();code.select();$('collaboration-status').textContent='Código selecionado. Use ⌘C ou Ctrl+C para copiar.';}
  };
  $('refresh-collaborators').onclick=refresh;
  $('open-collaborators').onclick=()=>{window.BlochWorkspace.pane('collection');$('projects-tab').click();$('collaboration-panel').open=true;refresh();};
  $('collaboration-panel').ontoggle=()=>{if($('collaboration-panel').open)refresh();};
  window.BlochWorkspace.onProject(event=>{
    project=event.detail;epoch++;resetCode();$('collaborator-list').replaceChildren();$('collaboration-status').textContent='';
    $('collaboration-project-title').textContent=project?'Permissões de '+project.name:'Selecione seu projeto';controls();
    if(owned()&&$('collaboration-panel').open)refresh();
  });
  controls();
})();
