'use strict';
(() => {
  let project=null,nodes=[],selected=new Set(),loading=0,saved='',dirty=false;
  const eligible=node=>!['task','model'].includes(node.kind);
  function render(){
    const scoped=$('scope-mode').value==='selection';
    $('scope-selection').hidden=!scoped;$('scope-selection').replaceChildren();
    for(const id of selected){const node=nodes.find(n=>n.id===id);if(!node)continue;const button=document.createElement('button');button.type='button';button.className='scope-chip';button.textContent=node.title+' ×';button.setAttribute('aria-label','Retirar '+node.title+' do escopo');button.onclick=()=>toggle(node);$('scope-selection').append(button);}
    $('scope-hint').textContent=scoped?`${selected.size} pontos · Shift/Ctrl/⌘ + clique no mapa para selecionar. Funções limitam a edição às suas linhas; pastas incluem novos arquivos.`:'O modelo poderá trabalhar nos arquivos deste projeto. O contexto é limitado à capacidade do modelo.';
    $('scope-clear').hidden=!scoped||!selected.size;
    $('graph-select').setAttribute('aria-pressed',String(scoped));
    $('graph-select').textContent=scoped?'✓ Selecionar pontos':'◎ Escopo da tarefa';
    window.BlochKnowledge?.draw();
  }
  function toggle(node){
    if(!eligible(node)||project?.shared)return;
    if(selected.has(node.id))selected.delete(node.id);
    else{if(selected.size>=30){error(new Error('Selecione até 30 pontos por tarefa.'));return;}selected.add(node.id);}
    $('scope-mode').value='selection';render();
  }
  function reset(){selected.clear();$('scope-mode').value='project';render();}
  $('scope-mode').onchange=render;$('scope-clear').onclick=()=>{selected.clear();render();};
  $('graph-select').onclick=()=>{$('scope-mode').value=$('scope-mode').value==='project'?'selection':'project';window.BlochWorkspace.pane('work');render();};
  $('global-prompt').oninput=()=>{dirty=$('global-prompt').value!==saved;$('global-prompt-status').textContent=dirty?'Alterações ainda não salvas.':'Instruções salvas para as próximas tarefas.';};
  $('save-global-prompt').onclick=async()=>{
    if(!project||project.shared)return;const id=project.id,value=$('global-prompt').value;$('save-global-prompt').disabled=true;
    try{const data=await api(`/api/projects/${id}/instructions`,{global_prompt:value});if(project?.id!==id)return;saved=data.global_prompt;dirty=$('global-prompt').value.trim()!==saved;$('global-prompt-status').textContent=dirty?'Há alterações posteriores ainda não salvas.':'Prompt global salvo para este projeto.';}
    catch(e){$('global-prompt-status').textContent=e.message;}finally{$('save-global-prompt').disabled=!project;}
  };
  window.addEventListener('blochai:graph',event=>{nodes=event.detail.nodes;selected=new Set([...selected].filter(id=>nodes.some(n=>n.id===id&&eligible(n))));render();});
  window.BlochWorkspace.onProject(async event=>{
    project=event.detail;const version=++loading;nodes=[];dirty=false;saved='';reset();$('global-prompt').value='';$('global-prompt-status').textContent='';$('save-global-prompt').disabled=!project;
    if(!project||project.shared)return;
    try{const data=await api(`/api/projects/${project.id}/instructions`);if(version!==loading)return;saved=data.global_prompt;$('global-prompt').value=saved;}
    catch(e){if(version===loading)$('global-prompt-status').textContent=e.message;}
  });
  window.BlochScope={toggle,reset,selected:id=>$('scope-mode').value==='selection'&&selected.has(id),selecting:()=>$('scope-mode').value==='selection',
    canLeave:()=>!dirty||window.confirm('O prompt global tem alterações não salvas. Deseja descartá-las?'),
    payload:()=>{if(dirty)throw new Error('Salve o prompt global antes de iniciar a tarefa.');return {scope_mode:$('scope-mode').value,scope_nodes:$('scope-mode').value==='selection'?[...selected]:[]};}};
  render();
})();
