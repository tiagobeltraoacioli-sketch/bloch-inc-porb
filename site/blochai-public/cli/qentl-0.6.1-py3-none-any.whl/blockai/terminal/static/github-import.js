'use strict';
(() => {
  let project=null,busy=false,epoch=0;
  const allowed=()=>Boolean(project&&window.BlochWorkspace.access?.().write);
  const status=value=>{$('github-import-status').textContent=value;};
  const reasons={protected_path:'Arquivo privado, dependência ou caminho protegido',unsupported_type:'Formato não importado',file_too_large:'Arquivo acima do limite',binary_or_invalid_utf8:'Binário ou texto sem UTF-8',credential_content:'Possível credencial no conteúdo',depth_limit:'Profundidade acima do limite',symlink:'Link simbólico',submodule:'Submódulo',lfs_pointer:'Referência Git LFS'};
  function controls(){
    $('open-github-import').disabled=!allowed()||busy;
    $('github-import-submit').disabled=!allowed()||busy;
    $('github-import-url').disabled=busy;
    $('github-import-progress').hidden=!busy;
    $('github-import-form').setAttribute('aria-busy',String(busy));
  }
  function sourceUrl(value){
    if(typeof value!=='string'||value.length>2048||!/^https:\/\/github\.com\//.test(value)||/[\\\s%?#]/.test(value))return null;
    try{
      const url=new URL(value),parts=url.pathname.split('/').filter(Boolean);
      if(url.origin!=='https://github.com'||url.username||url.password||parts.length<2||parts.some(part=>part==='.'||part==='..'))return null;
      if(!parts.slice(0,2).every(part=>/^[A-Za-z0-9_.-]+$/.test(part)))return null;
      if(parts.length>2&&(parts[2]!=='tree'||parts.length<4))return null;
      return value;
    }catch{return null;}
  }
  function render(result){
    const repository=result?.repository,imported=result?.import;
    if(!repository||!imported||!Array.isArray(imported.accepted)||!Array.isArray(imported.skipped)||!sourceUrl(repository.url)||!/^[a-f0-9]{40}$/.test(repository.commit||''))throw new Error('A resposta não trouxe a origem e o commit esperados. Atualize o Graphus e confira os arquivos antes de repetir a importação.');
    const url=new URL(repository.url),parts=url.pathname.split('/').filter(Boolean);
    $('github-import-source').href=`https://github.com/${parts[0]}/${parts[1]}/tree/${repository.commit}`;
    $('github-import-source').textContent=repository.url;
    $('github-import-commit').textContent='Commit: '+repository.commit;
    const license=repository.license?.spdx_id||repository.license?.name;
    $('github-import-summary').textContent=`${imported.files_imported} arquivos · ${size(imported.bytes_imported)} · Pasta: ${imported.path}${license?' · Licença informada: '+license:'. Licença não identificada; confira os termos do repositório.'}`;
    const accepted=imported.accepted.slice(0,500).map(row=>'Incluído: '+row.path);
    const skipped=imported.skipped.slice(0,500).map(row=>'Excluído: '+row.path+' · '+(reasons[row.reason]||row.reason));
    $('github-import-files').textContent=[...accepted,...skipped,...(imported.skipped.length>500?['A lista exibida de exclusões foi limitada a 500 itens.']:[])].join('\n');
    $('github-import-result').hidden=false;
  }
  $('open-github-import').onclick=()=>{
    if(!allowed()||busy)return;
    window.BlochWorkspace.pane('collection');$('files-tab').click();$('github-import-details').open=true;$('github-import-url').focus();
  };
  $('github-import-form').onsubmit=async event=>{
    event.preventDefault();if(!allowed()||busy)return;
    if(window.BlochWorkspace.busy?.()){status('Conclua a tarefa ou o envio em andamento antes de importar um repositório.');return;}
    if(window.BlochCode?.hasUnsaved?.()||window.BlochKnowledge?.hasUnsaved?.()){status('Salve os rascunhos ou aplique a comparação de código antes de importar. Seu conteúdo foi preservado.');return;}
    const url=sourceUrl($('github-import-url').value.trim());
    if(!url){status('Informe https://github.com/organização/repositório ou /tree/referência, sem credenciais, parâmetros ou fragmentos.');return;}
    const version=epoch,id=project.id;let imported=false;busy=true;controls();window.dispatchEvent(new Event('qentl:github-import'));
    $('github-import-result').hidden=true;status('Obtendo a cópia pública e verificando os arquivos. Aguarde a conclusão; o código não será executado.');
    try{
      const result=await api(`/api/projects/${id}/github-import`,{url});
      if(version!==epoch)return;
      imported=true;render(result);status('Cópia importada. Atualizando os arquivos do Graphus…');
      await window.BlochWorkspace.refreshFiles();if(version!==epoch)return;
      status('Importação concluída no commit exibido. Abra os pontos do Graphus para ler os arquivos; nenhuma tarefa de IA foi iniciada.');
    }catch(error){if(version===epoch)status(imported?'A importação foi recebida, mas a atualização da interface não terminou. Confira o Graphus antes de importar novamente. '+error.message:error.message);}
    finally{busy=false;controls();window.dispatchEvent(new Event('qentl:github-import'));}
  };
  window.BlochWorkspace.onProject(event=>{
    project=event.detail;epoch++;$('github-import-url').value='';$('github-import-result').hidden=true;
    $('github-import-source').removeAttribute('href');$('github-import-source').textContent='';$('github-import-commit').textContent='';$('github-import-files').textContent='';status('');controls();
  });
  window.addEventListener('beforeunload',event=>{if(busy){event.preventDefault();event.returnValue='';}});
  window.BlochGithub={busy:()=>busy,canLeave:()=>{if(busy)status('Aguarde a conclusão da importação antes de trocar de projeto ou sair.');return !busy;}};
  controls();
})();
