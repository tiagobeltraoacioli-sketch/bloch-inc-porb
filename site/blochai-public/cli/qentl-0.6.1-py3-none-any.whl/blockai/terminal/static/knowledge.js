'use strict';
(() => {
  const canvas=$('knowledge-globe'),ctx=canvas.getContext('2d');
  const colors={note:'#baff28',pdf:'#e7cfa5',document:'#bfcdbf',image:'#a7a9ee',code:'#6bd2cd',folder:'#8697ab',function:'#86c5ff',class:'#ada4ff',task:'#ffb47e',model:'#ed90e7'};
  const access=()=>window.BlochWorkspace?.access?.()||{write:true,ai:true,export:true};
  const labels={note:'Ideia .md',pdf:'PDF',document:'Documento',image:'Imagem',code:'Código',folder:'Pasta',function:'Função',class:'Classe',task:'Tarefa',model:'Modelo IA'};
  let project=null,notes=[],graph={nodes:[],edges:[]},visible=[],points=[],yaw=.3,pitch=.12,zoom=1;
  let frame=null,hover=null,drag=null,version=0,searchTimer=null,note=null,dirty=false,saving=false;
  let panX=0,panY=0,born=new Map(),seen=new Set();
  const hash=value=>{let number=2166136261;for(const c of value)number=Math.imul(number^c.charCodeAt(0),16777619);return (number>>>0)/4294967296;};
  function location(node){
    const parts=(node.path||'').split('/'),group=node.path?'code:'+parts[0]:node.partition||node.kind;
    const angle=hash(group)*Math.PI*2,spread=.48+hash(group+'r')*.23;
    let x=Math.cos(angle)*spread,y=Math.sin(angle)*spread;
    for(let level=1;level<parts.length;level++){const key=parts.slice(0,level+1).join('/'),a=hash(key)*Math.PI*2,step=.26/(level+.4);x+=Math.cos(a)*step;y+=Math.sin(a)*step;}
    if(node.kind!=='folder'){const a=hash(node.kind==='function'||node.kind==='class'?node.id:node.path||node.id)*Math.PI*2;const step=node.path?.includes('/') ? .065 : .25;x+=Math.cos(a)*step;y+=Math.sin(a)*step;}
    return {x,y};
  }

  function canLeave(){return !dirty||window.confirm('Há uma ideia com alterações não salvas. Deseja descartá-las?');}
  function projectUrl(){if(!project)throw new Error('Crie ou selecione um projeto primeiro.');return `/api/projects/${project.id}`;}
  function drawSoon(){if(frame===null)frame=requestAnimationFrame(()=>{frame=null;draw();});}
  function coordinates(x,y,z,r,cx,cy){
    const a=x*Math.cos(yaw)+z*Math.sin(yaw),b=-x*Math.sin(yaw)+z*Math.cos(yaw);
    const c=y*Math.cos(pitch)-b*Math.sin(pitch),d=y*Math.sin(pitch)+b*Math.cos(pitch),scale=3/(3-d*.35);
    return {x:cx+a*r*scale,y:cy+c*r*scale,z:d,scale};
  }
  function draw(){
    const rect=canvas.getBoundingClientRect();if(!rect.width||!rect.height)return;
    const dpr=Math.min(window.devicePixelRatio||1,2),w=rect.width,h=rect.height;
    if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
    const globe=$('graph-view').value==='globe';
    const cx=w/2+(globe?0:panX),cy=h/2-10+(globe?0:panY),r=Math.min(w*.40,h*.39)*zoom;
    const glow=ctx.createRadialGradient(cx,cy,0,cx,cy,r*1.5);glow.addColorStop(0,'#baff280e');glow.addColorStop(.7,'#baff2803');glow.addColorStop(1,'#05070600');ctx.fillStyle=glow;ctx.fillRect(0,0,w,h);
    if(globe)for(let lat=-60;lat<=60;lat+=30){let previous=null;const angle=lat*Math.PI/180;for(let i=0;i<=80;i++){const lon=i/80*Math.PI*2,p=coordinates(Math.cos(angle)*Math.cos(lon),Math.sin(angle),Math.cos(angle)*Math.sin(lon),r,cx,cy);if(previous){ctx.strokeStyle=p.z>0?'#49613c55':'#293a2933';ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(previous.x,previous.y);ctx.lineTo(p.x,p.y);ctx.stroke();}previous=p;}}
    if(globe)for(let lon=0;lon<180;lon+=30){let previous=null;const angle=lon*Math.PI/180;for(let i=0;i<=80;i++){const lat=i/80*Math.PI*2,p=coordinates(Math.cos(lat)*Math.cos(angle),Math.sin(lat),Math.cos(lat)*Math.sin(angle),r,cx,cy);if(previous){ctx.strokeStyle=p.z>0?'#49613c44':'#293a2922';ctx.beginPath();ctx.moveTo(previous.x,previous.y);ctx.lineTo(p.x,p.y);ctx.stroke();}previous=p;}}
    points=visible.map((node,index)=>{if(!globe){const p=location(node);return {x:cx+p.x*r*1.3,y:cy+p.y*r*1.1,z:1,scale:1,node};}const y=1-2*(index+.5)/Math.max(1,visible.length),angle=index*Math.PI*(3-Math.sqrt(5)),radius=Math.sqrt(1-y*y);return {...coordinates(Math.cos(angle)*radius,y,Math.sin(angle)*radius,r,cx,cy),node};});
    const byId=new Map(points.map(point=>[point.node.id,point]));
    for(const edge of graph.edges){const a=byId.get(edge.source),b=byId.get(edge.target);if(!a||!b)continue;const related=hover===edge.source||hover===edge.target;ctx.strokeStyle=related?'#e4eee9bb':['contains','defines'].includes(edge.kind)?'#63778938':['calls','imports'].includes(edge.kind)?'#6bd2cd60':edge.kind==='changed'?'#baff2888':edge.kind==='executes'?'#ed90e766':'#baff2838';ctx.globalAlpha=Math.max(.12,(a.z+b.z+2)/4);ctx.lineWidth=related?1.5:.8;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}ctx.globalAlpha=1;
    for(const point of [...points].sort((a,b)=>a.z-b.z)){
      const color=point.node.diagnostics?'#ff777f':colors[point.node.kind]||colors.document,selected=point.node.id===note?.id||point.node.id===hover||window.BlochScope?.selected(point.node.id);
      ctx.globalAlpha=point.z<0?.34:.95;ctx.fillStyle=color;ctx.beginPath();ctx.arc(point.x,point.y,(selected?6:3.5)*point.scale,0,Math.PI*2);ctx.fill();
      if(selected){ctx.strokeStyle=color;ctx.lineWidth=1;ctx.beginPath();ctx.arc(point.x,point.y,11*point.scale,0,Math.PI*2);ctx.stroke();}
      const age=performance.now()-(born.get(point.node.id)||0);if(born.has(point.node.id)&&age<900&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){ctx.globalAlpha=1-age/900;ctx.strokeStyle=color;ctx.beginPath();ctx.arc(point.x,point.y,8+age/35,0,Math.PI*2);ctx.stroke();drawSoon();}
      if(selected||(visible.length<=22&&point.z>.15)||['folder','model'].includes(point.node.kind)){
        ctx.globalAlpha=1;ctx.font='10px ui-monospace, monospace';const title=point.node.title.length>29?point.node.title.slice(0,28)+'…':point.node.title;const width=ctx.measureText(title).width;const tx=Math.min(w-width-8,Math.max(8,point.x+11));const ty=Math.max(20,point.y-10);ctx.fillStyle='#050706e8';ctx.fillRect(tx-4,ty-11,width+8,16);ctx.fillStyle=color;ctx.fillText(title,tx,ty);
      }
    }
    ctx.globalAlpha=1;
  }
  function hit(event){const rect=canvas.getBoundingClientRect(),x=event.clientX-rect.left,y=event.clientY-rect.top;return points.filter(p=>p.z>-.5&&Math.hypot(p.x-x,p.y-y)<14).sort((a,b)=>b.z-a.z)[0]?.node;}
  canvas.addEventListener('pointerdown',event=>{if(event.button!==0)return;drag={x:event.clientX,y:event.clientY,lastX:event.clientX,lastY:event.clientY};canvas.setPointerCapture(event.pointerId);canvas.focus();});
  canvas.addEventListener('pointermove',event=>{if(drag){if($('graph-view').value==='globe'){yaw+=(event.clientX-drag.lastX)*.006;pitch=Math.max(-1.4,Math.min(1.4,pitch+(event.clientY-drag.lastY)*.006));}else{panX+=event.clientX-drag.lastX;panY+=event.clientY-drag.lastY;}drag.lastX=event.clientX;drag.lastY=event.clientY;}else{hover=hit(event)?.id||null;canvas.style.cursor=hover?'pointer':'grab';}drawSoon();});
  canvas.addEventListener('pointerup',event=>{if(!drag)return;const moved=Math.hypot(event.clientX-drag.x,event.clientY-drag.y);drag=null;if(canvas.hasPointerCapture(event.pointerId))canvas.releasePointerCapture(event.pointerId);if(moved<6){const node=hit(event);if(node){if(event.shiftKey||event.ctrlKey||event.metaKey||window.BlochScope?.selecting())window.BlochScope?.toggle(node);else openNode(node);}}});
  canvas.addEventListener('pointercancel',()=>{drag=null;});canvas.addEventListener('pointerleave',()=>{hover=null;drawSoon();});
  canvas.addEventListener('contextmenu',event=>{const node=hit(event);if(node&&['code','note','pdf','image','document'].includes(node.kind)){event.preventDefault();window.BlochFiles?.manage(node);}});
  canvas.addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){event.preventDefault();const x=event.key==='ArrowLeft'?-1:event.key==='ArrowRight'?1:0,y=event.key==='ArrowUp'?-1:event.key==='ArrowDown'?1:0;if($('graph-view').value==='globe'){yaw+=x*.15;pitch+=y*.12;}else{panX+=x*25;panY+=y*25;}drawSoon();}});
  new ResizeObserver(drawSoon).observe(canvas);$('globe-zoom').oninput=()=>{zoom=Number($('globe-zoom').value)/100;drawSoon();};
  $('graph-view').onchange=()=>{panX=panY=0;drawSoon();};

  function filter(){
    const query=$('knowledge-search').value.toLocaleLowerCase('pt-BR'),partition=$('partition-filter').value;
    const matchingNotes=new Set(notes.map(item=>item.id));
    visible=graph.nodes.filter(node=>(!partition||node.partition===partition)&&(!query||(node.kind==='note'?matchingNotes.has(node.id):(node.title+' '+(node.path||'')).toLocaleLowerCase('pt-BR').includes(query))))
      .sort((a,b)=>(a.partition||'').localeCompare(b.partition||'')||a.title.localeCompare(b.title));
    $('knowledge-nodes').replaceChildren();
    for(const node of visible){const row=document.createElement('div');row.className='graph-list-row';const button=document.createElement('button');button.type='button';button.className='knowledge-node node-'+node.kind;const title=document.createElement('strong'),meta=document.createElement('small');title.textContent=node.title;meta.textContent=`${labels[node.kind]||'Arquivo'} · ${node.partition||'Projeto'}${node.line?' · L'+node.line:''}${node.status?' · '+(statuses[node.status]||node.status):''}`;button.append(title,meta);button.onclick=()=>openNode(node);row.append(button);if(access().ai&&!['task','model'].includes(node.kind)){const select=document.createElement('button');select.type='button';select.className='text-button';select.textContent='◎';select.setAttribute('aria-label','Selecionar '+node.title+' para a tarefa');select.onclick=()=>window.BlochScope?.toggle(node);row.append(select);}if(['code','note','pdf','image','document'].includes(node.kind)){const action=document.createElement('button');action.type='button';action.className='text-button graph-file-menu';action.textContent='⋯';action.setAttribute('aria-label','Organizar '+node.title);action.onclick=()=>window.BlochFiles?.manage(node);row.append(action);}$('knowledge-nodes').append(row);}
    $('knowledge-list-count').textContent=String(visible.length);
    const n=graph.nodes.filter(node=>node.kind==='note').length,c=graph.nodes.filter(node=>node.kind==='code').length;
    const functions=graph.nodes.filter(node=>['function','class'].includes(node.kind)).length,tasks=graph.nodes.filter(node=>node.kind==='task').length;
    $('globe-counts').textContent=`${n} ideias · ${c} arquivos · ${functions} funções/classes · ${tasks} tarefas · ${graph.edges.length} conexões${graph.truncated?' · visão parcial':''}`;
    $('globe-empty').hidden=graph.nodes.length>0;$('globe-empty').querySelector('strong').textContent=project?'Uma ideia é o começo.':'Crie seu primeiro projeto.';
    $('new-note').disabled=!project||!access().write;$('knowledge-upload').disabled=!project||!access().write;$('ask-knowledge').disabled=!project||!n||!access().ai;$('export-vault').hidden=!project||!access().export;
    if(project)$('export-vault').href=projectUrl()+'/vault.zip';
    $('note-link-target').replaceChildren();const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='Conectar uma ideia ou arquivo…';$('note-link-target').append(placeholder);
    for(const node of graph.nodes){if(node.id===note?.id)continue;const option=document.createElement('option');option.value=node.title;option.textContent=node.title;$('note-link-target').append(option);}
    for(const id of ['connection-source','connection-target']){const previous=$(id).value;$(id).replaceChildren();const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='Selecione um nó…';$(id).append(placeholder);for(const node of graph.nodes){const option=document.createElement('option');option.value=node.id;option.textContent=node.title;$(id).append(option);}if(graph.nodes.some(node=>node.id===previous))$(id).value=previous;}
    $('connection-list').replaceChildren();
    for(const edge of graph.edges.filter(edge=>edge.kind==='association')){const row=document.createElement('div');row.className='connection-row';const text=document.createElement('span');text.textContent=`${graph.nodes.find(node=>node.id===edge.source)?.title} → ${edge.label} → ${graph.nodes.find(node=>node.id===edge.target)?.title}`;const remove=document.createElement('button');remove.type='button';remove.className='text-button';remove.textContent='Remover';remove.hidden=!access().write;remove.setAttribute('aria-label','Remover associação: '+text.textContent);remove.onclick=async()=>{try{await api(projectUrl()+'/connections/'+edge.id+'/delete',{});await refresh();}catch(e){error(e);}};row.append(text,remove);$('connection-list').append(row);}
    drawSoon();
  }
  async function refresh(){
    const requestVersion=++version;if(!project){notes=[];graph={nodes:[],edges:[]};filter();return;}
    try{const data=await api(projectUrl()+'/knowledge?q='+encodeURIComponent($('knowledge-search').value));if(requestVersion!==version)return;notes=data.notes;graph=data.graph;
      if(seen.size)for(const node of graph.nodes)if(!seen.has(node.id))born.set(node.id,performance.now());seen=new Set(graph.nodes.map(node=>node.id));born=new Map([...born].filter(([id,at])=>seen.has(id)&&performance.now()-at<1000));
      window.dispatchEvent(new CustomEvent('blochai:graph',{detail:graph}));
      const selected=$('partition-filter').value;$('partition-filter').replaceChildren();const all=document.createElement('option');all.value='';all.textContent='Todas as partições';$('partition-filter').append(all);
      for(const partition of [...new Set(graph.nodes.map(node=>node.partition||'Projeto'))].sort()){const option=document.createElement('option');option.value=partition;option.textContent=partition;$('partition-filter').append(option);}
      $('partition-filter').value=selected;if($('partition-filter').selectedIndex<0)$('partition-filter').value='';filter();connections();
    }catch(e){error(e);}
  }
  async function openNode(node){
    if(!['function','class'].includes(node.kind))window.BlochFiles?.select(node);
    if(node.kind==='task')return window.BlochWorkspace.selectJob(node.job_id);
    if(node.kind==='model')return window.BlochWorkspace.chooseModel(node.model_choice);
    if(node.kind==='folder'){$('knowledge-search').value=node.path+'/';filter();window.BlochWorkspace.pane('collection');$('files-tab').click();return;}
    if(['function','class'].includes(node.kind))return window.BlochCode?.open(node.code_id,node.line);
    if(node.kind==='note')return openNote(node.id);
    if(node.kind==='code'){if(window.BlochCode)return window.BlochCode.open(node.id);error(new Error('O editor de código está carregando.'));return;}
    await window.BlochWorkspace.preview(node.upload_id);
  }
  function edit(data){
    note=data;$('note-editor').hidden=false;$('note-editor-heading').textContent=data?.id?'Ideia conectada':'Nova ideia';
    window.BlochFiles?.select(data?.id?{...data,kind:'note'}:null);
    $('note-title').value=data?.title||'';$('note-title').readOnly=Boolean(data?.id)||!access().write;$('note-title').title=data?.id?'Este título identifica os links para a nota.':'';
    $('note-body').value=data?.body||'';$('note-tags').value=(data?.tags||[]).join(', ');$('note-partition').value=data?.partition||'Ideias';
    $('note-status').textContent=data?.id?'Salva em '+data.path:'Sua ideia será salva como um arquivo .md no projeto.';
    $('download-note').hidden=!data?.id;if(data?.id)$('download-note').href=projectUrl()+'/notes/'+data.id+'/download';
    $('organize-note').disabled=!data?.id||!access().ai;$('save-note').disabled=!access().write;$('insert-note-link').disabled=!access().write;for(const id of ['note-body','note-tags','note-partition'])$(id).readOnly=!access().write;dirty=false;window.BlochWorkspace.inspect('note');filter();connections();
    $('organize-note-file').disabled=!data?.id;
    $('note-editor').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'nearest'});
  }
  function connections(){
    $('note-connections').replaceChildren();if(!note?.id)return;
    const related=new Set();for(const edge of graph.edges){if(edge.source===note.id)related.add(edge.target);if(edge.target===note.id)related.add(edge.source);}
    if(!related.size){$('note-connections').textContent='Conecte esta nota usando [[Título da nota]] ou o seletor acima.';return;}
    const label=document.createElement('span');label.textContent='CONEXÕES E REFERÊNCIAS';$('note-connections').append(label);
    for(const id of related){const node=graph.nodes.find(item=>item.id===id);if(!node)continue;const button=document.createElement('button');button.type='button';button.className='small-button';button.textContent=node.title;button.onclick=()=>openNode(node);$('note-connections').append(button);}
  }
  async function openNote(id){
    if(!canLeave())return;
    try{const url=projectUrl();const data=await api(url+'/notes/'+id);if(project&&projectUrl()===url)edit(data.note);}catch(e){error(e);}
  }
  async function convert(id,excerpt=null){
    if(!access().write)throw new Error('Este projeto foi compartilhado para leitura.');
    if(!canLeave())throw new Error('Salve sua ideia atual antes de converter outra fonte.');
    const data=await api(projectUrl()+'/convert',{upload_id:id,...(excerpt?{excerpt}:{})});await refresh();edit(data.note);
  }
  function draft(body=''){
    if(!access().write)return;
    if(!project){error(new Error('Crie um projeto para salvar suas ideias.'));return;}
    if(!canLeave())return;edit({body});dirty=Boolean(body);$('note-title').focus();
  }
  $('note-form').addEventListener('input',()=>{if(!access().write)return;dirty=true;$('note-status').textContent='Alterações ainda não salvas.';});
  $('note-form').addEventListener('submit',async event=>{
    event.preventDefault();if(saving||!access().write)return;saving=true;$('save-note').disabled=true;const url=projectUrl();
    try{const data=await api(url+'/notes'+(note?.id?'/'+note.id:''),{title:$('note-title').value,body:$('note-body').value,tags:$('note-tags').value.split(',').map(tag=>tag.trim()).filter(Boolean),partition:$('note-partition').value,source_ids:note?.source_ids||[],revision:note?.revision});
      if(project&&projectUrl()===url){dirty=false;await refresh();edit(data.note);$('note-status').textContent='Nota .md salva. Conexões atualizadas no globo.';}
    }catch(e){$('note-status').textContent=e.message;}finally{saving=false;$('save-note').disabled=!access().write;}
  });
  $('new-note').onclick=()=>draft();$('close-note').onclick=()=>{if(canLeave()){note=null;dirty=false;$('note-editor').hidden=true;$('editor-empty').hidden=false;drawSoon();}};
  $('organize-note-file').onclick=()=>{if(note?.id)window.BlochFiles?.manage({...note,kind:'note'});};
  $('insert-note-link').onclick=()=>{const title=$('note-link-target').value;if(!title)return;const field=$('note-body');field.setRangeText('[['+title+']]',field.selectionStart,field.selectionEnd,'end');field.focus();dirty=true;$('note-status').textContent='Conexão inserida. Salve para atualizar o globo.';};
  $('organize-note').onclick=()=>{if(dirty){$('note-status').textContent='Salve a nota antes de pedir a organização à IA.';return;}window.BlochWorkspace.ask(`Organize as informações da nota "${note.title}" que são relevantes para o projeto "${project.name}" (${project.description||'objetivo ainda não informado'}). Responda em Markdown, separando fatos da fonte, minhas ideias, conexões úteis e perguntas em aberto. Cite o título da nota. Não invente evidências nem afirme que arquivos foram alterados.`,[note.id]);};
  $('knowledge-ask').onsubmit=event=>{event.preventDefault();window.BlochWorkspace.ask($('knowledge-question').value);};
  $('connection-form').onsubmit=async event=>{event.preventDefault();if(!access().write)return;event.submitter.disabled=true;const url=projectUrl();try{await api(url+'/connections',{source:$('connection-source').value,target:$('connection-target').value,label:$('connection-label').value});if(project&&projectUrl()===url){$('connection-status').textContent='Associação criada. O globo foi atualizado.';await refresh();}}catch(e){$('connection-status').textContent=e.message;}finally{event.submitter.disabled=false;}};
  $('knowledge-search').oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(refresh,250);};$('partition-filter').onchange=filter;
  $('refresh-globe').onclick=refresh;$('knowledge-upload').onclick=()=>window.BlochWorkspace.upload();
  window.BlochWorkspace.onProject(event=>{project=event.detail;note=null;dirty=false;seen.clear();born.clear();panX=panY=0;$('note-editor').hidden=true;$('knowledge-search').value='';$('partition-filter').value='';refresh();});
  window.addEventListener('blochai:files',()=>{if(project)refresh();});
  window.addEventListener('qentl:file-action',event=>{
    const action=event.detail,affected=[action.previous_node_id,...(action.linked_notes||[]).map(row=>row.id||row)];
    if(!note?.id||action.project!==project?.id||!affected.includes(note.id)||!['move','trash'].includes(action.action))return;
    if(dirty||saving){$('note-status').textContent='A nota foi movida ou enviada à lixeira. Seu rascunho foi preservado; copie-o antes de reabrir.';return;}
    note=null;dirty=false;$('note-editor').hidden=true;$('editor-empty').hidden=false;drawSoon();
  });
  window.addEventListener('beforeunload',event=>{if(dirty){event.preventDefault();event.returnValue='';}});
  window.BlochKnowledge={refresh,draw:drawSoon,canLeave,open:openNote,convert,draft,hasUnsaved:()=>dirty||saving};
  filter();
})();
