'use strict';
(() => {
  const node=id=>document.getElementById(id);
  let claiming=false,authBusy=false,adminBusy=false,canManage=false,invitationId=null,epoch=0;
  const tokenPattern=/^[a-f0-9]{64}$/;
  const inviteIdPattern=/^[a-f0-9]{32}$/;

  function clearPasswords(){
    node('password').value='';node('claim-password').value='';node('claim-confirm').value='';
  }
  function clearInvitation(){
    invitationId=null;node('account-invite-link').value='';node('account-invite-meta').textContent='';node('account-invite-result').hidden=true;
  }
  function claim(open,token=''){
    claiming=open;node('login').hidden=open;node('account-claim').hidden=!open;
    node('claim-token').value=token;node('claim-status').textContent='';node('login-error').textContent='';clearPasswords();
  }
  function authControls(){
    for(const id of ['login-submit','claim-submit','show-account-claim','cancel-account-claim'])node(id).disabled=authBusy;
  }
  function adminControls(){
    const revoke=node('account-admin-action').value==='revoke';
    node('account-invites-panel').hidden=!canManage;
    node('account-revoke-confirm-row').hidden=!revoke;
    node('account-admin-submit').textContent=revoke?'Revogar acesso à conta':node('account-admin-action').value==='reset'?'Gerar recuperação de senha':'Gerar convite pessoal';
    for(const id of ['account-admin-submit','account-admin-action','account-invite-email','revoke-account-invite'])node(id).disabled=adminBusy||!canManage;
  }

  // Capture the secret fragment before app.js restores a session or makes API
  // requests. Fragments never reach HTTP; remove it from history immediately.
  if(location.hash.startsWith('#invite')){
    const match=/^#invite=([a-f0-9]{64})$/.exec(location.hash);
    history.replaceState(null,'',location.pathname+location.search);
    claim(true,match?match[1]:'');
    if(!match)node('claim-status').textContent='Este link não contém um código válido. Cole o código recebido do administrador.';
  }
  window.QentlAccess={claimPending:()=>claiming};

  node('show-account-claim').onclick=()=>{
    if(authBusy)return;const email=node('email').value.trim();claim(true);node('claim-email').value=email;node('claim-token').focus();
  };
  node('cancel-account-claim').onclick=()=>{if(!authBusy){claim(false);node('email').focus();}};
  node('login').onsubmit=async event=>{
    event.preventDefault();if(authBusy)return;authBusy=true;authControls();node('login-error').textContent='';
    try{
      const identity=await api('/api/login',{email:node('email').value.trim(),password:node('password').value});
      clearPasswords();await account(identity);
    }catch(error){node('login-error').textContent=error.message||'Não foi possível entrar. Confira seu e-mail e sua senha Qentl.';}
    finally{authBusy=false;clearPasswords();authControls();}
  };
  node('account-claim').onsubmit=async event=>{
    event.preventDefault();if(authBusy)return;
    const token=node('claim-token').value.trim(),password=node('claim-password').value;
    if(!tokenPattern.test(token)){node('claim-status').textContent='Use o código completo de 64 caracteres recebido no convite.';return;}
    if([...password].length<14||[...password].length>128||new TextEncoder().encode(password).length>512){node('claim-status').textContent='Escolha uma senha de 14 a 128 caracteres.';return;}
    if(password!==node('claim-confirm').value){node('claim-status').textContent='As senhas não coincidem. Confira a confirmação.';return;}
    authBusy=true;authControls();node('claim-status').textContent='Definindo seu acesso…';
    try{
      const identity=await api('/api/account-invitations/accept',{token,email:node('claim-email').value.trim(),password});
      node('claim-token').value='';clearPasswords();claiming=false;await account(identity);
    }catch(error){node('claim-status').textContent=error.message||'Não foi possível usar este convite. Confira o e-mail ou solicite um novo link.';}
    finally{authBusy=false;clearPasswords();authControls();}
  };

  async function capabilities(){
    const current=++epoch;canManage=false;clearInvitation();adminControls();
    try{
      const result=await api('/api/accounts/capabilities');
      if(current!==epoch)return;
      canManage=result.can_manage_accounts===true;adminControls();
    }catch{if(current===epoch){canManage=false;adminControls();}}
  }
  node('account-admin-action').onchange=()=>{
    node('account-revoke-confirm').checked=false;clearInvitation();node('account-admin-status').textContent='';adminControls();
  };
  node('account-invite-email').oninput=()=>{
    node('account-revoke-confirm').checked=false;clearInvitation();node('account-admin-status').textContent='';
  };
  node('account-admin-form').onsubmit=async event=>{
    event.preventDefault();if(adminBusy||!canManage)return;
    const action=node('account-admin-action').value;
    if(!['invite','reset','revoke'].includes(action))return;
    if(action==='revoke'&&!node('account-revoke-confirm').checked){node('account-admin-status').textContent='Confirme a revogação antes de continuar.';return;}
    const current=epoch,email=node('account-invite-email').value.trim();
    adminBusy=true;clearInvitation();adminControls();node('account-admin-status').textContent='Processando…';
    try{
      const path={invite:'/api/account-invitations',reset:'/api/account-resets',revoke:'/api/accounts/revoke'}[action];
      const result=await api(path,{email});if(current!==epoch)return;
      if(action==='revoke'){
        node('account-admin-status').textContent='Acesso revogado. A conta deixa de autenticar no Qentl.';node('account-revoke-confirm').checked=false;
      }else{
        const invite=result.invitation;
        if(!invite||!tokenPattern.test(invite.token)||!inviteIdPattern.test(invite.id))throw new Error('O servidor não retornou um convite válido. Gere um novo convite.');
        invitationId=invite.id;
        // Desktop accounts use the same hosted identity authority. Links must
        // never point at the operator's loopback workspace or contain a query.
        node('account-invite-link').value='https://qentl.ai/#invite='+invite.token;
        node('account-invite-meta').textContent=`${invite.email} · ${action==='reset'?'Recuperação de senha':'Primeiro acesso'} · válido até ${formatDate(invite.expires_at)} · uso único.`;
        node('account-invite-result').hidden=false;
        node('account-admin-status').textContent='Link gerado. Envie diretamente à pessoa indicada; nenhum e-mail foi enviado. Este convite não compartilha projetos.';
      }
    }catch(error){if(current===epoch)node('account-admin-status').textContent=error.message;}
    finally{adminBusy=false;adminControls();}
  };
  node('copy-account-invite').onclick=async()=>{
    const field=node('account-invite-link');if(!field.value||!canManage)return;
    try{await navigator.clipboard.writeText(field.value);node('account-admin-status').textContent='Link copiado. Compartilhe apenas com a pessoa indicada.';}
    catch{field.focus();field.select();node('account-admin-status').textContent='Link selecionado. Use ⌘C ou Ctrl+C para copiar.';}
  };
  node('clear-account-invite').onclick=clearInvitation;
  node('revoke-account-invite').onclick=async()=>{
    if(adminBusy||!canManage||!invitationId)return;
    const identifier=invitationId,current=epoch;adminBusy=true;adminControls();
    try{
      await api('/api/account-invitations/'+identifier+'/revoke',{});
      if(current===epoch){clearInvitation();node('account-admin-status').textContent='Este convite foi invalidado e não pode mais ser usado.';}
    }catch(error){if(current===epoch)node('account-admin-status').textContent=error.message;}
    finally{adminBusy=false;adminControls();}
  };
  window.addEventListener('blochai:account',()=>{
    claiming=false;node('account-claim').hidden=true;node('claim-token').value='';clearPasswords();capabilities();
  });
  window.addEventListener('pagehide',()=>{epoch++;clearPasswords();node('claim-token').value='';clearInvitation();});
  adminControls();
})();
