'use strict';
const $ = id => document.getElementById(id);
const activeStatuses = new Set(['RUNNING', 'AWAITING_APPROVAL']);
const statuses = {RUNNING:'Em andamento', AWAITING_APPROVAL:'Aguardando sua aprovação', COMPLETED:'Concluída', PAUSED:'Pausada para revisão', FAILED:'Não concluída', CANCELLED:'Cancelada', INTERRUPTED:'Interrompida'};
const modes = {auto:'Automático', chat:'Conversa', coder:'Programação', analyst:'Análise', publisher:'Criação'};
const hints = {auto:'Descreva o resultado desejado. O Qentl escolhe conversa, análise, criação de arquivo ou programação; alterações de código continuam exigindo escopo aprovado.',chat:'Converse e explore ideias com QENTL.', coder:'Revise alterações antes de aplicar. Execução de comandos aguarda isolamento por conta.', analyst:'Fontes, dados e revisão crítica. Confira as evidências e limitações.', publisher:'Gere PDF, PPTX ou Excel para baixar. Revise e aprove a prévia; esta tarefa não altera o código do projeto.'};
const kinds = {general:'Geral', code:'Programação', research:'Pesquisa', documents:'Documentos'};
const tabs = ['tasks','files','projects'];
const accepted = new Set(['png','jpg','jpeg','webp','gif','pdf','docx','pptx','xlsx','txt','md','csv','json']);
let selectedJob=null, pending=null, poll=null, rows=[], activeJob=null;
let projects=[], uploads=[], currentProject='', projectVersion=0, previewVersion=0, activeTab='tasks';
let selectedUploads=new Set(), uploading=false, uploadRequest=null, uploadCancelled=false;
let previewingUpload=null, knowledgeNoteIds=[], completedNotification=null;
let graphJobVersion='';
let folderPlan=null, folderImporting=false;
const standardIngest={profile:'standard',max_source_files:500,source_file_bytes:200000,batch_files:500,batch_decoded_bytes:20*1024*1024,batch_request_bytes:30*1024*1024,resumable_folder_batches:false,graph_source_files:500};
let ingestPolicy={...standardIngest};
function checkedIngest(data){
  if(!data||!['standard','internal'].includes(data.profile))throw new Error('Política de importação inválida.');
  const result={...standardIngest,profile:data.profile};
  for(const [key,max] of Object.entries({max_source_files:data.profile==='internal'?10000:500,source_file_bytes:200000,batch_files:500,batch_decoded_bytes:20*1024*1024,batch_request_bytes:30*1024*1024,graph_source_files:500})){
    if(!Number.isInteger(data[key])||data[key]<1||data[key]>max)throw new Error('Limites de importação inválidos.');result[key]=data[key];
  }
  result.resumable_folder_batches=data.profile==='internal'&&data.resumable_folder_batches===true;
  if(data.profile==='internal'&&!result.resumable_folder_batches)throw new Error('A importação interna exige lotes retomáveis.');
  return result;
}
async function loadIngestPolicy(identity){
  ingestPolicy={...standardIngest};
  try{const data=checkedIngest(await api('/api/ingest-policy'));if(accountIdentity===identity)ingestPolicy=data;}
  catch{ /* Older/offline deployments retain conservative transfer limits. */ }
}
let projectPoll=null,projectPolling=false,projectRevision=null,projectFileStamps=new Map(),cliRunStamp='';
let accountIdentity=null,publishedProject=null;
let workspaceDeployment={mode:'unknown',local_cli:false};
let selectedArtifactFormat='';
const folderExtensions=new Set(['py','js','mjs','cjs','ts','tsx','jsx','rs','go','java','kt','swift','c','h','cpp','hpp','cs','sol','html','css','scss','json','toml','yaml','yml','md','txt','sh','sql','graphql','proto','vue','svelte']);
const folderExcluded=new Set(['.git','.ssh','.aws','.gnupg','.codex','.agents','.config','.deployment','.venv','venv','env','node_modules','__pycache__','target','.blochai','dist','build','vendor','.next','.nuxt','coverage','.cache','.tox']);
const folderPrivate=/(^\.env($|\.)|(^|[._-])(secrets?|credentials?|passwords?|tokens?)([._-]|$)|\.(key|pem|p12|pfx|keychain)$|^id_(rsa|ed25519))/i;
const folderSkipReasons={protected_path:'Credencial, diretório privado ou dependência',unsupported_type:'Formato não aceito nesta importação',file_too_large:'Acima de 200 KB por arquivo',binary_or_invalid_utf8:'Conteúdo binário ou texto sem codificação UTF-8',credential_content:'Possível credencial detectada no conteúdo',depth_limit:'Pastas além da profundidade permitida'};

async function api(path,body) {
  const response=await fetch(path,{credentials:'same-origin',cache:'no-store',headers:body===undefined?{}:{'Content-Type':'application/json','X-BlochAI-Action':'1'},method:body===undefined?'GET':'POST',body:body===undefined?undefined:JSON.stringify(body)});
  const data=await response.json();
  if(!response.ok) throw new Error(data.error || (typeof data.detail==='string'?data.detail:null) || `HTTP ${response.status}`);
  return data;
}
function error(e){$('error').textContent=e.message||String(e);$('login-error').textContent=$('error').textContent;}
function state(text,busy=false){$('state').textContent=text;$('task-dot').classList.toggle('ready',busy);}
function formatDate(value){return new Date(value*1000).toLocaleString('pt-BR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});}
function size(bytes){return bytes<1048576?`${Math.max(1,Math.round(bytes/1024))} KB`:`${(bytes/1048576).toFixed(1)} MB`;}
function renderFormat(){
  $('artifact-format-selection').textContent=selectedArtifactFormat?'Formato escolhido: '+{pdf:'PDF',pptx:'PPTX',xlsx:'Excel (.xlsx)'}[selectedArtifactFormat]+'. Descreva abaixo o conteúdo do arquivo.':'';
  for(const button of document.querySelectorAll('[data-format]'))button.setAttribute('aria-pressed',String(button.dataset.format===selectedArtifactFormat));
}
function modeChanged(){selectedArtifactFormat='';renderFormat();$('mode-hint').textContent=hints[$('mode').value];}
function setPane(name){
  if(name==='globe'){window.BlochKnowledge?.draw();return;}
  sidebar(true);
  const panes={work:'task-workspace',collection:'activity',editor:'editor-workspace',privacy:'privacy-workspace'};
  for(const [tab,panel] of Object.entries(panes)){$(panel).hidden=tab!==name;$(tab+'-tab').setAttribute('aria-selected',String(tab===name));$(tab+'-tab').tabIndex=tab===name?0:-1;}
  if(name==='privacy')window.BlochPrivacy?.refresh();
  document.body.classList.toggle('editor-open',name==='editor');
  window.dispatchEvent(new Event('blochai:layout'));
}
function sidebar(open){document.body.classList.toggle('side-collapsed',!open);$('expand-sidebar').hidden=open;$('expand-sidebar').setAttribute('aria-expanded',String(open));window.BlochKnowledge?.draw();}
function inspect(kind){setPane('editor');$('editor-empty').hidden=true;$('code-create').hidden=true;$('note-editor').hidden=kind!=='note';$('code-editor').hidden=kind!=='code';}
function uploadUrl(file,action=''){return `/api/projects/${currentProject}/uploads/${file.id}${action?'/'+action:''}`;}
function projectAccess(){
  const project=projects.find(item=>item.id===currentProject);
  return project?.shared?project.capabilities||{read:true,write:false,manage:false,ai:false,cli:false,export:false}:{read:true,write:true,manage:true,ai:true,cli:true,export:true};
}
function setBusy(){
  const access=projectAccess();
  const importing=Boolean(window.BlochGithub?.busy());
  $('submit').disabled=Boolean(activeJob)||uploading||importing||!currentProject||!access.ai;
  $('cancel').hidden=!activeJob||activeJob!==selectedJob;
  $('view-active').hidden=!activeJob||activeJob===selectedJob;
  $('attach-button').disabled=uploading||!currentProject||!access.write;
  $('folder-upload-button').disabled=uploading||!currentProject||!access.write;
  $('shared-upload').disabled=$('shared-folder').disabled=$('shared-code').disabled=uploading||!access.write;
  $('project').disabled=uploading||importing;$('open-projects').disabled=uploading||importing;
  $('create-project-toggle').disabled=uploading||importing;$('new-task').disabled=uploading||importing;
  window.BlochClosedScope?.update();
}
function showTab(name){
  activeTab=name;
  for(const tab of tabs){const selected=tab===name;$(tab+'-tab').setAttribute('aria-selected',String(selected));$(tab+'-tab').tabIndex=selected?0:-1;$(tab+'-panel').hidden=!selected;}
  $('search').placeholder={tasks:'Buscar uma tarefa…',files:'Buscar um arquivo…',projects:'Buscar um projeto…'}[name];
  const label={tasks:'Nova tarefa',files:'Enviar arquivos',projects:'Criar projeto'}[name];
  $('new-task').title=label;$('new-task').setAttribute('aria-label',label);
}
function toggleAttachment(file){
  if(selectedUploads.has(file.id))selectedUploads.delete(file.id);
  else if(selectedUploads.size<6)selectedUploads.add(file.id);
  else{error(new Error('Selecione até 6 anexos por tarefa.'));return;}
  renderAttachments();renderSidebar();
}
function renderAttachments(){
  $('selected-files').replaceChildren();
  const selected=uploads.filter(file=>selectedUploads.has(file.id));
  for(const file of selected){
    const chip=document.createElement('div');chip.className='attachment-chip';
    const view=document.createElement('button');view.type='button';view.className='chip-view';view.title=`Ver ${file.name}`;
    if(file.kind==='image'){const img=document.createElement('img');img.src=uploadUrl(file,'preview');img.alt='';view.append(img);}
    else{const mark=document.createElement('span');mark.className='chip-extension';mark.textContent=file.name.split('.').pop().toUpperCase();view.append(mark);}
    const name=document.createElement('span');name.textContent=file.name;view.append(name);view.onclick=()=>previewFile(file);
    const remove=document.createElement('button');remove.type='button';remove.className='chip-remove';remove.textContent='×';remove.setAttribute('aria-label',`Retirar ${file.name} desta tarefa`);remove.onclick=()=>toggleAttachment(file);
    chip.append(view,remove);$('selected-files').append(chip);
  }
  $('attachment-hint').hidden=selected.length===0;
  $('attachment-hint').textContent=selected.some(file=>file.kind==='image')?
    `${selected.length}/6 anexos · Imagens disponíveis para referência. A análise visual ainda não está habilitada.`:
    `${selected.length}/6 anexos · Os agentes receberão trechos do texto. Retirar um anexo aqui mantém o arquivo no projeto.`;
}
function renderSidebar(){
  const query=$('search').value.toLocaleLowerCase('pt-BR');
  const projectRows=rows.filter(row=>row.project===currentProject);
  $('task-count').textContent=String(projectRows.length).padStart(2,'0');
  for(const id of ['task-list','file-list','project-list'])$(id).replaceChildren();
  let taskCount=0,fileCount=0,projectCount=0;
  for(const row of projectRows){
    if(row.title.toLocaleLowerCase('pt-BR').includes(query)){
      const button=document.createElement('button');button.className='task-item';button.type='button';button.disabled=uploading;
      button.setAttribute('aria-current',String(row.id===selectedJob));
      const title=document.createElement('strong');title.textContent=row.title;
      const meta=document.createElement('small');meta.textContent=`${statuses[row.status]||row.status} · ${formatDate(row.created_at)}\n${modes[row.mode]||row.mode}`;
      if(activeStatuses.has(row.status))meta.className='running';
      button.append(title,meta);button.onclick=()=>selectJob(row.id);$('task-list').append(button);taskCount++;
    }
    for(const file of row.artifacts||[]){
      if(!file.path.toLocaleLowerCase('pt-BR').includes(query))continue;
      const link=document.createElement('a');link.className='file-item';link.href=`/api/jobs/${row.id}/artifacts/${file.id}`;link.download='';
      const extension=document.createElement('span');extension.className='file-extension';extension.textContent=file.path.split('.').pop().toUpperCase();
      const info=document.createElement('div'),title=document.createElement('strong'),meta=document.createElement('small'),arrow=document.createElement('span');
      title.textContent=file.path.split('/').pop();meta.textContent=`Gerado · ${formatDate(row.created_at)}`;arrow.textContent='↓';
      info.append(title,meta);link.append(extension,info,arrow);$('file-list').append(link);fileCount++;
    }
  }
  for(const file of uploads){
    if(!file.name.toLocaleLowerCase('pt-BR').includes(query))continue;
    const row=document.createElement('div');row.className='uploaded-file';
    const view=document.createElement('button');view.type='button';view.className='uploaded-view';view.onclick=()=>previewFile(file);
    if(file.kind==='image'){const img=document.createElement('img');img.src=uploadUrl(file,'preview');img.alt='';img.loading='lazy';view.append(img);}
    else{const extension=document.createElement('span');extension.className='file-extension';extension.textContent=file.name.split('.').pop().toUpperCase();view.append(extension);}
    const info=document.createElement('span'),title=document.createElement('strong'),meta=document.createElement('small');
    title.textContent=file.name;meta.textContent=`Enviado · ${size(file.size)}${file.truncated?' · leitura parcial':''}`;info.append(title,meta);view.append(info);
    const use=document.createElement('button');use.className='use-file';use.type='button';use.textContent=selectedUploads.has(file.id)?'✓ Anexado':'+ Usar';use.setAttribute('aria-pressed',String(selectedUploads.has(file.id)));use.setAttribute('aria-label',`${selectedUploads.has(file.id)?'Retirar':'Usar'} ${file.name} na tarefa`);use.onclick=()=>toggleAttachment(file);
    use.hidden=!projectAccess().ai;row.append(view,use);$('file-list').append(row);fileCount++;
  }
  for(const project of projects){
    if(!`${project.name} ${project.description}`.toLocaleLowerCase('pt-BR').includes(query))continue;
    const button=document.createElement('button');button.type='button';button.className='task-item project-item';button.disabled=uploading;button.setAttribute('aria-current',String(project.id===currentProject));
    const title=document.createElement('strong'),description=document.createElement('p'),meta=document.createElement('small');title.textContent=project.name;description.textContent=project.description;description.hidden=!project.description;
    meta.textContent=project.shared?`Compartilhado · ${project.role==='editor'?'Edição':'Leitura'}`:`${kinds[project.kind]||'Geral'} · ${project.upload_count} arquivos · ${rows.filter(row=>row.project===project.id).length} tarefas`;
    button.append(title,description,meta);button.onclick=()=>selectProject(project.id).catch(error);$('project-list').append(button);projectCount++;
  }
  $('tasks-empty').hidden=taskCount>0;$('files-empty').hidden=fileCount>0;$('projects-empty').hidden=projectCount>0;
  $('tasks-empty').textContent=!projectAccess().ai?'O histórico privado de tarefas não é compartilhado. Abra Arquivos para explorar este projeto.':query?'Nenhuma tarefa encontrada.':currentProject?'As tarefas deste projeto aparecerão aqui.':'Crie ou selecione um projeto para começar.';
  $('files-empty').textContent=query?'Nenhum arquivo encontrado.':currentProject?'Envie imagens e documentos ou gere um novo arquivo.':'Escolha um projeto para organizar seus arquivos.';
  $('projects-empty').textContent=query?'Nenhum projeto encontrado.':'Dê um espaço à sua próxima ideia. Crie seu primeiro projeto.';
}
async function loadProjects(){
  const [data,shared]=await Promise.all([api('/api/projects'),api('/api/shared-projects')]);projects=[...data.projects,...(shared.projects||[])];
  $('project').replaceChildren();const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='Selecione um projeto';$('project').append(placeholder);
  for(const project of projects){const option=document.createElement('option');option.value=project.id;option.textContent=project.name+(project.shared?' · compartilhado':'');$('project').append(option);}
  $('project').value=currentProject;renderSidebar();
}
function clearTask(){
  selectedJob=null;pending=null;$('approval').hidden=true;$('downloads').replaceChildren();
  $('answer').textContent='O próximo passo começa com a sua ideia. Suas respostas aparecerão aqui.';$('answer').classList.add('empty');
  $('event-details').hidden=true;$('result-meta').textContent='QENTL / OUTPUT';state(activeJob?'Há uma tarefa em andamento.':'Pronto para uma nova ideia',Boolean(activeJob));setBusy();
  $('answer-to-note').hidden=true;$('knowledge-evidence').replaceChildren();
}
async function loadUploads(){
  const project=currentProject,version=projectVersion;
  const data=project?await api(`/api/projects/${project}/uploads`):{uploads:[]};
  if(version!==projectVersion)return;
  uploads=data.uploads;selectedUploads=new Set([...selectedUploads].filter(id=>uploads.some(file=>file.id===id)));
  renderAttachments();renderSidebar();
  window.dispatchEvent(new CustomEvent('blochai:files'));
}
async function selectProject(id,keepTask=false){
  if(uploading)return false;
  if(id===currentProject)return true;
  if((window.BlochGithub&&!window.BlochGithub.canLeave())||(window.BlochKnowledge&&!window.BlochKnowledge.canLeave())||(window.BlochCode&&!window.BlochCode.canLeave())||(window.BlochScope&&!window.BlochScope.canLeave())||(window.BlochClosedScope&&!window.BlochClosedScope.canLeave())||(window.BlochFiles&&!window.BlochFiles.canLeave())){$('project').value=currentProject;return false;}
  currentProject=id;const selectionVersion=++projectVersion;publishedProject=null;selectedUploads.clear();uploads=[];$('project').value=id;
  folderPlan=null;$('folder-preview').close();$('folder-input').value='';$('web-source-status').textContent='';
  projectRevision=null;projectFileStamps=new Map();cliRunStamp='';clearTimeout(projectPoll);
  $('project-cli-command').value='';$('project-cli-path').textContent='';$('project-cli-status').textContent='';$('project-cli-runs').replaceChildren();
  const project=projects.find(item=>item.id===id);
  const access=projectAccess();
  $('shared-project-notice').hidden=!project?.shared;$('request').hidden=Boolean(project?.shared);
  $('shared-project-role').textContent=access.write?'Você pode ler e editar arquivos e notas.':'Você tem acesso de leitura.';
  $('open-project-cli').hidden=$('project-cli-details').hidden=!access.cli;
  $('graph-select').hidden=!access.ai;
  $('open-web-source').hidden=$('web-source-details').hidden=!access.write;
  $('open-github-import').hidden=$('github-import-details').hidden=!access.write;
  $('connect-nodes').disabled=!access.write;$('connection-form').hidden=!access.write;
  $('map-project-title').textContent=project?.name||'Seu universo de ideias.';
  $('project-context').textContent=project?.description||'';$('project-context').hidden=!project?.description;
  if(!keepTask){clearTask();$('prompt').value='';$('mode').value='auto';modeChanged();}
  renderAttachments();renderSidebar();setBusy();await loadUploads();
  if(selectionVersion!==projectVersion||id!==currentProject)return false;
  knowledgeNoteIds=[];$('use-knowledge').checked=false;
  publishedProject=project||null;
  window.dispatchEvent(new CustomEvent('blochai:project',{detail:project||null}));
  if(project){if(access.cli)loadProjectCli(id,projectVersion);pollProjectFiles();}
  return true;
}

async function loadProjectCli(id,version){
  if(workspaceDeployment.mode==='hosted'){
    if(version!==projectVersion||id!==currentProject)return;
    $('project-cli-command').value=`qentl login\nqentl projects list --remote\nqentl projects scope ${id} --remote\nqentl run 'Implementar o requisito selecionado' --remote --project ${id} --requirement REQ-ID\n\nqentl sync --project ${id} --workspace '/caminho/da/pasta-escolhida' --dry-run\nqentl sync --project ${id} --workspace '/caminho/da/pasta-escolhida' --watch`;
    $('project-cli-path').textContent='Projeto hospedado no Qentl.ai. Escolha explicitamente a pasta local que deseja sincronizar.';
    $('project-cli-status').textContent='Substitua REQ-ID por um requisito aprovado e o caminho pela pasta escolhida. Revise a prévia --dry-run antes do envio. Para trazer alterações do site, use qentl sync com --pull. Conflitos preservam as versões; arquivos omitidos não são excluídos.';
    $('project-cli-progress').textContent='Tarefas iniciadas pela CLI remota aparecem na aba Tarefas. Alterações sincronizadas aparecem no Graphus.';
    $('project-cli-runs').replaceChildren();return;
  }
  if(!workspaceDeployment.local_cli){$('project-cli-status').textContent='Não foi possível confirmar a configuração do terminal desta instalação.';return;}
  try{const data=await api(`/api/projects/${id}/cli-info`);if(version!==projectVersion||id!==currentProject)return;
    $('project-cli-command').value=data.command;$('project-cli-path').textContent=data.workspace;
    $('project-cli-status').textContent=data.launcher_available?'Troque a descrição da tarefa antes de executar. Alterações em arquivos pedem aprovação no terminal; comandos de sistema permanecem bloqueados neste modo.':'Instale a CLI ou use o lançador incluído no aplicativo antes de executar este comando.';
    if(data.closed_scope){
      $('project-cli-status').textContent+=data.closed_scope.state==='approved'?' Use --requirement com um dos requisitos aprovados: '+(data.closed_scope.requirements||[]).map(row=>row.id).join(', ')+'.':' Aprove uma versão atual do escopo .md e selecione um requisito antes de executar desenvolvimento na CLI.';
    }
  }catch(e){if(version===projectVersion)$('project-cli-status').textContent=e.message;}
}

function renderCliRuns(runs){
  const stamp=JSON.stringify(runs.map(run=>[run.id,run.status,run.updated_at,run.steps,run.heartbeat_current]));
  if(stamp===cliRunStamp)return;cliRunStamp=stamp;
  const opened=new Set([...$('project-cli-runs').querySelectorAll('details[open]')].map(item=>item.dataset.run));
  $('project-cli-runs').replaceChildren();
  const active=runs.find(run=>['RUNNING','AWAITING_APPROVAL'].includes(run.status)&&run.heartbeat_current);
  $('project-cli-progress').textContent=active?`CLI em andamento · ${active.steps||0} etapas registradas`:(runs.length?'Execuções recentes do terminal neste projeto.':'Nenhuma execução da CLI registrada neste projeto.');
  for(const run of runs.slice(0,5)){
    const details=document.createElement('details'),summary=document.createElement('summary'),content=document.createElement('pre');
    details.dataset.run=run.id;details.open=opened.has(run.id);
    const stale=['RUNNING','AWAITING_APPROVAL'].includes(run.status)&&!run.heartbeat_current;
    summary.textContent=`${stale?'Sem atualização recente':statuses[run.status]||run.status} · ${run.agent} · ${run.steps||0} etapas`;
    const lines=[run.task||'',run.summary||'',`Atualização registrada: ${run.updated_at||''}`];
    for(const event of run.events||[]){const result=event.result||{};lines.push(`${event.action||event.kind}${result.path?' · '+result.path:''}${result.changed?' · alterado':''}${result.denied?' · recusado':''}${Number.isInteger(result.exit_code)?' · saída '+result.exit_code:''}`);}
    content.textContent=lines.filter(Boolean).join('\n');details.append(summary,content);$('project-cli-runs').append(details);
  }
}

async function pollProjectFiles(){
  clearTimeout(projectPoll);
  if(!currentProject||document.visibilityState==='hidden')return;
  if(projectPolling){projectPoll=setTimeout(pollProjectFiles,3000);return;}
  projectPolling=true;const id=currentProject,version=projectVersion;
  try{const [snapshot,history]=await Promise.all([api(`/api/projects/${id}/revision`),projectAccess().cli&&workspaceDeployment.local_cli?api(`/api/projects/${id}/cli-runs`):Promise.resolve({runs:[]})]);
    if(version!==projectVersion||id!==currentProject||document.visibilityState==='hidden')return;
    if(workspaceDeployment.local_cli)renderCliRuns(history.runs||[]);
    if(snapshot.revision!==projectRevision){
      const next=new Map(snapshot.files.map(file=>[file.id,JSON.stringify([file.path,file.size,file.mtime_ns,file.ctime_ns])]));
      const changed=[...next].filter(([key,value])=>projectFileStamps.get(key)!==value).map(([key])=>key);
      for(const key of projectFileStamps.keys())if(!next.has(key))changed.push(key);
      projectRevision=snapshot.revision;projectFileStamps=next;
      window.dispatchEvent(new CustomEvent('blochai:revision',{detail:{project:id,files:snapshot.files,changed_ids:changed}}));
      window.dispatchEvent(new CustomEvent('blochai:files'));
    }
  }catch(e){if(version===projectVersion)$('project-cli-progress').textContent='Sincronização do terminal indisponível: '+e.message;}
  finally{projectPolling=false;if(currentProject&&document.visibilityState!=='hidden')projectPoll=setTimeout(pollProjectFiles,3000);}
}

document.addEventListener('visibilitychange',()=>{clearTimeout(projectPoll);if(document.visibilityState!=='hidden')pollProjectFiles();});
async function history(){const data=await api('/api/jobs');rows=data.jobs;activeJob=rows.find(row=>activeStatuses.has(row.status))?.id||null;setBusy();renderSidebar();}
async function account(data){
  accountIdentity=data;
  const ingestion=loadIngestPolicy(data);
  document.body.classList.add('signed-in');$('login').hidden=true;$('welcome').hidden=true;$('workbench').hidden=false;$('activity').hidden=false;$('logout').hidden=false;
  $('account').textContent=`${data.user.email} · ${data.organization.name}`;$('account').title=$('account').textContent;
  $('workspace-dock').hidden=false;setPane('work');
  window.dispatchEvent(new CustomEvent('blochai:account',{detail:data}));
  try{workspaceDeployment=await api('/api/deployment');}catch{workspaceDeployment={mode:'unknown',local_cli:false};}
  window.dispatchEvent(new CustomEvent('qentl:deployment',{detail:workspaceDeployment}));
  if(workspaceDeployment.mode==='hosted'){
    $('collaboration-scope').textContent='Os convites de projeto funcionam neste workspace Qentl.ai. A pessoa precisa de uma conta Qentl ativa e de uma permissão específica para o projeto.';
    $('privacy-delete').textContent='Excluir projeto deste servidor';
  }
  loadModels();
  api('/api/web-policy').then(data=>{$('web-source-policy').textContent=(data.allowed_sites||[]).map(site=>site.host+(site.path_prefixes?.length?' · '+site.path_prefixes.join(', '):'')).join('\n')||'Consulte a política do operador.';}).catch(()=>{$('web-source-policy').textContent='Não foi possível consultar a política de acesso.';});
  await ingestion;
  try{await loadProjects();if(projects.length)await selectProject(projects[0].id);else openProjectForm();await tick();if(activeJob)await selectJob(activeJob);}catch(e){error(e);}
}
async function refresh(){
  try{const choice=$('model-choice').value;const data=await api('/api/status'+(choice?'?model='+encodeURIComponent(choice):''));
    if(choice!==$('model-choice').value)return;
    const limits=data.limits||{},number=value=>Number(value).toLocaleString('pt-BR');
    const parts=[];
    if(Number.isInteger(limits.context_tokens))parts.push(`Contexto: ${number(limits.context_tokens)} tokens`);
    if(Number.isInteger(limits.max_prompt_tokens))parts.push(`Entrada: até ${number(limits.max_prompt_tokens)} tokens`);
    const output=limits.effective_output_tokens??limits.max_new_tokens;
    if(Number.isInteger(output)&&output>0)parts.push(`Saída: até ${number(output)} tokens`);
    $('model-limits').textContent=parts.join(' · ')+(parts.length?' · O pedido, as diretrizes e os anexos compartilham o contexto.':'');
    if(limits.token_counting==='utf8_upper_bound')$('model-limits').textContent+=' A entrada usa um limite conservador por bytes UTF-8.';
    $('model').textContent=data.ready?'Modelo disponível':'IA aguardando modelo';$('model').title=data.reason||`${data.model} · ${parts.join(' · ')}${data.processing_region?' · '+data.processing_region:''}`;$('model-dot').classList.toggle('ready',data.ready);if(data.processing_region)$('privacy-processing').textContent=data.processing_region+' · sem gravação de conteúdo no servidor de inferência';}
  catch(e){$('model').textContent='Não foi possível verificar';$('model-limits').textContent='Limites do modelo indisponíveis.';$('model-dot').classList.remove('ready');error(e);}
}
async function loadModels(){
  try{const data=await api('/api/models'),selected=$('model-choice').value;$('model-choice').replaceChildren();
    if(!data.models.some(model=>model.enabled)){const empty=document.createElement('option');empty.value='';empty.textContent='Nenhum modelo configurado';$('model-choice').append(empty);}
    for(const model of data.models){const option=document.createElement('option');option.value=model.id;option.textContent=model.label;option.disabled=!model.enabled;$('model-choice').append(option);}
    if(data.models.some(model=>model.id===selected&&model.enabled))$('model-choice').value=selected;
    $('model-policy').textContent=data.note;await refresh();
  }catch(e){error(e);}
}
function renderJob(data){
  state(statuses[data.status]||data.status,activeStatuses.has(data.status));
  $('answer').textContent=data.summary||(activeStatuses.has(data.status)?'Os agentes estão trabalhando. Acompanhe as ações abaixo.':'Esta tarefa não registrou uma resposta.');
  $('answer').classList.toggle('empty',!data.summary);$('result-meta').textContent=`${modes[data.mode]||'QENTL'} / ${data.project}${data.attachments?.length?' · '+data.attachments.length+' anexos':''}`;
  $('events').textContent=data.events.map(event=>JSON.stringify(event,null,2)).join('\n\n');$('event-details').hidden=data.events.length===0;
  pending=data.approval||null;$('approval').hidden=!pending;if(pending)$('preview').textContent=pending.preview;
  $('downloads').replaceChildren();
  for(const file of data.artifacts){const link=document.createElement('a');link.className='download-link';link.textContent=`↓ ${file.path.split('/').pop()}`;link.href=`/api/jobs/${data.id}/artifacts/${file.id}`;link.download='';$('downloads').append(link);}
  $('answer-to-note').hidden=!data.summary||data.status!=='COMPLETED';
  $('knowledge-evidence').replaceChildren();
  for(const note of data.knowledge_notes||[]){const button=document.createElement('button');button.type='button';button.className='text-button';button.textContent='Fonte: '+note.title;button.onclick=()=>window.BlochKnowledge?.open(note.id);$('knowledge-evidence').append(button);}
  if(data.status==='COMPLETED'&&completedNotification!==data.id){completedNotification=data.id;window.dispatchEvent(new CustomEvent('blochai:files'));}
  const graphVersion=[data.id,data.status,...(data.changed_files||[])].join('|');
  if(graphVersion!==graphJobVersion){graphJobVersion=graphVersion;window.dispatchEvent(new CustomEvent('blochai:files'));}
  const scope=data.scope?.mode==='selection'?data.scope.nodes.map(node=>node.title).join(', '):'Projeto inteiro';
  const routing=data.routing?' · '+(modes[data.routing.effective_mode]||data.mode)+(data.routing.artifact_formats?.length?' / '+data.routing.artifact_formats.join(', ').toUpperCase():''):'';
  $('task-provenance').textContent=`${data.model_choice||'Modelo não registrado'} · ${scope}${routing}${data.changed_files?.length?' · '+data.changed_files.length+' arquivos alterados':''}`;
  if(data.code_review)window.dispatchEvent(new CustomEvent('blochai:review',{detail:data}));
}
async function selectJob(id){
  try{const row=rows.find(item=>item.id===id);if(row&&row.project!==currentProject&&!await selectProject(row.project,true))return;setPane('work');selectedJob=id;pending=null;$('approval').hidden=true;await tick();}catch(e){error(e);}
}
async function tick(){
  clearTimeout(poll);
  try{await history();if(selectedJob){const id=selectedJob;const data=await api(`/api/jobs/${id}`);if(id===selectedJob)renderJob(data);}else if(activeJob)state('Há uma tarefa em andamento.',true);}
  catch(e){error(e);}
  if(activeJob)poll=setTimeout(tick,2500);
}
function openProjectForm(){
  setPane('collection');showTab('projects');$('search').value='';renderSidebar();$('project-create').hidden=false;$('project-error').textContent='';$('project-name').focus();
}
$('project-create').addEventListener('submit',async event=>{
  event.preventDefault();$('save-project').disabled=true;$('project-error').textContent='';
  try{const data=await api('/api/projects',{name:$('project-name').value,description:$('project-description').value,kind:$('project-kind').value});await loadProjects();await selectProject(data.project.id);$('project-create').reset();$('project-create').hidden=true;setPane('work');$('prompt').focus();}
  catch(e){$('project-error').textContent=e.message;}finally{$('save-project').disabled=false;}
});
function sendFile(project,file,index,total){
  return new Promise((resolve,reject)=>{
    const xhr=new XMLHttpRequest();uploadRequest=xhr;xhr.open('POST',`/api/projects/${project}/uploads`);xhr.timeout=45000;
    xhr.setRequestHeader('Content-Type','application/octet-stream');xhr.setRequestHeader('X-BlochAI-Action','1');xhr.setRequestHeader('X-BlochAI-Filename',encodeURIComponent(file.name));
    xhr.upload.onprogress=event=>{if(event.lengthComputable){const value=Math.round(event.loaded/event.total*100);$('upload-progress').value=value;$('upload-label').textContent=value===100?`Lendo ${file.name}…`:`Enviando ${index}/${total}: ${file.name} · ${value}%`;}};
    xhr.onload=()=>{try{const data=JSON.parse(xhr.responseText);if(xhr.status>=200&&xhr.status<300)resolve(data.upload);else reject(new Error(data.error||data.detail||'Falha no envio.'));}catch(e){reject(e);}};
    xhr.onerror=()=>reject(new Error('Não foi possível enviar. Verifique a conexão e a lista de arquivos antes de tentar novamente.'));
    xhr.ontimeout=()=>reject(new Error('O envio excedeu o tempo limite. Confira a lista de arquivos antes de repetir.'));
    xhr.onabort=()=>reject(new Error('Envio cancelado. Arquivos já recebidos permanecem no projeto.'));
    xhr.send(file);
  });
}
async function uploadFiles(files){
  if(uploading||!projectAccess().write)return;
  if(!currentProject){openProjectForm();error(new Error('Crie ou selecione um projeto antes de enviar arquivos.'));return;}
  const list=Array.from(files);if(!list.length)return;
  if(list.length>10){error(new Error('Envie até 10 arquivos de cada vez.'));return;}
  for(const file of list){if(file.size>10*1024*1024||!file.size){error(new Error(`${file.name}: use um arquivo com conteúdo e até 10 MB.`));return;}if(!accepted.has(file.name.split('.').pop().toLowerCase())){error(new Error(`${file.name}: formato não aceito. Use imagens, PDF, DOCX, PPTX, XLSX ou texto.`));return;}}
  const project=currentProject;uploading=true;uploadCancelled=false;$('error').textContent='';$('upload-status').hidden=false;setBusy();renderSidebar();
  try{
    for(let index=0;index<list.length&&!uploadCancelled;index++){
      $('upload-progress').value=0;$('upload-label').textContent=`Enviando ${index+1}/${list.length}: ${list[index].name}`;
      try{const item=await sendFile(project,list[index],index+1,list.length);if(selectedUploads.size<6)selectedUploads.add(item.id);await loadUploads();}
      catch(e){error(e);break;}
    }
  }finally{uploading=false;uploadRequest=null;$('upload-status').hidden=true;$('file-input').value='';setBusy();try{await loadProjects();await loadUploads();}catch(e){error(e);}}
}

function folderExclusions(plan){
  $('folder-skipped').textContent=plan.skipped.slice(0,300).map(item=>item.path+' — '+(folderSkipReasons[item.reason]||item.reason)).join('\n')+(plan.skipped.length>300?`\n… mais ${plan.skipped.length-300} arquivos excluídos.`:'')||'Nenhum arquivo excluído.';
}
function prepareFolder(files){
  if(uploading||!currentProject||!projectAccess().write)return;
  const accepted=[],skipped=[],policy={...ingestPolicy};let bytes=0;
  for(const file of files){
    const path=file.webkitRelativePath||file.name,parts=path.split('/'),name=parts.at(-1);
    let reason='';
    if(!file.webkitRelativePath||parts.length<2||path.length>500||parts.some(part=>!part||part==='.'||part==='..'||/[\\:\x00-\x1f]/.test(part)||/[. ]$/.test(part)||/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part)))reason='Caminho não suportado';
    else if(parts.some(part=>folderExcluded.has(part.toLowerCase())||folderPrivate.test(part)))reason='Credencial, diretório privado ou dependência';
    else if(parts.some(part=>part.startsWith('.')))reason='Arquivo ou pasta oculta';
    else if(parts.length>6)reason='Pastas além da profundidade permitida';
    else if(!folderExtensions.has(name.split('.').pop().toLowerCase())&&!['Dockerfile','Makefile'].includes(name))reason='Use anexos para este formato; esta importação aceita texto e código';
    else if(file.size>policy.source_file_bytes)reason='Acima de 200 KB por arquivo';
    if(reason)skipped.push({path,reason});else{accepted.push({path,file});bytes+=file.size;}
  }
  const batches=[];let batch=[],batchBytes=0;
  for(const item of accepted){
    if(batch.length&&(batch.length>=policy.batch_files||batchBytes+item.file.size>policy.batch_decoded_bytes)){batches.push(batch);batch=[];batchBytes=0;}
    batch.push(item);batchBytes+=item.file.size;
  }
  if(batch.length)batches.push(batch);
  folderPlan={project:currentProject,version:projectVersion,owner:accountIdentity,policy,accepted,skipped,bytes,batches,next:0,pending:null,importId:null,confirmed:0,confirmedBytes:0,confirmedPaths:[]};
  const internal=policy.resumable_folder_batches;
  $('folder-summary').textContent=`${accepted.length} arquivos preparados · ${size(bytes)} · ${skipped.length} excluídos. `+(internal?`${batches.length} lotes de até ${policy.batch_files} arquivos / ${size(policy.batch_decoded_bytes)}; sem cota fixa de bytes por projeto, sujeito ao disco disponível.`:`Limites: ${policy.batch_files} arquivos e 20 MiB por pasta.`);
  $('folder-accepted').textContent=accepted.slice(0,500).map(item=>item.path+' · '+size(item.file.size)).join('\n')+(accepted.length>500?`\n… mais ${accepted.length-500} arquivos preparados.`:'')||'Nenhum arquivo elegível.';
  folderExclusions(folderPlan);
  const oversized=accepted.length>policy.max_source_files||(!internal&&(accepted.length>policy.batch_files||bytes>policy.batch_decoded_bytes));
  folderPlan.oversized=oversized;
  $('folder-status').textContent=oversized?`Selecione uma subpasta menor: até ${policy.max_source_files} arquivos elegíveis neste perfil.`:`Verificação final no recebimento. Graphus exibe até ${policy.graph_source_files} arquivos de código; anexos e contexto da IA têm limites próprios. O projeto inteiro não entra automaticamente em um prompt.`;
  $('folder-import-confirm').disabled=oversized||!accepted.length;$('folder-import-confirm').hidden=false;$('folder-import-confirm').textContent='Importar esta pasta ↗';
  $('folder-progress').hidden=true;$('folder-import-cancel').hidden=true;$('folder-import-new').hidden=true;$('folder-preview-close').disabled=false;
  if(!$('folder-preview').open)$('folder-preview').showModal();
}

function sendFolder(project,payload,label=''){
  return new Promise((resolve,reject)=>{
    const xhr=new XMLHttpRequest();uploadRequest=xhr;xhr.open('POST',`/api/projects/${project}/folder-import`);xhr.timeout=120000;
    xhr.setRequestHeader('Content-Type','application/json');xhr.setRequestHeader('X-BlochAI-Action','1');
    xhr.upload.onprogress=event=>{if(event.lengthComputable){const percent=Math.round(event.loaded/event.total*100);$('folder-progress').value=percent;$('folder-status').textContent=label+' · '+(percent===100?'Verificando os arquivos e atualizando o Graphus…':`Enviando · ${percent}%`);}};
    xhr.onload=()=>{try{const data=JSON.parse(xhr.responseText);if(xhr.status>=200&&xhr.status<300)resolve(data);else reject(new Error(data.error||(typeof data.detail==='string'?data.detail:null)||'A pasta não pôde ser importada.'));}catch(e){reject(e);}};
    xhr.onerror=()=>reject(new Error('Falha de conexão; o último lote pode ter sido recebido.'));
    xhr.ontimeout=()=>reject(new Error('Tempo limite atingido; o último lote pode ter sido recebido.'));
    xhr.onabort=()=>reject(new Error('Envio cancelado; o último lote pode ter sido recebido.'));
    xhr.send(JSON.stringify(payload));
  });
}
function guardFolder(plan){
  if(plan!==folderPlan||plan.project!==currentProject||plan.version!==projectVersion||plan.owner!==accountIdentity)throw new Error('O projeto ou a conta mudou; nenhuma nova parte será enviada.');
  if(uploadCancelled)throw new Error('Envio interrompido pelo usuário.');
}
async function importFolder(){
  const plan=folderPlan;
  if(!plan||plan.oversized||!plan.accepted.length||uploading||plan.project!==currentProject||plan.version!==projectVersion||plan.owner!==accountIdentity)return;
  uploading=folderImporting=true;uploadCancelled=false;setBusy();
  $('folder-import-confirm').disabled=true;$('folder-import-new').hidden=true;$('folder-preview-close').disabled=true;$('folder-import-cancel').hidden=false;$('folder-progress').hidden=false;$('folder-progress').value=0;
  try{
    guardFolder(plan);
    if(plan.policy.resumable_folder_batches&&!plan.importId){
      $('folder-status').textContent='Reservando o identificador da importação; nenhum arquivo foi enviado…';
      const reservation=await api(`/api/projects/${plan.project}/folder-imports`,{name:plan.accepted[0].path.split('/')[0]});
      guardFolder(plan);
      if(typeof reservation.import_id!=='string'||!/^[a-f0-9]{16}$/.test(reservation.import_id))throw new Error('Reserva de importação inválida. Nenhum arquivo foi enviado.');
      plan.importId=reservation.import_id;plan.destination=reservation.path;
    }
    while(plan.next<plan.batches.length){
      guardFolder(plan);
      if(!plan.pending){
        const files=[];
        for(const item of plan.batches[plan.next]){
          guardFolder(plan);const bytes=new Uint8Array(await item.file.arrayBuffer());guardFolder(plan);
          if(bytes.length!==item.file.size||bytes.length>plan.policy.source_file_bytes)throw new Error('Um arquivo mudou durante a preparação; selecione a pasta novamente.');
          let binary='';for(let offset=0;offset<bytes.length;offset+=32768)binary+=String.fromCharCode(...bytes.subarray(offset,offset+32768));
          files.push({path:item.path,content_base64:btoa(binary)});
          $('folder-status').textContent=`Preparando lote ${plan.next+1}/${plan.batches.length}: ${item.path}`;
        }
        const pending={files,...(plan.importId?{import_id:plan.importId}:{})};
        if(new TextEncoder().encode(JSON.stringify(pending)).length>plan.policy.batch_request_bytes)throw new Error('O lote excede o tamanho seguro da requisição.');
        plan.pending=pending;
      }
      guardFolder(plan);
      if(plan.lastBatchAt){const pause=1050-(Date.now()-plan.lastBatchAt);if(pause>0)await new Promise(resolve=>setTimeout(resolve,pause));guardFolder(plan);}
      plan.lastBatchAt=Date.now();
      const result=await sendFolder(plan.project,plan.pending,`Lote ${plan.next+1}/${plan.batches.length} · ${plan.confirmed} arquivos confirmados`);
      guardFolder(plan);
      if(plan.importId&&result.import_id!==plan.importId)throw new Error('O identificador recebido mudou. A importação foi interrompida.');
      const acceptedRows=result.accepted||[],replayed=(result.skipped||[]).filter(item=>item.reason==='already_imported');
      plan.confirmed+=acceptedRows.length+replayed.length;
      plan.confirmedBytes+=plan.batches[plan.next].filter(item=>acceptedRows.some(row=>(row.source_path||row.path)===item.path||row.path?.endsWith('/'+item.path))||replayed.some(row=>row.path===item.path)).reduce((sum,item)=>sum+item.file.size,0);
      plan.confirmedPaths.push(...acceptedRows.map(item=>item.path),...replayed.map(item=>item.path));
      plan.skipped.push(...(result.skipped||[]).filter(item=>item.reason!=='already_imported'));
      plan.destination=result.path||plan.destination;plan.next++;plan.pending=null;
      $('folder-summary').textContent=`${plan.confirmed} arquivos importados/confirmados · ${size(plan.confirmedBytes)} · ${plan.next}/${plan.batches.length} lotes · ${plan.destination||''}`;
      folderExclusions(plan);
    }
    $('folder-accepted').textContent=plan.confirmedPaths.slice(0,500).join('\n')+(plan.confirmedPaths.length>500?`\n… mais ${plan.confirmedPaths.length-500} arquivos confirmados.`:'');
    $('folder-status').textContent=`Importação concluída. Graphus exibe até ${plan.policy.graph_source_files} arquivos de código; os demais permanecem armazenados. A análise usa seleções e contexto limitado.`;
    $('folder-import-confirm').hidden=true;folderPlan=null;
  }catch(e){
    $('folder-status').textContent=e.message+` ${plan.confirmed} arquivos confirmados em ${plan.next}/${plan.batches.length} lotes.`+(plan.importId?' Use Retomar nesta janela para reenviar com segurança o lote não confirmado; os lotes concluídos são preservados.':' Confira o Graphus antes de repetir um envio sem identificador de retomada.');
    $('folder-import-confirm').textContent=plan.importId?'Retomar importação ↗':'Tentar novamente ↗';$('folder-import-confirm').disabled=false;$('folder-import-new').hidden=!plan.importId;
  }
  finally{uploading=folderImporting=false;uploadRequest=null;$('folder-import-cancel').hidden=true;$('folder-preview-close').disabled=false;$('folder-progress').hidden=true;$('folder-input').value='';setBusy();try{await loadProjects();await loadUploads();}catch(e){error(e);}}
}
async function previewFile(file){
  previewingUpload=file;
  window.BlochFiles?.select({id:'source:'+file.id,upload_id:file.id,title:file.name,path:file.path,kind:file.mime==='application/pdf'?'pdf':file.kind==='image'?'image':'document'});
  $('preview-to-note').hidden=!projectAccess().write;
  const version=++previewVersion;const url=uploadUrl(file);
  $('preview-title').textContent=file.name;$('preview-info').textContent='Carregando prévia…';$('preview-image').hidden=true;$('preview-image').removeAttribute('src');$('preview-text').hidden=true;
  $('preview-download').href=url+'/download';if(!$('file-preview').open)$('file-preview').showModal();
  $('preview-open').hidden=file.mime!=='application/pdf';$('preview-open').href=url+'/view';
  try{const data=await api(url);if(version!==previewVersion)return;
    $('preview-info').textContent=`${size(file.size)}${data.upload.note?' · '+data.upload.note:''}${data.upload.truncated||data.preview_truncated?' · Prévia parcial do documento.':''}`;
    if(file.kind==='image'){$('preview-image').src=url+'/preview';$('preview-image').alt=file.name;$('preview-image').hidden=false;}
    if(data.text){$('preview-text').textContent=data.text;$('preview-text').hidden=false;}
  }catch(e){$('preview-info').textContent=e.message;}
}
$('logout').onclick=async()=>{try{if((window.BlochGithub&&!window.BlochGithub.canLeave())||!window.BlochKnowledge?.canLeave()||!window.BlochCode?.canLeave()||(window.BlochFiles&&!window.BlochFiles.canLeave()))return;if(uploadRequest)uploadRequest.abort();await api('/api/logout',{});location.reload();}catch(e){error(e);}};
$('refresh').onclick=loadModels;$('model-choice').onchange=refresh;$('mode').onchange=modeChanged;$('project').onchange=()=>selectProject($('project').value).catch(error);
$('open-projects').onclick=openProjectForm;$('create-project-toggle').onclick=openProjectForm;$('close-project-form').onclick=()=>{$('project-create').hidden=true;};
$('request').addEventListener('submit',async event=>{
  event.preventDefault();if(activeJob||uploading||window.BlochGithub?.busy()||!currentProject||!projectAccess().ai)return;$('error').textContent='';$('submit').disabled=true;
  try{const data=await api('/api/jobs',{prompt:$('prompt').value,mode:$('mode').value,project:currentProject,attachments:[...selectedUploads],use_knowledge:$('use-knowledge').checked,note_ids:knowledgeNoteIds,model:$('model-choice').value||null,...(selectedArtifactFormat?{artifact_format:selectedArtifactFormat}:{}),...window.BlochScope.payload(),...window.BlochClosedScope?.payload($('mode').value==='coder')});activeJob=data.id;await selectJob(data.id);}catch(e){error(e);}finally{setBusy();}
});
$('prompt').addEventListener('keydown',event=>{if((event.metaKey||event.ctrlKey)&&event.key==='Enter'){event.preventDefault();if(!$('submit').disabled)$('request').requestSubmit($('submit'));}});
for(const button of document.querySelectorAll('[data-prompt]'))button.onclick=()=>{$('mode').value=button.dataset.mode;$('prompt').value=button.dataset.prompt;modeChanged();$('prompt').focus();};
for(const button of document.querySelectorAll('[data-format]'))button.onclick=()=>{
  const format=button.dataset.format;if(!['pdf','pptx','xlsx'].includes(format))return;
  $('mode').value='publisher';modeChanged();selectedArtifactFormat=format;renderFormat();
  if(!$('prompt').value.trim())$('prompt').value={pdf:'Crie um PDF com uma análise das informações do projeto. Mostre as fontes e os pontos que precisam de confirmação.',pptx:'Crie uma apresentação PPTX sobre o projeto: visão, problema, solução, evidências e próximos passos.',xlsx:'Crie uma planilha Excel para organizar e analisar os dados disponíveis no projeto. Explique os campos e as fórmulas utilizadas.'}[format];
  setPane('work');$('prompt').focus();
};
window.addEventListener('qentl:github-import',setBusy);
async function decide(allow){
  if(!pending)return;const id=selectedJob,approval=pending.id;$('allow').disabled=true;$('deny').disabled=true;
  try{await api(`/api/jobs/${id}/approval`,{id:approval,allow});if(selectedJob===id){$('approval').hidden=true;pending=null;await tick();}}catch(e){error(e);}finally{$('allow').disabled=false;$('deny').disabled=false;}
}
$('allow').onclick=()=>decide(true);$('deny').onclick=()=>decide(false);
$('cancel').onclick=async()=>{try{await api(`/api/jobs/${selectedJob}/cancel`,{});state('Cancelamento solicitado');}catch(e){error(e);}};
$('view-active').onclick=()=>selectJob(activeJob);
$('new-task').onclick=()=>{if(activeTab==='projects'){openProjectForm();return;}if(activeTab==='files'){$('attach-button').click();return;}if(activeJob){selectJob(activeJob);return;}clearTask();$('prompt').value='';selectedUploads.clear();knowledgeNoteIds=[];renderAttachments();renderSidebar();setPane('work');$('prompt').focus();};
$('search').oninput=renderSidebar;
for(const name of tabs){$(name+'-tab').onclick=()=>showTab(name);$(name+'-tab').onkeydown=event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();const next=event.key==='Home'?tabs[0]:event.key==='End'?tabs[2]:tabs[(tabs.indexOf(name)+(event.key==='ArrowRight'?1:2))%3];showTab(next);$(next+'-tab').focus();}};}
$('attach-button').onclick=()=>$('file-input').click();$('file-input').onchange=()=>uploadFiles($('file-input').files);
$('folder-upload-button').onclick=()=>{
  if(folderPlan?.importId&&folderPlan.project===currentProject&&folderPlan.owner===accountIdentity){if(!$('folder-preview').open)$('folder-preview').showModal();return;}
  $('folder-input').click();
};$('folder-input').onchange=()=>prepareFolder($('folder-input').files);
$('shared-upload').onclick=()=>$('attach-button').click();$('shared-folder').onclick=()=>$('folder-upload-button').click();$('shared-code').onclick=()=>window.BlochCode?.create();
$('folder-import-confirm').onclick=importFolder;
$('folder-import-new').onclick=()=>{if(folderImporting)return;folderPlan=null;$('folder-preview').close();$('folder-input').click();};
$('folder-preview-close').onclick=()=>{if(!folderImporting)$('folder-preview').close();};
$('folder-preview').addEventListener('cancel',event=>{if(folderImporting)event.preventDefault();});
$('folder-import-cancel').onclick=()=>{uploadCancelled=true;if(uploadRequest)uploadRequest.abort();};
$('cancel-upload').onclick=()=>{uploadCancelled=true;if(uploadRequest)uploadRequest.abort();};
let dragDepth=0;
$('request').addEventListener('dragenter',event=>{if(event.dataTransfer.types.includes('Files')){event.preventDefault();dragDepth++;$('request').classList.add('is-dragover');}});
$('request').addEventListener('dragover',event=>{if(event.dataTransfer.types.includes('Files'))event.preventDefault();});
$('request').addEventListener('dragleave',()=>{dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)$('request').classList.remove('is-dragover');});
$('request').addEventListener('drop',event=>{event.preventDefault();dragDepth=0;$('request').classList.remove('is-dragover');uploadFiles(event.dataTransfer.files);});
for(const type of ['dragover','drop'])document.addEventListener(type,event=>{if(event.dataTransfer.types.includes('Files'))event.preventDefault();});
$('prompt').addEventListener('paste',event=>{if(event.clipboardData.files.length){event.preventDefault();uploadFiles(event.clipboardData.files);}});
$('show-agents').onclick=()=>$('agents-dialog').showModal();$('close-agents').onclick=()=>$('agents-dialog').close();
$('close-preview').onclick=()=>{$('file-preview').close();previewVersion++;};
$('preview-file-actions').onclick=()=>{if(!previewingUpload)return;$('file-preview').close();window.BlochFiles?.manage({id:'source:'+previewingUpload.id,upload_id:previewingUpload.id,title:previewingUpload.name,path:previewingUpload.path,kind:'document'});};
$('preview-to-note').onclick=async()=>{
  if(!previewingUpload||!projectAccess().write)return;
  const selection=window.getSelection();const excerpt=selection?.anchorNode&&$('preview-text').contains(selection.anchorNode)&&$('preview-text').contains(selection.focusNode)?selection.toString():null;
  $('preview-to-note').disabled=true;
  try{await window.BlochKnowledge.convert(previewingUpload.id,excerpt||null);$('file-preview').close();}catch(e){error(e);$('preview-info').textContent=e.message;}finally{$('preview-to-note').disabled=false;}
};
$('globe-tab').onclick=()=>$('knowledge-globe').focus();
const dockTabs=['work','collection','editor','privacy'];
for(const tab of dockTabs){$(tab+'-tab').onclick=()=>setPane(tab);$(tab+'-tab').onkeydown=event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();const next=event.key==='Home'?dockTabs[0]:event.key==='End'?dockTabs[3]:dockTabs[(dockTabs.indexOf(tab)+(event.key==='ArrowRight'?1:3))%4];setPane(next);$(next+'-tab').focus();}};}
$('collapse-sidebar').onclick=()=>{sidebar(false);$('expand-sidebar').focus();};$('expand-sidebar').onclick=()=>{sidebar(true);$('collapse-sidebar').focus();};
$('fullscreen-map').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch(e){error(new Error('Este navegador não permitiu tela cheia. O mapa já ocupa a área disponível da janela.'));}};
$('error').onclick=()=>{$('error').textContent='';};
$('prompt-to-idea').onclick=()=>window.BlochKnowledge?.draft($('prompt').value);
$('prompt-new-code').onclick=()=>window.BlochCode?.create();
$('connect-nodes').onclick=()=>{setPane('collection');showTab('files');$('connection-details').open=true;$('connection-source').focus();};
$('open-web-source').onclick=()=>{setPane('collection');showTab('files');$('web-source-details').open=true;$('web-source-url').focus();};
$('open-project-cli').onclick=()=>{setPane('collection');showTab('files');$('project-cli-details').open=true;if(currentProject)loadProjectCli(currentProject,projectVersion);};
$('copy-project-cli').onclick=async()=>{const value=$('project-cli-command').value;if(!value)return;try{await navigator.clipboard.writeText(value);$('project-cli-status').textContent='Comando copiado. Troque a descrição da tarefa antes de executar no terminal.';}catch{$('project-cli-command').focus();$('project-cli-command').select();$('project-cli-status').textContent='O comando está selecionado. Use ⌘C ou Ctrl+C para copiar.';}};
$('web-source-form').onsubmit=async event=>{
  event.preventDefault();
  if(!currentProject){openProjectForm();return;}
  if(!projectAccess().write)return;
  const project=currentProject,version=projectVersion;
  $('web-source-submit').disabled=true;$('web-source-status').textContent='Lendo a página pública solicitada…';
  try{const data=await api(`/api/projects/${project}/web-source`,{url:$('web-source-url').value.trim()});
    if(version!==projectVersion)return;
    $('web-source-status').textContent='Fonte salva no Graphus: '+data.note.title+'. '+data.source.url;
    $('web-source-url').value='';window.dispatchEvent(new CustomEvent('blochai:files'));
  }catch(e){if(version===projectVersion)$('web-source-status').textContent=e.message;}
  finally{$('web-source-submit').disabled=false;}
};
$('answer-to-note').onclick=()=>window.BlochKnowledge?.draft($('answer').textContent);
window.BlochWorkspace={
  project:()=>projects.find(item=>item.id===currentProject),pane:setPane,inspect,
  identity:()=>accountIdentity,
  onProject:listener=>{window.addEventListener('blochai:project',listener);if(publishedProject?.id===currentProject)listener({detail:publishedProject});},
  busy:()=>Boolean(activeJob)||uploading||Boolean(window.BlochGithub?.busy()),
  access:projectAccess,
  reloadProjects:loadProjects,selectProject,
  refreshFiles:async()=>{const id=currentProject;await loadProjects();if(id!==currentProject)return;await loadUploads();if(id!==currentProject)return;window.dispatchEvent(new CustomEvent('blochai:files'));projectRevision=null;pollProjectFiles();},
  continueScope:async(requirement_id,scope_revision)=>{
    if(!currentProject||!projectAccess().ai)throw new Error('Selecione um projeto próprio com escopo aprovado.');
    if(activeJob||uploading||window.BlochGithub?.busy())throw new Error('Conclua a tarefa ou o envio em andamento antes de seguir.');
    const data=await api('/api/jobs',{project:currentProject,mode:'coder',continuation:true,requirement_id,scope_revision,model:$('model-choice').value||null,...window.BlochScope.payload()});
    activeJob=data.id;await selectJob(data.id);setPane('work');
  },
  selectJob,
  chooseModel:choice=>{if([...$('model-choice').options].some(option=>option.value===choice&&!option.disabled)){$('model-choice').value=choice;refresh();setPane('work');}else error(new Error('Este modelo histórico não está disponível agora.'));},
  deleted:async()=>{currentProject='';publishedProject=null;projectVersion++;selectedJob=null;activeJob=null;uploads=[];selectedUploads.clear();knowledgeNoteIds=[];clearTask();window.dispatchEvent(new CustomEvent('blochai:project',{detail:null}));await loadProjects();if(projects.length)await selectProject(projects[0].id);else{renderAttachments();$('map-project-title').textContent='Seu universo de ideias.';openProjectForm();}await history();},
  preview:async id=>{let file=uploads.find(item=>item.id===id);if(!file){await loadUploads();file=uploads.find(item=>item.id===id);}if(file)await previewFile(file);},
  upload:()=>{if(!currentProject)openProjectForm();else $('file-input').click();},
  ask:(question,noteIds=[])=>{if(!projectAccess().ai)return;if(activeJob){error(new Error('Conclua a tarefa atual antes de consultar a base.'));return;}setPane('work');clearTask();window.BlochScope.reset();$('prompt').value=question;$('mode').value='chat';modeChanged();$('use-knowledge').checked=true;knowledgeNoteIds=noteIds;selectedUploads.clear();renderAttachments();$('request').requestSubmit($('submit'));},
  reviewCode:async(file,content,prompt,start,action='review')=>{if(!projectAccess().ai)throw new Error('Revisão com IA disponível apenas nos seus próprios projetos.');if(activeJob)throw new Error('Conclua a tarefa atual antes de pedir uma revisão.');const data=await api('/api/jobs',{project:currentProject,mode:'chat',prompt,model:$('model-choice').value||null,code_id:file.id,code_revision:file.sha256,code_draft:content,code_start_line:start,code_action:action,scope_mode:'selection',scope_nodes:[file.id],...window.BlochClosedScope?.payload(action==='patch')});selectedJob=data.id;activeJob=data.id;await tick();setPane('editor');return data.id;}
};
modeChanged();setBusy();if(!window.QentlAccess?.claimPending())api('/api/session').then(account).catch(()=>{});
