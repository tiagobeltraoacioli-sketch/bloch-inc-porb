"""Private configuration permissions on POSIX and Windows user profiles."""
import os
from pathlib import Path


def _windows():
    import ctypes
    from ctypes import wintypes as w
    advapi=ctypes.WinDLL('advapi32',use_last_error=True)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    pointer=ctypes.c_void_p
    kernel.GetCurrentProcess.restype=w.HANDLE
    kernel.CloseHandle.argtypes=[w.HANDLE]
    kernel.LocalFree.argtypes=[pointer];kernel.LocalFree.restype=pointer
    advapi.OpenProcessToken.argtypes=[w.HANDLE,w.DWORD,ctypes.POINTER(w.HANDLE)]
    advapi.GetTokenInformation.argtypes=[w.HANDLE,ctypes.c_int,pointer,w.DWORD,ctypes.POINTER(w.DWORD)]
    advapi.ConvertSidToStringSidW.argtypes=[pointer,ctypes.POINTER(w.LPWSTR)]
    advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes=[w.LPCWSTR,w.DWORD,ctypes.POINTER(pointer),ctypes.POINTER(w.DWORD)]
    advapi.SetFileSecurityW.argtypes=[w.LPCWSTR,w.DWORD,pointer]
    advapi.GetNamedSecurityInfoW.argtypes=[w.LPWSTR,ctypes.c_int,w.DWORD,ctypes.POINTER(pointer),ctypes.POINTER(pointer),ctypes.POINTER(pointer),ctypes.POINTER(pointer),ctypes.POINTER(pointer)]
    advapi.GetNamedSecurityInfoW.restype=w.DWORD
    advapi.GetAclInformation.argtypes=[pointer,pointer,w.DWORD,ctypes.c_int]
    advapi.GetAce.argtypes=[pointer,w.DWORD,ctypes.POINTER(pointer)]
    def sid_string(sid):
        output=w.LPWSTR()
        if not advapi.ConvertSidToStringSidW(sid,ctypes.byref(output)):raise ctypes.WinError(ctypes.get_last_error())
        try:return output.value
        finally:kernel.LocalFree(ctypes.cast(output,pointer))
    handle=w.HANDLE();needed=w.DWORD()
    if not advapi.OpenProcessToken(kernel.GetCurrentProcess(),8,ctypes.byref(handle)):raise ctypes.WinError(ctypes.get_last_error())
    try:
        advapi.GetTokenInformation(handle,1,None,0,ctypes.byref(needed))
        buffer=ctypes.create_string_buffer(needed.value)
        if not advapi.GetTokenInformation(handle,1,buffer,len(buffer),ctypes.byref(needed)):raise ctypes.WinError(ctypes.get_last_error())
        sid=sid_string(ctypes.cast(buffer,ctypes.POINTER(pointer))[0])
    finally:kernel.CloseHandle(handle)
    return ctypes,w,advapi,kernel,sid_string,sid


def protect_directory(path):
    path=Path(path)
    if os.name!='nt':path.chmod(0o700);return
    c,w,api,kernel,_string,sid=_windows()
    descriptor=c.c_void_p()
    # A protected inheritable ACL gives the user, SYSTEM and local admins access.
    sddl=f'D:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;FA;;;{sid})'
    if not api.ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl,1,c.byref(descriptor),None):raise c.WinError(c.get_last_error())
    try:
        if not api.SetFileSecurityW(str(path),0x80000004,descriptor):raise c.WinError(c.get_last_error())
    finally:kernel.LocalFree(descriptor)


def is_private(path):
    path=Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_nlink!=1:return False
    if os.name!='nt':return not bool(path.stat().st_mode&0o077)
    c,w,api,kernel,string,sid=_windows()
    owner=c.c_void_p();acl=c.c_void_p();descriptor=c.c_void_p()
    result=api.GetNamedSecurityInfoW(str(path),1,5,c.byref(owner),None,c.byref(acl),None,c.byref(descriptor))
    if result:raise c.WinError(result)
    class Size(c.Structure):_fields_=[('count',w.DWORD),('used',w.DWORD),('free',w.DWORD)]
    try:
        allowed={sid,'S-1-5-18','S-1-5-32-544'}
        # Elevated Windows accounts can create files owned by Administrators.
        # The owner must still be one of the principals already trusted by the ACL.
        if not acl or string(owner) not in allowed:return False
        size=Size()
        if not api.GetAclInformation(acl,c.byref(size),c.sizeof(size),2):return False
        user_access=False
        for index in range(size.count):
            ace=c.c_void_p()
            if not api.GetAce(acl,index,c.byref(ace)):return False
            kind=c.cast(ace,c.POINTER(c.c_ubyte))[0]
            if kind==1:continue  # A deny ACE does not grant another principal access.
            if kind!=0:return False
            principal=string(c.c_void_p(ace.value+8))
            if principal not in allowed:return False
            user_access |= principal==sid
        return user_access
    finally:kernel.LocalFree(descriptor)
