"""BlochAI terminal assistant and local project agents."""

VERSION = "0.1.0"
