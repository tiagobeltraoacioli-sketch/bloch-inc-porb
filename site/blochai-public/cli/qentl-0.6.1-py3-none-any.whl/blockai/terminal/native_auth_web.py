"""Native account endpoints; browser and CLI share one authoritative account DB."""
import anyio
import re

from fastapi import HTTPException, Request
from starlette.concurrency import run_in_threadpool

from .native_auth import NativeAuthError


def install_native_auth_routes(app,portal_factory,session,body,mint_session,reserve_auth_attempt,hosted):
    async def bounded(request,maximum=2048):
        try:
            with anyio.fail_after(15):return await body(request,maximum)
        except TimeoutError:raise HTTPException(408,'Qentl account request timed out.') from None

    def exact(data,fields):
        if set(data)!=set(fields):raise HTTPException(422,'Supply only the required Qentl account fields.')

    def credential(request):
        if not hosted:raise HTTPException(404,'This native account endpoint is hosted by qentl.ai.')
        values=request.headers.getlist('authorization')
        if len(values)!=1 or not re.fullmatch(r'Bearer [a-f0-9]{64}',values[0]):
            raise HTTPException(401,'An authenticated Qentl session is required.')
        return values[0][7:]

    def invoke(token,method,path,data=None):
        portal=portal_factory(token)
        try:return portal.request(method,path,json=data) if data is not None else portal.request(method,path)
        finally:portal.close()

    @app.exception_handler(NativeAuthError)
    async def native_error(request,exc):
        from fastapi.responses import JSONResponse
        return JSONResponse({'error':str(exc)},status_code=exc.status_code)

    @app.get('/api/account-access')
    def access():return {'registration':'invitation_only','authentication':'qentl'}

    @app.get('/api/auth/session')
    async def identity(request: Request):
        portal=portal_factory(credential(request))
        try:return await run_in_threadpool(portal.identity)
        finally:portal.close()

    @app.post('/api/auth/logout')
    async def logout(request: Request):
        token=credential(request);data=await bounded(request,512);exact(data,())
        portal=portal_factory(token)
        try:return await run_in_threadpool(portal.logout)
        finally:portal.close()

    @app.post('/api/cli/login')
    async def cli_login(request: Request):
        if not hosted:raise HTTPException(404,'Native CLI login is hosted by qentl.ai.')
        data=await bounded(request);exact(data,('email','password'))
        reserve_auth_attempt('web',data['email'])
        portal=portal_factory()
        try:
            identity=await run_in_threadpool(portal.login,data['email'],data['password'])
            return {'token':portal.token,'identity':identity}
        finally:portal.close()

    async def accept(request,for_cli):
        if for_cli and not hosted:raise HTTPException(404,'Native CLI account claims are hosted by qentl.ai.')
        data=await bounded(request);exact(data,('email','password','token'))
        reserve_auth_attempt('claim',data['token'])
        portal=portal_factory()
        try:
            identity=await run_in_threadpool(portal.accept_invitation,data['email'],data['password'],data['token'])
            if for_cli:return {'token':portal.token,'identity':identity}
            return mint_session(identity,portal.token,'web')
        finally:portal.close()

    @app.post('/api/account-invitations/accept')
    async def browser_accept(request: Request):return await accept(request,False)

    @app.post('/api/cli/invitations/accept')
    async def cli_accept(request: Request):return await accept(request,True)

    async def account_record(request,manage=False):
        # Native account CLI management authenticates its bearer token directly;
        # desktop/browser management uses its workbench cookie and fresh identity.
        if hosted and request.headers.get('authorization'):
            token=credential(request);portal=portal_factory(token)
            try:identity=await run_in_threadpool(portal.identity)
            finally:portal.close()
            record={'token':token,'identity':identity}
        else:record=await run_in_threadpool(session,request,False,True)
        if manage and record['identity'].get('account_role')!='master':
            raise HTTPException(403,'Only the Qentl master account can manage account access.')
        return record

    @app.get('/api/accounts/capabilities')
    async def capabilities(request: Request):
        record=await account_record(request)
        return await run_in_threadpool(invoke,record['token'],'GET','/api/accounts/capabilities')

    async def manage(request,path,fields):
        record=await account_record(request,True)
        data=await bounded(request);exact(data,fields)
        reserve_auth_attempt('account',record['token'])
        # The authoritative native server checks the master role again inside
        # its write transaction; no browser-provided role is used.
        return await run_in_threadpool(invoke,record['token'],'POST',path,data)

    @app.post('/api/account-invitations')
    async def issue(request: Request):return await manage(request,'/api/account-invitations',('email',))

    @app.post('/api/account-resets')
    async def reset(request: Request):return await manage(request,'/api/account-resets',('email',))

    @app.post('/api/accounts/revoke')
    async def revoke(request: Request):return await manage(request,'/api/accounts/revoke',('email',))

    @app.post('/api/account-invitations/{identifier}/revoke')
    async def revoke_invitation(identifier: str,request: Request):
        if not re.fullmatch(r'[a-f0-9]{32}',identifier):raise HTTPException(422,'Invalid invitation identifier.')
        return await manage(request,'/api/account-invitations/'+identifier+'/revoke',())
