"""Keep the approved contract intact in every generation and context estimate."""
class ScopeBoundProvider:
    def __init__(self, provider, scope, check=None):
        self.provider, self.scope, self.check = provider, scope, check

    def __getattr__(self, name):
        return getattr(self.provider, name)

    @property
    def on_task(self):
        return self.provider.on_task

    @on_task.setter
    def on_task(self, callback):
        self.provider.on_task = callback

    def bind(self, messages):
        return self.scope.bind_messages(messages) if self.scope else messages

    def messages_fit(self, messages):
        bound = self.bind(messages)
        if callable(getattr(self.provider, 'messages_fit', None)):
            return self.provider.messages_fit(bound)
        return len(self.provider.flatten(bound)) <= self.provider.prompt_limit

    def context_budget(self, messages):
        bound = self.bind(messages)
        if callable(getattr(self.provider, 'context_budget', None)):
            return self.provider.context_budget(bound)
        return self.provider.prompt_limit - sum(len(row['content']) for row in bound)

    def complete(self, messages, **kwargs):
        if self.check:
            self.check()
        bound = self.bind(messages)
        return self.provider.complete(bound, **kwargs)

    def close(self):
        return self.provider.close()
