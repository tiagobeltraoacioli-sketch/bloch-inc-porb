"""Explicit Qentl.ai terminal jobs and conflict-aware, selected-folder transfers.

No project is discovered or uploaded automatically. Authentication is sent only
to the fixed first-party HTTPS origin; remote cookies live only in memory.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import time

import httpx

from .auth import saved_token
from .cli_projects import identity_owner
from .config import BlochAIError, save_json, state_home
from .file_permissions import is_private
from .folder_import import MAX_FILES, MAX_FILE_BYTES, MAX_DECODED_BYTES, _path, _skip_reason, _CREDENTIAL
from .project_lock import project_write_lock
from .store import scrub
from .workspace import Workspace

ORIGIN='https://qentl.ai'
COOKIE='__Host-qentl_session'
MAX_RESPONSE=30*1024*1024
BATCH_WRITE_INTERVAL=1.05
HEX64=re.compile(r'[a-f0-9]{64}')
HEX16=re.compile(r'[a-f0-9]{16}')
PROJECT=re.compile(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}')
STANDARD_INGEST={'profile':'standard','max_source_files':500,'sync_total_bytes':20*1024*1024,
                 'batch_files':500,'batch_decoded_bytes':20*1024*1024,'paged_sync_snapshots':False}


class RemoteHTTPError(BlochAIError):
    def __init__(self,status,message):
        self.status=status
        super().__init__(message)


def transfer_policy(data):
    """Only the authenticated operator response can enlarge aggregate capacity."""
    if not isinstance(data,dict) or data.get('profile') not in ('standard','internal'):
        raise BlochAIError('Qentl.ai returned an invalid ingestion policy.')
    result=dict(STANDARD_INGEST);result['profile']=data['profile']
    for key,maximum in [('max_source_files',10000 if data['profile']=='internal' else 500),
                        ('batch_files',500),('batch_decoded_bytes',20*1024*1024)]:
        value=data.get(key)
        if type(value) is not int or not 1<=value<=maximum:raise BlochAIError('Qentl.ai returned an invalid transfer limit.')
        result[key]=value
    aggregate=data.get('sync_total_bytes')
    if aggregate is None and data['profile']=='internal':result['sync_total_bytes']=None
    elif type(aggregate) is int and 1<=aggregate<=20*1024*1024:result['sync_total_bytes']=aggregate
    else:raise BlochAIError('Qentl.ai returned an invalid storage limit.')
    if type(data.get('paged_sync_snapshots')) is not bool:raise BlochAIError('Qentl.ai returned an invalid paging policy.')
    result['paged_sync_snapshots']=data['paged_sync_snapshots']
    if result['sync_total_bytes'] is None and not result['paged_sync_snapshots']:
        raise BlochAIError('Large remote folders require paged transfers.')
    return result


class RemoteConflict(BlochAIError):
    def __init__(self,paths=(),message='Files changed on both sides. Review them before synchronizing again.'):
        self.paths=list(paths)
        super().__init__(message+(' Conflicts: '+', '.join(self.paths[:20]) if self.paths else ''))


def project_id(value):
    if not isinstance(value,str) or not PROJECT.fullmatch(value) or value.startswith('shared-'):
        raise BlochAIError('Choose an owned project ID from qentl projects list --remote.')
    return value


def relative_path(value):
    # Reuse the same portable-path and depth rules as explicit folder imports.
    normalized=_path('project/'+value if isinstance(value,str) else value)
    return normalized[len('project/'):]


def local_hash(file):
    """Bound the second read too: editors may change a file during download."""
    try:
        fd=os.open(file,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0))
    except FileNotFoundError:return None
    except OSError as exc:raise RemoteConflict([file.name],'A local file changed during download. Nothing was written.') from exc
    with os.fdopen(fd,'rb') as stream:
        info=os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_size>MAX_FILE_BYTES:
            raise RemoteConflict([file.name],'A local file changed during download. Nothing was written.')
        raw=stream.read(MAX_FILE_BYTES+1)
    if len(raw)>MAX_FILE_BYTES:raise RemoteConflict([file.name],'A local file grew during download. Nothing was written.')
    return hashlib.sha256(raw).hexdigest()


class RemoteSession:
    def __init__(self,*,transport=None):
        self.secrets=(saved_token(),);self.identity=None;self.owner=None
        self.http=httpx.Client(base_url=ORIGIN,follow_redirects=False,trust_env=False,timeout=60,transport=transport,
                               headers={'Origin':ORIGIN,'X-BlochAI-Action':'1'})
        try:
            data=self.request('POST','/api/cli/session',{'qentl_token':self.secrets[0]})
            self.owner=identity_owner(data)
            cookie=next((item for item in self.http.cookies.jar if item.name==COOKIE and item.domain=='qentl.ai'
                         and not item.domain_specified and item.path=='/' and item.secure),None)
            if cookie is None or not re.fullmatch(r'[A-Za-z0-9_-]{16,256}',cookie.value):
                raise BlochAIError('Qentl.ai did not establish a secure terminal session.')
            self.secrets+=(cookie.value,);self.identity=data
        except Exception:
            self.http.close();raise

    def __enter__(self):return self
    def __exit__(self,*args):self.close()

    def close(self):
        if self.http.is_closed:return
        try:
            if self.identity:self.request('POST','/api/cli/disconnect',{})
        except BlochAIError:pass
        finally:self.http.close()

    def request(self,method,path,body=None,*,params=None):
        if method not in ('GET','POST') or not isinstance(path,str) or not path.startswith('/api/') or any(c in path for c in ('\\','\r','\n','#','?')):
            raise BlochAIError('Invalid Qentl.ai API request.')
        if params is not None and (method!='GET' or not re.fullmatch(r'/api/projects/[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}/syncs/[a-f0-9]{16}/snapshot',path)
                or not isinstance(params,dict) or set(params)!={'offset','limit','revision'}
                or type(params['offset']) is not int or not 0<=params['offset']<=10000
                or type(params['limit']) is not int or not 1<=params['limit']<=500
                or not isinstance(params['revision'],str) or not HEX64.fullmatch(params['revision'])):
            raise BlochAIError('Invalid Qentl.ai snapshot page request.')
        try:
            with self.http.stream(method,path,json=body if method=='POST' else None,params=params) as response:
                raw=bytearray()
                for chunk in response.iter_bytes():
                    if len(raw)+len(chunk)>MAX_RESPONSE:raise BlochAIError('Qentl.ai returned a response larger than the transfer limit.')
                    raw.extend(chunk)
                if 300<=response.status_code<400:raise BlochAIError('Qentl.ai redirected the request; credentials were not forwarded.')
                try:data=json.loads(raw)
                except (ValueError,UnicodeError) as exc:raise BlochAIError('Qentl.ai returned an invalid response.') from exc
                if not isinstance(data,dict):raise BlochAIError('Qentl.ai returned an invalid response.')
                if response.status_code==409:
                    raise RemoteConflict([scrub(str(row.get('path',''))[:180],self.secrets) for row in data.get('conflicts',[]) if isinstance(row,dict)],
                                         scrub(str(data.get('error') or data.get('detail') or 'Remote revision changed. Fetch and reconcile before retrying.'),self.secrets))
                if response.status_code in (401,403):raise BlochAIError('Qentl.ai rejected this session or project permission. Check the Qentl account workspace.')
                if response.status_code>=400:
                    message=data.get('error') or data.get('detail') or 'Request failed.'
                    raise RemoteHTTPError(response.status_code,f'Qentl.ai HTTP {response.status_code}: '+scrub(str(message)[:2000],self.secrets))
                return data
        except httpx.HTTPError as exc:
            raise BlochAIError('The Qentl.ai request could not be confirmed. Check its current state before repeating a write or starting another task.') from exc

    def projects(self):return self.request('GET','/api/projects')

    def ingest_policy(self):
        try:return transfer_policy(self.request('GET','/api/ingest-policy'))
        except RemoteHTTPError as exc:
            if exc.status==404:return dict(STANDARD_INGEST)
            raise

    def create(self,name,description='',kind='code'):
        return self.request('POST','/api/projects',{'name':name,'description':description,'kind':kind})

    def scope(self,project):return self.request('GET',f'/api/projects/{project_id(project)}/closed-scope')

    def submit(self,project,task,agent='coder',requirement=None,scope_revision=None,model=None,continuation=False,reference_context=None):
        project=project_id(project)
        if agent not in ('auto','chat','coder','analyst','publisher'):
            raise BlochAIError('Remote runs support auto, chat, coder, analyst and publisher agents.')
        data={'project':project,'mode':agent,'model':model,'scope_mode':'project','scope_nodes':[]}
        if reference_context is not None:
            from .interactive import validate_reference_context
            data['reference_context']=validate_reference_context(reference_context)
        if continuation:
            scope=self.scope(project);next_id=(scope.get('progress') or {}).get('next_requirement_id')
            if scope.get('state')!='approved' or not next_id:raise BlochAIError('There is no next pending requirement in an approved remote scope.')
            if requirement and requirement!=next_id:raise BlochAIError('Continue must use the next pending approved requirement.')
            requirement=next_id;data['continuation']=True
        else:data['prompt']=task
        if agent=='coder' or (agent!='publisher' and (requirement or scope_revision)):
            scope=self.scope(project)
            if scope.get('state')!='approved':raise BlochAIError('Approve the current Markdown scope on qentl.ai before starting remote development.')
            if scope_revision and scope_revision!=scope.get('revision'):raise BlochAIError('The approved remote scope revision changed. Review it before starting this task.')
            if not requirement or requirement not in {row['id'] for row in (scope.get('contract') or {}).get('requirements',[])}:
                raise BlochAIError('Select --requirement from the approved remote Markdown scope.')
            data.update(requirement_id=requirement,scope_revision=scope['revision'])
        result=self.request('POST','/api/jobs',data)
        if not HEX16.fullmatch(str(result.get('id',''))):raise BlochAIError('The remote task response is invalid. Inspect the project before submitting again.')
        return result

    def artifact_document(self,identifier,project,receipt):
        from .document_exports import MAX_DOCUMENT_BYTES,receipt_name,verified_document
        if not isinstance(identifier,str) or not HEX16.fullmatch(identifier):raise BlochAIError('Invalid remote task ID.')
        project=project_id(project);receipt_name(receipt)
        if type(receipt.get('id')) is not int or not 0<=receipt['id']<100:raise BlochAIError('Invalid remote document ID.')
        current=self.request('GET','/api/jobs/'+identifier)
        if current.get('project')!=project or current.get('id')!=identifier:raise BlochAIError('The document belongs to another project.')
        actual=next((row for row in current.get('artifacts',[]) if row.get('id')==receipt['id']),None)
        if actual!=receipt or not receipt['path'].startswith('artifacts/'+identifier+'/'):
            raise BlochAIError('The remote document receipt changed. Refresh the task before exporting.')
        try:
            with self.http.stream('GET',f"/api/jobs/{identifier}/artifacts/{receipt['id']}") as response:
                if response.status_code!=200:raise BlochAIError('The remote generated document is unavailable; nothing was exported.')
                raw=bytearray()
                for chunk in response.iter_bytes():
                    if len(raw)+len(chunk)>MAX_DOCUMENT_BYTES:raise BlochAIError('The generated document exceeds the export size limit.')
                    raw.extend(chunk)
            return verified_document(receipt,bytes(raw))
        except httpx.HTTPError as exc:raise BlochAIError('Document download failed; no Downloads file was created.') from exc

    def cancel(self,identifier):
        if not isinstance(identifier,str) or not HEX16.fullmatch(identifier):raise BlochAIError('Invalid remote job ID.')
        return self.request('POST',f'/api/jobs/{identifier}/cancel',{})

    def follow(self,identifier,project,approve,notify=lambda _row:None,*,interval=2,sleep=time.sleep):
        if not isinstance(identifier,str) or not HEX16.fullmatch(identifier):raise BlochAIError('Invalid remote job ID.')
        project=project_id(project);answered=set();last=None
        while True:
            data=self.request('GET','/api/jobs/'+identifier)
            if data.get('id')!=identifier or data.get('project')!=project:raise BlochAIError('Remote job does not belong to the selected project.')
            signature=(data.get('status'),len(data.get('events',[])),data.get('summary'))
            if signature!=last:
                notify(scrub({'id':identifier,'project':project,'status':data.get('status'),'summary':data.get('summary',''),
                              'events':data.get('events',[])[-3:]},self.secrets));last=signature
            if data.get('status') not in ('RUNNING','AWAITING_APPROVAL'):return scrub(data,self.secrets)
            pending=data.get('approval')
            if pending and pending.get('id') not in answered:
                # Display only this project's authoritative pending action. A
                # terminal acknowledgement never approves other or future IDs.
                allowed=approve(scrub(str(pending.get('action','action')),self.secrets),scrub(str(pending.get('preview','')),self.secrets))
                self.request('POST',f'/api/jobs/{identifier}/approval',{'id':pending['id'],'allow':bool(allowed)})
                answered.add(pending['id'])
            sleep(interval)


def scan_folder(root,secrets=(),*,policy=None,retain_content=True):
    policy=policy or STANDARD_INGEST
    max_files=policy['max_source_files'];max_total=policy['sync_total_bytes'];max_entries=max(10000,max_files*6)
    root=Path(root)
    if root.is_symlink() or not root.is_dir():raise BlochAIError('Select an existing local directory, not a symbolic link.')
    if _skip_reason([root.name,'file.py'],0):raise BlochAIError('Select a project directory, not a protected configuration or credential folder.')
    root=root.resolve();workspace=Workspace(root,lambda *_:False,allow_commands=False)
    files={};skipped=[];seen={};total=0;visited=0
    def walk(folder):
        nonlocal total,visited
        entries=[]
        for entry in folder.iterdir():
            if len(entries)+visited>=max_entries:raise BlochAIError('The selected folder contains too many entries. Select a smaller project directory.')
            entries.append(entry)
        for entry in sorted(entries,key=lambda item:item.name):
            visited+=1
            if visited>max_entries:raise BlochAIError('The selected folder contains too many entries. Select a smaller project directory.')
            relative=entry.relative_to(root).as_posix()
            try:path=relative_path(relative)
            except BlochAIError:
                skipped.append({'path':relative,'reason':'unsupported_path'});continue
            parts=['project']+path.split('/')
            if entry.is_symlink():skipped.append({'path':path,'reason':'symbolic_link'});continue
            if entry.is_dir():
                reason=_skip_reason(parts+['file.py'],0)
                if reason:skipped.append({'path':path,'reason':reason});continue
                walk(entry);continue
            try:
                info=entry.stat()
                reason=_skip_reason(parts,info.st_size)
                if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:reason='unsupported_link_or_type'
                if reason:skipped.append({'path':path,'reason':reason});continue
                checked=workspace.path(relative)
                fd=os.open(checked,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0))
                with os.fdopen(fd,'rb') as stream:
                    opened=os.fstat(stream.fileno())
                    if not stat.S_ISREG(opened.st_mode) or opened.st_nlink!=1 or (info.st_dev,info.st_ino)!=(opened.st_dev,opened.st_ino):
                        raise BlochAIError('A selected file changed while being read. No files were transferred.')
                    raw=stream.read(MAX_FILE_BYTES+1)
                if len(raw)>MAX_FILE_BYTES:skipped.append({'path':path,'reason':'file_too_large'});continue
                after=checked.stat()
                if (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):
                    raise BlochAIError('A selected file changed while being read. Retry after the editor has saved it.')
                text=raw.decode('utf-8')
                if any(ord(char)<32 and char not in '\t\r\n' for char in text):raise UnicodeError()
            except UnicodeError:skipped.append({'path':path,'reason':'binary_or_invalid_utf8'});continue
            except OSError as exc:raise BlochAIError('A selected file could not be read safely. No files were transferred.') from exc
            if _CREDENTIAL.search(text) or scrub(text,secrets)!=text:
                skipped.append({'path':path,'reason':'credential_content'});continue
            for index in range(1,len(parts)):
                node='/'.join(parts[1:index+1]);folded=node.casefold();kind='file' if index==len(parts)-1 else 'directory'
                if folded in seen and seen[folded]!=(node,kind):raise BlochAIError('Selected paths collide after portable filename normalization.')
                seen[folded]=(node,kind)
            if path in files:raise BlochAIError('Selected paths collide after Unicode normalization.')
            files[path]={'path':path,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'local_path':checked}
            if retain_content:files[path]['raw']=raw
            total+=len(raw)
            if len(files)>max_files or (max_total is not None and total>max_total):
                raise BlochAIError(f'The selected folder exceeds the active storage policy ({max_files} eligible files'+(f', {max_total} bytes in total' if max_total is not None else '')+').')
    walk(root)
    return files,skipped


class FolderSync:
    def __init__(self,session,project,root):
        self.session=session;self.project=project_id(project);selected=Path(root).expanduser()
        if selected.is_symlink() or not selected.is_dir():raise BlochAIError('Choose an existing directory explicitly with --workspace.')
        self.root=selected.resolve();self.workspace=Workspace(self.root,lambda *_:True,allow_commands=False)
        info=self.root.stat();self.generation=(info.st_dev,info.st_ino)
        key=hashlib.sha256((self.project+'\0'+str(self.root)).encode()).hexdigest()
        self.path=state_home()/'remote-projects'/session.owner/(key+'.json')
        self.base=f'/api/projects/{self.project}/syncs';self.manifest=self._load();self.policy=dict(STANDARD_INGEST);self._last_batch_at=None

    def _load(self):
        if not self.path.exists():return None
        if not is_private(self.path) or self.path.stat().st_size>16*1024*1024:raise BlochAIError('The local synchronization record must be a private regular file.')
        try:data=json.loads(self.path.read_text(encoding='utf-8'))
        except (OSError,ValueError) as exc:raise BlochAIError('The local synchronization record is invalid.') from exc
        if (not isinstance(data,dict) or data.get('schema')!='qentl-folder-sync-v1' or data.get('origin')!=ORIGIN or data.get('owner')!=self.session.owner
                or data.get('project')!=self.project or data.get('workspace')!=str(self.root)
                or not HEX16.fullmatch(str(data.get('id',''))) or not isinstance(data.get('files'),dict) or len(data['files'])>10000
                or any(relative_path(path)!=path or not HEX64.fullmatch(str(digest)) for path,digest in data['files'].items())):
            raise BlochAIError('The synchronization record does not match this account, project and selected directory.')
        return data

    def _guard(self):
        try:info=self.root.stat()
        except OSError as exc:raise BlochAIError('The selected directory is no longer available.') from exc
        if self.root.is_symlink() or (info.st_dev,info.st_ino)!=self.generation:
            raise BlochAIError('The selected directory was replaced. Start a new synchronization command.')

    def _snapshot(self,data):
        if not isinstance(data,dict) or not HEX16.fullmatch(str(data.get('id',''))) or not HEX64.fullmatch(str(data.get('revision',''))):
            raise BlochAIError('The remote folder snapshot is invalid.')
        if self.manifest and data['id']!=self.manifest['id']:raise BlochAIError('The remote synchronization binding changed.')
        rows=data.get('files');total=0;seen={}
        if not isinstance(rows,list) or len(rows)>self.policy['max_source_files']:raise BlochAIError('The remote folder exceeds its file limit.')
        for row in rows:
            if (not isinstance(row,dict) or relative_path(row.get('path'))!=row.get('path')
                    or not HEX64.fullmatch(str(row.get('sha256',''))) or type(row.get('bytes')) is not int or not 0<=row['bytes']<=MAX_FILE_BYTES):
                raise BlochAIError('The remote folder contains an invalid file entry.')
            path=row['path']
            parts=path.split('/')
            for length in range(1,len(parts)+1):
                prefix='/'.join(parts[:length]);kind='file' if length==len(parts) else 'directory';key=prefix.casefold()
                if key in seen and (seen[key]!=(prefix,kind) or kind=='file'):raise BlochAIError('Remote filenames collide on this computer.')
                seen[key]=(prefix,kind)
            total+=row['bytes']
        if self.policy['sync_total_bytes'] is not None and total>self.policy['sync_total_bytes']:
            raise BlochAIError('The remote folder exceeds the active storage limit.')
        return data

    def _save(self,snapshot,hashes):
        self._guard()
        self.manifest={'schema':'qentl-folder-sync-v1','origin':ORIGIN,'owner':self.session.owner,'project':self.project,
                       'workspace':str(self.root),'id':snapshot['id'],'remote_root':snapshot.get('root'),
                       'revision':snapshot['revision'],'files':hashes,'updated_at':time.time()}
        save_json(self.path,self.manifest)

    def _upload_row(self,row):
        """Re-read only the current batch; never retain a whole large project."""
        self._guard();file=self.workspace.path(row['path'])
        try:
            fd=os.open(file,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0))
            with os.fdopen(fd,'rb') as stream:
                info=os.fstat(stream.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_size>MAX_FILE_BYTES:
                    raise BlochAIError('A local source file changed after synchronization preview.')
                raw=stream.read(MAX_FILE_BYTES+1)
        except OSError as exc:raise BlochAIError('A local source file is no longer safely readable.') from exc
        if len(raw)!=row['bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:
            raise RemoteConflict([row['path']],'A local file changed after synchronization preview.')
        return {'path':row['path'],'base_sha256':row['base_sha256'],'content_base64':base64.b64encode(raw).decode('ascii')}

    def _pages(self,snapshot):
        endpoint=self.base+'/'+snapshot['id']+'/snapshot'
        if not self.policy['paged_sync_snapshots']:
            page=self._snapshot(self.session.request('GET',endpoint))
            if page['revision']!=snapshot['revision'] or [(r['path'],r['sha256'],r['bytes']) for r in page['files']]!=[(r['path'],r['sha256'],r['bytes']) for r in snapshot['files']]:
                raise RemoteConflict(message='Remote files changed during download. Nothing was written locally.')
            yield page['files'];return
        offset=0;total=len(snapshot['files'])
        while offset<total:
            page=self._snapshot(self.session.request('GET',endpoint,params={'offset':offset,'limit':self.policy['batch_files'],'revision':snapshot['revision']}))
            rows=page['files'];end=offset+len(rows)
            if (page['revision']!=snapshot['revision'] or page.get('root')!=snapshot.get('root')
                    or type(page.get('offset')) is not int or page['offset']!=offset
                    or type(page.get('total_files')) is not int or page['total_files']!=total
                    or not rows or len(rows)>self.policy['batch_files'] or end>total
                    or sum(r['bytes'] for r in rows)>self.policy['batch_decoded_bytes']
                    or (end==total and page.get('next_offset') is not None)
                    or (end<total and (type(page.get('next_offset')) is not int or page['next_offset']!=end))
                    or [(r['path'],r['sha256'],r['bytes']) for r in rows]!=[(r['path'],r['sha256'],r['bytes']) for r in snapshot['files'][offset:end]]):
                raise RemoteConflict(message='The remote snapshot page changed or is incomplete. Nothing was written locally.')
            yield rows;offset=end

    def _pull(self,snapshot,changes,local,baseline,skipped,notify):
        wanted={row['path']:row for row in changes};prepared=[];downloaded=0
        # Private staging is outside the chosen project and removed on every
        # exit. A failed later page must never partially change local files.
        with tempfile.TemporaryDirectory(prefix='qentl-pull-') as temporary:
            staging=Path(temporary)
            for rows in self._pages(snapshot):
                for row in rows:
                    if row['path'] not in wanted:continue
                    encoded=row.get('content_base64')
                    if not isinstance(encoded,str) or len(encoded)>4*((MAX_FILE_BYTES+2)//3):
                        raise BlochAIError('The remote file encoding exceeds its limit. No local files were changed.')
                    try:raw=base64.b64decode(encoded,validate=True);text=raw.decode('utf-8')
                    except (ValueError,UnicodeError) as exc:raise BlochAIError('The remote file encoding is invalid. No local files were changed.') from exc
                    if base64.b64encode(raw).decode('ascii')!=encoded or len(raw)!=row['bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:
                        raise BlochAIError('The remote content did not match its revision. No local files were changed.')
                    if any(ord(char)<32 and char not in '\t\r\n' for char in text) or _CREDENTIAL.search(text) or scrub(text,self.session.secrets)!=text:
                        skipped.append({'path':row['path'],'reason':'protected_or_binary_content'});continue
                    stored=staging/str(len(prepared))
                    try:stored.write_bytes(raw)
                    except OSError as exc:raise BlochAIError('Local download staging failed. No project files were changed; check free disk space before retrying.') from exc
                    prepared.append((row['path'],stored,row['sha256']))
                downloaded+=len(rows)
                notify({'downloaded_files':downloaded,'total_files':len(snapshot['files']),'local_files_written':0})
            with project_write_lock(self.root):
                self._guard()
                for path,stored,digest in prepared:
                    file=self.workspace.path(path);expected=local.get(path,{}).get('sha256')
                    if local_hash(file)!=expected:raise RemoteConflict([path],'A local file changed during download. Nothing was written.')
                try:
                    for path,stored,digest in prepared:
                        file=self.workspace.path(path);file.parent.mkdir(parents=True,exist_ok=True);self.workspace.path(path)
                        mode=stat.S_IMODE(file.stat().st_mode) if file.exists() else 0o600
                        fd,temporary_file=tempfile.mkstemp(prefix='.qentl-sync-',dir=file.parent)
                        try:
                            with os.fdopen(fd,'wb') as stream:stream.write(stored.read_bytes())
                            os.chmod(temporary_file,mode);os.replace(temporary_file,file)
                        finally:
                            if os.path.exists(temporary_file):os.unlink(temporary_file)
                        baseline[path]=digest
                except OSError as exc:
                    self._save(snapshot,baseline)
                    raise BlochAIError('Local publication stopped after a filesystem error. Some files may already have been updated; inspect the folder before retrying.') from exc
        return [{'path':path} for path,_,_ in prepared]

    def once(self,*,pull=False,dry_run=False,notify=lambda _row:None):
        self._guard();self.policy=self.session.ingest_policy()
        local,skipped=scan_folder(self.root,self.session.secrets,policy=self.policy,retain_content=False)
        if self.manifest:
            snapshot=self._snapshot(self.session.request('GET',self.base+'/'+self.manifest['id']))
        else:
            if pull:raise BlochAIError('Push this selected directory once to create its remote binding before using --pull.')
            if dry_run:return {'direction':'push','dry_run':True,'new_binding':True,'changes':[{'path':p,'bytes':row['bytes']} for p,row in local.items()],'skipped':skipped}
            snapshot=self._snapshot(self.session.request('POST',self.base,{'name':self.root.name}))
            self._save(snapshot,{})
        remote={row['path']:row for row in snapshot['files']};baseline=dict(self.manifest['files']);conflicts=[];changes=[]
        if pull:
            for path,row in remote.items():
                reason=_skip_reason(['project']+path.split('/'),row['bytes'])
                if reason:skipped.append({'path':path,'reason':reason});continue
                local_row=local.get(path);file=self.workspace.path(path)
                if local_row and local_row['sha256']==row['sha256']:baseline[path]=row['sha256'];continue
                if file.exists() and (not local_row or local_row['sha256']!=baseline.get(path)):
                    conflicts.append(path);continue
                changes.append(row)
        else:
            for path,row in local.items():
                current=remote.get(path,{}).get('sha256')
                if current==row['sha256']:baseline[path]=current;continue
                if current!=baseline.get(path):conflicts.append(path);continue
                changes.append({**row,'base_sha256':current})
        if conflicts:raise RemoteConflict(conflicts)
        report={'direction':'pull' if pull else 'push','dry_run':dry_run,'id':snapshot['id'],'remote_root':snapshot.get('root'),
                'changes':[{'path':row['path']} for row in changes],'skipped':skipped,'deletions':False,'confirmed_batches':0}
        if dry_run:return report
        if changes and not pull:
            pending=[];batch_bytes=0;batches=[]
            for row in changes:
                if pending and (len(pending)>=self.policy['batch_files'] or batch_bytes+row['bytes']>self.policy['batch_decoded_bytes']):
                    batches.append(pending);pending=[];batch_bytes=0
                if row['bytes']>self.policy['batch_decoded_bytes']:raise BlochAIError('A source file exceeds the advertised transfer batch size.')
                pending.append(row);batch_bytes+=row['bytes']
            if pending:batches.append(pending)
            acknowledged=[]
            try:
                for batch in batches:
                    payload=[self._upload_row(row) for row in batch]
                    if self._last_batch_at is not None:
                        remaining=BATCH_WRITE_INTERVAL-(time.monotonic()-self._last_batch_at)
                        if remaining>0:time.sleep(remaining)
                    self._guard();self._last_batch_at=time.monotonic()
                    result=self._snapshot(self.session.request('POST',self.base+'/'+snapshot['id']+'/changes',{'expected_revision':snapshot['revision'],'files':payload}))
                    actual={row['path']:row for row in result['files']};accepted=[]
                    for row in batch:
                        if actual.get(row['path'],{}).get('sha256')==row['sha256']:
                            baseline[row['path']]=row['sha256'];accepted.append({'path':row['path']})
                    snapshot=result;report['skipped']+=result.get('skipped',[])
                    self._save(snapshot,baseline);acknowledged.extend(accepted);report['confirmed_batches']+=1
                    notify({'confirmed_files':len(acknowledged),'total_files':len(changes),'confirmed_batches':report['confirmed_batches'],'total_batches':len(batches)})
            except (BlochAIError,OSError) as original:
                exc=original if isinstance(original,BlochAIError) else BlochAIError('The local synchronization record could not be saved safely.')
                exc.confirmed_files=len(acknowledged);exc.confirmed_batches=report['confirmed_batches']
                exc.args=(str(exc)+f' Confirmed before this interruption: {len(acknowledged)} files in {report["confirmed_batches"]} batches. The last unconfirmed batch may have reached the server; synchronize again to reconcile hashes.',)
                if exc is original:raise
                raise exc from original
            report['changes']=acknowledged
        elif changes:
            report['changes']=self._pull(snapshot,changes,local,baseline,skipped,notify)
        self._save(snapshot,baseline)
        return report
