"""A fixed investigation/review sequence on top of the bounded agent engine."""
from .agents import AgentRunner, system_prompt
from .config import BlochAIError
from .store import now


def investigate(provider,workspace,question,store=None,notify=None,max_steps=24):
    """Measure separate analysis and skeptical review; do not hide unfinished stages."""
    if not 8<=max_steps<=48:
        raise BlochAIError("An analysis uses 8..48 steps shared between investigation and review.")
    runner=AgentRunner(provider,workspace,store,notify)
    # Two independent prompts force a review even when the first model chooses
    # not to delegate. The review receives actual observations, not only claims.
    investigation=runner.run("Investigate this question. State a plan, inspect evidence with tools, compare plausible explanations, and identify missing data. Question: "+question,
                             "analyst",max_steps-6)
    if investigation["status"]!="COMPLETED":
        return investigation
    observations=[]
    for event in investigation["events"]:
        result=event.get("result",{})
        if event.get("action") in ("read_file","read_source","inspect_table"):
            observations.append(str(result)[:16000])
    evidence="\n".join(observations[-6:])
    contract=system_prompt('reviewer',allow_commands=getattr(workspace,'allow_commands',True))
    header="Critically review the investigation using the recorded observations and project files. Identify unsupported claims, uncertain data and numerical errors. Do not assume that the conclusion is correct."
    base=[{'role':'system','content':contract},{'role':'user','content':header}]
    available=(provider.context_budget(base) if callable(getattr(provider,'context_budget',None))
               else provider.prompt_limit-len(contract)-len(header))-800
    if available<300:raise BlochAIError('The selected model has insufficient context for an independent review.')
    available=min(60000,available)
    def excerpt(text,budget):
        return text if len(text)<=budget else text[:max(0,budget-24)]+'\n[Excerpt shortened.]'
    review_prompt=header+'\nOriginal question: '+excerpt(question,available//3)
    review_prompt+='\nInvestigation: '+excerpt(investigation['summary'],available//3)
    review_prompt+='\nObserved evidence: '+excerpt(evidence,available//3)
    review=runner.run(review_prompt,"reviewer",6)
    investigation["analysis_review"]={"run_id":review["id"],"status":review["status"],"summary":review["summary"],"at":now()}
    investigation["summary"]+="\n\nCritical review ("+review["status"]+"):\n"+review["summary"]
    if review["status"]!="COMPLETED": investigation["status"]="PAUSED"
    runner.store.save(investigation)
    return investigation
