"""Reviewed references and explicit public URL reading through the egress policy."""
from __future__ import annotations

import json
import re
from pathlib import Path

from .config import BlochAIError
from urllib.parse import urlsplit, urlunsplit


def catalog():
    return json.loads((Path(__file__).parent/"sources.json").read_text(encoding="utf-8"))


def sources(query):
    if not isinstance(query,str) or not 1<=len(query)<=200:
        raise BlochAIError("Use a source query of 1..200 characters.")
    words=set(re.findall(r"\w+",query.lower()))
    items=catalog()["references"]
    ranked=sorted(items,key=lambda item:len(words & set(re.findall(r"\w+",(item["title"]+" "+item["topics"]).lower()))),reverse=True)
    return {"scope":"Reviewed primary-source catalog; not an exhaustive internet search.","sources":ranked}


def source_record(source_id):
    source=next((item for item in catalog()['references'] if item['id']==source_id),None)
    if source is None:raise BlochAIError('Choose a source_id returned by sources.')
    return source


def source_url(source_id):
    # Only operator-reviewed catalog entries lose their version query here.
    parsed=urlsplit(source_record(source_id)['url'])
    from .safe_web import validate_url
    return validate_url(urlunsplit((parsed.scheme,parsed.netloc,parsed.path,'','')))


def requested_urls(text):
    """Extract grants only from the direct user's prompt, never tool/page data."""
    from .safe_web import validate_url
    direct=[];fence=None
    for line in text.splitlines():
        stripped=line.lstrip()
        if stripped.startswith(('```','~~~')):
            marker=stripped[:3]
            if fence is None:fence=marker
            elif marker==fence:fence=None
            continue
        if fence or stripped.startswith('>'):continue
        direct.append(line)
    text='\n'.join(direct)
    text=re.sub(r'`[^`]*`|"[^"\n]*"', '', text)
    from .task_routing import positive_text
    text=positive_text(text)
    urls=[]
    for match in re.finditer(r'https://[^\s<>"\x00-\x1f]+',text):
        candidate=match.group().rstrip('.,;:!?)]}')
        try:url=validate_url(candidate,explicit_url=True)
        except BlochAIError:continue
        if url not in urls:urls.append(url)
        if len(urls)>=16:break
    return tuple(urls)


def read_web(url, *, explicit_url=False):
    from .safe_web import read_url
    return read_url(url, explicit_url=explicit_url)


def read_source(source_id):
    source=source_record(source_id)
    result=read_web(source_url(source_id))
    return {**result,'source_id':source_id,'editorial_note':source['note'],
            'excerpt':result['text'],'excerpt_scope':'Bounded public-page excerpt; do not infer unread content.'}
