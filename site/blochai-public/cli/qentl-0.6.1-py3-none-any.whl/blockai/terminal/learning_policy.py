"""Executable admission rules for a small, owner-reviewed coding curriculum.

This policy authorizes these synthetic exercises only. It does not classify
arbitrary code as ethical or authorize private data, external tasks, execution,
model deployment or expansion of the reviewed curriculum.
"""
from __future__ import annotations

import hashlib
import json

from .config import BlochAIError
from .curriculum import SYSTEM, digest, evaluate_code

POLICY_ID = "qentl-reviewed-coding-feedback-v1"
GENERATOR = "qentl-feedback-v1"
FAMILIES = ("sum", "length", "sort")
MAX_ANSWER_BYTES = 8192


def _deny():
    raise BlochAIError("Coding feedback violates the reviewed synthetic learning policy.")


def _families(families):
    if (type(families) not in (list, tuple) or not 1 <= len(families) <= 3
            or any(type(value) is not str or value not in FAMILIES for value in families)
            or len(set(families)) != len(families)):
        _deny()
    return list(families)


def _round(round_id):
    if type(round_id) is not int or not 0 <= round_id < 10_000_000_000:
        _deny()
    return round_id


def approved_feedback_tasks(round_id, families):
    """Return reproducible reviewed tasks; no caller-supplied prompt is accepted."""
    round_id = _round(round_id)
    selected = _families(families)
    tasks = []
    for family in selected:
        seed = hashlib.sha256(f"{POLICY_ID}:{round_id}:{family}".encode()).digest()
        offset = int.from_bytes(seed[:2], "big") % 21 - 10
        shift = int.from_bytes(seed[2:4], "big") % 19 + 2
        visible_inputs = [[], [1, -3, 7], [5, 5]]
        confirmation_inputs = [[shift, -shift, 2], [-shift, -1], [shift, 0, shift, -3]]
        if family == "sum":
            requirement = f"Return the sum of the numbers in list x, then add {offset}."
            expression = f"sum(x) + ({offset})"
            expected = lambda values: sum(values) + offset
        elif family == "length":
            requirement = f"Return the number of elements in list x, then add {offset}."
            expression = f"len(x) + ({offset})"
            expected = lambda values: len(values) + offset
        else:
            requirement = "Return the numbers in list x sorted in ascending order, preserving duplicate values."
            expression = "sorted(x)"
            expected = sorted
        task = {"policy_id": POLICY_ID, "round_id": round_id, "family": family,
                "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": requirement}],
                "visible_cases": [[values, expected(values)] for values in visible_inputs],
                "confirmation_cases": [[values, expected(values)] for values in confirmation_inputs],
                "reference_answer": f"def solve(x):\n    return {expression}\n"}
        task["id"] = digest(task)
        tasks.append(task)
    return tasks


def _plain_json(value):
    """Reject objects and excessive containers before equality/serialization."""
    count = [0]

    def visit(item, depth=0):
        count[0] += 1
        if count[0] > 4096 or depth > 12:
            _deny()
        if type(item) in (str, int, bool, type(None)):
            if type(item) is str and (len(item) > 16_384 or len(item.encode("utf-8")) > 32_768):
                _deny()
            if type(item) is int and abs(item) > 10_000_000_000:
                _deny()
            return
        if type(item) is list:
            if len(item) > 256:
                _deny()
            for child in item:
                visit(child, depth + 1)
            return
        if type(item) is dict:
            if len(item) > 32 or any(type(key) is not str for key in item):
                _deny()
            for key, child in item.items():
                visit(key, depth + 1)
                visit(child, depth + 1)
            return
        _deny()

    try:
        visit(value)
        if len(json.dumps(value, ensure_ascii=False).encode("utf-8")) > 65_536:
            _deny()
    except (UnicodeError, RecursionError, ValueError, OverflowError) as exc:
        raise BlochAIError("Coding feedback contains invalid bounded data.") from exc


def require_feedback_policy(families, tasks=None):
    """Fail closed on any unreviewed task; task equality includes private tests."""
    selected = _families(families)
    if tasks is not None:
        _plain_json(tasks)
        if type(tasks) is not list or len(tasks) != len(selected):
            _deny()
        for family, task in zip(selected, tasks):
            if type(task) is not dict:
                _deny()
            expected = approved_feedback_tasks(task.get("round_id"), [family])[0]
            if task != expected:
                _deny()
        if len({task["round_id"] for task in tasks}) != 1:
            _deny()
    return {"policy_id": POLICY_ID, "families": selected, "synthetic_only": True,
            "external_prompts_allowed": False, "private_user_data_allowed": False,
            "arbitrary_code_execution_allowed": False, "automatic_promotion_allowed": False,
            "max_tasks": 3, "max_revisions_per_task": 2}


def validate_feedback_row(row):
    """Reconstruct source task and verify code/results, not self-reported flags."""
    _plain_json(row)
    if type(row) is not dict or set(row) != {"id", "family", "messages", "answer", "provenance"}:
        _deny()
    family = row.get("family")
    if type(family) is not str or family not in {"authored:" + name for name in FAMILIES}:
        _deny()
    provenance = row.get("provenance")
    if type(provenance) is not dict:
        _deny()
    task = approved_feedback_tasks(provenance.get("round"), [family.removeprefix("authored:")])[0]
    answer = row.get("answer")
    if type(answer) is not str or not 0 < len(answer.encode("utf-8")) <= MAX_ANSWER_BYTES:
        _deny()
    expected_provenance = {"kind": "OWNER_AUTHORED_SYNTHETIC", "license": "MIT", "generator": GENERATOR,
                           "policy_id": POLICY_ID, "round": task["round_id"], "task_id": task["id"],
                           "answer_sha256": hashlib.sha256(answer.encode("utf-8")).hexdigest(),
                           "visible_tests_passed": len(task["visible_cases"]),
                           "confirmation_tests_passed": len(task["confirmation_cases"])}
    if row["messages"] != task["messages"] or provenance != expected_provenance:
        _deny()
    if row["id"] != digest({key: value for key, value in row.items() if key != "id"}):
        _deny()
    if not all(evaluate_code(answer, task[key])["passed"] for key in ("visible_cases", "confirmation_cases")):
        _deny()
    return True
