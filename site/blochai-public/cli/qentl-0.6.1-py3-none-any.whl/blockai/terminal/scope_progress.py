"""Explicit owner acceptance, scoped to one approved Markdown revision."""
import json
import math
import time

from .closed_scope import ClosedScopeStore
from .config import BlochAIError, save_json
from .file_permissions import is_private
from .project_lock import project_write_lock


class ScopeProgressStore:
    def __init__(self,projects,project):
        self.projects,self.project=projects,project
        self.scope=ClosedScopeStore(projects,project)
        self.directory=self.scope.directory/'progress'

    def _read(self,status):
        self.scope._project()
        if self.directory.is_symlink():raise BlochAIError('Registro de progresso inválido.')
        contract=status.get('contract')
        if not contract:return []
        path=self.directory/(status['revision']+'.json')
        if not path.exists():return []
        if not is_private(path) or path.stat().st_size>24000:
            raise BlochAIError('Registro de progresso inválido.')
        try:
            data=json.loads(path.read_text(encoding='utf-8'))
        except (OSError,ValueError,RecursionError) as exc:
            raise BlochAIError('Registro de progresso inválido.') from exc
        if (not isinstance(data,dict) or data.get('schema')!='qentl-scope-progress-v1'
                or data.get('owner')!=self.projects.owner or data.get('project')!=self.project
                or data.get('revision')!=status['revision'] or not isinstance(data.get('accepted'),list)
                or len(data['accepted'])>64):
            raise BlochAIError('Registro de progresso fora do escopo deste projeto.')
        allowed={row['id'] for row in contract['requirements']};seen=set()
        for row in data['accepted']:
            if (not isinstance(row,dict) or set(row)!={'requirement_id','accepted_at','accepted_by'}
                    or not isinstance(row['requirement_id'],str) or row['requirement_id'] not in allowed
                    or row['requirement_id'] in seen or row['accepted_by']!=self.projects.owner
                    or type(row['accepted_at']) not in (int,float) or not math.isfinite(row['accepted_at'])
                    or row['accepted_at']<=0):
                raise BlochAIError('Aceite de requisito inválido.')
            seen.add(row['requirement_id'])
        return data['accepted']

    def status(self):
        current=self.scope.status()
        accepted={row['requirement_id'] for row in self._read(current)}
        requirements=(current.get('contract') or {}).get('requirements',[])
        active=current['state']=='approved'
        next_id=next((row['id'] for row in requirements if row['id'] not in accepted),None) if active else None
        return {'revision':current['revision'],
                'accepted_requirement_ids':[row['id'] for row in requirements if row['id'] in accepted],
                'next_requirement_id':next_id,
                'complete':bool(active and requirements and len(accepted)==len(requirements))}

    def accept(self,requirement_id,*,expected_revision,actor):
        if actor!=self.projects.owner:
            raise BlochAIError('Somente o proprietário pode aceitar a conclusão de um requisito.')
        with project_write_lock(self.scope.folder):
            # require() binds both the explicit requirement and the currently
            # approved revision; it never accepts a model's completion claim.
            current=self.scope.status()
            if expected_revision!=current['revision'] or current['state']!='approved':
                raise BlochAIError('O escopo mudou. Revise a versão atual antes de aceitar o requisito.')
            guard=self.scope.require(requirement_id,expected_revision)
            guard.check()
            accepted=self._read(current)
            if requirement_id not in {row['requirement_id'] for row in accepted}:
                accepted.append({'requirement_id':requirement_id,'accepted_at':time.time(),'accepted_by':actor})
                save_json(self.directory/(current['revision']+'.json'),{
                    'schema':'qentl-scope-progress-v1','owner':actor,'project':self.project,
                    'revision':current['revision'],'accepted':accepted,'training_allowed':False})
            return self.status()
