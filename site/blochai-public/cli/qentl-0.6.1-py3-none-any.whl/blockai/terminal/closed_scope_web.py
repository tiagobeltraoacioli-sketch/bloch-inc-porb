"""Owner-approved Markdown project scope, with read-only shared summaries."""
from fastapi import HTTPException, Request
from starlette.concurrency import run_in_threadpool


def public_status(status):
    result={key:status.get(key) for key in ('state','revision','version')}
    contract=status.get('contract')
    if isinstance(contract,dict):
        # Account namespaces and approval actor IDs are internal authorization
        # evidence. Team members receive the project contract, not those IDs.
        result['contract']={key:value for key,value in contract.items()
                            if key not in ('owner','actor','project','workspace','approved_by','revoked_by')}
    else:result['contract']=None
    if isinstance(status.get('reason'),str):result['reason']=status['reason'][:512]
    return result


def install_closed_scope_routes(app,session,body,projects,publish_project):
    def store(record,project):
        from .closed_scope import ClosedScopeStore
        return ClosedScopeStore(projects(record),project)

    def owner(request,write=False):
        record=session(request,write,True)
        if record.get('shared'):
            raise HTTPException(403,'Somente o proprietário pode aprovar ou revogar o escopo do projeto.')
        return record

    @app.get('/api/projects/{project}/closed-scope')
    def status(project: str,request: Request):
        from .scope_progress import ScopeProgressStore
        record=session(request,fresh=True)
        scoped=store(record,project)
        return {**public_status(scoped.status()),'sources':scoped.sources(),
                'progress':ScopeProgressStore(projects(record),project).status(),
                'can_approve':not record.get('shared') and record['identity']['organization'].get('role') in ('owner','admin','analyst')}

    @app.post('/api/projects/{project}/closed-scope/preview')
    async def preview(project: str,request: Request):
        record=await run_in_threadpool(owner,request)
        data=await body(request,16384)
        if set(data)!={'source_paths'}:
            raise HTTPException(422,'Selecione apenas as fontes Markdown do escopo.')
        def inspect():
            checked=owner(request)
            return store(checked,project).preview(data['source_paths'])
        return await publish_project(record,project,inspect)

    @app.post('/api/projects/{project}/closed-scope/approve')
    async def approve(project: str,request: Request):
        record=await run_in_threadpool(owner,request,True)
        data=await body(request,65536)
        required={'source_paths','allowed_paths','source_digests','expected_revision','confirm'}
        if not required.issubset(data) or set(data)-required-{'requirements'} or data.get('confirm') is not True:
            raise HTTPException(422,'Revise as fontes e os caminhos e confirme explicitamente a aprovação do escopo.')
        def publish():
            checked=owner(request,True)
            result=store(checked,project).approve(data['source_paths'],data['allowed_paths'],data.get('requirements'),
                source_digests=data['source_digests'],expected_revision=data['expected_revision'],actor=checked['owner'])
            return public_status(result)
        return await publish_project(record,project,publish)

    @app.post('/api/projects/{project}/closed-scope/revoke')
    async def revoke(project: str,request: Request):
        record=await run_in_threadpool(owner,request,True)
        data=await body(request,4096)
        if set(data)!={'expected_revision','confirm'} or data.get('confirm') is not True:
            raise HTTPException(422,'Confirme explicitamente a revogação da revisão atual do escopo.')
        def publish():
            checked=owner(request,True)
            return public_status(store(checked,project).revoke(expected_revision=data['expected_revision'],actor=checked['owner']))
        return await publish_project(record,project,publish)

    @app.post('/api/projects/{project}/closed-scope/requirements/{requirement_id}/accept')
    async def accept_requirement(project: str,requirement_id: str,request: Request):
        from .scope_progress import ScopeProgressStore
        record=await run_in_threadpool(owner,request,True)
        data=await body(request,4096)
        if set(data)!={'expected_revision','confirm'} or data.get('confirm') is not True:
            raise HTTPException(422,'Revise o trabalho e confirme explicitamente o aceite deste requisito.')
        def publish():
            checked=owner(request,True)
            result=ScopeProgressStore(projects(checked),project).accept(requirement_id,
                expected_revision=data['expected_revision'],actor=checked['owner'])
            return {'progress':result}
        return await publish_project(record,project,publish)
