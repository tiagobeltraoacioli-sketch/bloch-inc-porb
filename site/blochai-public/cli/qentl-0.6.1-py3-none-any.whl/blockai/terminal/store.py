"""Private resumable run records and deliberately reviewed programming examples."""
from __future__ import annotations

import datetime
import hashlib
import json
import re
import uuid
from pathlib import Path

from .config import BlochAIError, private_directory, save_json, state_home


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def scrub(value, secrets=()):
    if isinstance(value, dict):
        return {str(k):scrub(v, secrets) for k,v in value.items()}
    if isinstance(value, list):
        return [scrub(v, secrets) for v in value]
    if not isinstance(value, str):
        return value
    for secret in secrets:
        if secret:
            value = value.replace(secret, "[REDACTED]")
    value = re.sub(r"-----BEGIN [^-]*PRIVATE KEY-----.*?-----END [^-]*PRIVATE KEY-----", "[REDACTED PRIVATE KEY]", value, flags=re.S)
    value = re.sub(r"(?i)\b(authorization\s*:\s*bearer\s+)[^\s\"']+", r"\1[REDACTED]", value)
    value = re.sub(r"(?i)\b([A-Z0-9_]*(?:API_KEY|TOKEN|SECRET|PASSWORD|PASSPHRASE)\s*[=:]\s*)[^\s\"']+", r"\1[REDACTED]", value)
    return value


class RunStore:
    def __init__(self, root=None, secrets=(), training_allowed=True):
        self.root = Path(root) if root else state_home()
        self.secrets = secrets
        private_web = (state_home()/'web').resolve()
        self.training_allowed = training_allowed and self.root.resolve()!=private_web and private_web not in self.root.resolve().parents

    def path(self, run_id):
        if not re.fullmatch(r"[a-f0-9]{16}", run_id):
            raise BlochAIError("Invalid run ID.")
        return self.root / "runs" / (run_id + ".json")

    def create(self, task, workspace, agent, provider):
        record = {"schema":"blochai-agent-run-v1", "id":uuid.uuid4().hex[:16], "created_at":now(),
                  "updated_at":now(), "status":"RUNNING", "task":task, "workspace":str(workspace),
                  "agent":agent, "provider":provider, "events":[], "messages":[], "summary":"",
                  "steps":0, "review":None, "training_allowed":self.training_allowed and not (isinstance(provider,dict) and provider.get('kind')=='private')}
        self.save(record)
        return record

    def save(self, record):
        record["updated_at"] = now()
        save_json(self.path(record["id"]), scrub(record, self.secrets))

    def load(self, run_id):
        path = self.path(run_id)
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 8_000_000:
            raise BlochAIError("Run was not found or is too large.")
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise BlochAIError("Cannot read this run.") from exc
        if record.get("id") != run_id or record.get("schema") != "blochai-agent-run-v1":
            raise BlochAIError("Invalid run record.")
        return record

    def list(self):
        directory = self.root / "runs"
        if not directory.exists():
            return []
        return sorted((self.load(p.stem) for p in directory.glob("*.json")), key=lambda r:r["created_at"], reverse=True)

    def approve(self, run_id, reviewer, license_name, note):
        record = self.load(run_id)
        if not self.training_allowed or record.get('training_allowed') is False:
            raise BlochAIError('Private workspace traces cannot be approved for training.')
        if record["status"] != "COMPLETED":
            raise BlochAIError("Only a completed run can become a training example.")
        tests = [e for e in record["events"] if e.get("action")=="run_command" and e.get("result",{}).get("purpose")=="test" and not e["result"].get("denied")]
        if not tests or tests[-1]["result"].get("exit_code") != 0 or tests[-1]["result"].get("timed_out"):
            raise BlochAIError("The run needs a successful final test command before review.")
        if not reviewer.strip() or not license_name.strip() or not note.strip():
            raise BlochAIError("Record the reviewer, reuse license/permission and review note.")
        record["review"] = {"approved_at":now(), "reviewer":reviewer, "license":license_name, "note":note,
                            "trace_sha256":self.trace_digest(record)}
        self.save(record)
        return record["review"]

    @staticmethod
    def trace_digest(record):
        return hashlib.sha256(json.dumps({"task":record["task"],"messages":record["messages"],"events":record["events"],"summary":record["summary"]},sort_keys=True,ensure_ascii=False).encode()).hexdigest()

    def export(self, destination):
        if not self.training_allowed:
            raise BlochAIError('Private workspace traces cannot be exported for training.')
        records = [r for r in self.list() if r.get("review")]
        if not records:
            raise BlochAIError("There are no reviewed examples. Use blochai learn approve first.")
        destination = Path(destination)
        if destination.exists():
            raise BlochAIError("Choose a new dataset directory; exports never overwrite existing data.")
        groups, splits = {}, {"train":[], "validation":[], "test":[]}
        for record in records:
            if record.get('training_allowed') is False:
                raise BlochAIError('Private workspace traces cannot be exported for training.')
            if record["status"] != "COMPLETED" or record["review"]["trace_sha256"] != self.trace_digest(record):
                raise BlochAIError("A reviewed trace changed; review it again before export.")
            if "[REDACTED" in json.dumps(record):
                raise BlochAIError("A trace contains redacted secrets and cannot enter the dataset. Review a clean task instead.")
            group = hashlib.sha256(" ".join(record["task"].split()).lower().encode()).hexdigest()
            bucket = int(group[:8],16)%10
            split = "test" if bucket==0 else "validation" if bucket==1 else "train"
            if group in groups:
                continue
            groups[group] = split
            splits[split].append({"id":record["id"],"group_id":group,"split":split,
                                  "messages":record["messages"],"provenance":{"classification":"OPERATOR_REVIEWED_AGENT_TRACE",
                                  "provider":record["provider"],"review":record["review"],
                                  "limitations":"A successful command and human review do not prove general programming capability."}})
        private_directory(destination)
        hashes = {}
        for split, rows in splits.items():
            text = "".join(json.dumps(row,ensure_ascii=False,sort_keys=True)+"\n" for row in rows)
            path=destination/(split+".jsonl"); path.write_text(text,encoding="utf-8"); path.chmod(0o600)
            hashes[path.name]=hashlib.sha256(text.encode()).hexdigest()
        manifest={"schema":"blochai-reviewed-code-v1","created_at":now(),"counts":{k:len(v) for k,v in splits.items()},
                  "files":hashes,"split_policy":"Normalized-task SHA-256 groups; 80/10/10 buckets; duplicate task groups removed",
                  "model_weights_updated":False,"intended_use":"Private dataset preparation; separate held-out evaluation and explicit fine-tuning remain necessary."}
        save_json(destination/"manifest.json",manifest)
        return manifest
