"""Local data lifecycle for one authenticated user/organization boundary.

This is application isolation, not protection against the operating-system owner.
Host execution is unavailable. A configured private GPU service runs off-ledger.
"""
from __future__ import annotations

import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import shutil
import time
import zipfile

from .config import BlochAIError, save_json
from .workspace import Workspace, blocked


class PrivacyStore:
    def __init__(self, projects):
        self.projects = projects
        self.root = projects.state.parent

    @staticmethod
    def read(path, default=None):
        if not path.exists():
            return default
        if path.is_symlink() or not path.is_file() or path.stat().st_nlink != 1 or path.stat().st_size > 8_000_000:
            raise BlochAIError('Registro de privacidade inválido.')
        return json.loads(path.read_text(encoding='utf-8'))

    def policy(self):
        return {'history_days':30, **(self.read(self.root/'privacy.json', {}) or {})}

    def describe(self):
        return {**self.policy(), 'scope':'user_and_organization', 'training_allowed':False,
                'remote_inference_allowed':False, 'host_commands_allowed':False,
                'content_retention':'until_project_deletion', 'audit_days':90,
                'limitations':[
                    'Os arquivos ficam neste computador. O administrador do sistema e cópias de segurança precisam de controles próprios.',
                    'A exclusão abrange os dados locais gerenciados pelo workspace; não apaga exportações, backups nem envios remotos anteriores.',
                    'O gateway distribuído permanece bloqueado: ele registra prompts no ledger e não oferece apagamento verificável.',
                    'A implantação multiusuário exige isolamento do processamento de arquivos e da inferência, criptografia e gestão de chaves.',
                ]}

    def set_policy(self, days):
        if type(days) is not int or days not in (7,30,90,365):
            raise BlochAIError('Escolha uma retenção de histórico de 7, 30, 90 ou 365 dias.')
        save_json(self.root/'privacy.json', {'history_days':days})
        self.audit('retention_changed')
        return self.describe()

    def audit(self, action, project=None):
        # No emails, prompts, filenames, paths, model answers or request bodies.
        rows=self.read(self.root/'audit.json', [])
        cutoff=time.time()-90*86400
        row={'at':time.time(), 'action':action}
        if project:
            row['project_ref']=hashlib.sha256((self.projects.owner+'\0'+project).encode()).hexdigest()[:24]
        save_json(self.root/'audit.json', [item for item in rows if item['at']>=cutoff][-1999:]+[row])

    def project_records(self, project):
        folder=self.projects.folder(project)
        paths=[]
        for path in (self.root/'jobs').glob('*.json'):
            row=self.read(path)
            if row and row.get('project')==project:paths.append(path)
        # Include old web traces saved before project-specific run directories.
        for path in (self.root/'runs').glob('*.json'):
            row=self.read(path)
            if row and row.get('workspace')==str(folder):paths.append(path)
        for path in (self.projects.state/(project+'.json'),self.root/'knowledge'/(project+'.json'),self.root/'connections'/(project+'.json')):
            if path.exists():paths.append(path)
        for directory in (self.root/'project-runs'/project,self.root/'code-history'/project,self.root/'closed-scopes'/project,self.root/'folder-imports'/project):
            if directory.parent.is_symlink() or directory.is_symlink():raise BlochAIError('Diretório de histórico inválido.')
            for path in directory.rglob('*.json'):
                self.read(path);paths.append(path)
        paths.extend(self.cli_records(project))
        return paths

    def cli_records(self, project, progress_only=False):
        folder=str(self.projects.folder(project).resolve())
        base=self.root/'cli'/project
        if any(path.is_symlink() for path in (base.parent,base)):
            raise BlochAIError('Diretório de histórico CLI inválido.')
        paths=[]
        for name in (('progress',) if progress_only else ('runs','progress')):
            directory=base/name
            if directory.is_symlink():raise BlochAIError('Diretório de histórico CLI inválido.')
            for path in directory.glob('*.json'):
                if not re.fullmatch(r'[a-f0-9]{16}',path.stem):continue
                if name=='progress' and path.stat().st_size>65536:
                    raise BlochAIError('Registro de progresso CLI excedeu o limite de tamanho.')
                row=self.read(path)
                if (not isinstance(row,dict) or row.get('owner')!=self.projects.owner
                        or row.get('project')!=project or row.get('workspace')!=folder
                        or row.get('id')!=path.stem):
                    raise BlochAIError('Registro CLI fora do escopo deste projeto.')
                paths.append(path)
                if len(paths)>2000:raise BlochAIError('O histórico CLI excedeu o limite de inspeção segura.')
        return paths

    def active_cli(self, project=None):
        identifiers=[project] if project is not None else [row['id'] for row in self.projects.list()]
        current=time.time()
        for identifier in identifiers:
            for path in self.cli_records(identifier,progress_only=True):
                row=self.read(path)
                heartbeat=row.get('heartbeat_at')
                if (row.get('status') in ('RUNNING','AWAITING_APPROVAL')
                        and type(heartbeat) in (int,float) and math.isfinite(heartbeat)
                        and 0<=current-heartbeat<35):
                    return True
        return False

    def export(self, project):
        if self.active_cli(project):raise BlochAIError('Conclua a tarefa no terminal antes de exportar o projeto.')
        folder=self.projects.folder(project)
        workspace=Workspace(folder,lambda *_:False)
        output=io.BytesIO();total=0;count=0;omitted=[]
        from .file_operations import FileOperations
        has_trash=bool(FileOperations(self.projects,project).list_trash()['entries'])
        with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED) as archive:
            def add(path, name):
                nonlocal total,count
                if path.is_symlink() or path.stat().st_nlink!=1:raise BlochAIError('Não é possível exportar atalhos ou arquivos vinculados.')
                total+=path.stat().st_size;count+=1
                if total>250*1024*1024 or count>20000 or path.stat().st_size>20*1024*1024:
                    raise BlochAIError('A exportação excede 250 MB, 20.000 arquivos ou 20 MB por arquivo. Divida o projeto antes de exportar.')
                archive.writestr(name,path.read_bytes())
            for directory,dirs,names in os.walk(folder,followlinks=False):
                dirs[:]=sorted(name for name in dirs if not name.startswith('.') and not blocked(name) and not (Path(directory)/name).is_symlink())
                for name in sorted(names):
                    relative=(Path(directory)/name).relative_to(folder).as_posix()
                    try:path=workspace.path(relative)
                    except BlochAIError:
                        omitted.append(relative);continue
                    if path.is_file():add(path,'project/'+relative)
            live_indexes={self.projects.state/(project+'.json'),self.root/'knowledge'/(project+'.json'),self.root/'connections'/(project+'.json')}
            for path in self.project_records(project):
                # Historical traces and approved Markdown snapshots can contain
                # copies of removed files. Keep them private while trash exists.
                if not has_trash or path in live_indexes:add(path,'records/'+path.relative_to(self.root).as_posix())
            archive.writestr('privacy.json',json.dumps(self.describe(),ensure_ascii=False,indent=2))
            from .github_import import source_records
            archive.writestr('repository-sources.json',json.dumps([] if has_trash else source_records(self.projects,project,include_notices=True),ensure_ascii=False,indent=2))
            from .collaboration import CollaborationStore
            archive.writestr('collaboration.json',json.dumps(CollaborationStore(self.projects.root).export(self.projects.owner,project),ensure_ascii=False,indent=2))
            archive.writestr('export.json',json.dumps({'project':project,'exported_at':time.time(),'omitted_protected_files':omitted,'historical_records_omitted_due_to_trash':has_trash,
                'limitations':'Local managed project data only. Hidden directories, credentials, external backups and prior remote submissions are excluded.'},ensure_ascii=False,indent=2))
        self.audit('project_exported',project)
        return output.getvalue()

    def delete_project(self, project):
        if self.active_cli(project):raise BlochAIError('Conclua a tarefa no terminal antes de excluir o projeto.')
        folder=self.projects.folder(project)
        paths=self.project_records(project)
        # The caller holds the project lock and has rejected active work.
        from .collaboration import CollaborationStore
        CollaborationStore(self.projects.root).forget(self.projects.owner,project)
        for path in paths:path.unlink()
        for directory in (self.root/'project-runs'/project,self.root/'code-history'/project,self.root/'cli'/project,self.root/'closed-scopes'/project,self.root/'folder-imports'/project):
            if directory.exists():shutil.rmtree(directory)
        shutil.rmtree(folder)
        self.audit('project_deleted',project)

    def cleanup(self, active=False):
        if active or self.active_cli():return 0
        cutoff=time.time()-self.policy()['history_days']*86400
        removed=0
        for name in ('jobs','runs','project-runs','code-history','cli'):
            directory=self.root/name
            if directory.is_symlink():raise BlochAIError('Diretório de histórico inválido.')
            for path in directory.rglob('*.json'):
                if path.is_symlink():continue
                row=self.read(path)
                if path.stat().st_mtime<cutoff:
                    path.unlink();removed+=1
        audit_path=self.root/'audit.json'
        if audit_path.exists():
            save_json(audit_path,[row for row in self.read(audit_path,[]) if row['at']>=time.time()-90*86400][-2000:])
        if removed:self.audit('history_expired')
        return removed
