"""Authored, reproducible programming exercises with family-disjoint evaluations."""
from __future__ import annotations

import ast
import hashlib
import json
import math
import operator
import random

from .config import BlochAIError

SYSTEM="Return only Python code defining solve(x) with one return expression. No imports, I/O, decorators, loops or explanations. Builtins allowed: len, sum, min, max, sorted, abs, list, tuple."
# Each concept occurs in exactly one split. The evaluator's inputs are never
# included in training prompts. This is a narrow benchmark, not a coding score.
EXERCISES={
    "train":[("sum", "Return the sum of the numbers in x.","sum(x)",[([1,2,3],6),([],0)]),
             ("length","Return the number of elements in x.","len(x)",[([],0),([2,4],2)]),
             ("sort","Return x sorted in ascending order.","sorted(x)",[([3,1,2],[1,2,3]),([],[])]),
             ("absolute","Return the absolute value of integer x.","abs(x)",[(-4,4),(0,0)])],
    "validation":[("minimum","Return the smallest number in the nonempty list x.","min(x)",[([3,1,-4],-4),([0],0),([5,5],5)]),
                  ("negation","Return the negation of integer x.","-x",[(-4,4),(2,-2),(0,0)])],
    "test":[("maximum","Return the largest number in the nonempty list x.","max(x)",[([-7,-1,-4],-1),([0],0),([8,3,8],8)]),
            ("reverse","Return the list x in reverse order.","x[::-1]",[([2,5,2],[2,5,2]),([1,2,3],[3,2,1]),([],[])]),
            ("nonnegative","Return whether integer x is nonnegative.","x >= 0",[(-1,False),(0,True),(12,True)]),
            ("parity","Return whether integer x is even.","x % 2 == 0",[(-2,True),(0,True),(7,False)])]
}


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(",",":")).encode()).hexdigest()


def authored_examples():
    result={name:[] for name in EXERCISES}
    for split, exercises in EXERCISES.items():
        for family, task, expression, cases in exercises:
            row={"family":"authored:"+family,"messages":[{"role":"system","content":SYSTEM},{"role":"user","content":task}],
                 "answer":"def solve(x):\n    return "+expression+"\n",
                 "provenance":{"kind":"OWNER_AUTHORED_SYNTHETIC","license":"MIT","generator":"blochai-coding-v1"}}
            row["id"]=digest(row)
            if split!="train":
                row["cases"]=cases
            result[split].append(row)
    # Teach exact tool shape on a separate, authored training-only family.
    for path in ("README.md","main.py","app.py","tests/test_app.py"):
        action={"action":"read_file","args":{"path":path}}
        row={"family":"authored:tool_read","messages":[{"role":"system","content":"Return one JSON tool action with action and args keys. Read an existing file before changing it."},
              {"role":"user","content":"Inspect "+path+" before planning an edit."}],"answer":json.dumps(action),
              "provenance":{"kind":"OWNER_AUTHORED_SYNTHETIC","license":"MIT","generator":"blochai-coding-v1"}}
        row["id"]=digest(row);result["train"].append(row)
    return result


def round_examples(round_id):
    """New verified exercise parameters each round; held-out families never enter training."""
    rows=[];randomizer=random.Random(round_id)
    for offset in randomizer.sample(range(-30,31),12):
        description=f"Return the sum of the numbers in list x, then add {offset}."
        answer=f"def solve(x):\n    return sum(x) + ({offset})\n"
        cases=[([1,-3,7],5+offset),([],offset),([-5],-5+offset)]
        if not evaluate_code(answer,cases)["passed"]:
            raise BlochAIError("Authored reference exercise failed its functional checks.")
        row={"family":"authored:sum","messages":[{"role":"system","content":SYSTEM},{"role":"user","content":description}],
             "answer":answer,"provenance":{"kind":"OWNER_AUTHORED_SYNTHETIC","license":"MIT","generator":"blochai-coding-round-v1","round":round_id,"reference_tests_passed":3}}
        row["id"]=digest(row);rows.append(row)
    return rows


def bounded(value, *, _depth=0, _budget=None):
    """Accept only finite, small built-in values; never invoke object methods."""
    budget = [2000] if _budget is None else _budget
    budget[0] -= 1
    if budget[0] < 0 or _depth > 8:
        raise ValueError("value_budget")
    kind = type(value)
    if kind in (list, tuple):
        if len(value) > 2000:
            raise ValueError("value_size")
        for item in value:
            bounded(item, _depth=_depth + 1, _budget=budget)
    elif kind is str:
        if len(value) > 2000:
            raise ValueError("value_size")
    elif kind in (int, float):
        if abs(value) > 1_000_000 or (kind is float and not math.isfinite(value)):
            raise ValueError("number_size")
    elif kind not in (bool, type(None)):
        raise ValueError("value_type")
    return value


def _failure_value(value):
    # Called only after exact primitive validation. Reports never contain an
    # arbitrary repr, exception message, or unbounded model-produced value.
    encoded = json.dumps(value, ensure_ascii=True, separators=(",", ":"))
    return value if len(encoded) <= 256 else {"truncated": True, "type": type(value).__name__}


def interpret(node, x):
    """A tiny expression interpreter; model output is never passed to eval/exec."""
    if isinstance(node,ast.Name) and node.id=="x": return x
    if isinstance(node,ast.Constant) and type(node.value) in (int,float,str,bool,type(None)): return bounded(node.value)
    if isinstance(node,ast.List): return bounded([interpret(n,x) for n in node.elts])
    if isinstance(node,ast.Tuple): return bounded(tuple(interpret(n,x) for n in node.elts))
    if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.USub,ast.UAdd,ast.Not)):
        value=interpret(node.operand,x)
        return bounded(-value if isinstance(node.op,ast.USub) else +value if isinstance(node.op,ast.UAdd) else not value)
    if isinstance(node,ast.BinOp):
        operations={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mod:operator.mod,ast.FloorDiv:operator.floordiv,ast.Div:operator.truediv}
        if type(node.op) not in operations: raise ValueError("operator")
        left, right = interpret(node.left, x), interpret(node.right, x)
        if isinstance(node.op, ast.Add) and type(left) is list and type(right) is list:
            if len(left) + len(right) > 2000:
                raise ValueError("value_size")
            return bounded(left + right)
        if type(left) not in (int, float) or type(right) not in (int, float):
            raise ValueError("numeric_operands_required")
        return bounded(operations[type(node.op)](left, right))
    if isinstance(node,ast.Compare):
        operations={ast.Eq:operator.eq,ast.NotEq:operator.ne,ast.Lt:operator.lt,ast.LtE:operator.le,ast.Gt:operator.gt,ast.GtE:operator.ge}
        values=[interpret(node.left,x)]+[interpret(n,x) for n in node.comparators]
        return all(operations[type(op)](values[i],values[i+1]) for i,op in enumerate(node.ops))
    if isinstance(node,ast.Subscript):
        value=interpret(node.value,x)
        if not isinstance(value,(list,tuple,str)): raise ValueError("subscript")
        return bounded(value[interpret(node.slice,x)])
    if isinstance(node,ast.Slice):
        return slice(*(interpret(part,x) if part is not None else None for part in (node.lower,node.upper,node.step)))
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and not node.keywords:
        allowed={"len":len,"sum":sum,"min":min,"max":max,"sorted":sorted,"abs":abs,"list":list,"tuple":tuple}
        if node.func.id not in allowed or len(node.args)!=1: raise ValueError("call")
        return bounded(allowed[node.func.id](interpret(node.args[0],x)))
    raise ValueError("unsupported_expression")


def evaluate_code(answer, cases, *, include_failures=False):
    """Evaluate a tiny expression language without Python execution or I/O."""
    case_count = len(cases) if type(cases) in (list, tuple) and len(cases) <= 32 else 0
    failures = []
    try:
        if type(answer) is not str or len(answer) > 8192 or len(answer.encode("utf-8")) > 8192:
            raise ValueError("answer_size")
        if type(cases) not in (list, tuple) or not 1 <= len(cases) <= 32:
            raise ValueError("case_count")
        for pair in cases:
            if type(pair) not in (list, tuple) or len(pair) != 2:
                raise ValueError("case_shape")
            bounded(pair[0]); bounded(pair[1])
        code=answer.strip()
        if code.startswith("```python\n") and code.endswith("```"):
            code=code[10:-3]
        tree=ast.parse(code)
        if any(index > 128 for index, _ in enumerate(ast.walk(tree), 1)) or len(tree.body)!=1:
            raise ValueError("program_shape")
        fn=tree.body[0]
        if not isinstance(fn,ast.FunctionDef) or fn.name!="solve" or fn.decorator_list or len(fn.body)!=1 or not isinstance(fn.body[0],ast.Return):
            raise ValueError("function_shape")
        if len(fn.args.args)!=1 or fn.args.args[0].arg!="x" or fn.args.defaults or fn.args.kw_defaults or fn.args.posonlyargs or fn.args.kwonlyargs or fn.args.vararg or fn.args.kwarg or fn.returns or fn.args.args[0].annotation or getattr(fn, "type_params", None):
            raise ValueError("function_signature")
        results=[]
        for index, (x, expected) in enumerate(cases):
            try:
                actual=bounded(interpret(fn.body[0].value,x))
                passed=type(actual)==type(expected) and actual==expected
                detail={"case":index,"input":_failure_value(x),"expected":_failure_value(expected),"actual":_failure_value(actual),"error":"wrong_output"}
            except (ValueError,KeyError,TypeError,ArithmeticError,IndexError,RecursionError,MemoryError):
                passed=False
                detail={"case":index,"input":_failure_value(x),"expected":_failure_value(expected),"actual":None,"error":"unsupported_or_invalid_expression"}
            results.append(passed)
            if not passed and len(failures)<3:
                failures.append(detail)
        result={"passed":all(results),"tests":len(results),"tests_passed":sum(results)}
    except (SyntaxError,ValueError,KeyError,TypeError,ArithmeticError,IndexError,RecursionError,MemoryError,UnicodeError):
        result={"passed":False,"tests":case_count,"tests_passed":0,"error":"Unsupported, invalid or incorrect program."}
        failures=[{"case":None,"error":"unsupported_program_or_cases"}]
    if include_failures:
        result["failures"]=failures
    return result


def audit_splits(splits):
    families={name:{r["family"] for r in rows} for name,rows in splits.items()}
    prompts={name:{digest(r["messages"]) for r in rows} for name,rows in splits.items()}
    for left,right in (("train","validation"),("train","test"),("validation","test")):
        if families[left]&families[right] or prompts[left]&prompts[right]:
            raise BlochAIError("Training/evaluation family or prompt leakage detected.")
    return {"family_disjoint":True,"prompt_disjoint":True,"counts":{k:len(v) for k,v in splits.items()}}
