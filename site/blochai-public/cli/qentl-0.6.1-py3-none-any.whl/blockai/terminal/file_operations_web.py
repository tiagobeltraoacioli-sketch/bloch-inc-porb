"""Authenticated, bounded manual file actions under the shared project lock."""
import threading
import time

import anyio
from fastapi import HTTPException,Request
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

from .file_operations import FileOperations,FileConflict


def install_file_operation_routes(app,session,body,projects,publish_project,assert_idle):
    lock=threading.Lock();attempts=[];slots=threading.BoundedSemaphore(4)

    @app.exception_handler(FileConflict)
    async def conflict(request,exc):return JSONResponse({'error':str(exc)},status_code=409)

    async def operation(project,request,action,fields=None,maximum=4096):
        write=fields is not None
        record=await run_in_threadpool(session,request,write,True)
        catalog=projects(record);stat=catalog.folder(project).stat();generation=(stat.st_dev,stat.st_ino)
        if write:
            with lock:
                attempts[:]=[(owner,at) for owner,at in attempts if at>time.monotonic()-60]
                if sum(owner==record['owner'] for owner,_ in attempts)>=60 or len(attempts)>=240:raise HTTPException(429,'Wait before changing more project files.')
                attempts.append((record['owner'],time.monotonic()))
        if not slots.acquire(blocking=False):raise HTTPException(429,'Other file operations are in progress. Retry shortly.')
        try:
            data={}
            if write:
                try:
                    with anyio.fail_after(15):data=await body(request,maximum)
                except TimeoutError:raise HTTPException(408,'File operation request timed out.') from None
                if set(data)!=set(fields):raise HTTPException(422,'Supply only the required file operation fields.')
            def publish():
                def recheck():
                    checked=session(request,write,True);current=projects(checked).folder(project).stat()
                    if (checked['owner']!=record['owner'] or projects(checked).owner!=catalog.owner
                            or (current.st_dev,current.st_ino)!=generation):raise HTTPException(409,'The account or project changed. No file operation was applied.')
                    if write:assert_idle(record,project)
                recheck()
                result=action(FileOperations(catalog,project,(record['token'],)),data,recheck)
                if isinstance(result,dict) and 'capabilities' in result:
                    writable=(record['identity']['organization'].get('role') in ('owner','admin','analyst')
                              and (not record.get('shared') or record['shared']['role']=='editor'))
                    result['capabilities']={'move':writable,'trash':writable}
                return result
            if write:return await publish_project(record,project,publish)
            def read_locked():
                from .project_lock import project_write_lock
                with project_write_lock(catalog.folder(project)):return publish()
            return await run_in_threadpool(read_locked)
        finally:slots.release()

    @app.get('/api/projects/{project}/file-actions/item')
    async def inspect(project: str,request: Request):
        return await operation(project,request,lambda store,data,check:store.inspect(request.query_params.get('node_id')))

    @app.get('/api/projects/{project}/file-actions/trash')
    async def trash(project: str,request: Request):
        return await operation(project,request,lambda store,data,check:store.list_trash())

    @app.post('/api/projects/{project}/file-actions/create')
    async def create(project: str,request: Request):
        return await operation(project,request,lambda store,data,check:store.create(data['path'],data['content'],check),('path','content'),1_250_000)

    @app.post('/api/projects/{project}/file-actions/move')
    async def move(project: str,request: Request):
        return await operation(project,request,lambda store,data,check:store.move(data['node_id'],data['destination'],data['expected_revision'],check),('node_id','destination','expected_revision'))

    @app.post('/api/projects/{project}/file-actions/trash')
    async def remove(project: str,request: Request):
        def action(store,data,check):
            if data['confirm'] is not True:raise HTTPException(422,'Explicitly confirm moving this file to trash.')
            return store.remove(data['node_id'],data['expected_revision'],data['include_linked_notes'],check)
        return await operation(project,request,action,('node_id','expected_revision','confirm','include_linked_notes'))

    @app.post('/api/projects/{project}/file-actions/trash/{identifier}/restore')
    async def restore(project: str,identifier: str,request: Request):
        def action(store,data,check):
            if data['confirm'] is not True:raise HTTPException(422,'Explicitly confirm restoring this trash entry.')
            return store.restore(identifier,check)
        return await operation(project,request,action,('confirm',))
