"""Direct human repository imports, with network outside the publication lock."""
import threading
import time

import anyio
from fastapi import HTTPException,Request
from starlette.concurrency import run_in_threadpool

from .github_import import parse_repository_url,fetch_repository,publish_repository,policy,source_records


def install_github_import_routes(app,session,body,projects,publish_project,assert_idle):
    lock=threading.Lock();attempts=[];slots=threading.BoundedSemaphore(2)

    @app.get('/api/github-policy')
    def describe(request: Request):
        session(request);return policy()

    @app.get('/api/projects/{project}/github-imports')
    def receipts(project: str,request: Request):
        record=session(request,False,True)
        return {'sources':source_records(projects(record),project)}

    @app.post('/api/projects/{project}/github-import')
    async def import_public_repository(project: str,request: Request):
        record=await run_in_threadpool(session,request,True,True)
        catalog=projects(record);stat=catalog.folder(project).stat();generation=(stat.st_dev,stat.st_ino)
        try:
            with anyio.fail_after(15):data=await body(request,8192)
        except TimeoutError:raise HTTPException(408,'Repository import request timed out.') from None
        if set(data)!={'url'}:raise HTTPException(422,'Supply only the explicit public GitHub repository URL.')
        url=parse_repository_url(data['url'])['url']
        with lock:
            attempts[:]=[(owner,at) for owner,at in attempts if at>time.monotonic()-3600]
            if sum(owner==record['owner'] for owner,_ in attempts)>=10 or len(attempts)>=20:
                raise HTTPException(429,'Public GitHub imports reached their hourly budget. Retry later.')
            attempts.append((record['owner'],time.monotonic()))
        if not slots.acquire(blocking=False):raise HTTPException(429,'Other repository imports are in progress. Retry shortly.')
        try:
            await run_in_threadpool(assert_idle,record,project)
            snapshot=await run_in_threadpool(fetch_repository,url)
            def publish():
                def recheck():
                    checked=session(request,True,True);current=projects(checked).folder(project).stat()
                    if (checked['owner']!=record['owner'] or projects(checked).owner!=catalog.owner
                            or (current.st_dev,current.st_ino)!=generation):raise HTTPException(409,'Account or project changed. No repository files were published.')
                    assert_idle(record,project)
                recheck()
                return publish_repository(catalog,project,snapshot,before_publish=recheck,secret_values=(record['token'],))
            return await publish_project(record,project,publish)
        finally:slots.release()
