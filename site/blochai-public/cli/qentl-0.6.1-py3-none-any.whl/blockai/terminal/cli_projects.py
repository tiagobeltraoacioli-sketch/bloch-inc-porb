"""Authenticated terminal access to the same account-scoped Graphus projects."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import sys
import threading
import time
import uuid

from . import auth
from .config import BlochAIError, load_settings, save_json, state_home
from .projects import ProjectStore
from .store import RunStore, scrub
from .task_scope import ScopedWorkspace, project_prompt, resolve_scope, scope_context


WRITE_ROLES={'owner','admin','analyst'}


def default_projects_root():
    legacy=Path.home()/'blochai-projects'
    return legacy if legacy.exists() else Path.home()/'qentl-projects'


def identity_owner(identity):
    user=identity.get('user',{}).get('id') or identity.get('user',{}).get('email')
    organization=identity.get('organization',{}).get('id')
    if not isinstance(user,str) or not user or not isinstance(organization,str) or not organization:
        raise BlochAIError('Qentl did not confirm the user and organization.')
    return hashlib.sha256((user+'\0'+organization).encode()).hexdigest()[:24]


class ProjectSession:
    def __init__(self,root=None):
        self.portal=auth.PortalSession(auth.saved_token())
        try:
            self.identity=self.portal.identity()
            self.owner=identity_owner(self.identity)
            self.catalog=ProjectStore(Path(root).expanduser() if root is not None else default_projects_root(),self.owner)
        except Exception:
            self.portal.close();raise

    def close(self):self.portal.close()

    def check(self,write=False):
        identity=self.portal.identity()
        if identity_owner(identity)!=self.owner:
            raise BlochAIError('The active Qentl account or organization changed. Start a new command.')
        if write and identity['organization'].get('role') not in WRITE_ROLES:
            raise BlochAIError('This organization role cannot run project changes.')
        self.identity=identity
        return identity

    def folder(self,project):
        try:return self.catalog.folder(project)
        except FileNotFoundError as exc:raise BlochAIError('Project not found for this Qentl account and organization.') from exc

    def settings(self):
        from .private_models import private_model
        settings=load_settings()
        if settings.provider in ('qentl','rednblue'):
            settings=private_model(self.owner)
            if settings is None:raise BlochAIError('Configure private inference or local Ollama before running a private Graphus project.')
        if settings.provider=='private' and settings.tenant==self.owner:return settings
        if settings.provider=='ollama' and settings.url=='http://127.0.0.1:11434':return settings
        raise BlochAIError('Private Graphus projects require this account’s private model or local Ollama. Ledger providers are blocked.')

    def workspace(self,project,approve,web_urls=(),run_guard=None,closed_scope=None,artifact_formats=None):
        self.check(write=True)
        folder=self.folder(project)
        stat=folder.stat();generation=(stat.st_dev,stat.st_ino)
        def check_project():
            self.check(write=True)
            stat=self.folder(project).stat()
            if (stat.st_dev,stat.st_ino)!=generation:
                raise BlochAIError('This project was replaced. Start a new project command.')
            if run_guard:run_guard()
        def checked_approval(action,preview):
            check_project()
            if artifact_formats is not None:
                if action!='create_artifact':raise BlochAIError('Document tasks can publish only new document outputs.')
                allowed=approve(action,preview)
                if allowed:check_project()
                return allowed
            if closed_scope is None:
                raise BlochAIError('Writing project files requires an approved closed Markdown scope and requirement ID.')
            closed_scope.check()
            allowed=approve(action,preview)
            if allowed:
                check_project();closed_scope.check()
            return allowed
        def check_mutation():
            check_project()
            if closed_scope is None:
                raise BlochAIError('This project run is read-only until an approved scope requirement is selected.')
        if artifact_formats is not None:
            from .task_routing import ArtifactWorkspace
            return ArtifactWorkspace(folder,checked_approval,resolve_scope({'nodes':[]}),uuid.uuid4().hex[:16],artifact_formats,
                                     web_urls=web_urls,mutation_guard=check_project)
        return ScopedWorkspace(folder,checked_approval,resolve_scope({'nodes':[]}),web_urls=web_urls,
                               mutation_guard=check_mutation,closed_scope=closed_scope)

    def task(self,project,prompt,provider,agent):
        from .agents import system_prompt
        instructions=project_prompt(self.catalog,project)
        prefix=('PROJECT INSTRUCTIONS (apply within this project):\n'+instructions+'\n\n') if instructions else ''
        task=prefix+'CURRENT TASK:\n'+prompt
        messages=[{'role':'system','content':system_prompt(agent,allow_commands=False)}, {'role':'user','content':task}]
        budget=(provider.context_budget(messages) if callable(getattr(provider,'context_budget',None))
                else provider.prompt_limit-sum(len(row['content']) for row in messages))-400
        if budget<250:raise BlochAIError('Project instructions and task exceed the selected model context.')
        return task+scope_context(self.catalog,project,resolve_scope({'nodes':[]}),min(16000,budget))


class ProjectProvider:
    """Recheck membership before each private prompt leaves the terminal."""
    def __init__(self,provider,session,project,closed_scope=None):
        self.provider=provider;self.session=session;self.project=project;self.run_store=None;self.closed_scope=closed_scope
        folder=session.folder(project);stat=folder.stat();self.generation=(stat.st_dev,stat.st_ino)
    def __getattr__(self,name):return getattr(self.provider,name)
    @property
    def on_task(self):return self.provider.on_task
    @on_task.setter
    def on_task(self,value):self.provider.on_task=value
    def messages_fit(self,messages):
        if self.closed_scope:messages=self.closed_scope.bind_messages(messages)
        if callable(getattr(self.provider,'messages_fit',None)):return self.provider.messages_fit(messages)
        return len(self.provider.flatten(messages))<=self.provider.prompt_limit
    def context_budget(self,messages):
        if self.closed_scope:messages=self.closed_scope.bind_messages(messages)
        if callable(getattr(self.provider,'context_budget',None)):return self.provider.context_budget(messages)
        return self.provider.prompt_limit-len(self.provider.flatten(messages))
    def complete(self,messages,json_mode=False):
        self.session.check(write=True)
        folder=self.session.folder(self.project);stat=folder.stat()
        if (stat.st_dev,stat.st_ino)!=self.generation:
            raise BlochAIError('This project was replaced. Start a new project command.')
        if self.run_store:self.run_store.ensure_active()
        if self.closed_scope:messages=self.closed_scope.bind_messages(messages)
        return self.provider.complete(messages,json_mode=json_mode)


def run_root(owner,project):
    if not re.fullmatch(r'[a-f0-9]{24}',owner) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}',project):
        raise BlochAIError('Invalid project run scope.')
    return state_home()/'web'/owner/'cli'/project


class ProjectRunStore(RunStore):
    def __init__(self,owner,project,workspace,secrets=(),closed_scope=None):
        super().__init__(run_root(owner,project),secrets=secrets,training_allowed=False)
        self.owner=owner;self.project=project;self.workspace=str(Path(workspace).resolve())
        self.closed_scope=closed_scope.provenance() if closed_scope else None
        self.lock=threading.RLock();self.progress=None;self.stop=threading.Event();self.worker=None
        folder=Path(self.workspace)
        if folder.name!=project or folder.parent.name!=owner:
            raise BlochAIError('CLI runs must use the authenticated project folder.')
        stat=folder.stat();self.generation=(stat.st_dev,stat.st_ino)
        self.lease=self.root/'leases'/(uuid.uuid4().hex+'.json')
        save_json(self.lease,{'owner':owner,'project':project})

    def ensure_active(self):
        folder=Path(self.workspace)
        try:
            valid=(not self.stop.is_set() and folder.is_dir()
                   and not any(path.is_symlink() for path in (folder,folder.parent,folder.parent.parent,self.root,self.lease.parent,self.lease))
                   and self.lease.is_file())
            stat=folder.stat()
            valid=valid and (stat.st_dev,stat.st_ino)==self.generation
        except OSError:valid=False
        if not valid:
            raise BlochAIError('This project was deleted, replaced or its CLI run was closed. Start a new project command.')

    def __enter__(self):
        def heartbeat():
            while not self.stop.wait(10):
                with self.lock:
                    if self.progress:
                        try:
                            self.ensure_active()
                            self.progress['heartbeat_at']=time.time()
                            save_json(self.root/'progress'/(self.progress['id']+'.json'),self.progress)
                        except (BlochAIError,OSError):
                            self.stop.set();return
        self.worker=threading.Thread(target=heartbeat,daemon=True,name='qentl-cli-progress');self.worker.start()
        return self

    def __exit__(self,*args):
        self.stop.set()
        if self.worker:self.worker.join(timeout=2)

    def save(self,record):
        with self.lock:
            self.ensure_active()
            if record.get('owner',self.owner)!=self.owner or record.get('project',self.project)!=self.project:
                raise BlochAIError('A CLI run cannot change account or project.')
            record.update(owner=self.owner,project=self.project,source='cli',training_allowed=False)
            record['closed_scope']=self.closed_scope
            if record.get('workspace')!=self.workspace:raise BlochAIError('CLI run workspace changed.')
            super().save(record)
            events=[]
            for item in record.get('events',[])[-12:]:
                result=item.get('result',{})
                events.append({**{key:item[key] for key in ('at','kind','agent','action','output_tokens') if key in item},
                               'result':{key:result[key] for key in ('path','changed','denied','exit_code') if key in result}})
            self.progress=scrub({key:record.get(key) for key in ('id','owner','project','workspace','agent','status','created_at','updated_at','steps')},self.secrets)
            self.progress.update(task=scrub(record.get('task','')[:180],self.secrets),summary=scrub(record.get('summary','')[:4000],self.secrets),
                                 events=scrub(events,self.secrets),heartbeat_at=time.time(),training_allowed=False,closed_scope=self.closed_scope)
            self.ensure_active()
            save_json(self.root/'progress'/(record['id']+'.json'),self.progress)


def project_runs(catalog,project):
    folder=str(catalog.folder(project).resolve())
    directory=run_root(catalog.owner,project)/'progress'
    if any(path.is_symlink() for path in (directory,directory.parent,directory.parent.parent)):
        raise BlochAIError('Invalid CLI progress directory.')
    paths=sorted(directory.glob('*.json'),key=lambda path:path.stat().st_mtime,reverse=True)[:20]
    runs=[]
    for path in paths:
        if path.is_symlink() or not re.fullmatch(r'[a-f0-9]{16}',path.stem) or path.stat().st_size>65536:continue
        try:data=json.loads(path.read_text(encoding='utf-8'))
        except (ValueError,OSError):continue
        if (data.get('owner')!=catalog.owner or data.get('project')!=project or data.get('workspace')!=folder
                or data.get('id')!=path.stem):continue
        if type(data.get('heartbeat_at')) not in (int,float):continue
        data['heartbeat_current']=0<=time.time()-data['heartbeat_at']<35
        runs.append({key:value for key,value in data.items() if key not in ('owner','workspace')})
    return runs


def revision(catalog,project):
    rows=catalog.code_files(project);workspace=ScopedWorkspace(catalog.folder(project),lambda *_:False,resolve_scope({'nodes':[]}))
    files=[]
    for row in rows['files']:
        try:
            stat=workspace.path(row['path']).stat()
            files.append({'id':row['id'],'path':row['path'],'size':stat.st_size,'mtime_ns':str(stat.st_mtime_ns),'ctime_ns':str(stat.st_ctime_ns)})
        except (OSError,BlochAIError):continue
    # Managed content contributes only to the fingerprint, never private index
    # contents or absolute state paths. This makes shared notes/uploads and
    # associations refresh Graphus as well as code written by the terminal.
    managed=[]
    def fingerprint(label,path):
        try:
            if path.is_symlink() or path.parent.is_symlink():return
            stat=path.stat()
            managed.append([label,stat.st_size,str(stat.st_mtime_ns),str(stat.st_ctime_ns)])
        except OSError:pass
    for name,path in (
        ('project',catalog.state/(project+'.json')),
        ('notes',catalog.state.parent/'knowledge'/(project+'.json')),
        ('connections',catalog.state.parent/'connections'/(project+'.json')),
        ('closed-scope',catalog.state.parent/'closed-scopes'/project/'current.json'),
    ):fingerprint(name,path)
    directory=workspace.root/'knowledge'
    if directory.is_dir() and not directory.is_symlink():
        fingerprint('knowledge-folder',directory)
        # Notes may be moved into nested folders. Inspect only the bounded,
        # managed index instead of walking arbitrary directories or reading text.
        from .knowledge import KnowledgeStore
        for row in KnowledgeStore(catalog,project).records():
            if not isinstance(row,dict) or not isinstance(row.get('path'),str):continue
            try:
                checked=workspace.path(row['path'])
                if checked.is_file():fingerprint('note:'+row['path'],checked)
            except BlochAIError:continue
    payload=json.dumps({'files':sorted(files,key=lambda item:item['path']),'managed':sorted(managed)},sort_keys=True,separators=(',',':'))
    return {'revision':hashlib.sha256(payload.encode()).hexdigest(),'files':files,'truncated':rows['truncated']}


def cli_info(catalog,project):
    from .closed_scope import ClosedScopeStore
    status=ClosedScopeStore(catalog,project).status()
    requirements=(status.get('contract') or {}).get('requirements',[])
    path=catalog.folder(project).resolve()
    name='qentl.cmd' if os.name=='nt' else 'qentl'
    bundled=Path(__file__).resolve().parents[3]/name
    installed=Path(sys.executable).with_name('qentl.exe' if os.name=='nt' else 'qentl')
    launcher=str(bundled) if Path(__file__).resolve().parents[2].name=='backend' and bundled.is_file() else str(installed) if installed.is_file() else shutil.which('qentl')
    prefix=[launcher or 'qentl']
    if os.name=='nt' and Path(__file__).resolve().parents[2].name=='backend':
        resources=Path(__file__).resolve().parents[3]
        python=resources/'python'/'python.exe';entry=resources/'backend'/'cli.py'
        if python.is_file() and entry.is_file():
            launcher=str(python);prefix=[launcher,'-I','-B',str(entry)]
    parts=prefix+['run','Describe the project change','--project',project,'--projects-root',str(catalog.root.resolve())]
    requirement=requirements[0]['id'] if status['state']=='approved' and len(requirements)==1 else 'REQUIREMENT_ID'
    parts+=['--requirement',requirement]
    if status['state']=='approved':parts+=['--scope-revision',status['revision']]
    if os.name=='nt':command='& '+' '.join("'"+part.replace("'","''")+"'" for part in parts)
    else:command=shlex.join(parts)
    return {'project':project,'workspace':str(path),'command':command,'shell':'powershell' if os.name=='nt' else 'posix',
            'launcher_available':bool(launcher),'launcher':launcher,
            'closed_scope':{'state':status['state'],'revision':status['revision'],'requirements':requirements},
            'note':'Use the same Qentl user and organization and a requirement from the owner-approved Markdown scope. Shell execution stays disabled; review file changes in the terminal.',
            **revision(catalog,project)}
