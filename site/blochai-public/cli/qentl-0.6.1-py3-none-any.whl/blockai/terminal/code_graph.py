"""Bounded, static project structure. Never import or execute project code."""
from __future__ import annotations

import ast
from collections import OrderedDict
import hashlib
import json
from pathlib import PurePosixPath
import threading

from .config import BlochAIError
from .workspace import Workspace

MAX_SYMBOLS = 60
MAX_NODES = 1800
MAX_CACHE_ENTRIES = 1000
_cache = OrderedDict()
_lock = threading.RLock()


def node_id(kind, value):
    return kind + ':' + hashlib.sha256(value.encode()).hexdigest()[:16]


def _diagnostic(line, column, message):
    return {'line': max(1, line or 1), 'column': max(1, column or 1),
            'severity': 'error', 'message': str(message)[:250]}


def analyze(path, text):
    """Resolve only lexical/local references; ambiguous or dynamic calls stay absent."""
    suffix = PurePosixPath(path).suffix.lower()
    symbols, calls, imports, diagnostics = [], [], [], []
    result = {'symbols': symbols, 'calls': calls, 'imports': imports,
              'diagnostics': diagnostics, 'supported': True, 'truncated': False}
    if len(text.encode()) > 200000:
        return {**result, 'supported': False, 'reason': 'Arquivo acima de 200 KB.'}
    if suffix == '.py':
        try:
            tree = ast.parse(text, filename=path)
            # Compilation also finds invalid break/return/await placements. No execution.
            compile(tree, path, 'exec', dont_inherit=True)
        except (SyntaxError, ValueError, RecursionError, MemoryError) as exc:
            diagnostics.append(_diagnostic(getattr(exc, 'lineno', 1), getattr(exc, 'offset', 1), getattr(exc, 'msg', str(exc))))
            return result
        class Visitor(ast.NodeVisitor):
            def __init__(self):
                self.parents = []
                self.count = 0
            def visit(self, node):
                self.count += 1
                if self.count > 20000:
                    result['truncated'] = True
                    return
                return super().visit(node)
            def symbol(self, node, kind):
                qualified = '.'.join(self.parents + [node.name])
                if len(symbols) < MAX_SYMBOLS:
                    symbols.append({'name': node.name, 'qualified': qualified, 'kind': kind,
                                    'line': min([node.lineno] + [n.lineno for n in node.decorator_list]),
                                    'end_line': node.end_lineno})
                else:
                    result['truncated'] = True
                self.parents.append(node.name)
                self.generic_visit(node)
                self.parents.pop()
            def visit_FunctionDef(self, node): self.symbol(node, 'function')
            def visit_AsyncFunctionDef(self, node): self.symbol(node, 'function')
            def visit_ClassDef(self, node): self.symbol(node, 'class')
            def visit_Call(self, node):
                if len(calls) < 500 and isinstance(node.func, ast.Name):
                    calls.append({'caller': '.'.join(self.parents), 'name': node.func.id})
                self.generic_visit(node)
            def visit_Import(self, node):
                imports.extend({'module': n.name, 'level': 0} for n in node.names)
            def visit_ImportFrom(self, node):
                imports.append({'module': node.module or '', 'level': node.level})
        try:
            Visitor().visit(tree)
        except (RecursionError, MemoryError):
            result['truncated'] = True
            diagnostics.append(_diagnostic(1, 1, 'A estrutura excedeu os limites da análise estática.'))
    elif suffix in ('.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx'):
        try:
            from tree_sitter import Language, Parser
            import tree_sitter_javascript as js
            import tree_sitter_typescript as ts
        except ImportError:
            return {**result, 'supported': False, 'reason': 'Instale blockai[graphus] para analisar JS/TS.'}
        language = ts.language_tsx() if suffix == '.tsx' else ts.language_typescript() if suffix == '.ts' else js.language()
        parser = Parser(Language(language))
        parser.timeout_micros = 200000
        raw = text.encode()
        try:
            root = parser.parse(raw).root_node
        except (ValueError, RuntimeError, RecursionError, MemoryError):
            return {**result, 'supported': False, 'reason': 'Análise excedeu o limite de tempo.'}
        def value(node): return raw[node.start_byte:node.end_byte].decode() if node else ''
        stack = [(root, ())]
        visited = 0
        while stack and visited < 20000:
            node, parents = stack.pop(); visited += 1
            if node.is_error or node.is_missing:
                if len(diagnostics) < 20:
                    diagnostics.append(_diagnostic(node.start_point.row + 1, node.start_point.column + 1, 'Sintaxe inválida ou incompleta (' + node.type + ').'))
                continue
            kind = 'class' if node.type in ('class_declaration', 'class') else 'function'
            symbol = node.type in ('function_declaration', 'generator_function_declaration', 'method_definition', 'class_declaration')
            name = value(node.child_by_field_name('name'))
            if node.type == 'variable_declarator':
                initializer = node.child_by_field_name('value')
                symbol = bool(initializer and initializer.type in ('arrow_function', 'function_expression', 'generator_function'))
            if symbol and name:
                qualified = '.'.join((*parents, name))
                if len(symbols) < MAX_SYMBOLS:
                    symbols.append({'name': name, 'qualified': qualified, 'kind': kind,
                                    'line': node.start_point.row + 1, 'end_line': node.end_point.row + 1})
                else: result['truncated'] = True
                parents = (*parents, name)
            if node.type in ('import_statement', 'export_statement'):
                source = value(node.child_by_field_name('source'))
                if source: imports.append({'module': source[1:-1], 'level': 0})
            if node.type == 'call_expression' and len(calls) < 500:
                function = node.child_by_field_name('function')
                if function and function.type == 'identifier': calls.append({'caller': '.'.join(parents), 'name': value(function)})
            stack.extend((child, parents) for child in reversed(node.named_children))
        result['truncated'] |= bool(stack)
    elif suffix == '.json':
        try: json.loads(text)
        except json.JSONDecodeError as exc: diagnostics.append(_diagnostic(exc.lineno, exc.colno, exc.msg))
        except (RecursionError, MemoryError, ValueError):
            result['truncated'] = True
            diagnostics.append(_diagnostic(1, 1, 'O JSON excedeu os limites da análise estática.'))
    else:
        result.update(supported=False, reason='Sem verificador estático para esta linguagem.')
    return result


def code_graph(projects, project, files):
    workspace = Workspace(projects.folder(project), lambda *_: False, allow_commands=False)
    nodes, edges, analyses = [], [], {}
    directories = set()
    truncated = False
    for file in files:
        path = PurePosixPath(file['path'])
        for directory in reversed(path.parents):
            if str(directory) == '.': continue
            name = str(directory)
            if name not in directories:
                directories.add(name)
                identifier = node_id('folder', name)
                nodes.append({'id': identifier, 'title': name, 'path': name, 'kind': 'folder', 'partition': file['partition']})
                if str(directory.parent) != '.': edges.append({'source': node_id('folder', str(directory.parent)), 'target': identifier, 'kind': 'contains'})
        if str(path.parent) != '.': edges.append({'source': node_id('folder', str(path.parent)), 'target': file['id'], 'kind': 'contains'})
        if file['size'] > 200000: continue
        try:
            raw = workspace.path(file['path']).read_bytes()
            text = raw.decode('utf-8')
            if '\x00' in text: continue
        except (OSError, UnicodeError, BlochAIError): continue
        cache_key = (projects.owner, project, file['path'], hashlib.sha256(raw).hexdigest())
        with _lock:
            analysis = _cache.get(cache_key)
            if analysis is not None: _cache.move_to_end(cache_key)
        if analysis is None:
            analysis = analyze(file['path'], text)
            with _lock:
                _cache[cache_key] = analysis
                _cache.move_to_end(cache_key)
                while len(_cache) > MAX_CACHE_ENTRIES: _cache.popitem(last=False)
        analyses[file['path']] = analysis
        file['diagnostics'] = len(analysis['diagnostics'])
        file['language_checked'] = analysis['supported']
        for symbol in analysis['symbols']:
            if len(nodes) + len(files) >= MAX_NODES:
                truncated = True; break
            identifier = node_id('symbol', file['path'] + ':' + symbol['qualified'] + ':' + str(symbol['line']))
            nodes.append({**symbol, 'id': identifier, 'title': symbol['qualified'] + '()', 'path': file['path'],
                          'code_id': file['id'], 'partition': file['partition']})
            edges.append({'source': file['id'], 'target': identifier, 'kind': 'defines'})
        truncated |= analysis['truncated']
    files_by_path = {item['path']: item['id'] for item in files}
    for path, analysis in analyses.items():
        symbols = [node for node in nodes if node.get('path') == path and node['kind'] in ('function', 'class')]
        by_name = {}
        for symbol in symbols: by_name.setdefault(symbol['qualified'], []).append(symbol['id'])
        for call in analysis['calls']:
            caller = by_name.get(call['caller'], [files_by_path[path]])
            parent = call['caller'].split('.')[:-1]
            target = []
            # Only lexical function calls, never guessed receiver dispatch.
            for depth in range(len(parent), -1, -1):
                target = by_name.get('.'.join(parent[:depth] + [call['name']]), [])
                if target: break
            if len(caller) == len(target) == 1 and caller != target:
                edges.append({'source': caller[0], 'target': target[0], 'kind': 'calls'})
        for dependency in analysis['imports']:
            module = dependency['module']
            suffix = PurePosixPath(path).suffix
            candidates = []
            if suffix == '.py':
                parts = list(PurePosixPath(path).parent.parts)
                level = dependency['level']
                if level:
                    if level > len(parts) + 1: continue
                    base = parts[:len(parts) - level + 1]
                else: base = []
                name = '/'.join(base + module.split('.')).rstrip('/')
                candidates = [name + '.py', name + '/__init__.py']
            elif module.startswith('.'):
                parts = list(PurePosixPath(path).parent.parts)
                for part in module.split('/'):
                    if part == '..':
                        if not parts: parts = None; break
                        parts.pop()
                    elif part and part != '.': parts.append(part)
                if parts is None: continue
                name = '/'.join(parts)
                candidates = [name] + [name + ext for ext in ('.ts', '.tsx', '.js', '.jsx', '/index.ts', '/index.js')]
            resolved = [files_by_path[name] for name in candidates if name in files_by_path]
            if len(resolved) == 1:
                edges.append({'source': files_by_path[path], 'target': resolved[0], 'kind': 'imports'})
    seen = set(); unique = []
    for edge in edges:
        signature = (edge['source'], edge['target'], edge['kind'])
        if signature not in seen: seen.add(signature); unique.append(edge)
    return {'nodes': nodes, 'edges': unique, 'truncated': truncated}
