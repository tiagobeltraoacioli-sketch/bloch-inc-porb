"""Explicit, account-scoped synchronization of inert source files.

Local paths and credentials never form part of the server mapping. Updates are
staged and checked against both a complete snapshot and per-file base hashes.
There is no execution, deletion protocol, or training enrollment here.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
from dataclasses import dataclass
from collections import OrderedDict
import shutil
import tempfile
import threading
import time
import unicodedata

from fastapi import Request

from .config import BlochAIError, private_directory, save_json
from .folder_import import (_CREDENTIAL, _manifest, _path, _skip_reason,
                            MAX_FILES, MAX_FILE_BYTES, MAX_DECODED_BYTES,
                            MAX_REQUEST_BYTES, REQUEST_TIMEOUT_SECONDS)
from .projects import MAX_CODE_FILES
from .ingest_policy import current_policy, ensure_space
from .store import scrub
from .workspace import Workspace


ID = re.compile(r'[a-f0-9]{16}')
SHA = re.compile(r'[a-f0-9]{64}')
MAX_MAPPINGS = 20
# Content-free, bounded cache. ctime prevents preserving mtime from hiding edits;
# every content transfer still reopens the file and checks its complete SHA256.
_VALIDATED_LIMIT = 20000
# Windows Python versions may expose creation time as st_ctime. Do not use
# that field as mutation evidence there; fall back to checked per-file reads.
_CACHE_VALIDATION = os.name != 'nt'
_validated = OrderedDict()
_validated_lock = threading.Lock()


def _stamp(details):
    return (details.st_dev, details.st_ino, details.st_size, details.st_mtime_ns, details.st_ctime_ns)


def _cache_key(workspace, relative, secret_values):
    secret_scope = hashlib.sha256(json.dumps(list(secret_values), ensure_ascii=False).encode()).digest()
    return (str(workspace.root), relative, secret_scope)


def _remember(key, stamp, digest):
    with _validated_lock:
        _validated[key] = (stamp, digest)
        _validated.move_to_end(key)
        while len(_validated) > _VALIDATED_LIMIT:
            _validated.popitem(last=False)



class SyncConflict(BlochAIError):
    def __init__(self, revision, conflicts):
        super().__init__('Remote files changed. Fetch and reconcile before syncing; no files were written.')
        self.revision = revision
        self.conflicts = conflicts


def _source_path(value):
    return _path('source/' + value)[7:] if isinstance(value, str) else _path(value)


def _text(raw, secret_values=()):
    try:
        text = raw.decode('utf-8')
    except UnicodeError:
        return 'binary_or_invalid_utf8'
    if any(ord(char) < 32 and char not in '\t\r\n' for char in text):
        return 'binary_or_invalid_utf8'
    if _CREDENTIAL.search(text) or scrub(text, secret_values) != text:
        return 'credential_content'
    return None


def _nodes(paths):
    seen = {}
    for path in paths:
        parts = path.split('/')
        for length in range(1, len(parts) + 1):
            prefix = '/'.join(parts[:length])
            value = (prefix, 'file' if length == len(parts) else 'directory')
            key = prefix.casefold()
            if key in seen and (seen[key] != value or value[1] == 'file'):
                raise BlochAIError('Sync paths collide after case folding or file/directory normalization.')
            seen[key] = value


def _read_source(workspace, relative):
    path = workspace.path(relative)
    descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
    with os.fdopen(descriptor, 'rb') as stream:
        details = os.fstat(stream.fileno())
        if not stat.S_ISREG(details.st_mode) or details.st_nlink != 1 or details.st_size > MAX_FILE_BYTES:
            raise BlochAIError('Sync source changed or exceeds its per-file limit.')
        raw = stream.read(MAX_FILE_BYTES + 1)
        if len(raw) > MAX_FILE_BYTES or len(raw) != details.st_size:
            raise BlochAIError('Sync source changed during inspection.')
        return raw


@dataclass(frozen=True)
class _DiskFile:
    workspace: Workspace
    relative: str
    size: int
    sha256: str

    def __len__(self):
        return self.size

    def read(self):
        raw = _read_source(self.workspace, self.relative)
        if len(raw) != self.size or hashlib.sha256(raw).hexdigest() != self.sha256:
            raise BlochAIError('Sync source changed during transfer. Fetch its current revision and retry.')
        return raw


def _inspect_source(workspace, relative, secret_values):
    path = workspace.path(relative)
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > MAX_FILE_BYTES:
        raise BlochAIError('Sync contains an invalid or oversized source file.')
    key = _cache_key(workspace, relative, secret_values)
    with _validated_lock:
        previous = _validated.get(key)
        if _CACHE_VALIDATION and previous is not None and previous[0] == _stamp(before):
            _validated.move_to_end(key)
            return _DiskFile(workspace, relative, before.st_size, previous[1])
    raw = _read_source(workspace, relative)
    if _stamp(path.stat()) != _stamp(before):
        raise BlochAIError('Sync source changed during inspection; fetch again.')
    if _text(raw, secret_values):
        raise BlochAIError('Sync contains protected credentials or non-text content. Review it on the server.')
    digest = hashlib.sha256(raw).hexdigest()
    _remember(key, _stamp(before), digest)
    return _DiskFile(workspace, relative, len(raw), digest)


def _limits():
    policy = current_policy()
    return (policy['max_source_files'] if policy['profile'] == 'internal' else MAX_FILES,
            None if policy['profile'] == 'internal' else MAX_DECODED_BYTES)


class RemoteSyncStore:
    """Call under the physical project lock; HTTP uses publish_project for this."""
    def __init__(self, catalog, project, secret_values=()):
        self.catalog, self.project, self.secret_values = catalog, project, secret_values
        self.folder = catalog.folder(project)
        self.workspace = Workspace(self.folder, lambda *_: False, allow_commands=False)

    def _mapping(self, identifier):
        if not isinstance(identifier, str) or not ID.fullmatch(identifier):
            raise FileNotFoundError('Sync mapping not found.')
        directory = self.workspace.path('sync/' + identifier, directory=True)
        path = self.workspace.path('sync/' + identifier + '/.qentl-sync.json')
        if not path.is_file():
            raise FileNotFoundError('Sync mapping not found.')
        if path.stat().st_size > 4096:
            raise BlochAIError('Invalid sync mapping metadata.')
        try:
            value = json.loads(path.read_text(encoding='utf-8'))
        except (ValueError, UnicodeError) as exc:
            raise BlochAIError('Invalid sync mapping metadata.') from exc
        if (not isinstance(value, dict) or value.get('id') != identifier
                or value.get('owner') != self.catalog.owner or value.get('project') != self.project
                or not isinstance(value.get('slug'), str) or not re.fullmatch(r'[a-z0-9-]{1,40}', value['slug'])):
            raise BlochAIError('Invalid sync mapping scope.')
        return directory, value

    def create(self, name, before_publish=lambda: None):
        if (not isinstance(name, str) or not 1 <= len(name.strip()) <= 80
                or any(unicodedata.category(char).startswith('C') for char in name)
                or '/' in name or '\\' in name):
            raise BlochAIError('Use a folder name only, without a local filesystem path.')
        sync = self.workspace.path('sync', directory=True)
        if sync.exists():
            entries = list(sync.iterdir())
            if len(entries) >= MAX_MAPPINGS:
                raise BlochAIError('A project supports at most 20 explicit sync mappings.')
        slug = re.sub(r'[^a-z0-9]+', '-', unicodedata.normalize('NFKD', name).encode('ascii', 'ignore').decode().lower()).strip('-')[:40] or 'source'
        identifier = secrets.token_hex(8)
        destination = self.workspace.path('sync/' + identifier, directory=True)
        stage = Path(tempfile.mkdtemp(prefix='.qentl-sync-', dir=str(self.folder.parent)))
        try:
            private_directory(stage / slug)
            save_json(stage / '.qentl-sync.json', {'id':identifier, 'name':name.strip(), 'slug':slug,
                'owner':self.catalog.owner, 'project':self.project, 'training_allowed':False})
            before_publish()
            private_directory(sync)
            if destination.exists():
                raise BlochAIError('Sync mapping already exists. Retry creation.')
            stage.rename(destination)
            return self.snapshot(identifier)
        finally:
            if stage.exists():
                shutil.rmtree(stage)

    def _contents(self, identifier):
        directory, meta = self._mapping(identifier)
        root = self.workspace.path('sync/' + identifier + '/' + meta['slug'], directory=True)
        # A process interrupted between the two publication renames leaves the
        # old tree here. Restore it before serving a snapshot; never lose a base.
        backup = directory / '.previous'
        if backup.exists():
            if backup.is_symlink():
                raise BlochAIError('Invalid sync recovery directory.')
            if not root.exists():
                backup.rename(root)
            else:
                shutil.rmtree(backup)
        if not root.is_dir():
            raise BlochAIError('Sync source directory is missing.')
        contents, total, visited = {}, 0, 0
        max_files, total_limit = _limits()
        def inaccessible(_):
            raise BlochAIError('A sync directory could not be inspected. No files were changed.')
        for current, dirs, names in os.walk(root, followlinks=False, onerror=inaccessible):
            visited += 1
            if visited > max_files * 6:
                raise BlochAIError('Sync directory inspection exceeds its limit.')
            for name in dirs:
                child = Path(current) / name
                relative = child.relative_to(root).as_posix()
                if (child.is_symlink() or _source_path(relative) != relative
                        or _skip_reason(['source'] + relative.split('/') + ['probe.py'], 0)):
                    raise BlochAIError('Sync directories must be portable and cannot contain links.')
            for name in sorted(names):
                child = Path(current) / name
                relative = child.relative_to(root).as_posix()
                path = self.workspace.path(child.relative_to(self.folder).as_posix())
                if not path.is_file() or _source_path(relative) != relative:
                    raise BlochAIError('Sync contains an unsupported filesystem entry.')
                size = path.stat().st_size
                if _skip_reason(['source'] + relative.split('/'), size):
                    raise BlochAIError('Sync contains a protected, unsupported or oversized file. Review it on the server.')
                relative_project = child.relative_to(self.folder).as_posix()
                raw = _inspect_source(self.workspace, relative_project, self.secret_values)
                total += len(raw)
                if len(contents) >= max_files or (total_limit is not None and total > total_limit):
                    raise BlochAIError('Sync exceeds the configured file count or aggregate byte limit.')
                contents[relative] = raw
        _nodes(contents)
        return meta, contents

    @staticmethod
    def _snapshot(meta, contents, include_content=False):
        if include_content and (len(contents) > MAX_FILES or sum(map(len, contents.values())) > MAX_DECODED_BYTES):
            raise BlochAIError('This snapshot requires a paginated client; request offset, limit and revision.')
        rows = []
        for path, raw in sorted(contents.items()):
            digest = raw.sha256 if isinstance(raw, _DiskFile) else hashlib.sha256(raw).hexdigest()
            row = {'path':path, 'sha256':digest, 'bytes':len(raw)}
            if include_content:
                row['content_base64'] = base64.b64encode(raw.read() if isinstance(raw, _DiskFile) else raw).decode('ascii')
            rows.append(row)
        revision = hashlib.sha256(json.dumps([meta['id'], [{key:row[key] for key in ('path','sha256','bytes')} for row in rows]], separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
        return {'id':meta['id'], 'name':meta['name'], 'root':'sync/' + meta['id'] + '/' + meta['slug'],
                'revision':revision, 'files':rows, 'training_allowed':False, 'execution':False}

    def snapshot(self, identifier, include_content=False, *, offset=None, limit=None, revision=None):
        meta, contents = self._contents(identifier)
        if offset is None and limit is None and revision is None:
            return self._snapshot(meta, contents, include_content)
        if (not include_content or type(offset) is not int or not 0 <= offset <= 10000
                or type(limit) is not int or not 1 <= limit <= MAX_FILES
                or not isinstance(revision, str) or not SHA.fullmatch(revision)):
            raise BlochAIError('Paged snapshots require offset >= 0, limit 1..500 and the complete snapshot revision.')
        snapshot = self._snapshot(meta, contents)
        if snapshot['revision'] != revision:
            raise SyncConflict(snapshot['revision'], [])
        if offset > len(snapshot['files']):
            raise BlochAIError('Snapshot offset is outside the file list.')
        page, total = [], 0
        for row in snapshot['files'][offset:offset + limit]:
            if total + row['bytes'] > MAX_DECODED_BYTES:
                break
            raw = contents[row['path']].read()
            page.append({**row, 'content_base64':base64.b64encode(raw).decode('ascii')})
            total += len(raw)
        next_offset = offset + len(page)
        if not page and offset < len(snapshot['files']):
            raise BlochAIError('A file cannot fit in the configured transfer page.')
        return {**snapshot, 'files':page, 'offset':offset,
                'next_offset':next_offset if next_offset < len(snapshot['files']) else None,
                'total_files':len(snapshot['files'])}


    def apply(self, identifier, expected_revision, files, before_publish=lambda: None):
        if not isinstance(expected_revision, str) or not SHA.fullmatch(expected_revision):
            raise BlochAIError('Provide the revision of the previously fetched sync snapshot.')
        if not isinstance(files, list) or not 1 <= len(files) <= MAX_FILES:
            raise BlochAIError('Sync 1 to 500 changed files per request.')
        bases, manifest = {}, []
        for item in files:
            if not isinstance(item, dict) or set(item) != {'path','base_sha256','content_base64'}:
                raise BlochAIError('Each change needs path, base_sha256 and content_base64 only.')
            relative = _source_path(item['path'])
            digest = item['base_sha256']
            if digest is not None and (not isinstance(digest, str) or not SHA.fullmatch(digest)):
                raise BlochAIError('A base SHA256 must be null for a new file or a full SHA256.')
            bases[relative] = digest
            manifest.append({'path':'source/' + relative, 'content_base64':item['content_base64']})
        _, prepared = _manifest(manifest)
        accepted, skipped = {}, []
        for full_path, parts, encoded, size in prepared:
            path = full_path[7:]
            reason = _skip_reason(parts, size)
            if not reason:
                try:
                    raw = base64.b64decode(encoded, validate=True)
                    if base64.b64encode(raw).decode('ascii') != encoded:
                        raise binascii.Error('noncanonical')
                except binascii.Error as exc:
                    raise BlochAIError('Sync content must use canonical base64.') from exc
                reason = _text(raw, self.secret_values)
            if reason:
                skipped.append({'path':path, 'reason':reason})
            else:
                accepted[path] = raw
        meta, original = self._contents(identifier)
        current = self._snapshot(meta, original)
        current_hashes = {row['path']:row['sha256'] for row in current['files']}
        conflicts = [{'path':path, 'expected_sha256':bases[path], 'actual_sha256':current_hashes.get(path)}
                     for path in accepted if bases[path] != current_hashes.get(path)]
        if current['revision'] != expected_revision or conflicts:
            raise SyncConflict(current['revision'], conflicts)
        merged = {**original, **accepted}
        _nodes(merged)
        max_files, total_limit = _limits()
        merged_bytes = sum(map(len, merged.values()))
        if len(merged) > max_files or (total_limit is not None and merged_bytes > total_limit):
            raise BlochAIError('The resulting sync namespace exceeds its configured file count or aggregate byte limit.')
        existing = self.catalog.code_files(self.project)
        if existing['truncated'] or len(existing['files']) + len(set(accepted) - set(original)) > current_policy()['max_source_files']:
            raise BlochAIError('The project would exceed its configured source file count.')
        if accepted:
            directory, _ = self._mapping(identifier)
            root = self.workspace.path(current['root'], directory=True)
            ensure_space(directory, merged_bytes, extra_bytes=1024 * 1024)
            stage = Path(tempfile.mkdtemp(prefix='.qentl-sync-', dir=str(directory)))
            backup = directory / '.previous'
            staged_hashes = []
            try:
                for path, raw in merged.items():
                    target = stage.joinpath(*path.split('/'))
                    for parent in reversed(target.parent.relative_to(stage).parents):
                        if str(parent) != '.':private_directory(stage / parent)
                    private_directory(target.parent)
                    raw_bytes = raw.read() if isinstance(raw, _DiskFile) else raw
                    with target.open('xb') as stream:stream.write(raw_bytes)
                    target.chmod(0o600)
                    staged_hashes.append((path, _stamp(target.stat()), hashlib.sha256(raw_bytes).hexdigest()))
                before_publish()
                # Recheck after authorization callbacks, which can block or
                # observe external changes; mutations never overwrite a new base.
                if self.snapshot(identifier)['revision'] != expected_revision:
                    raise SyncConflict(self.snapshot(identifier)['revision'], [])
                if backup.exists():raise BlochAIError('A sync recovery directory already exists.')
                root.rename(backup)
                try:
                    stage.rename(root)
                except BaseException:
                    backup.rename(root)
                    raise
                shutil.rmtree(backup)
                for path, stamp, digest in staged_hashes:
                    relative = current['root'] + '/' + path
                    target = self.workspace.path(relative)
                    if _CACHE_VALIDATION and _stamp(target.stat()) == stamp:
                        _remember(_cache_key(self.workspace, relative, self.secret_values), stamp, digest)
            finally:
                if stage.exists():shutil.rmtree(stage)
        result = self._snapshot(meta, merged)
        result.update(accepted=[row for row in result['files'] if row['path'] in accepted], skipped=skipped)
        return result


def install_remote_sync_routes(app, session, body, projects, publish_project):
    from fastapi import HTTPException, Request
    from fastapi.responses import JSONResponse
    from starlette.concurrency import run_in_threadpool
    import anyio

    slots, budget_lock, attempts = threading.BoundedSemaphore(2), threading.Lock(), []

    @app.exception_handler(SyncConflict)
    async def conflict(request, exc):
        return JSONResponse({'error':str(exc), 'revision':exc.revision, 'conflicts':exc.conflicts}, status_code=409)

    def owner(request, write=False):
        record = session(request, write, True)
        if record.get('shared'):
            raise HTTPException(403, 'Only the project owner may synchronize a local directory.')
        return record

    def budget(record):
        with budget_lock:
            attempts[:] = [(who, at) for who, at in attempts if at > time.time() - 60]
            if sum(who == record['owner'] for who, _ in attempts) >= 60 or len(attempts) >= 200:
                raise HTTPException(429, 'Wait before synchronizing more files.')
            attempts.append((record['owner'], time.time()))

    async def operation(project, request, write, action, maximum=None):
        record = await run_in_threadpool(owner, request, write)
        catalog = projects(record)
        stat = catalog.folder(project).stat()
        generation = (stat.st_dev, stat.st_ino)
        if write:budget(record)
        if not slots.acquire(blocking=False):
            raise HTTPException(429, 'Other sync transfers are in progress. Retry shortly.')
        try:
            data = None
            if maximum is not None:
                length = request.headers.get('content-length', '')
                if length and (not length.isdigit() or len(length) > 10 or int(length) > maximum):
                    raise HTTPException(413, 'Sync request exceeds its permitted size.')
                try:
                    with anyio.fail_after(REQUEST_TIMEOUT_SECONDS):data = await body(request, maximum)
                except TimeoutError:
                    raise HTTPException(408, 'Sync transfer exceeded its 60 second receive deadline.')
            def publish():
                def recheck():
                    checked = owner(request, write)
                    current = projects(checked).folder(project).stat()
                    if checked['owner'] != record['owner'] or (current.st_dev, current.st_ino) != generation:
                        raise HTTPException(409, 'The account or project changed. No sync files were published.')
                recheck()
                return action(RemoteSyncStore(catalog, project, (record['token'],)), data, recheck)
            return await publish_project(record, project, publish)
        finally:
            slots.release()

    @app.post('/api/projects/{project}/syncs')
    async def create(project: str, request: Request):
        def action(store, data, recheck):
            if set(data) != {'name'}:raise HTTPException(422, 'Provide only the selected directory name.')
            return store.create(data['name'], recheck)
        return await operation(project, request, True, action, 4096)

    @app.get('/api/projects/{project}/syncs/{identifier}')
    async def inspect(project: str, identifier: str, request: Request):
        return await operation(project, request, False, lambda store, data, check:store.snapshot(identifier))

    @app.get('/api/projects/{project}/syncs/{identifier}/snapshot')
    async def snapshot(project: str, identifier: str, request: Request, offset: int = None, limit: int = None, revision: str = None):
        return await operation(project, request, False, lambda store, data, check:store.snapshot(identifier, True, offset=offset, limit=limit, revision=revision))

    @app.post('/api/projects/{project}/syncs/{identifier}/changes')
    async def changes(project: str, identifier: str, request: Request):
        def action(store, data, recheck):
            if set(data) != {'expected_revision','files'}:
                raise HTTPException(422, 'Provide expected_revision and changed files only; implicit deletion is unsupported.')
            return store.apply(identifier, data['expected_revision'], data['files'], recheck)
        return await operation(project, request, True, action, MAX_REQUEST_BYTES)
