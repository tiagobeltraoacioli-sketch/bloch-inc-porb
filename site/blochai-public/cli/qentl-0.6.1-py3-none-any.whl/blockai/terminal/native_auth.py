"""Invite-only native Qentl accounts; credentials never enter project state."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time

from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

from .collaboration import normalize_email
from .config import BlochAIError, config_home, private_directory, save_json, state_home
from .file_permissions import is_private

MASTER_EMAIL='tiago@blochprotocol.io'
TOKEN=re.compile(r'[a-f0-9]{64}')
ID=re.compile(r'[a-f0-9]{32}')
SESSION_SECONDS=43200
INVITE_SECONDS=72*3600
MAX_ACCOUNTS=10000
MAX_INVITES=20000
_KDF_SLOTS=threading.BoundedSemaphore(2)


class NativeAuthError(BlochAIError):
    def __init__(self,message,status_code=400):
        super().__init__(message);self.status_code=status_code


def email_value(value):
    try:return normalize_email(value.strip() if isinstance(value,str) else value)
    except BlochAIError:raise NativeAuthError('Use a valid Qentl account email.') from None


def password_value(value):
    if not isinstance(value,str) or not 14<=len(value)<=128:
        raise NativeAuthError('Use a password of 14 to 128 characters.')
    try:raw=value.encode('utf-8')
    except UnicodeError:raise NativeAuthError('Use a valid UTF-8 password.') from None
    if len(raw)>512 or '\0' in value:raise NativeAuthError('Use a valid password of at most 512 UTF-8 bytes.')
    return raw


def password_hash(password,salt):
    raw=password_value(password)
    if not _KDF_SLOTS.acquire(blocking=False):raise NativeAuthError('Authentication is busy. Retry shortly.',429)
    # cryptography is already a required dependency and supplies scrypt on
    # macOS Python builds whose system hashlib lacks OpenSSL scrypt support.
    try:return Scrypt(salt=bytes.fromhex(salt),n=32768,r=8,p=1,length=64).derive(raw).hex()
    finally:_KDF_SLOTS.release()


def token_hash(token):
    if not isinstance(token,str) or not TOKEN.fullmatch(token):raise NativeAuthError('Invalid or expired Qentl credential.',401)
    return hashlib.sha256(token.encode('ascii')).hexdigest()


class NativeAccounts:
    def __init__(self,directory=None,mapping_file=None):
        self.directory=Path(directory) if directory else state_home()/'native-auth'
        self.path=self.directory/'accounts.sqlite3'
        self.mapping_file=Path(mapping_file) if mapping_file else config_home()/'native-identity-map.json'

    @contextmanager
    def database(self,write=False):
        private_directory(self.directory)
        if self.path.is_symlink() or (self.path.exists() and not is_private(self.path)):
            raise NativeAuthError('The private account database needs operator review.',503)
        fd=None
        try:
            fd=os.open(self.path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        except FileExistsError:pass
        finally:
            if fd is not None:os.close(fd)
        db=sqlite3.connect(self.path,timeout=10);db.row_factory=sqlite3.Row
        try:
            db.execute('PRAGMA foreign_keys=ON')
            db.execute('PRAGMA secure_delete=ON')
            db.executescript('''
                CREATE TABLE IF NOT EXISTS accounts (
                  id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,role TEXT NOT NULL,
                  state TEXT NOT NULL,password_hash TEXT,salt TEXT,
                  namespace_user TEXT NOT NULL,namespace_org TEXT NOT NULL,created_at REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS sessions (
                  digest TEXT PRIMARY KEY,account TEXT NOT NULL REFERENCES accounts(id),
                  created_at REAL NOT NULL,expires_at REAL NOT NULL);
                CREATE INDEX IF NOT EXISTS account_sessions ON sessions(account);
                CREATE TABLE IF NOT EXISTS invitations (
                  id TEXT PRIMARY KEY,email TEXT NOT NULL,kind TEXT NOT NULL,digest TEXT UNIQUE NOT NULL,
                  created_at REAL NOT NULL,expires_at REAL NOT NULL,consumed_at REAL,revoked_at REAL,
                  issuer TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS audit (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,at REAL NOT NULL,actor TEXT NOT NULL,
                  action TEXT NOT NULL,target TEXT NOT NULL);
            ''')
            if write:db.execute('BEGIN IMMEDIATE')
            yield db
            db.commit()
        except Exception:
            db.rollback();raise
        finally:db.close()

    def _namespace(self,email,account):
        if not self.mapping_file.exists():return account,'qentl-native'
        if not is_private(self.mapping_file) or self.mapping_file.stat().st_size>1000000:
            raise NativeAuthError('Native identity bindings need operator review.',503)
        try:
            data=json.loads(self.mapping_file.read_text(encoding='utf-8'))
            if set(data)!={'schema','bindings'} or data['schema']!='qentl-native-identity-map-v1' or not isinstance(data['bindings'],dict):raise ValueError
            namespaces=set()
            for address,binding in data['bindings'].items():
                if (email_value(address)!=address or not isinstance(binding,dict)
                        or set(binding)!={'user_id','organization_id'}
                        or any(not isinstance(value,str) or not 1<=len(value)<=254 or '\0' in value for value in binding.values())):raise ValueError
                pair=(binding['user_id'],binding['organization_id'])
                if pair in namespaces:raise ValueError
                namespaces.add(pair)
            row=data['bindings'].get(email)
            if row is None:return account,'qentl-native'
            return row['user_id'],row['organization_id']
        except (OSError,ValueError,TypeError,KeyError,RecursionError,NativeAuthError):
            raise NativeAuthError('Native identity bindings need operator review.',503) from None

    def _unique_namespace(self,db,account,namespace):
        if db.execute('SELECT 1 FROM accounts WHERE namespace_user=? AND namespace_org=? AND id!=?',(*namespace,account)).fetchone():
            raise NativeAuthError('Native identity binding is already assigned to another account.',503)

    def _audit(self,db,actor,action,target):
        db.execute('INSERT INTO audit(at,actor,action,target) VALUES(?,?,?,?)',(time.time(),actor,action,target))
        db.execute('DELETE FROM audit WHERE id NOT IN (SELECT id FROM audit ORDER BY id DESC LIMIT 10000)')

    def _identity(self,row):
        return {'authenticated':True,'user':{'id':row['namespace_user'],'email':row['email']},
                'organization':{'id':row['namespace_org'],'name':'Qentl workspace','role':'owner'},
                'account_role':row['role']}

    def _account(self,db,token):
        row=db.execute('SELECT a.* FROM accounts a JOIN sessions s ON s.account=a.id WHERE s.digest=? AND s.expires_at>? AND a.state=?',
                       (token_hash(token),time.time(),'active')).fetchone()
        if not row:raise NativeAuthError('Qentl session expired or account access was revoked.',401)
        return row

    def _master(self,db,token):
        row=self._account(db,token)
        if row['role']!='master' or row['email']!=MASTER_EMAIL:
            raise NativeAuthError('Only the Qentl master account can manage account access.',403)
        return row

    def _session(self,db,row):
        now=time.time();token=secrets.token_hex(32)
        db.execute('DELETE FROM sessions WHERE expires_at<=?',(now,))
        # Native credentials are distinct from ephemeral workbench cookies.
        db.execute('DELETE FROM sessions WHERE account=? AND digest NOT IN (SELECT digest FROM sessions WHERE account=? ORDER BY created_at DESC LIMIT 31)',(row['id'],row['id']))
        if db.execute('SELECT COUNT(*) FROM sessions').fetchone()[0]>=10000:
            raise NativeAuthError('Qentl authentication capacity reached. Retry later.',429)
        db.execute('INSERT INTO sessions VALUES(?,?,?,?)',(token_hash(token),row['id'],now,now+SESSION_SECONDS))
        return token,self._identity(row)

    def login(self,email,password):
        email=email_value(email);password_value(password)
        with self.database() as db:
            row=db.execute('SELECT * FROM accounts WHERE email=?',(email,)).fetchone()
        salt=row['salt'] if row and row['salt'] else '0'*32
        candidate=password_hash(password,salt)
        expected=row['password_hash'] if row and row['password_hash'] else '0'*128
        if not hmac.compare_digest(candidate,expected) or not row or row['state']!='active':
            raise NativeAuthError('Invalid Qentl email or password. Access is invitation-only.',401)
        with self.database(write=True) as db:
            current=db.execute('SELECT * FROM accounts WHERE id=?',(row['id'],)).fetchone()
            if not current or current['state']!='active' or current['password_hash']!=expected:
                raise NativeAuthError('Qentl credentials changed. Sign in again.',401)
            result=self._session(db,current);self._audit(db,current['id'],'login',current['id'])
            return result

    def identity(self,token):
        with self.database() as db:return self._identity(self._account(db,token))

    def logout(self,token):
        with self.database(write=True) as db:db.execute('DELETE FROM sessions WHERE digest=?',(token_hash(token),))
        return {'authenticated':False}

    def _invitation(self,db,email,kind,issuer):
        now=time.time()
        db.execute('DELETE FROM invitations WHERE expires_at<?',(now-7*86400,))
        if db.execute('SELECT COUNT(*) FROM invitations').fetchone()[0]>=MAX_INVITES:
            raise NativeAuthError('Invitation capacity reached. Wait for expired records to clear.',429)
        db.execute('UPDATE invitations SET revoked_at=? WHERE email=? AND kind=? AND consumed_at IS NULL AND revoked_at IS NULL',(now,email,kind))
        identifier,token=secrets.token_hex(16),secrets.token_hex(32)
        expires=now+INVITE_SECONDS
        db.execute('INSERT INTO invitations VALUES(?,?,?,?,?,?,NULL,NULL,?)',(identifier,email,kind,token_hash(token),now,expires,issuer))
        self._audit(db,issuer,'invite.'+kind,identifier)
        return {'id':identifier,'email':email,'kind':kind,'token':token,'expires_at':expires}

    def bootstrap(self,destination):
        """Operator-only setup: no token is printed or put in process arguments."""
        destination=Path(destination)
        with self.database(write=True) as db:
            row=db.execute('SELECT * FROM accounts WHERE email=?',(MASTER_EMAIL,)).fetchone()
            if row and row['state']=='active':return {'created':False,'claimed':True}
            if row and row['state']!='pending':raise NativeAuthError('Master account requires explicit operator recovery.',503)
            if not row:
                account=secrets.token_hex(16);namespace=self._namespace(MASTER_EMAIL,account)
                self._unique_namespace(db,account,namespace)
                db.execute('INSERT INTO accounts VALUES(?,?,?,?,NULL,NULL,?,?,?)',(account,MASTER_EMAIL,'master','pending',*namespace,time.time()))
            existing=db.execute('SELECT id,expires_at FROM invitations WHERE email=? AND kind=? AND consumed_at IS NULL AND revoked_at IS NULL AND expires_at>?',
                                (MASTER_EMAIL,'bootstrap',time.time())).fetchone()
            if existing:
                if not is_private(destination):raise NativeAuthError('An active bootstrap exists; restore its protected operator file instead of replacing the token.',409)
                try:
                    saved=json.loads(destination.read_text(encoding='utf-8'))
                    matches=saved.get('id')==existing['id'] and db.execute('SELECT 1 FROM invitations WHERE id=? AND digest=?',(existing['id'],token_hash(saved.get('token')))).fetchone()
                except (ValueError,TypeError,NativeAuthError):matches=False
                if not matches:raise NativeAuthError('The protected bootstrap file does not match the active one-time claim.',409)
                return {'created':False,'claimed':False,'expires_at':existing['expires_at']}
            invitation=self._invitation(db,MASTER_EMAIL,'bootstrap','operator')
            save_json(destination,{'schema':'qentl-master-bootstrap-v1',**invitation,
                                  'claim_url':'https://qentl.ai/#invite='+invitation['token']})
            return {'created':True,'claimed':False,'expires_at':invitation['expires_at']}

    def issue(self,token,email,kind='signup'):
        email=email_value(email)
        if kind not in ('signup','reset'):raise NativeAuthError('Invalid account invitation type.')
        with self.database(write=True) as db:
            actor=self._master(db,token)
            row=db.execute('SELECT * FROM accounts WHERE email=?',(email,)).fetchone()
            if kind=='signup' and (row or email==MASTER_EMAIL):raise NativeAuthError('This account already exists; use its recovery action.',409)
            if kind=='reset' and (not row or row['state']!='active'):raise NativeAuthError('Only an active invited account can be reset.',409)
            if kind=='signup' and db.execute('SELECT COUNT(*) FROM accounts').fetchone()[0]>=MAX_ACCOUNTS:
                raise NativeAuthError('Native account capacity reached.',429)
            return {'invitation':self._invitation(db,email,kind,actor['id'])}

    def accept(self,email,password,token):
        email=email_value(email);password_value(password);digest=token_hash(token)
        with self.database() as db:
            preview=db.execute('SELECT * FROM invitations WHERE digest=?',(digest,)).fetchone()
            if not preview or preview['email']!=email or preview['consumed_at'] or preview['revoked_at'] or preview['expires_at']<=time.time():
                raise NativeAuthError('Invalid, expired or already-used Qentl invitation.',401)
        salt=secrets.token_hex(16);hashed=password_hash(password,salt)
        with self.database(write=True) as db:
            invite=db.execute('SELECT * FROM invitations WHERE digest=?',(digest,)).fetchone()
            if not invite or invite['email']!=email or invite['consumed_at'] or invite['revoked_at'] or invite['expires_at']<=time.time():
                raise NativeAuthError('Invalid, expired or already-used Qentl invitation.',401)
            row=db.execute('SELECT * FROM accounts WHERE email=?',(email,)).fetchone()
            if invite['kind']=='signup':
                if row or email==MASTER_EMAIL:raise NativeAuthError('This account cannot be created by this invitation.',409)
                if db.execute('SELECT COUNT(*) FROM accounts').fetchone()[0]>=MAX_ACCOUNTS:raise NativeAuthError('Native account capacity reached.',429)
                account=secrets.token_hex(16);namespace=self._namespace(email,account)
                self._unique_namespace(db,account,namespace)
                db.execute('INSERT INTO accounts VALUES(?,?,?,?,?,?,?, ?,?)',(account,email,'member','active',hashed,salt,*namespace,time.time()))
            else:
                if (not row or (invite['kind']=='bootstrap' and (email!=MASTER_EMAIL or row['state']!='pending'))
                        or (invite['kind']=='reset' and row['state']!='active')):
                    raise NativeAuthError('This account claim is no longer valid.',409)
                if invite['kind']=='bootstrap':
                    namespace=self._namespace(email,row['id'])
                    self._unique_namespace(db,row['id'],namespace)
                    db.execute('UPDATE accounts SET namespace_user=?,namespace_org=? WHERE id=?',(*namespace,row['id']))
                db.execute('UPDATE accounts SET password_hash=?,salt=?,state=? WHERE id=?',(hashed,salt,'active',row['id']))
                db.execute('DELETE FROM sessions WHERE account=?',(row['id'],))
            db.execute('UPDATE invitations SET consumed_at=? WHERE id=?',(time.time(),invite['id']))
            db.execute('UPDATE invitations SET revoked_at=? WHERE email=? AND consumed_at IS NULL AND revoked_at IS NULL',(time.time(),email))
            current=db.execute('SELECT * FROM accounts WHERE email=?',(email,)).fetchone()
            self._audit(db,current['id'],'account.'+invite['kind'],current['id'])
            return self._session(db,current)

    def revoke_invitation(self,token,identifier):
        if not isinstance(identifier,str) or not ID.fullmatch(identifier):raise NativeAuthError('Invalid invitation identifier.')
        with self.database(write=True) as db:
            actor=self._master(db,token)
            db.execute('UPDATE invitations SET revoked_at=? WHERE id=? AND consumed_at IS NULL',(time.time(),identifier))
            self._audit(db,actor['id'],'invite.revoke',identifier)
        return {'revoked':True}

    def revoke_account(self,token,email):
        email=email_value(email)
        if email==MASTER_EMAIL:raise NativeAuthError('The master account cannot revoke itself.',403)
        with self.database(write=True) as db:
            actor=self._master(db,token)
            row=db.execute('SELECT id FROM accounts WHERE email=?',(email,)).fetchone()
            if not row:raise NativeAuthError('Qentl account not found.',404)
            db.execute('UPDATE accounts SET state=? WHERE id=?',('revoked',row['id']))
            db.execute('DELETE FROM sessions WHERE account=?',(row['id'],))
            db.execute('UPDATE invitations SET revoked_at=? WHERE email=? AND consumed_at IS NULL',(time.time(),email))
            self._audit(db,actor['id'],'account.revoke',row['id'])
        return {'revoked':True}


class NativeSession:
    """Portal-shaped adapter used only by the hosted process and injected tests."""
    def __init__(self,accounts,token=''):self.accounts,self.token=accounts,token
    def close(self):pass
    def login(self,email,password):
        self.token,identity=self.accounts.login(email,password);return identity
    def accept_invitation(self,email,password,token):
        self.token,identity=self.accounts.accept(email,password,token);return identity
    def identity(self):return self.accounts.identity(self.token)
    def logout(self):return self.accounts.logout(self.token)
    def request(self,method,path,json=None):
        data={} if json is None else json
        if method=='GET' and path=='/api/accounts/capabilities':
            identity=self.identity();return {'can_manage_accounts':identity['account_role']=='master','account_role':identity['account_role']}
        if method=='POST' and path in ('/api/account-invitations','/api/account-resets','/api/accounts/revoke'):
            if not isinstance(data,dict) or set(data)!={'email'}:raise NativeAuthError('Supply only the account email.')
            if path=='/api/accounts/revoke':return self.accounts.revoke_account(self.token,data['email'])
            return self.accounts.issue(self.token,data['email'],'reset' if path=='/api/account-resets' else 'signup')
        match=re.fullmatch(r'/api/account-invitations/([a-f0-9]{32})/revoke',path)
        if method=='POST' and match and data=={}:return self.accounts.revoke_invitation(self.token,match.group(1))
        raise NativeAuthError('Unsupported Qentl account operation.',404)


def main():
    parser=argparse.ArgumentParser(description='Prepare a one-time Qentl master claim without printing credentials.')
    parser.add_argument('action',choices=['bootstrap'])
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=NativeAccounts().bootstrap(args.output)
    print(json.dumps(result))


if __name__=='__main__':main()
