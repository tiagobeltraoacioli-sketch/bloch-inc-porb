"""Bounded solve/test/revise loop for reviewed synthetic programming exercises.

Generation is injected by the isolated candidate runtime. This module cannot
fetch a model, read a project, execute Python, or change production weights.
"""
from __future__ import annotations

import hashlib
import json
import math
import time

from .config import BlochAIError
from .curriculum import digest, evaluate_code
from .learning_policy import (GENERATOR, POLICY_ID, approved_feedback_tasks,
                              require_feedback_policy, validate_feedback_row)

METRICS = ('tasks', 'attempts', 'revisions', 'visible_failures',
           'confirmation_rejections', 'verified_solutions', 'repaired_solutions',
           'duplicate_solutions', 'generation_errors', 'budget_exhausted_rounds')


def _answer(value):
    if type(value) is not str or len(value) > 8192 or len(value.encode('utf-8')) > 8192:
        raise BlochAIError('Generator response exceeds the bounded code policy.')
    value = value.strip()
    if value.startswith('```python\n') and value.endswith('```'):
        value = value[10:-3].strip()
    return value + '\n'


def _row(task, answer):
    row = {'family': 'authored:' + task['family'], 'messages': task['messages'], 'answer': answer,
           'provenance': {'kind': 'OWNER_AUTHORED_SYNTHETIC', 'license': 'MIT', 'generator': GENERATOR,
                          'policy_id': POLICY_ID, 'round': task['round_id'], 'task_id': task['id'],
                          'answer_sha256': hashlib.sha256(answer.encode()).hexdigest(),
                          'visible_tests_passed': len(task['visible_cases']),
                          'confirmation_tests_passed': len(task['confirmation_cases'])}}
    row['id'] = digest(row)
    validate_feedback_row(row)
    return row


def run_feedback_round(generate, round_id, families, *, wall_seconds=100,
                       clock=time.monotonic, checkpoint=None):
    """Run <=3 tasks, <=2 corrections each; hold confirmation tests out of prompts.

    ``generate(messages, max_seconds=..., max_new_tokens=96)`` must honor its
    timeout. The production wrapper uses local model.generate and the outer
    candidate process has a hard wall deadline. No arbitrary task input exists.
    ``checkpoint`` durably writes bounded progress after each actual attempt.
    """
    if type(wall_seconds) not in (int, float) or not math.isfinite(wall_seconds) or not 0 < wall_seconds <= 100:
        raise BlochAIError('Feedback wall budget must be positive and at most 100 seconds.')
    tasks = approved_feedback_tasks(round_id, families)
    policy = require_feedback_policy(families, tasks)
    started = clock()
    report = {'schema': 'qentl-coding-feedback-v1', 'round_id': round_id, 'policy': policy,
              'status': 'running', 'metrics': {key: 0 for key in METRICS}, 'tasks': [], 'verified_rows': [],
              'frozen_evaluation_used_for_feedback': False, 'confirmation_cases_sent_to_model': False,
              'production_model_weights_updated': False, 'automatic_promotion': False,
              'limits': {'tasks': 3, 'revisions_per_task': 2, 'model_calls': 9,
                         'output_tokens_per_call': 96, 'seconds_per_call': 8, 'wall_seconds': wall_seconds}}

    def remaining():
        return wall_seconds - (clock() - started)

    def persist():
        report['elapsed_seconds'] = round(max(0, clock() - started), 3)
        if checkpoint:
            checkpoint(report)

    def exhausted():
        report['status'] = 'budget_exhausted'
        report['metrics']['budget_exhausted_rounds'] = 1

    persist()
    for task in tasks:
        if remaining() <= 0:
            exhausted(); break
        trace = {'id': task['id'], 'family': task['family'], 'status': 'unverified', 'attempts': []}
        report['tasks'].append(trace)
        report['metrics']['tasks'] += 1
        messages = list(task['messages'])
        seen = set()
        for revision in range(3):
            if remaining() <= 0:
                trace['status'] = 'budget_exhausted'; exhausted(); break
            report['metrics']['attempts'] += 1
            report['metrics']['revisions'] += int(revision > 0)
            attempt = {'revision': revision, 'status': 'generating'}
            trace['attempts'].append(attempt)
            persist()
            try:
                answer = _answer(generate(messages, max_seconds=min(8.0, remaining()), max_new_tokens=96))
            except Exception as exc:
                # No arbitrary exception text or failed content becomes data.
                attempt.update(status='generation_error', error_type=type(exc).__name__[:80])
                report['metrics']['generation_errors'] += 1
                trace['status'] = 'generation_error'
                if remaining() <= 0:
                    exhausted()
                persist(); break
            if remaining() <= 0:
                attempt['status'] = 'budget_exhausted'; trace['status'] = 'budget_exhausted'; exhausted(); persist(); break
            answer_hash = hashlib.sha256(answer.encode()).hexdigest()
            attempt.update(answer=answer, answer_sha256=answer_hash,
                           evidence_id=digest({'task_id': task['id'], 'answer_sha256': answer_hash}))
            if answer_hash in seen:
                attempt['status'] = 'duplicate'; trace['status'] = 'duplicate'
                report['metrics']['duplicate_solutions'] += 1
                persist(); break
            seen.add(answer_hash)
            visible = evaluate_code(answer, task['visible_cases'], include_failures=True)
            attempt['visible'] = visible
            if visible['passed']:
                confirmation = evaluate_code(answer, task['confirmation_cases'])
                attempt['confirmation'] = confirmation
                if confirmation['passed']:
                    row = _row(task, answer)
                    report['verified_rows'].append(row)
                    report['metrics']['verified_solutions'] += 1
                    report['metrics']['repaired_solutions'] += int(revision > 0)
                    attempt['status'] = trace['status'] = 'verified'
                else:
                    # Never give these failures or answers to a later solver.
                    report['metrics']['confirmation_rejections'] += 1
                    attempt['status'] = trace['status'] = 'confirmation_rejected'
                persist(); break
            report['metrics']['visible_failures'] += 1
            attempt['status'] = 'visible_failed'
            trace['status'] = 'visible_failed'
            # Only the current failed answer plus executable test observations
            # are included; no reference solution, held-out cases or user data.
            feedback = json.dumps(visible['failures'], ensure_ascii=True, separators=(',', ':'))
            messages = task['messages'] + [
                {'role': 'assistant', 'content': answer},
                {'role': 'user', 'content': 'The bounded test interpreter observed these failures: ' + feedback +
                 '\nReturn a different corrected solve(x) expression. Use the observed input/output evidence; no explanations, imports or I/O.'}]
            persist()
        if report['status'] == 'budget_exhausted':
            break
    if report['status'] == 'running':
        report['status'] = 'completed'
    persist()
    return report
