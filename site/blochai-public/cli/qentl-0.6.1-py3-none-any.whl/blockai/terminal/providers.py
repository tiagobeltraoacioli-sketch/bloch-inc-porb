"""Real inference through the private BlochAI gateway or an existing Ollama server."""
from __future__ import annotations

import json
import math
from email.utils import parsedate_to_datetime
import re
import time
from dataclasses import dataclass
from typing import Callable, Optional

import httpx

from .config import BlochAIError, Settings


class InferenceBusyError(BlochAIError):
    """Transient capacity response; no task is automatically resubmitted."""
    def __init__(self, reason='busy_or_rate_limited', retry_after_seconds=None):
        self.reason = reason
        self.retry_after_seconds = retry_after_seconds
        label = ('Inference request rate limit reached' if reason == 'rate_limited'
                 else 'Inference GPU is temporarily busy' if reason in ('gpu_busy', 'queue_full', 'queue_timeout')
                 else 'Inference service is temporarily busy or rate-limited')
        delay = f' Wait {retry_after_seconds} seconds before trying again.' if retry_after_seconds else ' Try again shortly.'
        super().__init__(label + ' (HTTP 429).' + delay + ' The request was not automatically retried.')


def _capacity_error(response):
    # Read only a small allowlisted error envelope: providers can echo prompts,
    # credentials or HTML in failures, and none of that belongs in user logs.
    raw = bytearray()
    reason = 'busy_or_rate_limited'
    try:
        for chunk in response.iter_bytes(chunk_size=1024):
            if len(raw) + len(chunk) > 4096:
                raw.clear(); break
            raw.extend(chunk)
        value = json.loads(raw) if raw else None
        if isinstance(value, dict):
            code = value.get('code')
            if code in ('gpu_busy', 'queue_full', 'queue_timeout', 'rate_limited'):
                reason = code
            elif value.get('error') == 'Private GPU runtime is busy.':
                reason = 'gpu_busy'
            elif value.get('error') == 'Request rate exceeded.':
                reason = 'rate_limited'
    except (ValueError, UnicodeError, RecursionError, httpx.HTTPError):
        pass
    retry = None
    header = response.headers.get('Retry-After', '').strip()
    if len(header) <= 100:
        try:
            if re.fullmatch(r'[0-9]{1,4}', header):
                seconds = int(header)
            else:
                date = parsedate_to_datetime(header)
                if date.tzinfo is None: raise ValueError('timezone required')
                seconds = math.ceil(date.timestamp() - time.time())
            if 1 <= seconds <= 3600: retry = seconds
        except (ValueError, TypeError, OverflowError):
            pass
    return InferenceBusyError(reason, retry)


@dataclass
class Generation:
    text: str
    model: str
    task_id: Optional[str] = None
    output_tokens: Optional[int] = None


class Provider:
    def __init__(self, settings: Settings, transport=None, on_task: Optional[Callable] = None, session_token=None, private_local=False):
        self.settings = settings.validate()
        self.private_local = private_local
        if settings.provider=='qentl':
            raise BlochAIError('Use a Qentl.ai project with --remote, or configure private inference/local Ollama for local tasks.')
        if private_local and (settings.provider!='ollama' or settings.url!='http://127.0.0.1:11434'):
            raise BlochAIError('Private workspace inference requires the local Ollama endpoint.')
        if settings.provider == "rednblue":
            # Legacy operators must supply a separate legacy credential; a
            # native Qentl session must never be sent to this old origin.
            self.secret = session_token or settings.token()
            if not re.fullmatch(r"[a-f0-9]{64}", self.secret):
                raise BlochAIError("Invalid Rednblue session.")
            headers = {"Cookie":"__Host-porb_session="+self.secret,"Origin":settings.url,"X-Porb-Action":"1"}
        else:
            self.secret = settings.token()
            headers = {"Authorization": "Bearer " + self.secret} if self.secret else {}
        self.http = httpx.Client(base_url=settings.url, timeout=httpx.Timeout(30, connect=10),
                                 follow_redirects=False, trust_env=False, transport=transport,
                                 headers=headers)
        self.on_task = on_task or (lambda task: None)
        self._status = None

    def close(self):
        self.http.close()

    def request(self, method, path, **kwargs):
        try:
            with self.http.stream(method, path, **kwargs) as response:
                if response.status_code == 429:
                    raise _capacity_error(response)
                if response.status_code >= 300:
                    labels = {401: "Credential rejected", 403: "Access denied", 404: "Resource not found",
                              413: "Request too large", 422: "Request rejected by the model gateway",
                              503: "Inference workers or service budget unavailable"}
                    raise BlochAIError(f"{labels.get(response.status_code, 'Provider request failed')} (HTTP {response.status_code}).")
                chunks, size = [], 0
                for chunk in response.iter_bytes():
                    size += len(chunk)
                    if size > 2_000_000:
                        raise BlochAIError("Provider response exceeded the size limit.")
                    chunks.append(chunk)
                data = json.loads(b"".join(chunks))
                if not isinstance(data, dict):
                    raise ValueError("object required")
                return data
        except BlochAIError:
            raise
        except httpx.TimeoutException as exc:
            raise BlochAIError("Provider request timed out. A submitted task may still be running; do not blindly resubmit.") from exc
        except httpx.HTTPError as exc:
            raise BlochAIError("Cannot reach the configured inference provider.") from exc
        except (ValueError, UnicodeError) as exc:
            raise BlochAIError("The provider returned an invalid JSON response.") from exc

    def status(self):
        if self.settings.provider=='private':
            data=self.request('GET','/v1/private/status')
            self.check_private_contract(data)
            if not isinstance(data.get('limits'),dict):
                raise BlochAIError('Private inference did not advertise request limits.')
        elif self.settings.provider in ("gateway", "rednblue"):
            path = "/api/porb/v1/blochai/status" if self.settings.provider == "rednblue" else "/v1/status"
            data = self.request("GET", path)
            if not isinstance(data.get("limits"), dict) or not isinstance(data.get("model"), str):
                raise BlochAIError("The gateway status is missing model or request limits.")
        else:
            tags = self.request("GET", "/api/tags")
            names = {m.get("name") for m in tags.get("models", []) if isinstance(m, dict)}
            model = self.settings.model
            ready = model in names or model + ":latest" in names
            data = {"service": "Ollama", "ready": ready, "model": model,
                    "limits": {"max_prompt_chars": 48000, "max_new_tokens": self.settings.max_output_tokens},
                    "reason": None if ready else "The selected model is not installed on this Ollama server."}
        self._status = data
        # Report the effective operator budget rather than promising the service
        # maximum when this profile deliberately requests a smaller answer.
        try:
            data['limits']['effective_output_tokens'] = self.output_limit
            self.prompt_limit
            self.prompt_byte_limit
            self.message_limit
            context = data['limits'].get('context_tokens', data.get('context_tokens'))
            prompt_tokens = data['limits'].get('max_prompt_tokens')
            if context is not None:
                if type(context) is not int or not 256 <= context <= 10_000_000:
                    raise BlochAIError('The provider advertised an invalid context window.')
                data['limits']['context_tokens'] = context
            if prompt_tokens is not None and (type(prompt_tokens) is not int or prompt_tokens < 1 or (context is not None and prompt_tokens >= context)):
                raise BlochAIError('The provider advertised an invalid input token budget.')
        except BlochAIError:
            self._status = None
            raise
        return data

    def check_private_contract(self,data):
        from ..network.private_inference import PRIVACY
        if (data.get('privacy')!=PRIVACY or not isinstance(data.get('processing_region'),str) or not data['processing_region'].strip()
                or data.get('model')!=self.settings.model or data.get('model_digest')!=self.settings.model_digest):
            raise BlochAIError('The private inference service did not confirm its data-handling contract and region.')

    @property
    def prompt_limit(self):
        data = self._status or self.status()
        value = data["limits"].get("max_prompt_chars")
        if type(value) is not int or not 256 <= value <= 1_000_000:
            raise BlochAIError("The provider advertised an invalid prompt limit.")
        return min(value, 240000)

    @property
    def prompt_byte_limit(self):
        data = self._status or self.status()
        value = data['limits'].get('max_prompt_bytes')
        if value is None and self.settings.provider != 'private':
            return self.prompt_limit * 4
        if type(value) is not int or not 256 <= value <= 4_000_000:
            raise BlochAIError('The provider advertised an invalid prompt byte limit.')
        token_budget = data['limits'].get('max_prompt_tokens')
        if data['limits'].get('token_counting') == 'utf8_upper_bound' and type(token_budget) is int and token_budget > 0:
            value = min(value, token_budget)
        return min(value, 960000)

    @property
    def output_limit(self):
        data = self._status or self.status()
        value = data['limits'].get('max_new_tokens')
        if type(value) is not int or value < 1:
            raise BlochAIError('The provider advertised an invalid generation budget.')
        return min(self.settings.max_output_tokens, value)

    @property
    def message_limit(self):
        data = self._status or self.status()
        value = data['limits'].get('max_messages', 32 if self.settings.provider == 'private' else 256)
        if type(value) is not int or not 2 <= value <= 1024:
            raise BlochAIError('The provider advertised an invalid conversation message limit.')
        return min(value, 256)

    def messages_fit(self, messages):
        """Check advertised transport limits; the service enforces its model context."""
        text = self.flatten(messages)
        return (len(messages) <= self.message_limit and len(text) <= self.prompt_limit
                and len(text.encode('utf-8')) <= self.prompt_byte_limit)

    def context_budget(self, messages):
        """Reserve enough UTF-8 bytes for optional excerpts, without guessing tokens."""
        text = self.flatten(messages)
        return max(0, min(self.prompt_limit - len(text),
                          (self.prompt_byte_limit - len(text.encode('utf-8'))) // 4))

    def flatten(self, messages):
        return "\n\n".join(f"{m['role'].upper()}: {m['content']}" for m in messages)

    def complete(self, messages, json_mode=False):
        if self.private_local:
            # Ollama can proxy cloud models through localhost. Recheck before each
            # generation, including agent iterations; a cached tag name is not proof.
            info=self.request('POST','/api/show',json={'model':self.settings.model},timeout=5)
            if info.get('remote_host') or info.get('remote_model') or not isinstance(info.get('model_info'),dict) or not info['model_info']:
                raise BlochAIError('Este modelo usa processamento remoto ou não confirmou pesos locais. Nenhum conteúdo foi enviado para geração.')
        data = self._status or self.status()
        if not data.get("ready"):
            raise BlochAIError("The configured inference provider is not ready. Check blochai status.")
        if not self.messages_fit(messages):
            raise BlochAIError("The conversation exceeds the model's context character or byte budget, or message limit. Start a new chat or narrow the task.")
        budget = self.output_limit
        if self.settings.provider=='private':
            self.check_private_contract(data)
            result=self.request('POST','/v1/private/completions',json={
                'tenant_id':self.settings.tenant,'model':self.settings.model,'messages':messages,
                'max_new_tokens':budget,'json_mode':json_mode},timeout=self.settings.timeout)
            self.check_private_contract(result)
            if result.get('tenant_id')!=self.settings.tenant or result.get('finish_reason')!='stop':
                raise BlochAIError('Private inference returned a mismatched account or model.')
            output=result.get('output')
            if not isinstance(output,str) or not output.strip():raise BlochAIError('Private inference returned no answer.')
            return Generation(output,self.settings.model,output_tokens=result.get('output_tokens'))
        if self.settings.provider == "ollama":
            payload = {"model": self.settings.model, "messages": messages, "stream": False,
                       "options": {"temperature": 0, "num_predict": budget}}
            if json_mode:
                payload["format"] = "json"
            result = self.request("POST", "/api/chat", json=payload, timeout=self.settings.timeout)
            message = result.get("message", {})
            if not result.get("done") or result.get("done_reason") == "length":
                raise BlochAIError("Model output was incomplete. Increase the output budget or request a smaller change.")
            output = message.get("content")
            if not isinstance(output, str) or not output.strip():
                raise BlochAIError("The model returned no answer.")
            return Generation(output, result.get("model", self.settings.model), output_tokens=result.get("eval_count"))
        portal = self.settings.provider == "rednblue"
        payload = {"prompt": self.flatten(messages), "max_new_tokens": max(16,budget) if portal else budget}
        if not portal:
            payload["tenant_id"] = self.settings.tenant
        if self.settings.model and not portal:
            payload["model"] = self.settings.model
        task = self.request("POST", "/api/porb/v1/blochai/tasks" if portal else "/v1/tasks", json=payload)
        if portal and data.get("organization_id") and task.get("organization_id") != data["organization_id"]:
            raise BlochAIError("The active organization changed. Start a new run.")
        task_id = task.get("task_id", "")
        if not isinstance(task_id, str) or not re.fullmatch(r"[a-f0-9]{64}", task_id):
            raise BlochAIError("The gateway returned an invalid tracking ID. The request is not automatically retried.")
        self.on_task(task_id)
        deadline = time.monotonic() + self.settings.timeout
        while task.get("status") not in ("COMPLETED", "FAILED"):
            if task.get("status") not in ("PENDING", "ASSIGNED", "READY"):
                raise BlochAIError(f"Unknown task status; inspect task {task_id}.")
            if time.monotonic() >= deadline:
                raise BlochAIError(f"Task still running: {task_id}. Use blochai task {task_id} to retrieve it.")
            interval = task.get("poll_after_ms", 1500)
            interval = interval if isinstance(interval, (int, float)) else 1500
            time.sleep(min(max(interval / 1000, 0.05), 5, max(0, deadline - time.monotonic())))
            task = self.task(task_id)
        if task["status"] == "FAILED":
            raise BlochAIError(f"Inference task {task_id} failed. No answer was generated.")
        output = task.get("output")
        if not isinstance(output, str) or not output.strip():
            raise BlochAIError("The completed task has no model answer.")
        return Generation(output, task.get("model", data["model"]), task_id=task_id)

    def task(self, task_id):
        if self.settings.provider not in ("gateway", "rednblue") or not re.fullmatch(r"[a-f0-9]{64}", task_id):
            raise BlochAIError("Use a valid gateway task ID.")
        if self.settings.provider == "rednblue":
            result = self.request("GET", "/api/porb/v1/blochai/tasks/" + task_id)
            expected = (self._status or {}).get("organization_id")
            if expected and result.get("organization_id") != expected:
                raise BlochAIError("The active organization changed. Start a new run.")
            return result
        return self.request("GET", "/v1/tasks/" + task_id, params={"tenant_id": self.settings.tenant})
