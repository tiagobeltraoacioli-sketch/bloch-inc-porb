"""Bounded attachment inspection in a separate process; uploaded code never executes."""
from __future__ import annotations

import io
import json
from pathlib import Path
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

MAX_UPLOAD = 10 * 1024 * 1024
MAX_TEXT = 50000
IMAGE_TYPES = {'.png':'PNG', '.jpg':'JPEG', '.jpeg':'JPEG', '.webp':'WEBP', '.gif':'GIF'}
MIME_TYPES = {
    '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.webp':'image/webp', '.gif':'image/gif',
    '.pdf':'application/pdf', '.docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.pptx':'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    '.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    '.txt':'text/plain', '.md':'text/markdown', '.csv':'text/csv', '.json':'application/json',
}


class InvalidAttachment(ValueError):
    pass


def office_archive(data, required):
    try:
        archive=zipfile.ZipFile(io.BytesIO(data))
        entries=archive.infolist()
        if len(entries)>2000 or sum(item.file_size for item in entries)>64*1024*1024:
            raise InvalidAttachment('Documento compactado excede o limite de leitura.')
        for item in entries:
            if item.flag_bits&1 or item.file_size>12*1024*1024 or item.file_size>max(1,item.compress_size)*300:
                raise InvalidAttachment('Documento protegido ou compactado além do limite de leitura.')
            if item.filename.startswith('/') or '..' in Path(item.filename).parts or '\\' in item.filename or 'vbaproject' in item.filename.lower():
                raise InvalidAttachment('Documentos com macros ou caminhos inválidos não são aceitos.')
        if required not in archive.namelist() or '[Content_Types].xml' not in archive.namelist():
            raise InvalidAttachment('O conteúdo não corresponde ao tipo de documento escolhido.')
        return archive
    except zipfile.BadZipFile as exc:
        raise InvalidAttachment('O documento Office está inválido ou corrompido.') from exc


def xml(archive, name):
    data=archive.read(name)
    if len(data)>5*1024*1024 or b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
        raise InvalidAttachment('O documento contém XML não suportado.')
    return ET.fromstring(data)


def inspect(data, extension):
    """Return extracted data and an optional normalized image preview."""
    result={'kind':'document','mime':MIME_TYPES[extension],'text':'','truncated':False,'note':''}
    preview=None
    if extension in IMAGE_TYPES:
        import warnings
        from PIL import Image, ImageOps
        Image.MAX_IMAGE_PIXELS=12_000_000
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('error',Image.DecompressionBombWarning)
                with Image.open(io.BytesIO(data)) as original:
                    if original.format!=IMAGE_TYPES[extension] or original.width*original.height>12_000_000:
                        raise InvalidAttachment('Imagem incompatível ou maior que 12 megapixels.')
                    width,height=original.size
                    original.verify()
                with Image.open(io.BytesIO(data)) as original:
                    picture=ImageOps.exif_transpose(original).convert('RGBA')
                    picture.thumbnail((640,640))
                    stream=io.BytesIO();picture.save(stream,format='PNG');preview=stream.getvalue()
            result.update(kind='image',width=width,height=height,note='Prévia disponível. O modelo atual lê texto e ainda não analisa o conteúdo visual de imagens.')
        except InvalidAttachment:
            raise
        except Exception as exc:
            raise InvalidAttachment('Não foi possível validar esta imagem. Use PNG, JPG, WebP ou GIF até 12 megapixels.') from exc
    elif extension=='.pdf':
        from pypdf import PdfReader
        if not data.startswith(b'%PDF-'):
            raise InvalidAttachment('O conteúdo não corresponde a um PDF.')
        reader=PdfReader(io.BytesIO(data),strict=False)
        if reader.is_encrypted:
            raise InvalidAttachment('Este PDF tem senha. Envie uma cópia sem senha.')
        parts=[];length=0
        for index,page in enumerate(reader.pages):
            if index>=30 or length>=MAX_TEXT:
                result['truncated']=True;break
            part=f'Página {index+1}\n'+(page.extract_text() or '')
            parts.append(part);length+=len(part)
        result['text']='\n\n'.join(parts)
        # Page labels alone must not masquerade as extracted document text.
        if not any(re.sub(r'^Página \d+\s*','',part).strip() for part in parts):
            result['text']='';result['note']='PDF sem texto selecionável. OCR ainda não está disponível.'
    elif extension=='.docx':
        with office_archive(data,'word/document.xml') as archive:
            document=xml(archive,'word/document.xml')
            paragraphs=[]
            for paragraph in document.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'):
                paragraphs.append(''.join(node.text or '' for node in paragraph.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t')))
            result['text']='\n'.join(paragraphs)
    elif extension=='.pptx':
        with office_archive(data,'ppt/presentation.xml') as archive:
            names=sorted((name for name in archive.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml',name)),key=lambda name:int(re.search(r'(\d+)\.xml',name).group(1)))
            parts=[]
            for index,name in enumerate(names[:30]):
                slide=xml(archive,name)
                parts.append(f'Slide {index+1}\n'+'\n'.join(node.text or '' for node in slide.iter('{http://schemas.openxmlformats.org/drawingml/2006/main}t')))
            result['text']='\n\n'.join(parts);result['truncated']=len(names)>30
    elif extension=='.xlsx':
        from openpyxl import load_workbook
        with office_archive(data,'xl/workbook.xml'):
            pass
        book=load_workbook(io.BytesIO(data),read_only=True,data_only=True,keep_links=False)
        try:
            parts=[];length=0
            for sheet in book.worksheets[:5]:
                parts.append('Planilha: '+sheet.title)
                for index,row in enumerate(sheet.iter_rows(values_only=True)):
                    if index>=200 or length>=MAX_TEXT:
                        result['truncated']=True;break
                    part=' | '.join('' if value is None else str(value)[:1000] for value in row[:30])
                    parts.append(part);length+=len(part)
                    if len(row)>30:result['truncated']=True
                if length>=MAX_TEXT:break
            result['text']='\n'.join(parts);result['truncated']|=len(book.worksheets)>5
            result['note']='Leitura dos valores salvos. Fórmulas sem resultado salvo não são calculadas.'
        finally:book.close()
    else:
        try:content=data.decode('utf-8-sig')
        except UnicodeError as exc:raise InvalidAttachment('Envie documentos de texto na codificação UTF-8.') from exc
        if '\x00' in content:
            raise InvalidAttachment('O arquivo contém dados binários incompatíveis com texto.')
        if extension=='.json':json.loads(content)
        result['text']=content
    if len(result['text'])>MAX_TEXT:
        result['text']=result['text'][:MAX_TEXT];result['truncated']=True
    result['text']=re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]','',result['text'])
    result['text_chars']=len(result['text'])
    if result['kind']=='document' and not result['text'].strip() and not result['note']:
        result['note']='Nenhum texto foi extraído deste documento.'
    return result,preview


def limit_resources():
    """Constrain the dedicated parser process; this is not an OS sandbox."""
    if sys.platform=='win32':
        import ctypes as c
        from ctypes import wintypes as w
        class Basic(c.Structure):
            _fields_=[('process_time',c.c_longlong),('job_time',c.c_longlong),('flags',w.DWORD),
                      ('minimum_working_set',c.c_size_t),('maximum_working_set',c.c_size_t),
                      ('active_processes',w.DWORD),('affinity',c.c_size_t),('priority',w.DWORD),('scheduling',w.DWORD)]
        class Limits(c.Structure):
            _fields_=[('basic',Basic),('io_counters',c.c_ulonglong*6),('process_memory',c.c_size_t),
                      ('job_memory',c.c_size_t),('peak_process_memory',c.c_size_t),('peak_job_memory',c.c_size_t)]
        kernel=c.WinDLL('kernel32',use_last_error=True)
        kernel.CreateJobObjectW.argtypes=[c.c_void_p,w.LPCWSTR];kernel.CreateJobObjectW.restype=w.HANDLE
        kernel.SetInformationJobObject.argtypes=[w.HANDLE,c.c_int,c.c_void_p,w.DWORD]
        kernel.AssignProcessToJobObject.argtypes=[w.HANDLE,w.HANDLE]
        kernel.GetCurrentProcess.restype=w.HANDLE
        kernel.CloseHandle.argtypes=[w.HANDLE]
        job=kernel.CreateJobObjectW(None,None)
        if not job:raise c.WinError(c.get_last_error())
        limits=Limits();limits.basic.flags=0x2|0x8|0x100
        limits.basic.process_time=15*10_000_000;limits.basic.active_processes=1
        limits.process_memory=768*1024*1024
        if not kernel.SetInformationJobObject(job,9,c.byref(limits),c.sizeof(limits)) or not kernel.AssignProcessToJobObject(job,kernel.GetCurrentProcess()):
            error=c.get_last_error();kernel.CloseHandle(job);raise c.WinError(error)
        # The OS releases the process's job handle at exit. Do not close it early.
        return job
    import resource
    resource.setrlimit(resource.RLIMIT_CPU,(15,15))
    resource.setrlimit(resource.RLIMIT_FSIZE,(3*1024*1024,3*1024*1024))
    if sys.platform.startswith('linux'):
        resource.setrlimit(resource.RLIMIT_AS,(768*1024*1024,768*1024*1024))


def main():
    source=Path(sys.argv[1]);extension=source.suffix.lower();destination=Path(sys.argv[2])
    try:
        parser_job=limit_resources()
        if source.stat().st_size>MAX_UPLOAD or extension not in MIME_TYPES:raise InvalidAttachment('Tipo ou tamanho de arquivo não suportado.')
        result,preview=inspect(source.read_bytes(),extension)
        if preview and len(preview)>3*1024*1024:raise InvalidAttachment('A prévia excedeu o limite de saída.')
        (destination/'inspection.json').write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
        if preview:(destination/'preview.png').write_bytes(preview)
    except Exception as exc:
        message=str(exc) if isinstance(exc,InvalidAttachment) else 'Não foi possível ler este arquivo. Confira se ele está íntegro e em um formato aceito.'
        (destination/'inspection.json').write_text(json.dumps({'error':message}),encoding='utf-8')
        return 1
    return 0


if __name__=='__main__':raise SystemExit(main())
