"""Cooperative cross-process locking for Qentl project file replacements."""
from contextlib import contextmanager
import errno
import hashlib
import os
import stat
import threading
import time

from .config import BlochAIError, private_directory, state_home


# Bounded stripes also serialize threads on platforms with process-scoped locks.
_THREAD_LOCKS = [threading.RLock() for _ in range(64)]
_HELD = threading.local()


@contextmanager
def project_write_lock(root, timeout=10):
    key = hashlib.sha256(os.path.normcase(str(root.resolve())).encode()).hexdigest()
    directory = state_home() / 'write-locks'
    private_directory(directory)
    path = directory / (key + '.lock')
    deadline = time.monotonic() + timeout
    local = _THREAD_LOCKS[int(key[:8], 16) % len(_THREAD_LOCKS)]
    if not local.acquire(timeout=max(0, deadline-time.monotonic())):
        raise BlochAIError('Another Qentl edit is in progress. Retry after it finishes.')
    held = getattr(_HELD, 'keys', None)
    if held is None:
        held = _HELD.keys = set()
    if key in held:
        try:yield
        finally:local.release()
        return
    fd = None
    locked = False
    try:
        if path.is_symlink():
            raise BlochAIError('Invalid project write lock.')
        fd = os.open(path, os.O_CREAT | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise BlochAIError('Invalid project write lock.')
        if info.st_size == 0:
            os.write(fd, b'\0')
        if os.name == 'nt':
            import msvcrt
            def acquire():
                os.lseek(fd, 0, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            def release():
                os.lseek(fd, 0, os.SEEK_SET)
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            def acquire():fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            def release():fcntl.flock(fd, fcntl.LOCK_UN)
        while True:
            try:
                acquire();locked = True;break
            except OSError as exc:
                if exc.errno not in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):raise
                if time.monotonic() >= deadline:
                    raise BlochAIError('Another Qentl edit is in progress. Retry after it finishes.') from exc
                time.sleep(min(.05, max(0, deadline-time.monotonic())))
        held.add(key)
        try:yield
        finally:held.remove(key)
    finally:
        if fd is not None:
            try:
                if locked:release()
            finally:os.close(fd)
        local.release()
