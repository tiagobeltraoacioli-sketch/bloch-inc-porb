"""Atomic private imports of inert UTF-8 project source files, never archives."""
from __future__ import annotations

import base64
import binascii
import hashlib
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import secrets
import shutil
import tempfile
import unicodedata

from .config import BlochAIError, private_directory
from .projects import CODE_EXTENSIONS, MAX_CODE_FILES
from .store import scrub
from .workspace import Workspace, blocked
from .ingest_policy import current_policy, ensure_space


MAX_FILES = 500
MAX_FILE_BYTES = 200_000
MAX_DECODED_BYTES = 20 * 1024 * 1024
MAX_REQUEST_BYTES = 30 * 1024 * 1024
REQUEST_TIMEOUT_SECONDS = 60.0
MAX_SOURCE_PARTS = 6
SKIP_DIRECTORIES = frozenset(("node_modules", "venv", "env", "__pycache__", "target",
                              "dist", "build", "coverage", "vendor", ".next", ".nuxt",
                              ".cache", ".tox", ".git", ".venv"))
_CREDENTIAL = re.compile(
    r"-----BEGIN [^-\r\n]*PRIVATE KEY-----|"
    r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b|\bgh[pousr]_[A-Za-z0-9]{20,}\b|"
    r"\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}\b|"
    r"\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\b|"
    r"[\"']?(?:api[_-]?key|access[_-]?token|client[_-]?secret|password|passphrase|"
    r"aws_access_key_id|aws_secret_access_key)[\"']?\s*[:=]\s*[\"']?[^\s\"',;]+", re.I)


def _path(value):
    if (not isinstance(value, str) or not 1 <= len(value) <= 180 or "\\" in value
            or value.startswith("/") or ":" in value
            or any(unicodedata.category(char).startswith("C") for char in value)):
        raise BlochAIError("Use portable relative folder paths without control characters.")
    value = unicodedata.normalize("NFC", value)
    parts = value.split("/")
    if len(parts) < 2 or any(not part or part in (".", "..") for part in parts):
        raise BlochAIError("Each folder file needs one root folder and a safe relative path.")
    if any(len(part) > 100 or part.endswith((" ", ".")) or part.startswith(" ")
           or any(char in '<>"|?*' for char in part) or PureWindowsPath(part).is_reserved()
           for part in parts):
        raise BlochAIError("Folder paths contain a reserved or nonportable filename.")
    return "/".join(parts)


def _manifest(files):
    if not isinstance(files, list) or not 1 <= len(files) <= MAX_FILES:
        raise BlochAIError("Import a folder containing 1 to 500 files per request.")
    prepared, nodes, root, total = [], {}, None, 0
    for item in files:
        if not isinstance(item, dict) or set(item) != {"path", "content_base64"}:
            raise BlochAIError("Each folder entry must contain only path and content_base64; links are not accepted.")
        path = _path(item["path"])
        parts = path.split("/")
        if root is None:
            root = parts[0]
        if parts[0] != root:
            raise BlochAIError("Import exactly one root folder at a time.")
        for index in range(1, len(parts) + 1):
            prefix = "/".join(parts[:index])
            key = prefix.casefold()
            kind = "file" if index == len(parts) else "directory"
            if key in nodes and (nodes[key] != (prefix, kind) or kind == "file"):
                raise BlochAIError("Folder paths collide after case folding or file/directory normalization.")
            nodes[key] = (prefix, kind)
        encoded = item["content_base64"]
        if not isinstance(encoded, str) or not encoded.isascii() or len(encoded) % 4:
            raise BlochAIError("Folder content must use canonical base64 encoding.")
        if not re.fullmatch(r"[A-Za-z0-9+/]*={0,2}", encoded):
            raise BlochAIError("Folder content must use canonical base64 encoding.")
        size = len(encoded) // 4 * 3 - (2 if encoded.endswith("==") else 1 if encoded.endswith("=") else 0)
        total += size
        if total > MAX_DECODED_BYTES:
            raise BlochAIError("The folder exceeds the 20 MiB decoded import limit.")
        prepared.append((path, parts, encoded, size))
    return root, prepared


def _skip_reason(parts, size):
    if any(part.startswith(".") or blocked(part.lower()) or part.casefold() in SKIP_DIRECTORIES for part in parts):
        return "protected_path"
    if len(parts) > MAX_SOURCE_PARTS:
        return "depth_limit"
    if size > MAX_FILE_BYTES:
        return "file_too_large"
    if PurePosixPath(parts[-1]).suffix.lower() not in CODE_EXTENSIONS and parts[-1] not in ("Dockerfile", "Makefile"):
        return "unsupported_type"
    return None


def import_folder(catalog, project, files, *, before_publish=None, secret_values=(), source_metadata=None, import_id=None):
    """Validate all paths, stage outside the project, then publish one new namespace.

    The HTTP caller holds the project lock and rechecks authorization through
    before_publish. No imported source is executed or enrolled in training.
    Suspected credentials are skipped entirely, not stored in a quarantine copy.
    """
    project_folder = catalog.folder(project)
    original_identity = (project_folder.stat().st_dev, project_folder.stat().st_ino)
    root, prepared = _manifest(files)
    accepted, skipped = [], []
    for path, parts, encoded, size in prepared:
        reason = _skip_reason(parts, size)
        if reason:
            skipped.append({"path": path, "reason": reason})
            continue
        try:
            raw = base64.b64decode(encoded, validate=True)
            if base64.b64encode(raw).decode("ascii") != encoded:
                raise BlochAIError("Folder content must use canonical base64 encoding.")
            text = raw.decode("utf-8")
        except binascii.Error as exc:
            raise BlochAIError("Folder content must use canonical base64 encoding.") from exc
        except UnicodeError:
            skipped.append({"path": path, "reason": "binary_or_invalid_utf8"})
            continue
        if any(ord(char) < 32 and char not in "\t\r\n" for char in text):
            skipped.append({"path": path, "reason": "binary_or_invalid_utf8"})
            continue
        if _CREDENTIAL.search(text) or scrub(text, secret_values) != text:
            skipped.append({"path": path, "reason": "credential_content"})
            continue
        accepted.append((path, raw))
    namespace = None
    workspace = Workspace(project_folder, lambda *_: False, allow_commands=False)
    if import_id is not None:
        if source_metadata is not None:
            raise BlochAIError("Repository snapshots cannot append to a folder reservation.")
        from .folder_batches import receipt, preflight
        namespace = receipt(catalog, project, import_id, root)['path']
        accepted, repeated = preflight(workspace, namespace, accepted)
        skipped.extend(repeated)
    existing = catalog.code_files(project)
    limit = current_policy()['max_source_files']
    if existing["truncated"] or len(existing["files"]) + len(accepted) > limit:
        raise BlochAIError(f"The project would exceed its {limit} source-file count limit.")
    result = {"import_id": import_id, "root": root, "path": namespace, "accepted": [], "skipped": skipped,
              "files_imported": 0, "bytes_imported": 0, "training_use": "Private project only; not training data.",
              "execution": "No imported code was executed."}
    if not accepted:
        if before_publish is not None:before_publish()
        return result
    ensure_space(project_folder, sum(len(raw) for _, raw in accepted), extra_bytes=1024*1024)
    if import_id is not None:
        from .folder_batches import publish_append
        if before_publish is not None:before_publish()
        checked = catalog.folder(project)
        if (checked.stat().st_dev, checked.stat().st_ino) != original_identity:
            raise BlochAIError("The project changed during import. No files were published.")
        receipt(catalog, project, import_id, root)
        # Revalidate collisions after an authorization callback that can block.
        fresh, repeated = preflight(workspace, namespace, accepted)
        result['skipped'].extend(repeated)
        publish_append(workspace, namespace, fresh)
        result['accepted'] = [{"source_path": relative, "path": namespace + "/" + relative,
                               "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()} for relative, raw in fresh]
        result.update(files_imported=len(fresh), bytes_imported=sum(len(raw) for _, raw in fresh))
        return result
    slug = re.sub(r"[^a-z0-9]+", "-", unicodedata.normalize("NFKD", root).encode("ascii", "ignore").decode().lower()).strip("-")[:32] or "folder"
    identifier = secrets.token_hex(8)
    namespace = "imports/" + slug + "-" + identifier
    workspace = Workspace(project_folder, lambda *_: False, allow_commands=False)
    imports = workspace.path("imports", directory=True)
    destination = workspace.path(namespace, directory=True)
    if destination.exists():
        raise BlochAIError("The import destination already exists. Retry with a new import.")
    staging = Path(tempfile.mkdtemp(prefix=".qentl-folder-", dir=str(project_folder.parent)))
    try:
        private_directory(staging)
        if source_metadata is not None:
            import json
            raw=json.dumps(source_metadata,ensure_ascii=False,allow_nan=False).encode('utf-8')
            if not isinstance(source_metadata,dict) or len(raw)>300000:raise BlochAIError('Repository provenance exceeds its size limit.')
            marker=staging/'.qentl-source.json';marker.write_bytes(raw);marker.chmod(0o600)
        for relative, raw in accepted:
            target = staging.joinpath(*relative.split("/"))
            parents = list(target.parent.relative_to(staging).parents)
            for parent in reversed(parents):
                if str(parent) != ".":
                    private_directory(staging / parent)
            private_directory(target.parent)
            with target.open("xb") as output:
                output.write(raw)
            target.chmod(0o600)
        if before_publish is not None:
            before_publish()
        checked = catalog.folder(project)
        if (checked.stat().st_dev, checked.stat().st_ino) != original_identity:
            raise BlochAIError("The project changed during import. No files were published.")
        workspace.path("imports", directory=True)
        private_directory(imports)
        workspace.path(namespace, directory=True)
        if destination.exists():
            raise BlochAIError("The import destination appeared during import. Existing files were preserved.")
        # One same-filesystem rename exposes the entire validated file set at once.
        staging.rename(destination)
        for relative, raw in accepted:
            result["accepted"].append({"source_path": relative, "path": namespace + "/" + relative,
                                       "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
        result.update(import_id=identifier, path=namespace, files_imported=len(accepted),
                      bytes_imported=sum(len(raw) for _, raw in accepted))
        return result
    finally:
        if staging.exists():
            shutil.rmtree(staging)
