"""Owner/project-bound append-only import reservations for bounded folder batches."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import unicodedata

from .config import BlochAIError, private_directory, save_json
from .ingest_policy import current_policy, ensure_space
from .workspace import Workspace

ID = re.compile(r'[a-f0-9]{16}')


def _directory(catalog, project):
    folder = catalog.state.parent / 'folder-imports' / project
    for path in (catalog.state.parent, folder.parent, folder):
        if path.is_symlink():
            raise BlochAIError('Folder import state cannot contain links.')
    return folder


def reserve(catalog, project, name):
    from .folder_import import _path
    if not current_policy()['resumable_folder_batches']:
        raise BlochAIError('Resumable folder batches require the operator internal profile.')
    if not isinstance(name, str) or '/' in name:
        raise BlochAIError('Provide only the selected root folder name.')
    root = _path(name + '/probe.py').split('/')[0]
    folder = catalog.folder(project); stat = folder.stat()
    directory = _directory(catalog, project); private_directory(directory)
    if sum(1 for _ in directory.iterdir()) >= 256:
        raise BlochAIError('This project has reached its folder import reservation limit.')
    identifier = secrets.token_hex(8)
    slug = re.sub(r'[^a-z0-9]+', '-', unicodedata.normalize('NFKD', root).encode('ascii', 'ignore').decode().lower()).strip('-')[:32] or 'folder'
    namespace = 'imports/' + slug + '-' + identifier
    ensure_space(folder, 8192)
    receipt = {'schema': 'qentl-folder-import-v1', 'id': identifier, 'owner': catalog.owner,
               'project': project, 'generation': [stat.st_dev, stat.st_ino],
               'root': root, 'path': namespace, 'training_allowed': False}
    path = directory / (identifier + '.json')
    if path.exists():
        raise BlochAIError('A folder import reservation already exists; no files were changed.')
    save_json(path, receipt)
    return {'import_id': identifier, 'root': root, 'path': namespace, 'files_imported': 0, 'bytes_imported': 0}


def receipt(catalog, project, identifier, root):
    if not current_policy()['resumable_folder_batches'] or not isinstance(identifier, str) or not ID.fullmatch(identifier):
        raise BlochAIError('Invalid folder import reservation.')
    path = _directory(catalog, project) / (identifier + '.json')
    if not path.is_file() or path.is_symlink() or path.stat().st_nlink != 1 or path.stat().st_size > 8192:
        raise BlochAIError('Folder import reservation not found.')
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise BlochAIError('Folder import reservation is invalid.') from exc
    stat = catalog.folder(project).stat()
    if (not isinstance(value, dict) or value.get('schema') != 'qentl-folder-import-v1'
            or value.get('id') != identifier or value.get('owner') != catalog.owner
            or value.get('project') != project or value.get('root') != root
            or value.get('generation') != [stat.st_dev, stat.st_ino]
            or not isinstance(value.get('path'), str)
            or not re.fullmatch(r'imports/[a-z0-9-]{1,32}-' + identifier, value['path'])):
        raise BlochAIError('The folder import reservation does not match this account, project or root.')
    return value


def _existing_bytes(workspace, relative, size):
    path = workspace.path(relative)
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
    with os.fdopen(fd, 'rb') as stream:
        details = os.fstat(stream.fileno())
        if not stat.S_ISREG(details.st_mode) or details.st_nlink != 1 or details.st_size != size:
            raise BlochAIError('An imported path changed during retry. Existing files were preserved.')
        return stream.read(size + 1)


def preflight(workspace, namespace, accepted):
    """Check cross-batch case collisions and idempotent repeats before staging."""
    destination = workspace.path(namespace, directory=True)
    existing = {}
    visited = 0
    if destination.exists():
        if not destination.is_dir():
            raise BlochAIError('The reserved import path is no longer a directory.')
        def inaccessible(_):
            raise BlochAIError('An import directory could not be inspected.')
        for directory, dirs, names in os.walk(destination, followlinks=False, onerror=inaccessible):
            for name in dirs + names:
                visited += 1
                if visited > 60000:
                    raise BlochAIError('Folder import namespace exceeds its inspection budget.')
                path = Path(directory) / name
                relative = path.relative_to(destination).as_posix()
                checked = workspace.path(namespace + '/' + relative, directory=name in dirs)
                kind = 'directory' if name in dirs else 'file'
                if (kind == 'file' and not checked.is_file()) or (kind == 'directory' and not checked.is_dir()):
                    raise BlochAIError('Unexpected folder import entry.')
                key = relative.casefold()
                if key in existing and existing[key] != (relative, kind):
                    raise BlochAIError('Existing import paths collide after case folding.')
                existing[key] = (relative, kind)
    fresh, repeated = [], []
    for relative, raw in accepted:
        parts = relative.split('/')
        for index in range(1, len(parts) + 1):
            prefix = '/'.join(parts[:index]); kind = 'file' if index == len(parts) else 'directory'
            previous = existing.get(prefix.casefold())
            if previous is not None and previous != (prefix, kind):
                raise BlochAIError('Folder batch paths collide with an earlier batch.')
        target = workspace.path(namespace + '/' + relative)
        if target.exists():
            if target.stat().st_size != len(raw) or hashlib.sha256(_existing_bytes(workspace, namespace + '/' + relative, len(raw))).digest() != hashlib.sha256(raw).digest():
                raise BlochAIError('An imported path already has different content. Existing files were preserved.')
            repeated.append({'path': relative, 'reason': 'already_imported'})
        else:
            fresh.append((relative, raw))
    return fresh, repeated


def publish_append(workspace, namespace, accepted):
    """Create only absent files, rolling back this batch on a known failure."""
    created = []; directories = []
    try:
        for relative, raw in accepted:
            target = workspace.path(namespace + '/' + relative)
            for parent in reversed(target.parent.relative_to(workspace.root).parents):
                path = workspace.root / parent
                if str(parent) != '.' and not path.exists():
                    private_directory(path); directories.append(path)
            if not target.parent.exists():
                private_directory(target.parent); directories.append(target.parent)
            workspace.path(namespace + '/' + relative)
            ensure_space(workspace.root,len(raw))
            fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
            stat = os.fstat(fd); created.append((target, stat.st_dev, stat.st_ino))
            with os.fdopen(fd, 'wb') as stream:
                stream.write(raw)
        return
    except BaseException:
        for path, device, inode in reversed(created):
            if path.exists() and not path.is_symlink():
                stat = path.stat()
                if (stat.st_dev, stat.st_ino) == (device, inode):
                    path.unlink()
        for path in reversed(directories):
            try:path.rmdir()
            except OSError:pass
        raise
