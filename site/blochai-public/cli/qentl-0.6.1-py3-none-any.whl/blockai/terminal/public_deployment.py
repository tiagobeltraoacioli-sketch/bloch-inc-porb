"""Explicit HTTPS publication policy; desktop mode remains loopback-only."""
from dataclasses import dataclass,field
import hmac
import ipaddress
import os
from pathlib import Path
import re
from urllib.parse import urlsplit

from .config import BlochAIError
from .file_permissions import is_private


@dataclass(frozen=True)
class DeploymentPolicy:
    public_origin: str
    hosts: frozenset
    origins: frozenset
    cookie: str
    origin_secret: str=field(default='',repr=False)

    @property
    def hosted(self):
        return bool(self.public_origin)

    def trusted_transport(self, request):
        if not self.hosted:
            return True
        # Uvicorn must run with proxy_headers=False. Inspect the actual socket
        # peer, not an address substituted from forwarded headers.
        trusted=(request.client is not None and request.client.host in ('127.0.0.1', '::1')
                 and request.headers.getlist('x-forwarded-proto') == ['https'])
        if self.origin_secret:
            values=request.headers.getlist('x-qentl-origin')
            trusted=trusted and len(values)==1 and bool(re.fullmatch(r'[a-f0-9]{64}',values[0])) and hmac.compare_digest(values[0],self.origin_secret)
        return trusted

    def capabilities(self):
        return {'mode': 'hosted' if self.hosted else 'local',
                'project_storage': 'server' if self.hosted else 'this_device',
                'local_cli': not self.hosted, 'local_models': not self.hosted,
                'remote_cli': self.hosted}


def deployment_policy(public_origin=None, port=8765, desktop_secret=None):
    if public_origin is None:
        return DeploymentPolicy('', frozenset((f'127.0.0.1:{port}', f'localhost:{port}')),
                                frozenset((f'http://127.0.0.1:{port}', f'http://localhost:{port}')), 'blochai_local')
    if desktop_secret:
        raise BlochAIError('Desktop launch credentials cannot be combined with public deployment.')
    try:
        if not isinstance(public_origin, str) or not public_origin.isascii() or len(public_origin) > 254:
            raise ValueError
        parsed = urlsplit(public_origin)
        host = parsed.hostname
        if (parsed.scheme != 'https' or not host or parsed.username is not None or parsed.password is not None
                or parsed.port is not None or parsed.path not in ('', '/') or parsed.query or parsed.fragment
                or not re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?', host)
                or '.' not in host or '..' in host or any(not 1 <= len(label) <= 63 or label.startswith('-')
                                                        or label.endswith('-') for label in host.split('.'))):
            raise ValueError
        try:
            ipaddress.ip_address(host)
        except ValueError:
            pass
        else:
            raise ValueError
        origin = 'https://' + host
        if public_origin not in (origin, origin + '/'):
            raise ValueError
    except (ValueError, TypeError):
        raise BlochAIError('Configure one canonical HTTPS public origin, without credentials, port, path or query.') from None
    secret=''
    configured=os.environ.get('QENTL_ORIGIN_SECRET_FILE')
    if configured:
        path=Path(configured)
        try:
            if not path.is_absolute() or not is_private(path) or path.stat().st_size>128:raise ValueError
            secret=path.read_text(encoding='ascii').strip()
            if not re.fullmatch(r'[a-f0-9]{64}',secret):raise ValueError
        except (OSError,ValueError,UnicodeError):
            raise BlochAIError('The private hosted-origin credential needs operator review.') from None
    return DeploymentPolicy(origin, frozenset((host,)), frozenset((origin,)), '__Host-qentl_session',secret)
