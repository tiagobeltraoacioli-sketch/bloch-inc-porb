"""Isolated A16 candidate adapter training with functional held-out evaluation."""
from __future__ import annotations

import gc
import os
import random
import time
from pathlib import Path

from .config import save_json
from .curriculum import digest, evaluate_code
from .learning_feedback import run_feedback_round
from .learning_policy import validate_feedback_row
from ..training.dataset import MODEL, REVISION
from ..training.runtime import cast_frozen_embeddings, runtime_versions, validate_cuda_reservation


def append_verified_feedback(tokenizer, original_rows, encoded, rows):
    """Validate all additions before publication; never truncate code answers."""
    if type(rows) is not list or len(rows) > 3:
        raise ValueError("Feedback additions exceeded policy.")
    for row in rows:
        validate_feedback_row(row)
    seen = {digest({"messages": row["messages"], "answer": row["answer"]}) for row in original_rows}
    additions = []; skipped = []; duplicates = []
    for row in rows:
        identity = digest({"messages": row["messages"], "answer": row["answer"]})
        if identity in seen:
            duplicates.append(row["id"]); continue
        seen.add(identity)
        prefix = tokenizer.apply_chat_template(row["messages"], tokenize=True, add_generation_prompt=True)
        full = tokenizer.apply_chat_template(row["messages"] + [{"role": "assistant", "content": row["answer"]}], tokenize=True, add_generation_prompt=False)
        if full[:len(prefix)] != prefix:
            raise RuntimeError("Tokenizer prefix mismatch.")
        if len(full) > 384:
            skipped.append(row["id"]); continue
        additions.append({"ids": full, "labels": [-100] * len(prefix) + full[len(prefix):],
                          "family": row["family"], "id": row["id"]})
    encoded.extend(additions)
    return {"retained": len(additions), "retained_ids": [row["id"] for row in additions],
            "overlength_skipped": skipped, "duplicate_skipped": duplicates, "truncated": 0}


def feedback_first_schedule(encoded, retained_ids):
    """Every admitted repair is sampled within the first three optimizer steps."""
    selected = set(retained_ids)
    if len(selected) > 3 or not selected.issubset({row['id'] for row in encoded}):
        raise ValueError("Feedback schedule identity mismatch.")
    verified = [row for row in encoded if row['id'] in selected]
    original = [row for row in encoded if row['id'] not in selected]
    random.Random(20261003).shuffle(original)
    return verified + original


def train(dataset, output, steps=48, wall_seconds=1080):
    output=Path(output)
    if output.exists(): raise ValueError("Candidate directory must be new.")
    output.mkdir(parents=True,mode=0o700)
    started=time.monotonic()
    report={"schema":"blochai-coding-training-v1","status":"initializing","model":MODEL,"revision":REVISION,
            "completed_steps":0,"requested_steps":steps,"promoted":False,
            "production_model_weights_updated":False,
            "weight_update_scope":"Isolated scratch candidate adapter; no production model promotion.",
            "benchmark":"Six held-out synthetic function families; not a general coding evaluation."}
    def save():
        report["elapsed_seconds"]=round(time.monotonic()-started,2)
        save_json(output/"report.json",report)
    def remaining(): return wall_seconds-(time.monotonic()-started)
    try:
        if not 1<=steps<=96 or not 600<=wall_seconds<=1800: raise ValueError("Training budget exceeded.")
        from .learning import load_dataset
        splits,manifest=load_dataset(dataset)
        report["dataset_fingerprint"]=manifest["fingerprint"]
        report["versions"]=runtime_versions("cuda")
        os.environ.update(HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",HF_HUB_DISABLE_TELEMETRY="1",WANDB_DISABLED="true",TOKENIZERS_PARALLELISM="false")
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
        torch.set_num_threads(2);torch.manual_seed(20261003)
        if not torch.cuda.is_available(): raise RuntimeError("Isolated CUDA device unavailable; no CPU fallback.")
        free,total=torch.cuda.mem_get_info();validate_cuda_reservation(free)
        report["hardware"]={"gpu":torch.cuda.get_device_name(0),"free_vram":free,"total_vram":total}
        torch.cuda.reset_peak_memory_stats()
        cache="/var/cache/blockai-huggingface/hub"
        tokenizer=AutoTokenizer.from_pretrained(MODEL,revision=REVISION,cache_dir=cache,local_files_only=True,trust_remote_code=False)
        tokenizer.pad_token_id=tokenizer.eos_token_id
        encoded=[];skipped=[]
        for row in splits["train"]:
            prefix=tokenizer.apply_chat_template(row["messages"],tokenize=True,add_generation_prompt=True)
            full=tokenizer.apply_chat_template(row["messages"]+[{"role":"assistant","content":row["answer"]}],tokenize=True,add_generation_prompt=False)
            if full[:len(prefix)]!=prefix: raise RuntimeError("Tokenizer prefix mismatch.")
            if len(full)>384:
                skipped.append(row["id"]);continue
            encoded.append({"ids":full,"labels":[-100]*len(prefix)+full[len(prefix):],"family":row["family"],"id":row["id"]})
        report["tokenization"]={"retained":len(encoded),"overlength_skipped":skipped,"truncated":0,"sequence_limit":384}
        if len(encoded)<8: raise RuntimeError("Too few complete training examples.")
        dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        model=AutoModelForCausalLM.from_pretrained(MODEL,revision=REVISION,cache_dir=cache,local_files_only=True,trust_remote_code=False,
            torch_dtype=dtype,attn_implementation="sdpa",device_map={"":0},
            quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type="nf4",bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=dtype))
        model.config.use_cache=False
        model=prepare_model_for_kbit_training(model,use_gradient_checkpointing=True,gradient_checkpointing_kwargs={"use_reentrant":False})
        report["frozen_embedding_precision"]=cast_frozen_embeddings(model,dtype)
        model=get_peft_model(model,LoraConfig(r=4,lora_alpha=8,target_modules=["q_proj","v_proj"],lora_dropout=.05,bias="none",task_type="CAUSAL_LM"))
        model.enable_input_require_grads()
        parameters=[p for p in model.parameters() if p.requires_grad]
        if any(p.dtype!=torch.float32 for p in parameters): raise RuntimeError("Adapter dtype mismatch.")
        report["trainable_parameters"]=sum(p.numel() for p in parameters)
        report["held_out_ids"]={split:[row["id"] for row in splits[split]] for split in ("validation","test")}
        save()
        def evaluate(label):
            model.eval();results=[]
            for split in ("validation","test"):
                for row in splits[split]:
                    if remaining()<20: raise TimeoutError("Evaluation budget exhausted.")
                    tokens=tokenizer.apply_chat_template(row["messages"],tokenize=True,add_generation_prompt=True,return_tensors="pt").to("cuda")
                    with torch.inference_mode(),torch.autocast("cuda",dtype=dtype):
                        generated=model.generate(input_ids=tokens,attention_mask=torch.ones_like(tokens),do_sample=False,max_new_tokens=96,
                            max_time=15,use_cache=True,pad_token_id=tokenizer.eos_token_id)
                    answer=tokenizer.decode(generated[0,tokens.shape[1]:],skip_special_tokens=True)
                    results.append({"id":row["id"],"split":split,"family":row["family"],"answer":answer,**evaluate_code(answer,row["cases"])})
                    save_json(output/(label+"-answers.json"),{"results":results})
            return {split:{"cases":sum(r["split"]==split for r in results),"passed":sum(r["split"]==split and r["passed"] for r in results)} for split in ("validation","test")}
        with model.disable_adapter(): report["baseline"]=evaluate("baseline")
        save()
        # Generate with the immutable base, not the random/new adapter. This
        # uses the already reserved pilot device and never a serving endpoint.
        feedback_round = int(manifest["fingerprint"][:16], 16) % 10_000_000_000
        def generate_feedback(messages, *, max_seconds, max_new_tokens):
            if remaining() < 150 + max_seconds:
                raise TimeoutError("Candidate evaluation time reserved.")
            ids = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
            if len(ids) > 768:
                raise ValueError("Feedback prompt exceeds its token budget; no truncation.")
            tokens = torch.tensor([ids], dtype=torch.long, device="cuda")
            with torch.inference_mode(), torch.autocast("cuda", dtype=dtype):
                generated = model.generate(input_ids=tokens, attention_mask=torch.ones_like(tokens),
                    do_sample=False, max_new_tokens=min(96, max_new_tokens), max_time=max_seconds,
                    use_cache=True, pad_token_id=tokenizer.eos_token_id)
            return tokenizer.decode(generated[0, tokens.shape[1]:], skip_special_tokens=True)
        if remaining() < 250:
            raise TimeoutError("Insufficient bounded feedback and final evaluation budget.")
        model.eval()
        with model.disable_adapter():
            feedback = run_feedback_round(generate_feedback, feedback_round, ["sum", "length", "sort"],
                wall_seconds=100, checkpoint=lambda value: save_json(output / "feedback-round.json", value))
        retained = append_verified_feedback(tokenizer, splits["train"], encoded, feedback["verified_rows"])
        report["feedback_loop"] = {"schema": feedback["schema"], "model": MODEL, "revision": REVISION,
            "status": feedback["status"], "round_id": feedback_round, "metrics": feedback["metrics"],
            "policy": feedback["policy"], "tokenization": retained,
            "evidence_sha256": digest(feedback), "elapsed_seconds": feedback["elapsed_seconds"],
            "frozen_evaluation_used_for_feedback": False, "production_model_weights_updated": False}
        report["tokenization"]["feedback_retained"] = retained["retained"]
        report["effective_training_fingerprint"] = digest({"authorized_dataset": manifest["fingerprint"], "encoded": encoded})
        report["training_attempt_identity"] = manifest["fingerprint"]  # existing durable no-retry ledger key
        save()
        optimizer=torch.optim.AdamW(parameters,lr=5e-5)
        scaler=torch.amp.GradScaler("cuda",enabled=dtype==torch.float16)
        schedule=feedback_first_schedule(encoded, retained['retained_ids']);losses=[]
        feedback_ids=set(retained['retained_ids']); feedback_seen=set()
        report['feedback_loop']['training_steps_used']=0
        report['feedback_loop']['unique_training_examples_used']=0
        model.train();model.config.use_cache=False
        for step in range(steps):
            if remaining()<150: raise TimeoutError("Candidate evaluation time reserved; training incomplete.")
            row=schedule[step%len(schedule)]
            ids=torch.tensor([row["ids"]],dtype=torch.long,device="cuda")
            labels=torch.tensor([row["labels"]],dtype=torch.long,device="cuda")
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast("cuda",dtype=dtype):
                loss=model(input_ids=ids,attention_mask=torch.ones_like(ids),labels=labels).loss
            if not torch.isfinite(loss): raise RuntimeError("Nonfinite loss.")
            scaler.scale(loss).backward();scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(parameters,1.0);scaler.step(optimizer);scaler.update()
            losses.append(float(loss.detach().cpu()));report["completed_steps"]=step+1
            if row['id'] in feedback_ids:
                feedback_seen.add(row['id'])
                report['feedback_loop']['training_steps_used'] += 1
                report['feedback_loop']['unique_training_examples_used'] = len(feedback_seen)
            if step%8==0: save()
        del optimizer,loss,ids,labels
        gc.collect();torch.cuda.empty_cache()
        model.save_pretrained(output/"adapter-candidate",safe_serialization=True)
        # Tokenizer is the immutable base revision; do not duplicate its files
        # on every recurring candidate run.
        report["training_loss"]={"first":losses[0],"last":losses[-1],"mean":sum(losses)/len(losses)}
        report["candidate"]=evaluate("candidate")
        report["comparison"]={split:{"baseline_passed":report["baseline"][split]["passed"],"candidate_passed":report["candidate"][split]["passed"],"cases":report["candidate"][split]["cases"]} for split in ("validation","test")}
        report["improvement_on_small_benchmark"]=all(report["candidate"][s]["passed"]>=report["baseline"][s]["passed"] for s in ("validation","test")) and any(report["candidate"][s]["passed"]>report["baseline"][s]["passed"] for s in ("validation","test"))
        report["release_eligible"]=False
        report["release_reason"]="Small synthetic benchmark; needs broader independent coding, multilingual, privacy, regression and tool-use evaluation. No automatic promotion."
        report["peak_vram_reserved"]=torch.cuda.max_memory_reserved()
        report["status"]="completed"
    except Exception as exc:
        report.update(status="failed",error=type(exc).__name__+": "+str(exc)[:500],promoted=False)
    finally: save()
    return report
