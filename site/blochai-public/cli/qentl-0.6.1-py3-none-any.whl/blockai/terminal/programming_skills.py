"""Read-only, operator-authored recipes; retrieval is not a model weight update."""
from __future__ import annotations

import copy
import json
import re

from .config import BlochAIError
from .curriculum import digest, evaluate_code

SCHEMA = 'qentl-programming-skills-v1'
TOPICS = ('python', 'rust', 'cpp', 'javascript', 'typescript', 'go', 'java', 'csharp', 'sql', 'shell', 'artifacts')
TESTS = [{'input': [], 'expected': 0}, {'input': [1, -3, 7], 'expected': 5},
         {'input': [5, 5, 0], 'expected': 10}]
CODE = {
    'python': 'def solve(x):\n    return sum(x)\n',
    'rust': 'fn sum_numbers(values: &[i64]) -> i64 {\n    values.iter().sum::<i64>()\n}\n',
    'cpp': '#include <numeric>\n#include <vector>\nlong long sum_numbers(const std::vector<long long>& values) {\n    return std::accumulate(values.begin(), values.end(), 0LL);\n}\n',
    'javascript': 'function sum_numbers(values) {\n  return values.reduce((total, value) => total + value, 0);\n}\n',
}
REFERENCES = {
    'python': 'https://docs.python.org/3/library/functions.html#sum',
    'rust': 'https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.sum',
    'cpp': 'https://eel.is/c++draft/accumulate',
    'javascript': 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce',
}
ERRORS = {
    'python': {'symptom': 'A list length is returned instead of its total.', 'cause': 'Counting elements does not sum their values.', 'correction': 'Use sum(x); check negative and empty inputs.'},
    'rust': {'symptom': 'An accumulator type cannot be inferred.', 'cause': 'The sum result needs an unambiguous numeric type.', 'correction': 'Use an i64 result and sum::<i64>(); keep the reviewed bounded integer precondition.'},
    'cpp': {'symptom': 'The accumulator has the wrong numeric width.', 'cause': 'The initial value determines the accumulator type.', 'correction': 'Use 0LL with long long values, and prove input bounds before accumulation.'},
    'javascript': {'symptom': 'An empty list throws or strings concatenate.', 'cause': 'A missing initial value or nonnumeric input changes reduce behavior.', 'correction': 'Provide initial 0 and validate exact finite integer inputs before calling this bounded recipe.'},
}

# These additional recipes remain reference-only until their exact compiler or
# runtime is executed inside a separately reviewed isolation boundary.
CODE.update({
    'typescript': 'function sum_numbers(values: readonly number[]): number {\n  return values.reduce((total, value) => total + value, 0);\n}\n',
    'go': 'func sumNumbers(values []int64) int64 {\n    var total int64\n    for _, value := range values { total += value }\n    return total\n}\n',
    'java': 'static long sumNumbers(long[] values) {\n    long total = 0L;\n    for (long value : values) total += value;\n    return total;\n}\n',
    'csharp': 'static long SumNumbers(long[] values) {\n    long total = 0;\n    foreach (long value in values) { checked { total += value; } }\n    return total;\n}\n',
    'sql': '-- input_values(value) contains only bounded integers.\nSELECT COALESCE(SUM(value), 0) AS total FROM input_values;\n',
    'shell': "# Reference pipeline: at most 100 newline-delimited integers in [-1000,1000].\n# awk is required; this tool does not launch it.\nawk 'BEGIN { total=0 } /^-?[0-9]+$/ { total += $0; next } { invalid=1 } END { if (invalid) exit 2; print total }'\n",
})
for _language in ('typescript', 'go', 'java', 'csharp', 'sql', 'shell'):
    ERRORS[_language] = {
        'symptom': 'Empty input, null values or a mismatched numeric type changes the result.',
        'cause': 'The declared input contract was not preserved by the caller or query schema.',
        'correction': 'Validate the bounded integer contract, retain an explicit zero identity, and test negative and repeated values before use.'}
WORKFLOW = [
    {'step': 'specify', 'action': 'Write a small requirement, exact input/output types, limits, and independent acceptance cases.'},
    {'step': 'read', 'action': 'Consult version-matched official language documentation; keep its source and license receipt.'},
    {'step': 'solve', 'action': 'Draft one bounded pure function and record the proposed explanation as a hypothesis, not evidence.'},
    {'step': 'test', 'action': 'Use only an operator-approved isolated runner with CPU/memory/time limits, no network or private mounts. If unavailable, mark not_executed.'},
    {'step': 'criticize', 'action': 'Record actual compiler/test failures, compare expected with observed output, and distinguish input-contract errors from implementation errors.'},
    {'step': 'revise', 'action': 'Try at most two distinct alternatives; preserve failure evidence and stop repeated answers.'},
    {'step': 'confirm', 'action': 'Run separate confirmation cases never shown during repair. Reject overfitted or unverified answers.'},
    {'step': 'evaluate', 'action': 'Only an explicitly reviewed training policy may curate examples. Compare a frozen independent baseline and retain regressions without promoting them.'},
]



def _program(topic):
    verification = {'status': 'not_executed', 'tests_passed': None,
                    'reason': 'No isolated compiler/runtime execution is claimed by this reference tool.'}
    if topic == 'python':
        result = evaluate_code(CODE[topic], [(row['input'], row['expected']) for row in TESTS])
        verification = {'status': 'verified_tiny_interpreter' if result['passed'] else 'failed',
                        'tests_passed': result['tests_passed'], 'tests': result['tests'],
                        'reason': 'Only the displayed pure expression and three bounded cases were evaluated; no arbitrary Python execution.'}
    return {'id': topic + ':bounded-integer-sum-v1', 'topic': topic, 'kind': 'programming_reference',
            'requirement': 'Sum a list of at most 100 integers, each between -1000 and 1000; an empty list returns 0.',
            'solution': CODE[topic], 'tests': copy.deepcopy(TESTS), 'verification': verification,
            'common_errors': [copy.deepcopy(ERRORS[topic])],
            'critical_review': ['Check empty input, negative values, duplicates and numeric type.',
                                'These three examples do not prove correctness for arbitrary inputs; preserve the explicit precondition.',
                                'A correct example does not establish general programming competence or updated model weights.'],
            'reference_urls': [REFERENCES[topic]] if topic in REFERENCES else []}


def _artifacts():
    sections = [{'heading': 'Observed evidence', 'body': 'Replace this example with supplied evidence and explicitly labeled assumptions.'}]
    common = ['Use only supplied or explicitly retrieved evidence; never invent revenue, credentials or forecasts.',
              'Ask create_artifact to render a declarative spec; do not generate shell commands or executable templates.',
              'Report the returned path and checks only after successful generation. Downloads export requires its own explicit destination authorization.']
    return [
        {'id': 'artifacts:' + kind + '-v1', 'topic': 'artifacts', 'kind': 'document_recipe',
         'requirement': 'Generate a ' + kind.upper() + ' from bounded supplied evidence.',
         'tool_example': {'action': 'create_artifact', 'args': {'kind': kind, 'path': filename, 'spec': spec}},
         'verification': {'status': 'reference_only', 'reason': 'Retrieving this recipe does not create a file or verify a user document.'},
         'tests': checks, 'common_errors': errors, 'critical_review': common,
         'reference_urls': []}
        for kind, filename, spec, checks, errors in (
            ('pdf', 'report.pdf', {'title': 'Evidence report', 'sections': sections},
             ['Generated bytes have a PDF header; text, page count and font/layout checks are required.', 'Inspect page rendering before claiming visual quality.'],
             [{'symptom': 'Unsupported glyph or clipped text.', 'cause': 'Font coverage or layout limits were exceeded.', 'correction': 'Use supported glyphs and shorter sections; request brand qentl only when explicitly authorized.'}]),
            ('pptx', 'slides.pptx', {'title': 'Evidence presentation', 'sections': sections},
             ['Reopen the archive and confirm expected slide count and text.', 'Inspect slide rendering for overflow before claiming visual quality.'],
             [{'symptom': 'A slide contains too much text.', 'cause': 'A report paragraph was copied without editing.', 'correction': 'Split the evidence across concise sections; preserve source attribution.'}]),
            ('xlsx', 'results.xlsx', {'sheets': [{'name': 'Results', 'columns': ['Item', 'Value'], 'rows': [['Observed example', 1]], 'totals': [2]}]},
             ['Reopen the workbook and verify rows, sheet names and authored totals.', 'User-provided strings remain literal; never enable arbitrary formulas or macros.'],
             [{'symptom': 'A total column is rejected.', 'cause': 'The column contains text or the index is not 1-based.', 'correction': 'Use numeric cells or blanks and a documented 1-based totals index.'}]),
        )]


def programming_skills(topic='all'):
    """Return reviewed data or an honest generic workflow for another language."""
    if type(topic) is not str or not 1 <= len(topic) <= 32:
        raise BlochAIError('Provide a short language name or a reviewed topic.')
    requested = topic.strip().lower()
    aliases = {'c++': 'cpp', 'c#': 'csharp', 'js': 'javascript', 'ts': 'typescript',
               'golang': 'go', 'bash': 'shell', 'sh': 'shell', 'py': 'python',
               'pdf': 'artifacts', 'pptx': 'artifacts', 'xlsx': 'artifacts', 'excel': 'artifacts'}
    topic = aliases.get(requested, requested)
    if not re.fullmatch(r'[a-z][a-z0-9+# .-]{0,31}', topic) or '..' in topic:
        raise BlochAIError('Provide a language name, not a URL, path, command, or task prompt.')
    selected = TOPICS if topic == 'all' else ((topic,) if topic in TOPICS else ())
    records = []
    for name in selected:
        records.extend(_artifacts() if name == 'artifacts' else [_program(name)])
    for row in records:
        row['source'] = {'kind': 'OWNER_AUTHORED_SYNTHETIC', 'license': 'MIT', 'generator': SCHEMA}
        row['states'] = {'reference_available': True, 'retrieved': True, 'studied_by_model': False,
                         'verified': row['verification']['status'] == 'verified_tiny_interpreter', 'learned_in_weights': False}
        row['training_allowed'] = False
        row['sha256'] = digest(row)
    report = {'schema': SCHEMA, 'topic': topic, 'available_topics': list(TOPICS), 'records': records,
              'topic_status': 'reviewed_reference' if selected else 'generic_workflow_only',
              'workflow': copy.deepcopy(WORKFLOW),
              'read_only': True, 'automatic_execution': False, 'production_model_weights_updated': False,
              'notice': 'Operator-authored reference data. Reference URLs are citations, not pages fetched by this tool. Retrieval does not mean studied, mastered or learned. Only the separate reviewed Python feedback pipeline may curate training rows. An unknown language receives a general workflow, not a claimed implementation or compiler result.'}
    if len(json.dumps(report, ensure_ascii=False).encode()) > 32_000:
        raise BlochAIError('The reviewed reference pack exceeded its response budget.')
    return report
