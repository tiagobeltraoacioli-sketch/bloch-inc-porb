"""Project file tools and explicit, bounded host-command execution."""
from __future__ import annotations

import difflib
import hashlib
import os
import re
import selectors
import shlex
import signal
import subprocess
import tempfile
import time
from pathlib import Path, PureWindowsPath
from typing import Callable

from .config import BlochAIError


SKIP = {".git", ".ssh", ".aws", ".gnupg", ".codex", ".agents", ".config", ".deployment",
        ".venv", "venv", "node_modules", "__pycache__", "target", ".blochai", ".qentl-trash", ".qentl-source.json"}
PRIVATE = re.compile(r"(^\.env($|\.)|(^|[._-])(secrets?|credentials?|passwords?|tokens?)([._-]|$)|\.(key|pem|p12|pfx|keychain)$|^id_(rsa|ed25519))", re.I)
CONTROL = re.compile(r"\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\))|[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean_text(value: str) -> str:
    return CONTROL.sub("", value)


def blocked(name: str) -> bool:
    return name in SKIP or bool(PRIVATE.search(name))


class Workspace:
    def __init__(self, root: Path, approve: Callable[[str, str], bool], command_timeout=120, allow_commands=True, web_urls=(), mutation_guard=None):
        if not root.is_dir():
            raise BlochAIError("Workspace must be an existing directory. Create the project folder first.")
        self.root = root.resolve()
        stat = self.root.stat()
        self._generation = (stat.st_dev, stat.st_ino)
        self._mutation_guard = mutation_guard
        self.approve = approve
        self.command_timeout = command_timeout
        self.allow_commands = allow_commands
        self._web_urls = frozenset(web_urls)
        self.observed = {}

    def create_artifact(self, kind, path, spec=None, spec_path=None):
        from .artifacts import create_artifact
        return create_artifact(self, kind, path, spec, spec_path)

    def inspect_table(self, path, sheet=None):
        from .artifacts import inspect_table
        return inspect_table(self, path, sheet)

    def simulate_forecast(self, spec):
        from .forecast import simulate_forecast
        if self._mutation_guard:self._mutation_guard()
        # No files or commands: retain the actual calculation for document evidence.
        result=simulate_forecast(spec)
        self.forecast_result=result
        return result

    def sources(self, query):
        from .research import sources
        return sources(query)

    def programming_skills(self, topic='all'):
        from .programming_skills import programming_skills
        return programming_skills(topic)

    def read_source(self, source_id):
        from .research import read_source, source_url
        url=source_url(source_id)
        self._check_web_access()
        return read_source(source_id)

    def _check_web_access(self):
        if self.allow_commands:
            raise BlochAIError('Public web reading requires shell commands to be disabled. Use qentl analyze.')

    def read_web(self, url):
        from .research import catalog, read_web, source_url
        from .safe_web import validate_url
        url=validate_url(url,explicit_url=True)
        explicit=url in self._web_urls
        if not explicit:url=validate_url(url,explicit_url=False)
        reviewed={source_url(item['id']) for item in catalog()['references']}
        if url not in self._web_urls and url not in reviewed:
            raise BlochAIError('This URL was not supplied directly in the user request or the reviewed source catalog. Page links cannot grant further access.')
        self._check_web_access()
        return read_web(url,explicit_url=explicit)

    def path(self, relative: str, directory=False) -> Path:
        if not isinstance(relative, str) or not relative or "\x00" in relative:
            raise BlochAIError("Use a nonempty relative project path.")
        candidate = Path(relative)
        if '\\' in relative or PureWindowsPath(relative).drive or any(':' in part or part.endswith((' ','.')) or PureWindowsPath(part).is_reserved() for part in candidate.parts if part != '.'):
            raise BlochAIError('Use um caminho portátil, sem barras invertidas, nomes reservados ou sufixos de espaço/ponto.')
        if candidate.is_absolute():
            raise BlochAIError("Paths must be relative to the project, without a leading slash. No action occurred. For example use 'hello.py', never '/hello.py'.")
        if candidate.is_absolute() or ".." in candidate.parts or any(blocked(x) for x in candidate.parts):
            raise BlochAIError("Path is outside the project or contains a protected credential/state location.")
        path = self.root
        for part in candidate.parts:
            path = path / part
            if path.is_symlink():
                raise BlochAIError("Symbolic links are not accessible to project file tools.")
        if path.resolve() != self.root and self.root not in path.resolve().parents:
            raise BlochAIError("Path escapes the project.")
        if path.exists() and path.is_file() and path.stat().st_nlink > 1:
            raise BlochAIError("Hard-linked files are not accessible to project file tools.")
        if not directory and path == self.root:
            raise BlochAIError("Choose a file inside the project.")
        return path

    def list_files(self, path="."):
        folder = self.path(path, directory=True)
        if not folder.is_dir():
            raise BlochAIError("Directory does not exist.")
        entries = []
        for entry in sorted(folder.iterdir(), key=lambda p: p.name):
            if blocked(entry.name) or entry.is_symlink():
                continue
            entries.append(entry.relative_to(self.root).as_posix() + ("/" if entry.is_dir() else ""))
            if len(entries) >= 120:
                return {"entries": entries, "truncated": True}
        return {"entries": entries, "truncated": False}

    def read_file(self, path, start_line=1, lines=60):
        if type(start_line) is not int or type(lines) is not int or not 1 <= start_line <= 1_000_000 or not 1 <= lines <= 200:
            raise BlochAIError("Use a positive starting line and 1..200 lines.")
        file = self.path(path)
        if not file.is_file() or file.stat().st_size > 1_000_000:
            raise BlochAIError("Read a text file smaller than 1 MB.")
        try:
            raw = file.read_bytes()
            text = raw.decode("utf-8")
        except (OSError, UnicodeError) as exc:
            raise BlochAIError("Cannot read this UTF-8 text file.") from exc
        if "\x00" in text:
            raise BlochAIError("Binary file access is not supported.")
        digest = hashlib.sha256(raw).hexdigest()
        self.observed[str(file)] = digest
        all_lines = text.splitlines()
        selected = all_lines[start_line - 1:start_line - 1 + lines]
        return {"path": path, "sha256": digest, "start_line": start_line, "total_lines": len(all_lines),
                "content": "\n".join(f"{i}: {line}" for i, line in enumerate(selected, start_line))}

    def write_file(self, path, content):
        if not isinstance(content, str) or len(content.encode()) > 100_000 or "\x00" in content:
            raise BlochAIError("Write at most 100 KB of UTF-8 text.")
        file = self.path(path)
        before, digest, mode = "", None, 0o644
        if file.exists():
            if not file.is_file() or file.stat().st_size > 1_000_000:
                raise BlochAIError("Existing path is not a supported text file.")
            raw = file.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            if self.observed.get(str(file)) != digest:
                raise BlochAIError("Read the current file before overwriting it; it may have changed.")
            try:
                before = raw.decode("utf-8")
            except UnicodeError as exc:
                raise BlochAIError("Cannot overwrite a binary file.") from exc
            mode = file.stat().st_mode & 0o777
        diff = "".join(difflib.unified_diff(before.splitlines(True), content.splitlines(True),
                                           fromfile=path, tofile=path)) or "No content changes."
        if before == content and file.exists():
            return {"path": path, "changed": False}
        if not self.approve("write_file", clean_text(diff)):
            return {"path": path, "denied": True, "message": "The user declined this edit."}
        from .project_lock import project_write_lock
        # Do not hold a lock during human review. Recheck inside the lock so
        # two Qentl processes cannot both replace the same observed revision.
        with project_write_lock(self.root):
            try:stat = self.root.stat()
            except OSError as exc:raise BlochAIError('The project was deleted. Start a new command.') from exc
            if self.root.is_symlink() or (stat.st_dev,stat.st_ino) != self._generation:
                raise BlochAIError('The project was replaced. Start a new command.')
            if self._mutation_guard:self._mutation_guard()
            file = self.path(path)
            if digest is not None and (not file.exists() or hashlib.sha256(file.read_bytes()).hexdigest() != digest):
                raise BlochAIError("File changed while awaiting approval; read it again.")
            if digest is None and file.exists():
                raise BlochAIError("Another process created the file; read it before writing.")
            file.parent.mkdir(parents=True, exist_ok=True)
            self.path(path)
            fd, temporary = tempfile.mkstemp(prefix=".blochai-edit-", dir=str(file.parent))
            try:
                with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
                    stream.write(content)
                os.chmod(temporary, mode)
                os.replace(temporary, file)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
        new_digest = hashlib.sha256(content.encode()).hexdigest()
        self.observed[str(file)] = new_digest
        return {"path": path, "changed": True, "sha256": new_digest, "diff": diff}

    def edit_file(self, path, old, new):
        if not isinstance(old, str) or not old or not isinstance(new, str):
            raise BlochAIError("Provide a nonempty exact old snippet and its replacement.")
        file = self.path(path)
        if not file.is_file() or file.stat().st_size > 1_000_000:
            raise BlochAIError("Read an existing text file first.")
        raw = file.read_bytes()
        if self.observed.get(str(file)) != hashlib.sha256(raw).hexdigest():
            raise BlochAIError("Read the current file before editing it.")
        text = raw.decode("utf-8")
        if text.count(old) != 1:
            raise BlochAIError("The old snippet must match exactly once.")
        return self.write_file(path, text.replace(old, new, 1))

    def run_command(self, argv, cwd=".", purpose="inspect"):
        if not self.allow_commands:
            raise BlochAIError("Comandos de sistema estão desabilitados no workspace web: é necessário um ambiente isolado por conta. Nenhum comando foi executado.")
        if not isinstance(argv, list) or not 1 <= len(argv) <= 80 or any(not isinstance(a, str) or not a or "\x00" in a or len(a)>8000 for a in argv):
            raise BlochAIError("Provide argv as a nonempty list of command arguments.")
        if purpose not in ("inspect", "build", "test", "run"):
            raise BlochAIError("Command purpose must be inspect, build, test or run.")
        directory = self.path(cwd, directory=True)
        if not directory.is_dir():
            raise BlochAIError("The command working directory does not exist.")
        preview = f"Directory: {directory}\nPurpose: {purpose}\nCommand: {shlex.join(argv)}"
        if not self.approve("run_command", clean_text(preview)):
            return {"argv": argv, "denied": True, "message": "The user declined this command."}
        # This is an approved host process, not a security sandbox. Do not inherit
        # API credentials into project subprocesses or automatically add a shell.
        env = {k:v for k,v in os.environ.items() if k in ("PATH", "HOME", "USER", "LANG", "TMPDIR", "SYSTEMROOT", "VIRTUAL_ENV") or k.startswith("LC_")}
        env.update(PYTHONUNBUFFERED="1", NO_COLOR="1", GIT_TERMINAL_PROMPT="0")
        started = time.monotonic()
        try:
            process = subprocess.Popen(argv, cwd=str(directory), env=env, stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
        except (OSError, ValueError) as exc:
            raise BlochAIError("Cannot start the requested command. Check the executable and project dependencies.") from exc
        output, total, timed_out = bytearray(), 0, False
        selector = selectors.DefaultSelector()
        selector.register(process.stdout, selectors.EVENT_READ)
        try:
            while selector.get_map():
                if time.monotonic() - started >= self.command_timeout:
                    timed_out = True
                    break
                for key, _ in selector.select(timeout=0.1):
                    chunk = os.read(key.fd, 8192)
                    if not chunk:
                        selector.unregister(key.fileobj)
                        break
                    total += len(chunk)
                    output.extend(chunk[:max(0, 64000-len(output))])
            if process.poll() is None:
                try:
                    process.wait(timeout=max(0.01, self.command_timeout-(time.monotonic()-started)))
                except subprocess.TimeoutExpired:
                    timed_out = True
        finally:
            selector.close()
            if timed_out or process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            process.wait()
            process.stdout.close()
        return {"argv": argv, "cwd": cwd, "purpose": purpose, "exit_code": process.returncode,
                "timed_out": timed_out, "seconds": round(time.monotonic()-started, 3),
                "output": clean_text(output.decode("utf-8", errors="replace")), "output_truncated": total>len(output)}
