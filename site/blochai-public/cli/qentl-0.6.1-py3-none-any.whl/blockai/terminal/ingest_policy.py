"""Operator-only storage profile; transfer/parser safety bounds remain finite."""
from __future__ import annotations

import os
from pathlib import Path
import shutil

from fastapi import Request

from .config import BlochAIError

MIB = 1024 * 1024


def current_policy():
    profile = os.environ.get('QENTL_INGEST_PROFILE', 'standard')
    if profile not in ('standard', 'internal'):
        raise BlochAIError('The operator ingestion profile is invalid.')
    internal = profile == 'internal'
    return {'profile': profile, 'project_total_bytes': None,
            'attachment_total_bytes': None if internal else 100 * MIB,
            'sync_total_bytes': None if internal else 20 * MIB,
            'max_source_files': 10000 if internal else 500,
            'max_attachments': 10000 if internal else 50,
            'max_metadata_bytes': 16 * MIB if internal else 200000,
            'max_directories': 50000 if internal else 5000,
            'source_file_bytes': 200000, 'attachment_file_bytes': 10 * MIB,
            'batch_files': 500, 'batch_decoded_bytes': 20 * MIB,
            'batch_request_bytes': 30 * MIB, 'receive_seconds': 60,
            'reserve_bytes': 512 * MIB if internal else 0,
            'resumable_folder_batches': internal, 'paged_sync_snapshots': True,
            'graph_source_files': 500, 'graph_attachments': 500,
            'analysis': {'selected_attachments': 6, 'extracted_text_chars': 50000,
                         'pdf_pages': 30, 'source_parse_bytes': 200000,
                         'model_context_separate': True, 'whole_project_in_one_prompt': False}}


def _storage(path, policy):
    volume = Path(path)
    # A fresh installation may not have created its first project directory.
    # Inspect its existing parent filesystem without creating account data.
    while not volume.exists():
        if volume.is_symlink() or volume.parent == volume:
            raise BlochAIError('The project storage volume is unavailable.')
        volume = volume.parent
    if volume.is_symlink():
        raise BlochAIError('Project storage cannot be a symbolic link.')
    usage = shutil.disk_usage(volume)
    available = max(0, usage.free - policy['reserve_bytes'])
    result = {'total_bytes': usage.total, 'free_bytes': usage.free,
              'reserve_bytes': policy['reserve_bytes'], 'available_bytes': available}
    backing = os.environ.get('QENTL_STORAGE_CAPACITY_PATH')
    reserve = os.environ.get('QENTL_STORAGE_CAPACITY_RESERVE_BYTES')
    if backing is not None or reserve is not None:
        if (not isinstance(backing, str) or not Path(backing).is_absolute()
                or not Path(backing).is_dir() or not isinstance(reserve, str)
                or not reserve.isdigit() or len(reserve) > 16 or int(reserve) > 10**15):
            raise BlochAIError('The operator backing-storage capacity guard is invalid.')
        physical = shutil.disk_usage(Path(backing))
        result.update(backing_free_bytes=physical.free, backing_reserve_bytes=int(reserve),
                      available_bytes=min(available, max(0, physical.free - int(reserve))))
    return result


def ensure_space(path, incoming_bytes, *, extra_bytes=0):
    """Include temporary copies and the operator's backing-volume free reserve."""
    if type(incoming_bytes) is not int or type(extra_bytes) is not int or min(incoming_bytes, extra_bytes) < 0:
        raise BlochAIError('Invalid storage reservation.')
    policy = current_policy()
    if policy['profile'] != 'internal':
        return
    if incoming_bytes + extra_bytes > _storage(path, policy)['available_bytes']:
        raise BlochAIError('Insufficient server storage for this batch and its temporary copy. Existing files were preserved; free space or expand storage before continuing.')


def public_policy(path):
    policy = current_policy()
    return {**policy, 'storage': _storage(path, policy),
            'notice': 'The internal profile has no aggregate project byte quota. Files still need physical storage; each transfer, parser and model context remains bounded. Large folders are sent in resumable batches. Single files retain the listed size limits.'}


def install_ingest_policy_routes(app, session, projects):
    @app.get('/api/ingest-policy')
    def policy(request: Request):
        record = session(request)
        return public_policy(projects(record).root)
