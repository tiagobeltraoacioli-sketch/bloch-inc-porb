"""Master-authorized, bounded control of the existing public-only learner."""
from __future__ import annotations

from collections import deque
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import threading
import time
import uuid

from fastapi import HTTPException, Request

from .config import BlochAIError, config_home
from .file_permissions import is_private

MASTER_EMAIL = 'tiago@blochprotocol.io'
HOST = ''  # operator-only; not distributed
SSH_USER = 'ubuntu'
REMOTE_COMMAND = 'sudo -n /usr/bin/python3 /opt/blochai-learning/ops/blochai_training_control.py'
ACTIONS = ('status', 'start', 'pause', 'resume', 'configure')
FAMILIES = ('sum', 'length', 'sort')


class TrainingControlError(BlochAIError):
    def __init__(self, message, status_code=503):
        super().__init__(message)
        self.status_code = status_code


def load_control_config():
    path = config_home() / 'training-control.json'
    if not path.is_file():
        raise TrainingControlError('Training control is not configured on this installation.')
    if not is_private(path) or path.stat().st_size > 8192:
        raise TrainingControlError('The operator training-control configuration must be private.')
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if (not isinstance(data, dict)
                or set(data) - {'schema', 'enabled', 'master_emails', 'ssh_identity_file', 'ssh_agent_socket'}
                or data.get('schema') != 'qentl-training-control-v1'
                or type(data.get('enabled')) is not bool
                or data.get('master_emails') != [MASTER_EMAIL]):
            raise ValueError
        identity = data.get('ssh_identity_file')
        if not isinstance(identity, str) or not Path(identity).is_absolute() or '\x00' in identity:
            raise ValueError
        socket = data.get('ssh_agent_socket')
        if socket is not None and (not isinstance(socket, str) or not Path(socket).is_absolute() or '\x00' in socket):
            raise ValueError
        return data
    except (ValueError, TypeError, OSError) as exc:
        raise TrainingControlError('Invalid operator training-control configuration.') from exc


def master_identity(record, config):
    """Accept only a fresh authoritative portal identity supplied by the server."""
    identity = record.get('identity', {})
    user, organization = identity.get('user', {}), identity.get('organization', {})
    email = user.get('email') if isinstance(user, dict) else None
    if (not isinstance(email, str) or email.casefold() != MASTER_EMAIL
            or not isinstance(organization, dict) or organization.get('role') not in ('owner', 'admin')
            or not isinstance(organization.get('id'), str) or not organization['id']
            or not config.get('enabled') or email.casefold() not in config.get('master_emails', [])):
        raise TrainingControlError('Master training access is required.', 403)
    # The remote audit receives opaque references, never the email or portal token.
    actor = hashlib.sha256((email.casefold() + '\0' + organization['id']).encode()).hexdigest()[:24]
    return actor


def validate_action(data):
    if not isinstance(data, dict) or data.get('action') not in ACTIONS:
        raise TrainingControlError('Choose a permitted training control action.', 422)
    action = data['action']
    if action == 'configure':
        if set(data) != {'action', 'max_workers', 'curriculum_families'}:
            raise TrainingControlError('Configure only study workers and reviewed curriculum families.', 422)
        workers, families = data['max_workers'], data['curriculum_families']
        if type(workers) is not int or not 1 <= workers <= 8:
            raise TrainingControlError('Choose 1 to 8 study workers.', 422)
        if (not isinstance(families, list) or not families or len(families) > 3
                or any(not isinstance(family, str) or family not in FAMILIES for family in families)
                or len(set(families)) != len(families)):
            raise TrainingControlError('Choose distinct reviewed curriculum families.', 422)
    elif set(data) != {'action'}:
        raise TrainingControlError('This action accepts no additional parameters.', 422)
    return data


class TrainingController:
    def __init__(self, config, runner=subprocess.run):
        self.config, self.runner = config, runner

    def readiness(self):
        identity = Path(self.config['ssh_identity_file'])
        socket = self.config.get('ssh_agent_socket')
        available = Path('/usr/bin/ssh').is_file() and identity.is_file() and not identity.is_symlink()
        if socket:
            try:
                available = available and stat.S_ISSOCK(Path(socket).stat().st_mode)
            except OSError:
                available = False
        return {'configured': True, 'available': bool(available), 'actions': list(ACTIONS),
                'bounds': {'study_workers_min': 1, 'study_workers_max': 8,
                           'curriculum_families': list(FAMILIES), 'training_parallelism': 1},
                'scope': 'Existing public-only learning service; no access to another account project.',
                'production_model_promotion_allowed': False,
                'readiness_note': 'Availability checks local prerequisites; remote status verifies SSH access.'}

    def execute(self, data, actor_ref):
        data = validate_action(data)
        if not re.fullmatch(r'[a-f0-9]{24}', actor_ref):
            raise TrainingControlError('Invalid master audit scope.', 403)
        if not self.readiness()['available']:
            raise TrainingControlError('Training control prerequisites are unavailable. The operator must restore SSH access.')
        identity = self.config['ssh_identity_file']
        command = ['/usr/bin/ssh', '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes',
                   '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=10',
                   '-o', 'ServerAliveInterval=10', '-o', 'ServerAliveCountMax=2',
                   '-p', '22', '-i', identity]
        if self.config.get('ssh_agent_socket'):
            command += ['-o', 'IdentityAgent=' + self.config['ssh_agent_socket']]
        command += [SSH_USER + '@' + HOST, REMOTE_COMMAND]
        payload = {**data, 'actor_ref': actor_ref, 'operation_id': uuid.uuid4().hex}
        try:
            # Input is bounded JSON over stdin. No user input becomes command syntax.
            result = self.runner(command, input=json.dumps(payload), capture_output=True, text=True,
                                 timeout=35, check=False)
            if result.returncode or len(result.stdout.encode()) > 65536:
                raise TrainingControlError('Training host could not be reached or rejected the control request.')
            response = json.loads(result.stdout)
            if (not isinstance(response, dict) or response.get('schema') != 'qentl-training-control-response-v1'
                    or response.get('operation_id') != payload['operation_id']):
                raise TrainingControlError('Training host returned an invalid control response.')
            if response.get('ok') is not True:
                code = response.get('error_code')
                if code in ('busy', 'operation_in_progress'):
                    raise TrainingControlError('A learning cycle or control operation is active. Try again after it finishes.', 409)
                raise TrainingControlError('The training host did not apply this action. Its audit records the outcome.')
            return response
        except TrainingControlError:
            raise
        except (OSError, subprocess.SubprocessError, ValueError, TypeError) as exc:
            raise TrainingControlError('Training control failed or timed out. Check status before retrying.') from exc


def install_admin_routes(app, session, controller_factory=TrainingController):
    """Install on the existing loopback app, preserving its CSRF and host boundary."""
    from starlette.concurrency import run_in_threadpool

    lock, slot, attempts = threading.Lock(), threading.BoundedSemaphore(1), deque()

    def authorize(request):
        # write=True forces a fresh portal identity on every GET and POST and
        # retains the application role policy; master_identity narrows it further.
        record = session(request, True)
        identity = record.get('identity', {})
        user, organization = identity.get('user', {}), identity.get('organization', {})
        if (not isinstance(user, dict) or not isinstance(user.get('email'), str)
                or user['email'].casefold() != MASTER_EMAIL or not isinstance(organization, dict)
                or organization.get('role') not in ('owner', 'admin')):
            raise HTTPException(403, 'Master training access is required.')
        try:
            config = load_control_config()
            actor = master_identity(record, config)
            return controller_factory(config), actor
        except TrainingControlError as exc:
            raise HTTPException(exc.status_code, str(exc)) from None

    async def execute(request, data):
        controller, actor = await run_in_threadpool(authorize, request)
        try:
            data = validate_action(data)
            with lock:
                cutoff = time.monotonic() - 60
                while attempts and attempts[0] < cutoff:
                    attempts.popleft()
                if len(attempts) >= 20:
                    raise TrainingControlError('Training control rate exceeded. Wait one minute.', 429)
                if not slot.acquire(blocking=False):
                    raise TrainingControlError('Another training control request is running.', 409)
                attempts.append(time.monotonic())
            try:
                return await run_in_threadpool(controller.execute, data, actor)
            finally:
                slot.release()
        except TrainingControlError as exc:
            raise HTTPException(exc.status_code, str(exc)) from None

    @app.get('/api/admin/training/capabilities')
    async def capabilities(request: Request):
        controller, _ = await run_in_threadpool(authorize, request)
        return {**controller.readiness(), 'can_control': True}

    @app.get('/api/admin/training/status')
    async def status(request: Request):
        return await execute(request, {'action': 'status'})

    @app.post('/api/admin/training/control')
    async def control(request: Request):
        import asyncio
        # Authenticate before reading a request body or contacting the training host.
        await run_in_threadpool(authorize, request)
        async def bounded_body():
            raw = bytearray()
            async for chunk in request.stream():
                if len(chunk) > 4096 - len(raw):
                    raise HTTPException(413, 'Training control request is too large.')
                raw.extend(chunk)
            return raw
        try:
            raw = await asyncio.wait_for(bounded_body(), timeout=30)
        except asyncio.TimeoutError:
            raise HTTPException(408, 'Training control request timed out.') from None
        try:
            data = json.loads(raw)
        except (ValueError, UnicodeError, RecursionError):
            raise HTTPException(422, 'A bounded JSON training action is required.') from None
        return await execute(request, data)
