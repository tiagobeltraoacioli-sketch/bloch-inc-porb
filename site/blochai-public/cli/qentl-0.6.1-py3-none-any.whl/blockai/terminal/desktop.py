"""Private loopback process owned by the Qentl desktop main process."""
import argparse
import json
import os
from pathlib import Path
import socket
import threading
import sys

import uvicorn

from .config import private_directory
from .web import create_app


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--workspace',type=Path,required=True)
    parser.add_argument('--parent-pid',type=int,required=True)
    args=parser.parse_args()
    secret=os.environ.pop('QENTL_DESKTOP_SECRET','')
    if len(secret)!=64:raise SystemExit('Desktop launch credential missing.')
    private_directory(args.workspace)
    sock=socket.socket();sock.bind(('127.0.0.1',0));sock.listen(128)
    port=sock.getsockname()[1]
    app=create_app(args.workspace,port,desktop_secret=secret)
    server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,access_log=False,log_level='error'))
    def parent_watch():
        # The inherited pipe reaches EOF if the main process exits, on Windows too.
        for _ in sys.stdin:pass
        server.should_exit=True
    threading.Thread(target=parent_watch,daemon=True).start()
    def ready():
        while not server.started and not server.should_exit:threading.Event().wait(.05)
        if server.started:print(json.dumps({'port':port,'product':'Qentl'}),flush=True)
    threading.Thread(target=ready,daemon=True).start()
    server.run(sockets=[sock])


if __name__=='__main__':main()
