"""Persistent, bounded study and candidate-training cycles; no model promotion."""
from __future__ import annotations

import ast
import base64
import fcntl
import hashlib
import json
import random
import threading
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import re
import time
from pathlib import Path

from .config import BlochAIError, private_directory, save_json
from .curriculum import SYSTEM, authored_examples, audit_splits, digest, evaluate_code, round_examples
from .research import catalog
from .store import now, scrub
from .learning_daily import record_daily


class GitHub:
    def __init__(self, transport=None):
        import httpx
        self.client=httpx.Client(base_url="https://api.github.com",timeout=25,follow_redirects=False,trust_env=False,transport=transport,
                                 headers={"Accept":"application/vnd.github+json","X-GitHub-Api-Version":"2022-11-28","User-Agent":"BlochAI-Learning/0.1"})
    def close(self): self.client.close()
    def get(self,path,**params):
        import httpx
        try:
            with self.client.stream("GET",path,params=params) as response:
                if response.status_code!=200:
                    raise BlochAIError(f"GitHub returned HTTP {response.status_code}; this source is deferred without automatic retry.")
                chunks=bytearray()
                for chunk in response.iter_bytes():
                    chunks.extend(chunk)
                    if len(chunks)>1_000_000: raise BlochAIError("GitHub response exceeded 1 MB.")
                data=json.loads(chunks)
                if not isinstance(data,dict): raise ValueError
                return data
        except (httpx.HTTPError,ValueError) as exc:
            raise BlochAIError("GitHub source could not be retrieved or validated.") from exc


def decode_content(result, maximum=200000):
    if result.get("encoding")!="base64" or not isinstance(result.get("content"),str) or result.get("size",maximum+1)>maximum:
        raise BlochAIError("Source must be a bounded base64 text file.")
    try:
        raw=base64.b64decode(result["content"],validate=False)
        if len(raw)>maximum or b"\x00" in raw: raise ValueError
        return raw.decode("utf-8")
    except (ValueError,UnicodeError) as exc:
        raise BlochAIError("Invalid source file encoding.") from exc


def collect_repository(client, policy):
    repository=policy["repository"]
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+",repository):
        raise BlochAIError("Invalid repository allowlist entry.")
    base="/repos/"+repository
    metadata=client.get(base)
    if metadata.get("private") is not False or metadata.get("archived"):
        raise BlochAIError("Only active public allowlisted repositories enter automatic study.")
    commit=client.get(base+"/commits/"+metadata["default_branch"])["sha"]
    if not re.fullmatch(r"[a-f0-9]{40}",commit): raise BlochAIError("Immutable commit required.")
    license_data=client.get(base+"/license",ref=commit)
    spdx=license_data.get("license",{}).get("spdx_id")
    if spdx!=policy["license"] or spdx not in ("MIT","BSD-2-Clause","BSD-3-Clause","Apache-2.0","ISC"):
        raise BlochAIError("License changed, is ambiguous, or is outside the approved permissive allowlist.")
    license_text=decode_content(license_data,60000)
    if len(license_text)<100: raise BlochAIError("Complete license text required.")
    result={"repository":repository,"commit":commit,"retrieved_at":now(),"license":spdx,"license_text":license_text,
            "license_path":license_data.get("path"),"files":[],"notices":[]}
    # Preserve an Apache NOTICE if the repository supplies one. Only 404 means
    # absent; rate limits or other failures must defer this repository.
    if spdx=="Apache-2.0":
        try:
            notice=client.get(base+"/contents/NOTICE",ref=commit)
            result["notices"].append({"path":"NOTICE","text":decode_content(notice,60000)})
        except BlochAIError as exc:
            if "HTTP 404;" not in str(exc): raise
    for path in policy["paths"]:
        if not isinstance(path,str) or ".." in Path(path).parts or not path.endswith(".py"):
            raise BlochAIError("Only reviewed Python source paths are ingested.")
        file=client.get(base+"/contents/"+path,ref=commit)
        if file.get("type")!="file": raise BlochAIError("Source must be a regular file.")
        source=decode_content(file)
        if scrub(source)!=source or re.search(r"(?i)(BEGIN .*PRIVATE KEY|gh[pousr]_[A-Za-z0-9]{30}|sk-[A-Za-z0-9]{30})",source):
            raise BlochAIError("Possible credential content quarantined; no examples created.")
        file_spdx=re.findall(r"SPDX-License-Identifier:\s*([^\n]+)",source)
        if any(identifier.strip()!=spdx for identifier in file_spdx):
            raise BlochAIError("File-level licensing differs from the reviewed repository license.")
        if re.search(r"(?i)(vendored|copied from|licensed under.*GPL|third.party copyright)",source):
            raise BlochAIError("Additional provenance review required for third-party source notices.")
        result["files"].append({"path":path,"content":source,"sha256":hashlib.sha256(source.encode()).hexdigest(),
                               "url":f"https://github.com/{repository}/blob/{commit}/{path}"})
    return result


def repository_examples(source):
    rows=[]
    for file in source["files"]:
        try: tree=ast.parse(file["content"])
        except SyntaxError: continue
        for node in tree.body:
            if not isinstance(node,ast.FunctionDef) or node.decorator_list: continue
            code=ast.get_source_segment(file["content"],node)
            doc=ast.get_docstring(node)
            if not code or not doc or not 80<=len(code)<=1100 or len(doc)>350: continue
            if any(isinstance(child,(ast.Import,ast.ImportFrom)) for child in ast.walk(node)): continue
            # Repository code is read as data only, never imported or executed.
            row={"family":"repository:"+source["repository"],
                 "messages":[{"role":"system","content":"Return the Python function implementation. Preserve the function signature. No surrounding prose."},
                             {"role":"user","content":node.name+": "+doc}],"answer":code,
                 "provenance":{"kind":"PERMISSIVE_PUBLIC_SOURCE","repository":source["repository"],"commit":source["commit"],
                    "url":file["url"],"source_sha256":file["sha256"],"license":source["license"],
                    "license_text":source["license_text"],"notices":source["notices"],
                    "limitations":"Repository license and inspected file notices; dependency licenses are not inferred. Reading code does not validate its behavior."}}
            row["id"]=digest(row);rows.append(row)
            if len(rows)>=16: return rows
    return rows


CONTROLLER_DEFAULTS = {"schema": "qentl-learning-controller-v1", "max_workers": 4,
                       "source_refresh_seconds": 86400, "curriculum_families": ["sum"],
                       "max_training_parallelism": 1}


def controller_config(root, supplied=None):
    """Bounded operator choices; no additional URLs, paths or model access."""
    path = Path(root) / "controller.json"
    if supplied is None and path.exists():
        if path.is_symlink() or path.stat().st_size > 4000:
            raise BlochAIError("Invalid learning controller file.")
        supplied = json.loads(path.read_text())
    if supplied is not None and not isinstance(supplied, dict):
        raise BlochAIError("Learning controller must be an object.")
    result = {**CONTROLLER_DEFAULTS, **(supplied or {})}
    if (set(result) != set(CONTROLLER_DEFAULTS) or result["schema"] != CONTROLLER_DEFAULTS["schema"]
            or type(result["max_workers"]) is not int or not 1 <= result["max_workers"] <= 8
            or type(result["source_refresh_seconds"]) is not int
            or not 86400 <= result["source_refresh_seconds"] <= 604800
            or type(result["max_training_parallelism"]) is not int
            or result["max_training_parallelism"] != 1):
        raise BlochAIError("Learning controller exceeds reviewed resource limits.")
    families = result["curriculum_families"]
    if (not isinstance(families, list) or not families or len(families) > 3
            or any(family not in ("sum", "length", "sort") for family in families)
            or len(set(families)) != len(families)):
        raise BlochAIError("Only distinct reviewed training curriculum families are allowed.")
    return result


@contextmanager
def learning_lock(path, wait_seconds=0):
    """Cross-process locking protects shared source snapshots and training state."""
    import os
    if path.is_symlink():
        raise BlochAIError("Learning lock must not be a symbolic link.")
    flags = os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0)
    with os.fdopen(os.open(str(path), flags, 0o600), "a") as handle:
        deadline = time.monotonic() + wait_seconds
        while True:
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError as exc:
                if time.monotonic() >= deadline:
                    raise BlochAIError("Another learning task holds this resource lock.") from exc
                time.sleep(.05)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


class StudyFleet:
    """Real bounded jobs with dependency phases and content-free outcome records."""
    def __init__(self, workers):
        self.pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="bloch-study")
        self.lock = threading.Lock()
        self.active = self.peak = 0
        self.records = []
        self.workers = workers

    def submit(self, identifier, role, operation, *args):
        def execute():
            started = time.monotonic()
            with self.lock:
                self.active += 1
                self.peak = max(self.peak, self.active)
            record = {"id": identifier, "role": role, "started_at": now()}
            try:
                value, outcome = operation(*args)
                record.update(status="completed", outcome=outcome)
                return value
            except Exception as exc:
                # Source content and unexpected backend error bodies are never status data.
                record.update(status="failed", error_type=type(exc).__name__)
                raise
            finally:
                record["elapsed_seconds"] = round(time.monotonic() - started, 4)
                with self.lock:
                    self.active -= 1
                    self.records.append(record)
        return self.pool.submit(execute)

    def summary(self):
        records = sorted(self.records, key=lambda row: row["id"])
        return {"schema": "qentl-study-fleet-v1", "max_workers": self.workers,
                "peak_concurrent_jobs": self.peak, "jobs_completed": sum(r["status"] == "completed" for r in records),
                "jobs_failed": sum(r["status"] == "failed" for r in records), "agents": records,
                "execution": "Bounded Python study and verification tasks; no LLM agents or repository code execution.",
                "private_inference_gpus_used": 0, "automatic_promotion": False}


def verified_snapshot(source, policy):
    if (not isinstance(source, dict) or source.get("repository") != policy["repository"]
            or source.get("license") != policy["license"]
            or source.get("policy_fingerprint") != digest(policy)
            or not re.fullmatch(r"[a-f0-9]{40}", source.get("commit", ""))
            or not 100 <= len(source.get("license_text", "")) <= 60000
            or not isinstance(source.get("files"), list)
            or len(source["files"]) != len(policy["paths"])):
        raise BlochAIError("Source snapshot no longer matches its reviewed policy.")
    if sorted(file.get("path", "") for file in source["files"]) != sorted(policy["paths"]):
        raise BlochAIError("Source snapshot contains unreviewed paths.")
    for file in source["files"]:
        text = file.get("content")
        if (not isinstance(text, str) or len(text.encode()) > 200000
                or file.get("sha256") != hashlib.sha256(text.encode()).hexdigest()
                or file.get("url") != f'https://github.com/{source["repository"]}/blob/{source["commit"]}/{file["path"]}'
                or scrub(text) != text
                or re.search(r"(?i)(BEGIN .*PRIVATE KEY|gh[pousr]_[A-Za-z0-9]{30}|sk-[A-Za-z0-9]{30})", text)):
            raise BlochAIError("Source snapshot integrity or credential audit failed.")
    return source


def source_task(root, policy, client, refresh_seconds):
    path = root / "sources" / (policy["repository"].replace("/", "--") + ".json")
    with learning_lock(path.with_suffix(".lock"), wait_seconds=3):
        cached = False
        if path.is_symlink():
            raise BlochAIError("Source snapshots must not be symbolic links.")
        if path.is_file() and time.time() - path.stat().st_mtime < refresh_seconds:
            if path.stat().st_size > 1_000_000:
                raise BlochAIError("Source snapshot exceeded its storage limit.")
            source = json.loads(path.read_text())
            if source.get("policy_fingerprint") == digest(policy):
                verified_snapshot(source, policy)
                cached = True
        if not cached:
            source = collect_repository(client, policy)
            source["policy_fingerprint"] = digest(policy)
            verified_snapshot(source, policy)
            save_json(path, source)
    return source, {"repository": policy["repository"], "commit": source["commit"],
                    "files_verified": len(source["files"]), "cache_hit": cached,
                    "license": source["license"]}


def extraction_task(source):
    rows = repository_examples(source)
    return rows, {"repository": source["repository"], "functions_retained": len(rows),
                  "files_parsed": len(source["files"]), "source_code_executed": False}


def curriculum_task(round_id, family):
    if family == "sum":
        rows = round_examples(round_id)
    else:
        randomizer = random.Random(str(round_id) + ":" + family)
        rows = []
        for offset in randomizer.sample(range(-30, 31), 12):
            if family == "length":
                description = f"Return the number of elements in list x, then add {offset}."
                expression = f"len(x) + ({offset})"
                cases = [([8, 4, 9], 3 + offset), ([], offset), ([2], 1 + offset)]
            else:
                description = f"Append integer {offset} to a copy of list x and return the values sorted in ascending order."
                expression = f"sorted(x + [{offset}])"
                cases = [([8, -3, 9], sorted([8, -3, 9, offset])), ([], [offset]), ([2], sorted([2, offset]))]
            answer = "def solve(x):\n    return " + expression + "\n"
            if not evaluate_code(answer, cases)["passed"]:
                raise BlochAIError("Authored curriculum failed its functional reference checks.")
            row = {"family": "authored:" + family,
                   "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": description}],
                   "answer": answer, "provenance": {"kind": "OWNER_AUTHORED_SYNTHETIC", "license": "MIT",
                   "generator": "qentl-curriculum-" + family + "-v1", "round": round_id, "reference_tests_passed": 3}}
            row["id"] = digest(row)
            rows.append(row)
    return rows, {"family": family, "exercises": len(rows), "reference_tests_passed": 3 * len(rows)}


def reference_task(references):
    rows = []
    for reference in references:
        if reference["id"] == "python-docs":
            continue
        row = {"family": "authored:ip_reference_summary", "messages": [
            {"role": "system", "content": "Summarize only the supplied educational note. Do not decide ownership, infringement or jurisdiction-specific legal rights."},
            {"role": "user", "content": reference["title"] + "\nSource: " + reference["url"] + "\nNote: " + reference["note"]}],
            "answer": reference["note"], "provenance": {"kind": "OWNER_AUTHORED_REFERENCE_PARAPHRASE", "license": "MIT",
            "source_url": reference["url"], "downloaded_page_text_used": False}}
        row["id"] = digest(row)
        rows.append(row)
    return rows, {"original_notes": len(rows), "downloaded_page_text_used": False,
                  "jurisdiction_or_legal_competence_evaluated": False}


def provenance_task(dataset, available):
    public = {source["repository"]: source for source in available}
    inspected = 0
    for rows in dataset.values():
        for row in rows:
            provenance = row.get("provenance", {})
            kind = provenance.get("kind")
            if kind not in ("PERMISSIVE_PUBLIC_SOURCE", "OWNER_AUTHORED_SYNTHETIC", "OWNER_AUTHORED_REFERENCE_PARAPHRASE"):
                raise BlochAIError("Unapproved provenance in candidate dataset.")
            if scrub(json.dumps(row)) != json.dumps(row):
                raise BlochAIError("Dataset credential audit failed.")
            if kind == "PERMISSIVE_PUBLIC_SOURCE":
                source = public.get(provenance.get("repository"))
                if (source is None or provenance.get("commit") != source["commit"]
                        or provenance.get("license_text") != source["license_text"]
                        or provenance.get("source_sha256") not in {f["sha256"] for f in source["files"]}):
                    raise BlochAIError("Dataset source provenance is not reproducible.")
            if row["family"] == "authored:tool_read":
                action = json.loads(row["answer"])
                if set(action) != {"action", "args"} or action["action"] != "read_file":
                    raise BlochAIError("Authored tool contract changed.")
            inspected += 1
    return True, {"rows_audited": inspected, "private_user_rows": 0,
                  "licensed_sources": len(public), "tool_contracts_validated": 4}


def heldout_task(dataset):
    frozen = authored_examples()
    passed = 0
    for split in ("validation", "test"):
        if digest(dataset[split]) != digest(frozen[split]):
            raise BlochAIError("Frozen held-out evaluation changed.")
        for row in dataset[split]:
            result = evaluate_code(row["answer"], row["cases"])
            if not result["passed"]:
                raise BlochAIError("Frozen reference answer no longer passes.")
            passed += result["tests_passed"]
    return True, {"frozen_families": 6, "reference_cases_passed": passed,
                  "candidate_model_evaluated": False}


def split_task(dataset):
    result = audit_splits(dataset)
    return result, result


def manifest_task(destination):
    data, manifest = load_dataset(destination)
    return True, {"dataset_fingerprint": manifest["fingerprint"],
                  "split_files_verified": len(data), "rows_verified": sum(map(len, data.values()))}


def study(root, client=None, config=None):
    root = Path(root)
    private_directory(root)
    with learning_lock(root / "study.lock"):
        return _study(root, client, config)


def _study(root, client, supplied):
    private_directory(root / "sources")
    config = controller_config(root, supplied)
    fleet = StudyFleet(config["max_workers"])
    own_client = client is None
    client = client or GitHub()
    round_id = int(time.time() // 600)
    report = {"schema": "blochai-learning-status-v1", "updated_at": now(), "stage": "study", "round_id": round_id,
              "sources": [], "errors": [], "model_weights_updated": False, "promoted": False,
              "production_model_weights_updated": False, "controller": config,
              "schedule": "Supervised 24/7 rounds every 10 minutes; bounded parallel study, one candidate-training GPU at a time; source refresh daily."}
    if (root / "status.json").is_file():
        previous = json.loads((root / "status.json").read_text())
        report["last_training"] = previous.get("training") or previous.get("last_training")
    available = []
    policies = catalog()
    if len(policies["repositories"]) > 8:
        raise BlochAIError("Source catalog exceeds reviewed fleet capacity.")
    try:
        source_jobs = [(policy, fleet.submit("source:" + policy["repository"], "public-source-collector",
                       source_task, root, policy, client, config["source_refresh_seconds"])) for policy in policies["repositories"]]
        curricula = [(family, fleet.submit("curriculum:" + family, "verified-curriculum-author",
                     curriculum_task, round_id, family)) for family in config["curriculum_families"]]
        references_job = fleet.submit("reference-notes", "educational-reference-editor", reference_task, policies["references"])
        extractions = []
        for policy, job in source_jobs:
            try:
                source = job.result()
                available.append(source)
                report["sources"].append({key: source[key] for key in ("repository", "commit", "license", "retrieved_at")})
                extractions.append(fleet.submit("extract:" + source["repository"], "licensed-function-extractor", extraction_task, source))
            except Exception as exc:
                report["errors"].append({"repository": policy["repository"], "error_type": type(exc).__name__,
                                         "error": "Source verification failed; no data from this source were admitted."})
        dataset = authored_examples()
        new_exercises = 0
        for family, job in curricula:
            rows = job.result()
            dataset["train"].extend(rows)
            new_exercises += len(rows)
        notes = references_job.result()
        dataset["train"].extend(notes)
        seen = set()
        for job in extractions:
            for row in job.result():
                fingerprint = digest(row["answer"])
                if fingerprint not in seen:
                    seen.add(fingerprint)
                    dataset["train"].append(row)
        checks = [fleet.submit("quality:provenance", "provenance-and-privacy-auditor", provenance_task, dataset, available),
                  fleet.submit("quality:frozen-reference", "heldout-reference-verifier", heldout_task, dataset),
                  fleet.submit("quality:split-integrity", "split-leakage-auditor", split_task, dataset)]
        for job in checks:
            job.result()
        audit = checks[-1].result()
        references = [{k: item[k] for k in ("id", "title", "url", "note", "training_use")} for item in policies["references"]]
        save_json(root / "knowledge.json", {"updated_at": now(), "references": references, "use": "Retrieval references; not training inputs."})
        fingerprint = digest(dataset)
        destination = root / "datasets" / fingerprint[:20]
        private_directory(destination)
        for split, rows in dataset.items():
            save_json(destination / (split + ".json"), {"rows": rows})
        manifest = {"schema": "blochai-coding-candidate-v1", "fingerprint": fingerprint, "audit": audit, "created_at": now(),
                    "files": {split + ".json": hashlib.sha256((destination / (split + ".json")).read_bytes()).hexdigest() for split in dataset},
                    "scope": "Verified authored programming exercises and licensed public function reconstruction. No private user data, no downloaded official-page text."}
        save_json(destination / "manifest.json", manifest)
        fleet.submit("quality:manifest", "dataset-integrity-verifier", manifest_task, destination).result()
        report.update(stage="studied", round_id=round_id, dataset=str(destination), dataset_fingerprint=fingerprint,
                      audit=audit, source_examples=len(seen), new_verified_exercises=new_exercises,
                      educational_ip_summaries=len(notes))
    except Exception as exc:
        report.update(stage="study_failed", error_type=type(exc).__name__,
                      study_error="A required study or quality task failed. No training candidate was authorized.")
        raise
    finally:
        fleet.pool.shutdown(wait=True)
        if own_client:
            client.close()
        report["fleet"] = fleet.summary()
        report["updated_at"] = now()
        try:
            report["daily_progress"] = record_daily(root, report, available)
        except Exception:
            # A missing durable audit must prevent the supervisor from training.
            report.update(stage="study_failed", daily_evidence_error="Daily learning evidence could not be persisted; training is deferred.")
            save_json(root / "status.json", report)
            raise
        save_json(root / "status.json", report)
    return report


def load_dataset(path):
    path=Path(path)
    manifest=json.loads((path/"manifest.json").read_text())
    splits={}
    for name in ("train","validation","test"):
        file=path/(name+".json")
        if file.is_symlink() or file.stat().st_size>4_000_000 or hashlib.sha256(file.read_bytes()).hexdigest()!=manifest["files"][file.name]:
            raise BlochAIError("Dataset integrity check failed.")
        splits[name]=json.loads(file.read_text())["rows"]
    audit_splits(splits)
    if digest(splits)!=manifest["fingerprint"]: raise BlochAIError("Dataset fingerprint changed.")
    # Held-out prompts/cases must exactly match the authored frozen benchmark.
    expected=authored_examples()
    if any(digest(splits[name])!=digest(expected[name]) for name in ("validation","test")):
        raise BlochAIError("Held-out evaluation changed.")
    return splits,manifest


def cycle(root, training=False):
    root=Path(root);private_directory(root)
    with (root/"cycle.lock").open("a") as lock:
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError as exc: raise BlochAIError("Another learning cycle is already running.") from exc
        if sum(path.stat().st_size for path in root.rglob("*") if path.is_file())>2_000_000_000:
            raise BlochAIError("Learning storage reached 2 GB. Archive reviewed candidates before continuing.")
        report=study(root)
        if training:
            report=train_latest(root)
        return report


def train_latest(root):
    root=Path(root);private_directory(root)
    with learning_lock(root/"study.lock"):
        return _train_latest(root)


def _train_latest(root):
    root=Path(root)
    report=json.loads((root/"status.json").read_text())
    if (report.get("stage") not in ("studied", "evaluated", "waiting_for_new_data", "training_deferred")
            or report.get("errors") or report.get("fleet", {}).get("jobs_failed", 1)):
        report.update(stage="training_deferred", training_reason="Study and every required quality task must complete before training.")
        save_json(root/"status.json",report);return report
    history_path=root/"training-history.json"
    history=json.loads(history_path.read_text()) if history_path.exists() else {"attempts":[]}
    today=now()[:10]
    if any(item["fingerprint"]==report["dataset_fingerprint"] for item in history["attempts"] if item["status"]=="completed"):
        report.update(stage="waiting_for_new_data",training_reason="A completed candidate already covers this dataset; waiting for the next exercise round.")
        save_json(root/"status.json",report);return report
    # Persist attempt before CUDA startup. Failed attempts do not silently loop.
    if any(item["fingerprint"]==report["dataset_fingerprint"] for item in history["attempts"]):
        report.update(stage="training_deferred",training_reason="This dataset was already attempted; a new exercise round is required before retrying.")
        save_json(root/"status.json",report);return report
    output=root/"candidates"/(today+"-"+str(int(time.time())))
    attempt={"date":today,"fingerprint":report["dataset_fingerprint"],"status":"starting","output":str(output)}
    history["attempts"].append(attempt);save_json(history_path,history)
    report.update(stage="training",candidate=str(output));save_json(root/"status.json",report)
    from .training_runtime import train
    result=train(Path(report["dataset"]),output)
    attempt["status"]=result["status"];save_json(history_path,history)
    report.update(stage="evaluated" if result["status"]=="completed" else "training_failed",training=result,
                  model_weights_updated=result.get("completed_steps",0)>0,promoted=False,
                  production_model_weights_updated=False,
                  weight_update_scope="An isolated candidate adapter on the fixed 0.5B base only; no serving Qwen model was changed.")
    report["updated_at"] = now()
    try:
        report["daily_progress"] = record_daily(root, report)
    except Exception:
        report["daily_evidence_error"] = "The candidate result was saved, but daily evidence could not be persisted. Operator review is required."
        save_json(root / "status.json", report)
        raise
    save_json(root/"status.json",report)
    prune_candidates(root)
    return report


def prune_candidates(root, keep=24):
    """Bound generated scratch weights, preserving every evaluation and source record."""
    candidates=Path(root)/"candidates"
    folders=sorted((path for path in candidates.iterdir() if path.is_dir() and not path.is_symlink()),key=lambda p:p.name,reverse=True) if candidates.exists() else []
    for folder in folders[keep:]:
        report_file=folder/"report.json"
        if not report_file.is_file():continue
        report=json.loads(report_file.read_text())
        if report.get("schema")!="blochai-coding-training-v1" or report.get("promoted") is not False:continue
        adapter=folder/"adapter-candidate"
        if adapter.is_dir() and not adapter.is_symlink():
            import shutil
            shutil.rmtree(adapter)
            report["scratch_adapter_retained"]=False
            report["retention_note"]="Only the 24 newest unpromoted scratch adapters are retained. Evaluation evidence is preserved."
            save_json(report_file,report)
