"""Deterministic routing from the direct user request, never retrieved data.

Routing chooses a bounded workflow; it never grants general file or shell access.
Document output gets its own namespace and approval boundary below.
"""
from __future__ import annotations

import re
import secrets
import unicodedata
from pathlib import PurePosixPath

from .config import BlochAIError
from .task_scope import ScopedWorkspace
from .workspace import Workspace

FORMATS=('pdf','pptx','xlsx')
MODES=('auto','chat','coder','analyst','publisher')


def direct_text(prompt):
    if not isinstance(prompt,str):raise BlochAIError('Provide the direct user request as text.')
    lines=[];fence=None
    for line in prompt.splitlines():
        stripped=line.lstrip()
        if stripped.startswith(('```','~~~')):
            marker=stripped[:3]
            if fence is None:fence=marker
            elif marker==fence:fence=None
            continue
        if fence or stripped.startswith('>'):continue
        lines.append(line)
    # Quoted excerpts and inline code are evidence, not an authorization source.
    return re.sub(r'`[^`]*`|"[^"\n]*"','', '\n'.join(lines))


def normalize(value):
    return ''.join(char for char in unicodedata.normalize('NFKD',value.casefold()) if not unicodedata.combining(char))


def positive_text(value):
    # URLs are indivisible tokens: dots, queries, or words such as "but" inside
    # a URL must never end a negative clause and authorize another URL.
    urls=[]
    prefix='QENTLURLTOKEN'+secrets.token_hex(16)
    while prefix in value:prefix='QENTLURLTOKEN'+secrets.token_hex(16)
    def protect(match):
        raw=match.group();url=raw.rstrip('.,;:!?)]}')
        marker=prefix+str(len(urls))+'END'
        urls.append((marker,url))
        return marker+raw[len(url):]
    protected=re.sub(r'https?://[^\s<>"\x00-\x1f]+',protect,value,flags=re.IGNORECASE)
    # Only a sentence boundary or explicit adversative conjunction ends the
    # clause. Embedded dots in filenames likewise do not grant permissions.
    result=re.sub(r"\b(?:do not|don't|dont|never|nao|não|sem|without)\b.*?(?=\b(?:but|however|mas|porem|porém)\b|[;!?\n]|\.(?=\s|$)|$)",
                  ' ',protected,flags=re.IGNORECASE)
    for marker,url in urls:result=result.replace(marker,url)
    return result


def route_task(prompt,requested_mode='auto',artifact_format=None,*,code_action=False):
    if requested_mode not in MODES:raise BlochAIError('Choose auto, chat, coder, analyst or publisher mode.')
    if artifact_format is not None and artifact_format not in FORMATS:raise BlochAIError('Choose PDF, PPTX or XLSX for the document output.')
    text=normalize(positive_text(direct_text(prompt)))
    kinds=[]
    for kind,pattern in (('pdf',r'\bpdf\b'),('pptx',r'\b(?:pptx|powerpoint|slides|apresentacao|presentation)\b'),
                         ('xlsx',r'\b(?:xlsx|excel|planilha|spreadsheet|workbook)\b')):
        if re.search(pattern,text):kinds.append(kind)
    if artifact_format and artifact_format not in kinds:kinds.insert(0,artifact_format)
    creation=bool(re.search(r'\b(?:crie|criar|cria|gere|gerar|gera|faca|produza|prepare|monte|exporte|exportar|converta|create|generate|make|produce|prepare|export|convert|build)\b',text))
    negated=bool(re.search(r'\b(?:nao|never|dont|don\x27t|do not)\s+(?:\w+\s+){0,2}(?:crie|criar|gere|gerar|faca|create|generate|make|export)\b',text))
    coding=bool(re.search(r'\b(?:implemente|implementar|implement|corrija|corrigir|refatore|refactor|debug|codifique|programar)\b',text)
                or re.search(r'\b(?:crie|criar|create|build|write|escreva)\s+(?:(?:um|uma|a|an|o|the|novo|new)\s+){0,3}(?:(?:python|javascript|typescript|rust|go|java|csharp|c\+\+)\s+)?(?:script|funcao|function|classe|class|codigo|code|app|aplicativo|api|teste|test|modulo|module)\b',text))
    analysis=bool(re.search(r'\b(?:analise|analisar|analyze|analyse|investigue|investigate|pesquise|research|audite|audit|compare|revisar|revise|review)\b',text))
    effective=requested_mode;reason='selected_mode'
    if requested_mode=='auto':
        if code_action:effective='chat';reason='code_editor_request'
        elif coding:effective='coder';reason='code_development_request'
        elif artifact_format or (kinds and creation and not negated):effective='publisher';reason='document_request'
        elif analysis:effective='analyst';reason='analysis_request'
        else:effective='chat';reason='conversation_request'
    elif requested_mode=='chat' and not code_action and (artifact_format or (kinds and creation and not negated)) and not coding:
        effective='publisher';reason='document_request'
    artifact_only=not code_action and (effective=='publisher' or (effective=='analyst' and bool(artifact_format or (kinds and creation and not negated))))
    return {'requested_mode':requested_mode,'effective_mode':effective,'reason':reason,
            'artifact_only':artifact_only,'artifact_formats':kinds if artifact_only else [],
            'requires_code_scope':effective=='coder' or bool(code_action),
            'calculation_required':'forecast' if artifact_only and re.search(r'\bmonte\s*[- ]?\s*carlo\b',text) else None}


def repository_requests(prompt):
    from .github_import import requested_repository_urls
    text=normalize(positive_text(direct_text(prompt)))
    intent=re.search(r'\b(?:importe|importar|import|baixe|baixar|download|clone|clonar|analise|analisar|analyze|analyse|review|revise|inspect|inspecione|examine|estude|study)\b',text)
    denied=re.search(r'\b(?:nao|never|dont|don\x27t|do not)\s+(?:\w+\s+){0,2}(?:importe|importar|import|baixe|baixar|download|clone|clonar|analise|analisar|analyze|review|inspect)\b',text)
    return requested_repository_urls(positive_text(direct_text(prompt))) if intent and not denied else ()


class ArtifactWorkspace(ScopedWorkspace):
    """Read selected evidence; write only new requested document outputs."""
    artifact_only=True
    allow_file_writes=False

    def __init__(self,root,approve,scope,identifier,formats=(),web_urls=(),mutation_guard=None,document_brand=None,calculation_required=None):
        if not isinstance(identifier,str) or not re.fullmatch(r'[a-f0-9]{16}',identifier):raise BlochAIError('Invalid document task namespace.')
        if any(kind not in FORMATS for kind in formats):raise BlochAIError('Unsupported document format.')
        super().__init__(root,approve,scope,web_urls=web_urls,mutation_guard=mutation_guard)
        if document_brand not in (None,'qentl') or calculation_required not in (None,'forecast'):raise BlochAIError('Unsupported document task configuration.')
        self.document_brand=document_brand
        self.required_calculation=calculation_required
        self.artifact_prefix='artifacts/'+identifier
        self.artifact_formats=tuple(formats) or FORMATS
        self.required_artifact_formats=tuple(formats)
        self.scope['folders']=list(self.scope['folders'])+[self.artifact_prefix]

    def write_file(self,*_args,**_kwargs):raise BlochAIError('This document task cannot change source files. Code development requires an approved Markdown scope.')
    def edit_file(self,*_args,**_kwargs):raise BlochAIError('This document task cannot edit source files. Code development requires an approved Markdown scope.')
    def run_command(self,*_args,**_kwargs):raise BlochAIError('Shell and executable code are unavailable in this document task.')

    def create_artifact(self,kind,path,spec=None,spec_path=None):
        if self.required_calculation=='forecast' and not getattr(self,'forecast_result',None):
            raise BlochAIError('This request requires a real simulate_forecast tool result before document generation. Do not invent Monte Carlo results.')
        if self.document_brand=='qentl' and kind=='pdf':
            if spec_path is not None or not isinstance(spec,dict):raise BlochAIError('Provide an inline PDF spec for the requested Qentl brand.')
            spec={**spec,'brand':'qentl'}
        if kind not in self.artifact_formats:raise BlochAIError('Create only the document formats requested for this task: '+', '.join(self.artifact_formats)+'.')
        if not isinstance(path,str) or not path or '\\' in path or any(part in ('.','..') for part in path.split('/')):
            raise BlochAIError('Use a new document filename inside '+self.artifact_prefix+'/ .')
        if '/' not in path:path=self.artifact_prefix+'/'+path
        if not path.startswith(self.artifact_prefix+'/') or len(PurePosixPath(path).parts)!=3:
            raise BlochAIError('Document outputs must stay directly inside '+self.artifact_prefix+'/ .')
        if self._mutation_guard:self._mutation_guard()
        # The declarative writer validates extension/spec, asks approval and
        # checks generation/permission again under the publication lock.
        return Workspace.create_artifact(self,kind,path,spec,spec_path)
