"""Operator configuration, never accepted from project files or HTTP inputs."""
from __future__ import annotations

import json
import hashlib

from .config import BlochAIError, Settings, config_home
from .file_permissions import is_private


def private_model(owner, path=None):
    path = path or config_home() / 'private-provider.json'
    if not path.exists():
        return None
    try:
        if not is_private(path) or path.stat().st_size > 8192:
            raise ValueError('Private operator configuration required.')
        data = json.loads(path.read_text(encoding='utf-8'))
        allowed = {'url', 'model', 'model_digest', 'token_file', 'max_output_tokens', 'timeout'}
        if set(data) - allowed:
            raise ValueError('Unsupported private provider option.')
        settings = Settings(provider='private', tenant=owner, token_env='BLOCHAI_PRIVATE_SERVICE_TOKEN', **data).validate()
        return settings
    except (OSError, ValueError, TypeError) as exc:
        raise BlochAIError('Configuração do servidor privado inválida; o operador precisa revisar private-provider.json.') from exc


def terminal_settings():
    """Use the operator GPU with the freshly verified native Qentl account."""
    from .config import load_settings
    from .auth import PortalSession, saved_token
    settings = load_settings()
    if settings.provider not in ('qentl','rednblue'):
        return settings
    if not (config_home() / 'private-provider.json').exists():
        if settings.provider=='rednblue' and (settings.token_file or settings.token()):return settings
        raise BlochAIError('Use qentl run TASK --remote --project ID --requirement ID for hosted development, or configure a private model/local Ollama for this computer.')
    portal = PortalSession(saved_token())
    try:
        identity = portal.identity()
        user = identity.get('user', {}).get('id') or identity.get('user', {}).get('email')
        organization = identity.get('organization', {}).get('id')
        if not isinstance(user, str) or not user or not isinstance(organization, str) or not organization:
            raise BlochAIError('Qentl did not confirm the account workspace.')
        owner = hashlib.sha256((user + '\0' + organization).encode()).hexdigest()[:24]
        return private_model(owner)
    finally:
        portal.close()


def private_models(owner):
    primary = private_model(owner)
    choices = [primary] if primary else []
    directory = config_home() / 'private-providers'
    if directory.is_symlink():
        raise BlochAIError('Diretório de modelos privados inválido.')
    for path in sorted(directory.glob('*.json'))[:8]:
        item = private_model(owner, path)
        if item.model in {row.model for row in choices}:
            raise BlochAIError('Cada modelo privado precisa ter um identificador único.')
        choices.append(item)
    return choices
