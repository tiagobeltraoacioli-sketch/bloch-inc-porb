"""Local configuration; credentials never enter project files or transcripts."""
from __future__ import annotations

import json
import os
import re
import stat
from dataclasses import asdict, dataclass
from pathlib import Path
from urllib.parse import urlsplit
from .file_permissions import protect_directory, is_private


class BlochAIError(Exception):
    """An actionable error safe to display without a traceback."""


def config_home() -> Path:
    return Path(os.environ.get("BLOCHAI_CONFIG_DIR", str(Path.home() / ".config/blochai"))).expanduser()


def state_home() -> Path:
    return Path(os.environ.get("BLOCHAI_STATE_DIR", str(Path.home() / ".local/share/blochai"))).expanduser()


def private_directory(path: Path) -> None:
    if path.is_symlink():
        raise BlochAIError("The state/configuration directory must not be a symbolic link.")
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    protect_directory(path)


def save_json(path: Path, value: dict) -> None:
    private_directory(path.parent)
    if path.is_symlink():
        raise BlochAIError("Refusing to replace a symbolic link.")
    import tempfile
    fd, temporary = tempfile.mkstemp(prefix=".blochai-", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@dataclass
class Settings:
    provider: str = "qentl"
    url: str = "https://qentl.ai"
    model: str = ""
    tenant: str = "terminal-local"
    token_env: str = "BLOCHAI_API_TOKEN"
    token_file: str = ""
    timeout: float = 1800.0
    max_output_tokens: int = 16384
    model_digest: str = ""

    def validate(self) -> "Settings":
        if any(not isinstance(getattr(self,key),str) for key in ("provider","url","model","tenant","token_env","token_file","model_digest")) or type(self.timeout) not in (int,float) or type(self.max_output_tokens) is not int:
            raise BlochAIError("Invalid configuration field types.")
        if self.provider not in ("qentl", "rednblue", "gateway", "ollama", "private"):
            raise BlochAIError("Provider must be qentl, gateway, ollama, private or explicitly configured legacy rednblue.")
        parsed = urlsplit(self.url)
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise BlochAIError("The provider URL cannot contain credentials, query parameters or a fragment.")
        if not parsed.hostname or parsed.path not in ("", "/"):
            raise BlochAIError("Use the provider origin, without an API path.")
        if parsed.scheme != "https" and not (parsed.scheme == "http" and parsed.hostname in ("localhost", "127.0.0.1", "::1")):
            raise BlochAIError("Use HTTPS, or HTTP on a loopback address.")
        if self.provider == "rednblue" and self.url.rstrip("/") != "https://rednblue.space":
            raise BlochAIError("Rednblue authentication is sent only to https://rednblue.space.")
        if self.provider == 'qentl' and self.url.rstrip('/') != 'https://qentl.ai':
            raise BlochAIError('Native Qentl authentication is sent only to https://qentl.ai.')
        if not re.fullmatch(r"[a-zA-Z0-9_.:@-]{1,128}", self.tenant) or self.tenant.lower().startswith("public:"):
            raise BlochAIError("Choose a private tenant identifier of 1 to 128 ASCII identifier characters.")
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", self.token_env):
            raise BlochAIError("Invalid credential environment-variable name.")
        if not 5 <= self.timeout <= 3600 or not 1 <= self.max_output_tokens <= 32768:
            raise BlochAIError("Use timeout 5..3600 seconds and output budget 1..32768 tokens.")
        if self.provider == "ollama" and not self.model.strip():
            raise BlochAIError("Choose an installed Ollama model with blochai configure --provider ollama --model NAME.")
        if self.provider == 'private' and (not self.model.strip() or not re.fullmatch(r'[a-f0-9]{64}',self.model_digest) or not re.fullmatch(r'[a-f0-9]{24}',self.tenant)):
            raise BlochAIError('Private inference requires a pinned model digest and an account scope hash.')
        self.url = self.url.rstrip("/")
        return self

    def token(self) -> str:
        token = os.environ.get(self.token_env, "")
        if not token and self.token_file:
            path = Path(self.token_file).expanduser()
            try:
                if not is_private(path):
                    raise BlochAIError("The token file must be a regular private file (chmod 600).")
                if path.stat().st_size > 8192:
                    raise BlochAIError("Invalid token file.")
                token = path.read_text(encoding="utf-8").strip()
            except OSError as exc:
                raise BlochAIError("Cannot read the configured token file.") from exc
        if self.provider in ("gateway","private") and not token:
            raise BlochAIError(f"Set {self.token_env}, or configure a private token file with blochai configure --token-file PATH.")
        if self.provider=='private' and not re.fullmatch(r'[a-f0-9]{64}',token):
            raise BlochAIError('Private inference requires a 256-bit service credential.')
        if any(ord(c) < 33 or ord(c) == 127 for c in token):
            raise BlochAIError("The API token contains invalid characters.")
        return token

    def save(self) -> None:
        self.validate()
        save_json(config_home() / "config.json", asdict(self))


def load_settings() -> Settings:
    path = config_home() / "config.json"
    try:
        values = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        settings = Settings(**values)
        if os.environ.get("BLOCHAI_API_URL"):
            settings.url = os.environ["BLOCHAI_API_URL"]
        return settings.validate()
    except (OSError, ValueError, TypeError) as exc:
        raise BlochAIError("Invalid BlochAI configuration. Run blochai configure to replace it.") from exc
