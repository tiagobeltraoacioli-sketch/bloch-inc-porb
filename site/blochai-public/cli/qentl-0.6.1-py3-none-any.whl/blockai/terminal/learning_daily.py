"""Bounded daily evidence for the existing public-only study scheduler.

The caller holds the learning study lock. Reports contain counters and reviewed
source receipts, never prompts, generated answers, credentials or private files.
"""
from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path
import re

from .config import BlochAIError, private_directory, save_json
from .curriculum import authored_examples, digest
from .store import now
from .learning_feedback import METRICS as FEEDBACK_METRICS
from ..training.dataset import MODEL, REVISION

SCHEMA = 'qentl-learning-day-v1'
MAX_DAYS = 90
MAX_REPORT_BYTES = 1_000_000
ROLES = (
    {'id': 'sources', 'name': 'Fontes e licenças', 'skills': ['Verificar commits, licenças permissivas e hashes'], 'tasks': ['source:']},
    {'id': 'python', 'name': 'Leitura de Python', 'skills': ['Inspecionar funções e docstrings por AST, sem execução'], 'tasks': ['extract:']},
    {'id': 'arithmetic', 'name': 'Exercícios numéricos', 'skills': ['Gerar e conferir exercícios de soma'], 'tasks': ['curriculum:sum']},
    {'id': 'sequences', 'name': 'Sequências', 'skills': ['Gerar e conferir exercícios de comprimento de listas'], 'tasks': ['curriculum:length']},
    {'id': 'ordering', 'name': 'Ordenação', 'skills': ['Gerar e conferir exercícios de ordenação'], 'tasks': ['curriculum:sort']},
    {'id': 'documentation', 'name': 'Documentação e atribuição', 'skills': ['Preservar notas educacionais originais e suas referências'], 'tasks': ['reference-notes']},
    {'id': 'provenance', 'name': 'Privacidade e procedência', 'skills': ['Auditar origem autorizada e possíveis credenciais no conjunto'], 'tasks': ['quality:provenance']},
    {'id': 'evaluation', 'name': 'Testes e qualidade', 'skills': ['Conferir respostas congeladas, separação de avaliação e integridade do conjunto'], 'tasks': ['quality:frozen-reference', 'quality:split-integrity', 'quality:manifest']},
)
METRICS = ('files_verified', 'functions_retained', 'files_parsed', 'exercises',
           'reference_tests_passed', 'original_notes', 'rows_audited', 'rows_verified')


def _read(path, default=None):
    if not path.exists():
        if path.is_symlink():
            raise BlochAIError('Daily learning evidence must not use symbolic links.')
        return default
    if path.is_symlink() or not path.is_file() or path.stat().st_nlink != 1 or path.stat().st_size > MAX_REPORT_BYTES:
        raise BlochAIError('Invalid daily learning evidence file.')
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (ValueError, RecursionError, OSError) as exc:
        raise BlochAIError('Daily learning evidence could not be verified.') from exc


def _count(value):
    return value if type(value) is int and 0 <= value <= 1_000_000 else 0


def _roles(jobs):
    rows = []
    for role in ROLES:
        selected = [job for job in jobs if isinstance(job, dict) and any(
            (isinstance(job.get('id'), str) and job['id'].startswith(task)) if task.endswith(':')
            else job.get('id') == task for task in role['tasks'])]
        rows.append({'id': role['id'], 'completed': sum(job.get('status') == 'completed' for job in selected),
                     'failed': sum(job.get('status') == 'failed' for job in selected),
                     'metrics': {key: sum(_count(job.get('outcome', {}).get(key)) for job in selected
                                          if isinstance(job.get('outcome'), dict)) for key in METRICS}})
    return rows


def _scores(candidate):
    frozen = authored_examples()
    expected_ids = {split: [row['id'] for row in frozen[split]] for split in ('validation', 'test')}
    if (candidate.get('held_out_ids') != expected_ids
            or candidate.get('model') != MODEL or candidate.get('revision') != REVISION):
        return None
    result = {}
    for version in ('baseline', 'candidate'):
        metrics = candidate.get(version, {})
        if not isinstance(metrics, dict):
            return None
        result[version] = {}
        for split in ('validation', 'test'):
            row = metrics.get(split, {})
            if (not isinstance(row, dict) or type(row.get('cases')) is not int
                    or type(row.get('passed')) is not int or not 0 <= row['passed'] <= row['cases'] <= 1000
                    or row['cases'] != len(frozen[split])):
                return None
            result[version][split] = {'passed': row['passed'], 'cases': row['cases']}
    if any(result['baseline'][split]['cases'] != result['candidate'][split]['cases'] for split in ('validation', 'test')):
        return None
    deltas = {split: result['candidate'][split]['passed'] - result['baseline'][split]['passed'] for split in ('validation', 'test')}
    result['delta_passed'] = deltas
    result['model'] = MODEL
    result['model_revision'] = REVISION
    result['benchmark_sha256'] = digest({split: frozen[split] for split in ('validation', 'test')})
    result['outcome'] = ('regressed' if any(delta < 0 for delta in deltas.values()) else
                         'improved_small_benchmark' if any(delta > 0 for delta in deltas.values()) else 'unchanged')
    return result


def _feedback(candidate):
    feedback = candidate.get('feedback_loop')
    if (not isinstance(feedback, dict) or feedback.get('schema') != 'qentl-coding-feedback-v1'
            or feedback.get('model') != MODEL or feedback.get('revision') != REVISION
            or feedback.get('frozen_evaluation_used_for_feedback') is not False):
        return None
    metrics = feedback.get('metrics')
    if not isinstance(metrics, dict):
        return None
    bounds = {'tasks': 3, 'attempts': 9, 'revisions': 6, 'visible_failures': 9,
              'confirmation_rejections': 3, 'verified_solutions': 3, 'repaired_solutions': 3,
              'duplicate_solutions': 3, 'generation_errors': 3, 'budget_exhausted_rounds': 1}
    if any(type(metrics.get(key)) is not int or not 0 <= metrics[key] <= bounds[key] for key in FEEDBACK_METRICS):
        return None
    if (metrics['verified_solutions'] + metrics['confirmation_rejections'] > metrics['tasks']
            or metrics['repaired_solutions'] > metrics['verified_solutions']
            or metrics['revisions'] > metrics['attempts']):
        return None
    return {key: metrics[key] for key in FEEDBACK_METRICS}


def _receipts(sources):
    result = {}
    for source in sources[:8]:
        repository, commit = source.get('repository'), source.get('commit')
        if (not isinstance(repository, str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,80}/[A-Za-z0-9_.-]{1,80}', repository)
                or not isinstance(commit, str) or not re.fullmatch(r'[a-f0-9]{40}', commit)):
            raise BlochAIError('Invalid reviewed source receipt.')
        files = []
        for row in source['files'][:50]:
            if not re.fullmatch(r'[a-f0-9]{64}', row['sha256']):
                raise BlochAIError('Invalid reviewed source hash.')
            files.append({'path': row['path'], 'sha256': row['sha256']})
        receipt = {'repository': repository, 'commit': commit, 'license': source['license'],
                   'license_sha256': hashlib.sha256(source['license_text'].encode()).hexdigest(),
                   'files': files, 'notices': [{'path': row['path'], 'sha256': hashlib.sha256(row['text'].encode()).hexdigest()}
                                              for row in source.get('notices', [])[:8]]}
        result[repository + '@' + commit] = receipt
    return result


def _summary(day):
    rounds = list(day['rounds'].values())
    attempts = list(day['candidates'].values())
    evaluated = [row for row in attempts if row.get('evaluation')]
    roles = []
    for role in ROLES:
        observed = [row for cycle in rounds for row in cycle['roles'] if row['id'] == role['id']]
        roles.append({**role, 'completed': sum(row['completed'] for row in observed),
                      'failed': sum(row['failed'] for row in observed),
                      'metrics': {key: sum(row['metrics'].get(key, 0) for row in observed) for key in METRICS}})
    latest = max(evaluated, key=lambda row: row['observed_at']) if evaluated else None
    return {'date_utc': day['date_utc'], 'updated_at': day['updated_at'],
            'study_rounds': len(rounds), 'successful_rounds': sum(row['success'] for row in rounds),
            'failed_rounds': sum(not row['success'] for row in rounds),
            'verified_exercise_observations': sum(row['verified_exercises'] for row in rounds),
            'source_example_observations': sum(row['source_examples'] for row in rounds),
            'source_snapshots': len(day['sources']), 'roles': roles,
            'candidate_attempts': len(attempts), 'evaluated_candidates': len(evaluated),
            'completed_training_steps': sum(row['completed_steps'] for row in attempts),
            'feedback': {key: sum(row.get('feedback', {}).get(key, 0) for row in attempts if row.get('feedback')) for key in FEEDBACK_METRICS},
            'feedback_model': MODEL, 'feedback_model_revision': REVISION,
            'feedback_measurement': 'Reviewed synthetic Python input/output tests on the isolated 0.5B pilot only; no human IQ, general reasoning or serving-model improvement claim.',
            'regressed_candidates': sum(row['evaluation']['outcome'] == 'regressed' for row in evaluated),
            'improved_candidates': sum(row['evaluation']['outcome'] == 'improved_small_benchmark' for row in evaluated),
            'latest_evaluation': latest['evaluation'] if latest else None,
            'production_model_weights_updated': False, 'automatic_promotion': False,
            'measurement': 'Repeated exercise observations are not unique skills; the six-case synthetic benchmark does not measure general programming intelligence.'}


def record_daily(root, report, sources=(), observed_at=None):
    """Upsert one observed scheduler round and its candidate; requires study lock."""
    observed_at = observed_at or now()
    try:
        stamp = datetime.datetime.fromisoformat(observed_at.replace('Z', '+00:00'))
        if stamp.tzinfo is None:
            raise ValueError
        stamp = stamp.astimezone(datetime.timezone.utc)
        observed_at = stamp.isoformat()
        date = stamp.date().isoformat()
    except (ValueError, TypeError, AttributeError) as exc:
        raise BlochAIError('Daily evidence requires a UTC-aware observation time.') from exc
    directory = Path(root) / 'daily'
    private_directory(directory)
    path = directory / (date + '.json')
    day = _read(path, {'schema': SCHEMA, 'date_utc': date, 'rounds': {}, 'candidates': {}, 'sources': {}})
    if not isinstance(day, dict) or day.get('schema') != SCHEMA or day.get('date_utc') != date:
        raise BlochAIError('Daily evidence schema changed.')
    day['updated_at'] = observed_at
    fleet = report.get('fleet', {})
    round_id = report.get('round_id')
    if (type(round_id) is int and 0 <= round_id < 10_000_000_000 and isinstance(fleet, dict)
            and report.get('stage') in ('study', 'studied', 'study_failed')):
        # A resumed/candidate callback updates evidence for the same scheduler
        # slot instead of inflating its completed-job and exercise counters.
        key = str(round_id)
        success = not report.get('errors') and report.get('stage') != 'study_failed' and fleet.get('jobs_failed') == 0
        day['rounds'][key] = {'observed_at': observed_at, 'success': success,
                              'dataset_fingerprint': (report.get('dataset_fingerprint') if re.fullmatch(r'[a-f0-9]{64}', str(report.get('dataset_fingerprint', ''))) else None),
                              'verified_exercises': _count(report.get('new_verified_exercises')),
                              'source_examples': _count(report.get('source_examples')),
                              'roles': _roles(fleet.get('agents', [])[:64])}
    candidate = report.get('training')
    fingerprint = report.get('dataset_fingerprint')
    if (isinstance(candidate, dict) and re.fullmatch(r'[a-f0-9]{64}', fingerprint or '')
            and report.get('stage') in ('evaluated', 'training_failed')):
        day['candidates'][fingerprint] = {'observed_at': observed_at,
            'status': 'completed' if candidate.get('status') == 'completed' else 'failed',
            'completed_steps': _count(candidate.get('completed_steps')),
            'evaluation': _scores(candidate) if candidate.get('status') == 'completed' else None,
            'feedback': _feedback(candidate),
            'promoted': False, 'production_model_weights_updated': False}
    day['sources'].update(_receipts(list(sources)))
    if len(day['rounds']) > 288 or len(day['candidates']) > 288 or len(day['sources']) > 64:
        raise BlochAIError('Daily evidence exceeded its reviewed bounds.')
    day['summary'] = _summary(day)
    if len(json.dumps(day, ensure_ascii=False, indent=2).encode()) + 1 > MAX_REPORT_BYTES:
        raise BlochAIError('Daily evidence exceeded its storage budget.')
    save_json(path, day)
    reports = sorted((item for item in directory.glob('????-??-??.json') if re.fullmatch(r'\d{4}-\d{2}-\d{2}', item.stem)), reverse=True)
    for old in reports[MAX_DAYS:]:
        if old.is_symlink() or not old.is_file() or old.stat().st_nlink != 1:
            raise BlochAIError('Invalid archived daily evidence.')
        old.unlink()
    reports = reports[:MAX_DAYS]
    recent = [{key: value for key, value in _read(item)['summary'].items() if key not in ('roles', 'measurement')}
              for item in reports[:7]]
    dashboard = {'schema': 'qentl-learning-daily-dashboard-v1', 'updated_at': observed_at,
                 'retained_days': min(len(reports), MAX_DAYS), 'retention_days': MAX_DAYS,
                 'roles': list(ROLES), 'recent_days': recent, 'latest': day['summary'],
                 'actual_execution': 'Eight skill roles over bounded Python study jobs; concurrency is the configured worker ceiling, not eight simultaneous LLMs.',
                 'unsupported_training_languages': ['JavaScript', 'TypeScript'],
                 'private_user_data_training': False, 'automatic_promotion': False,
                 'production_model_weights_updated': False}
    dashboard['source_receipts'] = [{key: value for key, value in receipt.items() if key not in ('files', 'notices')}
                                    | {'files_verified': len(receipt['files']), 'receipt_sha256': digest(receipt)}
                                    for receipt in list(day['sources'].values())[-8:]]
    if len(json.dumps(dashboard, ensure_ascii=False, indent=2).encode()) + 1 > 40000:
        raise BlochAIError('Daily dashboard exceeded its reviewed response budget.')
    save_json(directory / 'status.json', dashboard)
    return day['summary']
