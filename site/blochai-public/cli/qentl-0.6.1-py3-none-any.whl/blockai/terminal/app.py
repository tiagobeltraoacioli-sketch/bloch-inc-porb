"""BlochAI terminal entry point; the legacy blockai command remains available."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from .agents import AGENTS, AgentRunner, fit_messages
from .auth import PortalSession, saved_token, session_path
from .config import BlochAIError, Settings, config_home, load_settings, state_home
from .providers import Provider
from .private_models import terminal_settings
from .store import RunStore, scrub
from .workspace import Workspace, clean_text
from .research import requested_urls
from .model_context import conversation_context

app = typer.Typer(help="Qentl — Quantum Entanglement by Bloch Inc.: talk, build projects, create files and review learning runs.", no_args_is_help=False)
agents = typer.Typer(help="Specialist Bloch Agents.")
runs = typer.Typer(help="Private execution history.")
learn = typer.Typer(help="Continuous learning and reviewed programming datasets.")
project_commands = typer.Typer(help="Authenticated projects shared with the Qentl Graphus workspace.")
app.add_typer(agents, name="agents")
app.add_typer(runs, name="runs")
app.add_typer(learn, name="learn")
app.add_typer(project_commands, name="projects")
console = Console(markup=False, highlight=False)


def show(value):
    console.print(clean_text(value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2)))


def approval(automatic=False):
    def decide(action, preview):
        show(preview)
        if automatic:
            show("Approved by explicit --yes for this run.")
            return True
        return typer.confirm("Allow this " + action + "?", default=False)
    return decide


def event(item):
    if item["kind"] == "inference_submitted":
        show("Inference task: " + item["task_id"])
    elif item["kind"] == "tool_result":
        show({"agent":item["agent"], "tool":item["action"], "result":item["result"]})
    elif item["kind"] == "tool_error":
        show("Tool: " + item["message"])


@app.callback(invoke_without_command=True)
def root(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        _chat_session()


@app.command()
def configure(provider: str = "qentl", url: Optional[str] = None, model: str = "",
              tenant: str = "terminal-local", token_file: str = "", max_output_tokens: int = 16384,
              timeout: float = 1800.0):
    """Select native Qentl, an operator gateway, or an installed Ollama model."""
    origin = url or ("http://127.0.0.1:11434" if provider == "ollama" else "https://rednblue.space" if provider == "rednblue" else "https://qentl.ai")
    Settings(provider=provider, url=origin, model=model, tenant=tenant,
             token_file=token_file, max_output_tokens=max_output_tokens, timeout=timeout).save()
    show("Configuration saved. Use qentl login for native Qentl access. Remote projects are available with --remote.")


@app.command()
def login(email: Optional[str] = typer.Option(None, help="Invited Qentl account email.")):
    """Authenticate with native Qentl. New accounts require an invitation; passwords are never saved."""
    portal = PortalSession()
    try:
        identity = portal.login(email or typer.prompt("Qentl email"), typer.prompt("Qentl password", hide_input=True))
        portal.save(identity)
        show({"user":identity["user"], "organization":identity["organization"]})
    finally:
        portal.close()


@app.command()
def whoami():
    """Validate the native Qentl session and account workspace."""
    portal = PortalSession(saved_token())
    try:
        show(portal.identity())
    finally:
        portal.close()


@app.command()
def organization(identifier: str):
    """Check the native Qentl account workspace; external organization switching is unavailable."""
    portal = PortalSession(saved_token())
    try:
        identity = portal.switch(identifier)
        portal.save(identity)
        show(identity["organization"])
    finally:
        portal.close()


@app.command()
def logout():
    """Revoke this Qentl session and remove its local credential."""
    portal = PortalSession(saved_token())
    try:
        portal.logout()
        session_path().unlink(missing_ok=True)
        show("Signed out.")
    finally:
        portal.close()


@app.command()
def status():
    """Inspect the actual inference model, availability and context limits."""
    provider = Provider(terminal_settings())
    try:
        show(provider.status())
    finally:
        provider.close()


@app.command()
def task(identifier: str):
    """Retrieve a previously submitted inference task without resubmitting it."""
    provider = Provider(load_settings())
    try:
        show(provider.task(identifier))
    finally:
        provider.close()


@app.command()
def ask(prompt: str):
    """Ask the LLM a question; this command never executes generated text."""
    provider = Provider(terminal_settings(), on_task=lambda ident: show("Inference task: " + ident))
    try:
        result = provider.complete([{"role":"system","content":conversation_context()}, {"role":"user","content":prompt}])
        show(result.text)
    finally:
        provider.close()


@app.command('web-policy')
def web_policy():
    """List permitted public sites and the bounded, read-only retrieval policy."""
    from .safe_web import policy
    show(policy())


@app.command('web-read')
def web_read(url: str):
    """Read an explicitly requested permitted public URL, without login or scripts."""
    from .research import read_web
    show(read_web(url,explicit_url=True))


@project_commands.command('list')
def list_projects(projects_root: Optional[Path] = typer.Option(None,help='Project storage root; defaults to the same existing or fresh workspace as the desktop app.'),
                  remote: bool = typer.Option(False,'--remote',help='List owned projects on https://qentl.ai using the current Qentl account.')):
    """List projects for the current native Qentl account workspace."""
    if remote:
        if projects_root is not None:raise BlochAIError('--projects-root is local; omit it for qentl.ai.')
        from .remote_projects import RemoteSession
        with RemoteSession() as session:show(session.projects())
        return
    from .cli_projects import ProjectSession
    session=ProjectSession(projects_root)
    try:show({'projects':session.catalog.list()})
    finally:session.close()


@project_commands.command('create')
def create_project(name: str,description: str='',kind: str='code',remote: bool=typer.Option(False,'--remote'),
                   projects_root: Optional[Path]=typer.Option(None)):
    """Create one project in the selected local or qentl.ai account."""
    if remote:
        if projects_root is not None:raise BlochAIError('--projects-root is local; omit it for qentl.ai.')
        from .remote_projects import RemoteSession
        with RemoteSession() as session:show(session.create(name,description,kind))
        return
    from .cli_projects import ProjectSession
    session=ProjectSession(projects_root)
    try:session.check(write=True);show({'project':session.catalog.create(name,description,kind)})
    finally:session.close()


@project_commands.command('scope')
def project_scope(project: str,remote: bool=typer.Option(False,'--remote'),projects_root: Optional[Path]=typer.Option(None)):
    """Inspect scope requirements; approval remains an explicit owner action."""
    if remote:
        if projects_root is not None:raise BlochAIError('--projects-root is local; omit it for qentl.ai.')
        from .remote_projects import RemoteSession
        with RemoteSession() as session:data=session.scope(project)
    else:
        from .cli_projects import ProjectSession
        from .closed_scope import ClosedScopeStore
        session=ProjectSession(projects_root)
        try:data=ClosedScopeStore(session.catalog,project).status()
        finally:session.close()
    contract=data.get('contract') or {}
    show({**{key:data.get(key) for key in ('state','revision','version','progress')},
          'source_paths':contract.get('source_paths',[]),'requirements':contract.get('requirements',[]),'allowed_paths':contract.get('allowed_paths',[])})


@project_commands.command('path')
def project_path(project: str,projects_root: Optional[Path] = typer.Option(None,help='Project storage root; defaults to the desktop workspace.')):
    """Print the actual workspace path for an owned Graphus project."""
    from .cli_projects import ProjectSession
    session=ProjectSession(projects_root)
    try:typer.echo(str(session.folder(project).resolve()))
    finally:session.close()


@app.command()
def run(task: str, workspace: Path = typer.Option(Path(".")), agent: str = "coder",
        max_steps: int = 16, yes: bool = typer.Option(False, "--yes", help="Explicitly approve all host edits and commands in this run."),
        project: Optional[str] = None, projects_root: Optional[Path] = typer.Option(None,help='Project storage root; defaults to the desktop workspace.'),
        requirement: Optional[str] = typer.Option(None,help='Requirement ID from the owner-approved Markdown project scope.'),
        scope_revision: Optional[str] = typer.Option(None,help='Require this exact approved scope revision.'),
        remote: bool = typer.Option(False,'--remote',help='Run in the selected qentl.ai project; no local files are uploaded.'),
        model: Optional[str] = typer.Option(None,help='Hosted model ID for --remote runs only.')):
    """Let an agent inspect a project, propose edits and run approved host commands."""
    if agent not in AGENTS and not (remote and agent in ('auto','chat')):raise BlochAIError('Choose a known agent, or --agent auto/chat for a remote task.')
    if remote:
        if not project or workspace!=Path('.') or projects_root is not None:
            raise BlochAIError('Remote runs require --project and do not accept a local workspace. Use qentl sync to transfer a selected folder.')
        if max_steps!=16:raise BlochAIError('The hosted service controls its step budget; --max-steps is a local-run option.')
        from .remote_projects import RemoteSession
        with RemoteSession() as session:
            result=session.submit(project,task,agent,requirement,scope_revision,model)
            show({'job_id':result['id'],'project':project,'site':'https://qentl.ai','note':'The task runs on the server. Ctrl+C stops waiting; use remote-cancel to cancel it.'})
            result=session.follow(result['id'],project,approval(yes),show)
            show({'job_id':result['id'],'project':project,'status':result['status'],'summary':result.get('summary','')})
        return
    if model is not None:raise BlochAIError('--model on qentl run is a hosted option; configure the local provider separately.')
    if project is not None:
        if workspace!=Path('.'):
            raise BlochAIError('Choose --project or --workspace; the private project path is resolved from your account.')
        from .cli_projects import ProjectSession, ProjectProvider, ProjectRunStore
        from .task_routing import route_task
        document_routing=route_task(task,agent) if agent in ('publisher','analyst') else {'artifact_only':False}
        session=ProjectSession(projects_root);provider=None
        try:
            session.check(write=True);folder=session.folder(project)
            from .closed_scope import ClosedScopeStore
            closed_scope=None
            if not document_routing['artifact_only'] and (agent in ('coder','coordinator','tester') or requirement is not None or scope_revision is not None):
                closed_scope=ClosedScopeStore(session.catalog,project).require(requirement,scope_revision)
            settings=session.settings()
            provider=Provider(settings,private_local=settings.provider=='ollama')
            guarded=ProjectProvider(provider,session,project,closed_scope)
            prepared=session.task(project,task,guarded,agent)
            with ProjectRunStore(session.owner,project,folder,secrets=(provider.secret,session.portal.token),closed_scope=closed_scope) as store:
                guarded.run_store=store
                scoped=session.workspace(project,approval(yes),web_urls=requested_urls(task),run_guard=store.ensure_active,closed_scope=closed_scope,artifact_formats=document_routing['artifact_formats'] if document_routing['artifact_only'] else None)
                if document_routing['artifact_only']:
                    from .interactive import requested_brand
                    scoped.document_brand=requested_brand(task);scoped.required_calculation=document_routing.get('calculation_required')
                result=AgentRunner(guarded,scoped,store,notify=event).run(prepared,agent,max_steps)
            show({'run_id':result['id'],'project':project,'status':result['status'],'summary':result['summary'],
                  'workspace':str(folder.resolve()),'graphus_sync':'Files are visible in this account’s project.'})
        finally:
            if provider:provider.close()
            session.close()
        return
    if requirement is not None or scope_revision is not None:
        raise BlochAIError('Closed-scope requirement options require an authenticated --project run.')
    provider = Provider(terminal_settings())
    try:
        from .task_routing import route_task,ArtifactWorkspace
        from .task_scope import resolve_scope
        from .interactive import requested_brand
        import secrets
        document_routing=route_task(task,agent) if agent in ('publisher','analyst') else {'artifact_only':False}
        tools=(ArtifactWorkspace(workspace,approval(yes),resolve_scope({'nodes':[]}),secrets.token_hex(8),document_routing['artifact_formats'],
                                 web_urls=requested_urls(task),document_brand=requested_brand(task),calculation_required=document_routing.get('calculation_required'))
               if document_routing['artifact_only'] else Workspace(workspace,approval(yes),allow_commands=agent!='analyst',web_urls=requested_urls(task)))
        result = AgentRunner(provider,tools,notify=event).run(task,agent,max_steps)
        show({"run_id":result["id"], "status":result["status"], "summary":result["summary"]})
    finally:
        provider.close()


@app.command('remote-job')
def remote_job(identifier: str,project: str=typer.Option(...),yes: bool=typer.Option(False,'--yes')):
    """Follow a qentl.ai task and review its pending file approvals."""
    from .remote_projects import RemoteSession
    with RemoteSession() as session:
        result=session.follow(identifier,project,approval(yes),show)
        show({'job_id':identifier,'project':project,'status':result['status'],'summary':result.get('summary','')})


@app.command('remote-cancel')
def remote_cancel(identifier: str):
    """Explicitly request cancellation of an owned qentl.ai task."""
    from .remote_projects import RemoteSession
    with RemoteSession() as session:show(session.cancel(identifier))


@app.command('sync')
def sync_project(project: str=typer.Option(...),workspace: Path=typer.Option(...,help='Only this explicitly selected directory is transferred.'),
                 pull: bool=typer.Option(False,'--pull',help='Fetch remote edits into the bound local folder without overwriting local changes.'),
                 watch: bool=typer.Option(False,'--watch',help='Repeat for this directory until Ctrl+C. No deletions are propagated.'),
                 dry_run: bool=typer.Option(False,'--dry-run',help='Show changes without creating a binding or writing files.'),
                 interval: float=typer.Option(3,help='Seconds between --watch passes (1..60).')):
    """Sync selected UTF-8 source files with their Graphus folder on qentl.ai."""
    import time
    from .remote_projects import FolderSync,RemoteSession
    if not 1<=interval<=60 or (watch and dry_run):raise BlochAIError('Use interval 1..60 seconds; --dry-run performs one preview only.')
    with RemoteSession() as session:
        show({'site':'https://qentl.ai','user':session.identity['user'],'organization':session.identity['organization'],
              'project':project,'workspace':str(workspace.expanduser().resolve()),'direction':'pull' if pull else 'push'})
        sync=FolderSync(session,project,workspace);last=None
        while True:
            result=sync.once(pull=pull,dry_run=dry_run,notify=lambda progress:show({'sync_progress':progress}));signature=json.dumps(result,sort_keys=True)
            if signature!=last or result.get('changes'):show(result);last=signature
            if not watch:break
            time.sleep(interval)


@app.command()
def analyze(question: str, workspace: Path = typer.Option(Path(".")), max_steps: int = 24):
    """Research supplied files and permitted sources, then challenge the conclusions."""
    from .analysis import investigate
    provider=Provider(terminal_settings())
    try:
        result=investigate(provider,Workspace(workspace,approval(),allow_commands=False,web_urls=requested_urls(question)),question,notify=event,max_steps=max_steps)
        show({"run_id":result["id"],"status":result["status"],"summary":result["summary"]})
    finally:
        provider.close()


@app.command()
def chat(workspace: Optional[Path] = typer.Option(None,help='Explicit local read context; the default console uses isolated scratch storage.'),
         remote: bool = typer.Option(False,'--remote',help='Use a hosted Qentl.ai project without uploading a local folder.'),
         project: Optional[str] = typer.Option(None,help='Owned local or hosted project ID.'),
         projects_root: Optional[Path] = typer.Option(None),
         requirement: Optional[str] = typer.Option(None,help='Approved code requirement for project development.'),
         scope_revision: Optional[str] = typer.Option(None)):
    """Interactive auto routing: talk, analyze and generate PDF/PPTX/XLSX without /run."""
    return _chat_session(workspace,remote,project,projects_root,requirement,scope_revision)


def _chat_session(workspace=None,remote=False,project=None,projects_root=None,requirement=None,scope_revision=None):
    import secrets
    from .interactive_ui import InteractiveUI
    ui=InteractiveUI(console)
    from .config import private_directory
    from .interactive import Transcript,wants_download,requested_brand
    from .document_exports import local_document,export_download,receipt_name
    from .task_routing import route_task,ArtifactWorkspace
    from .task_scope import ScopedWorkspace,resolve_scope
    if remote and (not project or workspace is not None or projects_root is not None):
        raise BlochAIError('Use chat --remote --project ID; no local workspace is uploaded.')
    if project and workspace is not None:raise BlochAIError('Choose --project or an explicit --workspace, not both.')
    if not project and (requirement or scope_revision or projects_root is not None):raise BlochAIError('Project scope options require --project.')
    if workspace is not None:
        workspace=Path(workspace).expanduser()
        if workspace.is_symlink() or not workspace.is_dir() or workspace.resolve() in (Path.home().resolve(),Path(workspace.anchor)):
            raise BlochAIError('Select a specific project directory for read context, not HOME, a drive root or a symbolic link.')
        workspace=workspace.resolve()
    transcript=Transcript();documents=[];provider=None;session=None;remote_session=None
    trace_root=state_home()/'interactive-runs'/secrets.token_hex(16)
    def scratch():
        path=state_home()/'interactive'/secrets.token_hex(16)
        private_directory(path)
        return path
    root_folder=workspace or (None if project else scratch())
    try:
        if remote:
            from .remote_projects import RemoteSession
            remote_session=RemoteSession()
            rows=remote_session.projects().get('projects',[])
            if project not in {row.get('id') for row in rows}:raise BlochAIError('Choose an owned project from qentl projects list --remote.')
            context_label='Hosted project on https://qentl.ai'
            ui.welcome(context_label,project=project)
        else:
            if project:
                from .cli_projects import ProjectSession
                session=ProjectSession(projects_root);root_folder=session.folder(project)
                settings=session.settings()
            else:settings=terminal_settings()
            provider=Provider(settings,private_local=settings.provider=='ollama')
            context_label='Authenticated local project' if project else 'Explicit local read context' if workspace else 'Private scratch conversation; no HOME or current-directory scan'
            ui.welcome(context_label,settings.model,project)
        def export_one(index):
            if not 0<=index<len(documents):raise BlochAIError('Choose a generated document number from /artifacts.')
            row=documents[index]
            document=(remote_session.artifact_document(row['job'],project,row['receipt']) if row['kind']=='remote'
                      else local_document(row['root'],row['receipt']))
            show(export_download(document,approval()))
        while True:
            try:prompt=typer.prompt('You',prompt_suffix=' > ').strip()
            except (EOFError,typer.Abort):break
            if prompt in ('/quit','/exit'):break
            if not prompt:continue
            try:
                if prompt=='/reset':
                    transcript.clear();documents.clear()
                    if not project and workspace is None:root_folder=scratch()
                    show('Conversation reference and document selections cleared.');continue
                if prompt=='/help':ui.help();continue
                if prompt=='/skills' or prompt.startswith('/skills '):
                    from .programming_skills import programming_skills
                    ui.skills(programming_skills(prompt.partition(' ')[2].strip() or 'all'));continue
                if prompt=='/status':
                    ui.status({} if remote else provider.status(),context=context_label,project=project);continue
                if prompt=='/artifacts':
                    ui.artifacts([{'number':index+1,'name':receipt_name(row['receipt']),'sha256':row['receipt']['sha256']} for index,row in enumerate(documents)]);continue
                if prompt.startswith('/download'):
                    parts=prompt.split()
                    if len(parts)!=2 or not parts[1].isdigit():show('Usage: /download NUMBER (choose a generated file from /artifacts)');continue
                    export_one(int(parts[1])-1);continue
                if prompt.startswith('/requirement'):
                    parts=prompt.split()
                    if len(parts)!=2 or not project:show('Usage: /requirement ID in chat --project PROJECT [--remote]');continue
                    requirement=parts[1];scope_revision=None;show('Selected requirement: '+requirement);continue
                selected_mode='auto';question=prompt
                if prompt in ('/run','/analyze'):
                    show('Usage: /run TASK or /analyze QUESTION. Plain PDF/PPTX/Excel requests need no /run.');continue
                if prompt.startswith(('/run ','/analyze ')):
                    selected_mode='auto' if prompt.startswith('/run ') else 'analyst';question=prompt.split(' ',1)[1].strip()
                elif prompt.startswith('/'):
                    ui.help();continue
                routing=route_task(question,selected_mode);mode=routing['effective_mode']
                ui.task(mode,routing.get('artifact_formats',()))
                new_documents=[]
                if remote:
                    created=remote_session.submit(project,question,selected_mode,requirement,scope_revision,reference_context=transcript.reference_context())
                    ui.text('Hosted job '+created['id']+' · Ctrl+C stops waiting; remote-cancel explicitly cancels the task.')
                    result=remote_session.follow(created['id'],project,approval(),ui.remote_event)
                    for receipt in result.get('artifacts',[]):
                        receipt_name(receipt);new_documents.append({'kind':'remote','job':created['id'],'receipt':receipt})
                    answer=result.get('summary','')
                else:
                    if mode=='coder' and not session:
                        raise BlochAIError('For code development, select chat --project ID --requirement REQ (or add --remote for the site). The default console does not run shell commands or scan HOME.')
                    closed_scope=None;active_provider=provider
                    if session:
                        from .closed_scope import ClosedScopeStore
                        from .cli_projects import ProjectProvider
                        session.check(write=mode!='chat')
                        if mode=='coder' or (not routing['artifact_only'] and requirement):
                            closed_scope=ClosedScopeStore(session.catalog,project).require(requirement,scope_revision)
                        active_provider=ProjectProvider(provider,session,project,closed_scope)
                    question_with_context=transcript.task(question)
                    if mode=='chat':
                        result=active_provider.complete(fit_messages(active_provider,[{'role':'system','content':conversation_context()}, {'role':'user','content':question_with_context}]))
                        answer=result.text
                    else:
                        if session:
                            from .cli_projects import ProjectRunStore
                            store=ProjectRunStore(session.owner,project,root_folder,secrets=(provider.secret,session.portal.token),closed_scope=closed_scope)
                            active_provider.run_store=store
                            tool_workspace=session.workspace(project,approval(),web_urls=requested_urls(question),run_guard=store.ensure_active,closed_scope=closed_scope,
                                artifact_formats=routing['artifact_formats'] if routing['artifact_only'] else None)
                            prepared=session.task(project,question_with_context,active_provider,mode)
                        else:
                            store=RunStore(trace_root,secrets=(provider.secret,),training_allowed=False)
                            prepared=question_with_context
                            tool_workspace=(ArtifactWorkspace(root_folder,approval(),resolve_scope({'nodes':[]}),secrets.token_hex(8),routing['artifact_formats'],web_urls=requested_urls(question))
                                            if routing['artifact_only'] else ScopedWorkspace(root_folder,approval(),resolve_scope({'nodes':[]}),web_urls=requested_urls(question),mutation_guard=lambda:(_ for _ in ()).throw(BlochAIError('This analysis is read-only.'))))
                            if not routing['artifact_only']:tool_workspace.allow_file_writes=False;tool_workspace.allow_artifacts=False
                        if not routing['artifact_only'] and not closed_scope:
                            tool_workspace.allow_file_writes=False;tool_workspace.allow_artifacts=False
                        if routing['artifact_only']:
                            tool_workspace.document_brand=requested_brand(question)
                            tool_workspace.required_calculation=routing.get('calculation_required')
                        from contextlib import nullcontext
                        with store if session else nullcontext(store):
                            result=AgentRunner(active_provider,tool_workspace,store,notify=ui.event).run(prepared,mode,24)
                        answer=result['summary']
                        for item in result.get('events',[]):
                            if item.get('action')=='create_artifact' and item.get('result',{}).get('sha256'):
                                receipt=item['result'];receipt_name(receipt)
                                if receipt['path'] not in {row['receipt']['path'] for row in new_documents}:
                                    new_documents.append({'kind':'local','root':root_folder,'receipt':receipt})
                        ui.result(result['status'])
                ui.answer(answer);transcript.add(question,answer)
                first=len(documents);documents.extend(new_documents)
                if new_documents:
                    ui.artifacts([{'number':first+index+1,'name':receipt_name(row['receipt']),'sha256':row['receipt']['sha256']} for index,row in enumerate(new_documents)])
                    if wants_download(question):
                        for index in range(first,len(documents)):export_one(index)
                    else:show('Use /download NUMBER to copy a generated file to Downloads after confirmation.')
            except BlochAIError as exc:ui.error(str(exc))
    finally:
        if provider:provider.close()
        if session:session.close()
        if remote_session:remote_session.close()


@agents.command("list")
def list_agents():
    for key, value in AGENTS.items():
        show(key + ": " + value["goal"])


@runs.command("list")
def list_runs():
    for record in RunStore().list()[:50]:
        show({key:record[key] for key in ("id", "agent", "status", "task", "updated_at")})


@runs.command("show")
def show_run(identifier: str):
    show(RunStore().load(identifier))


@runs.command("resume")
def resume(identifier: str, max_steps: int = 16, yes: bool = False):
    provider = Provider(terminal_settings())
    try:
        store = RunStore(secrets=(provider.secret,))
        record = store.load(identifier)
        result = AgentRunner(provider, Workspace(Path(record["workspace"]), approval(yes)), store, event).run(
            record["task"], record["agent"], max_steps, record=record)
        show({"run_id":result["id"], "status":result["status"], "summary":result["summary"]})
    finally:
        provider.close()


@learn.command("approve")
def approve_run(identifier: str, reviewer: str, license_name: str, note: str):
    """Mark an inspected, successfully tested trace as reusable for training."""
    show(RunStore().approve(identifier, reviewer, license_name, note))


@learn.command("export")
def export_runs(destination: Path):
    show(RunStore().export(destination))


@learn.command("cycle")
def learn_cycle(directory: Path = typer.Option(None), training: bool = False):
    """Run one bounded study/evaluation cycle; --training requires an isolated GPU."""
    from .learning import cycle
    show(cycle(directory or state_home()/"learning", training=training))


@learn.command("status")
def learn_status(directory: Path = typer.Option(None)):
    path = (directory or state_home()/"learning")/"status.json"
    show(json.loads(path.read_text()) if path.exists() else {"status":"not_started"})


@app.command()
def serve(port: int = 8765, workspace: Path = typer.Option(Path.home()/"blochai-projects"),
          public_origin: Optional[str]=typer.Option(None,help='Operator-only fixed HTTPS origin behind a trusted local proxy.')):
    """Open the workbench using native Qentl login. Binds loopback only."""
    import uvicorn
    from .web import create_app
    if not 1024 <= port <= 65535:
        raise BlochAIError("Choose a port from 1024 to 65535.")
    workspace.mkdir(parents=True, exist_ok=True)
    web=create_app(workspace,port,public_origin=public_origin)
    show(f"Qentl: {public_origin or 'http://127.0.0.1:'+str(port)} · sign in with Qentl")
    uvicorn.run(web,host="127.0.0.1",port=port,log_level="warning",access_log=False,proxy_headers=False)


@app.command()
def artifact(kind: str, specification: Path, output: str, workspace: Path = typer.Option(Path(".")), yes: bool = False):
    """Generate PDF/PPTX/XLSX from an explicit JSON spec, without an LLM call."""
    root=workspace.resolve()
    try:
        relative=specification.resolve().relative_to(root).as_posix()
    except ValueError as exc:
        raise BlochAIError("The JSON specification must be inside the selected workspace.") from exc
    show(Workspace(root,approval(yes)).create_artifact(kind,output,spec_path=relative))


def main():
    try:
        app()
    except BlochAIError as exc:
        show("Qentl: " + str(exc))
        raise SystemExit(1)
    except KeyboardInterrupt:
        show("Interrupted.")
        raise SystemExit(130)


if __name__ == "__main__":
    main()
