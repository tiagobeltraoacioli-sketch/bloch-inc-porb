"""Human-requested file lifecycle; no code execution or implicit content erasure.

Call under the physical project write lock. Trash payloads stay on the same
filesystem, outside every graph/export/tool allowlist, until explicit restore
or whole-project deletion. Multi-file failures roll back bytes and indexes.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import tempfile
import time
from urllib.parse import quote

from .config import BlochAIError, private_directory, save_json
from .folder_import import _path, _skip_reason, MAX_FILE_BYTES
from .knowledge import KnowledgeStore, MAX_NOTES, key, valid_title
from .projects import CODE_EXTENSIONS, UPLOAD_ID
from .ingest_policy import current_policy, ensure_space
from .remote_sync import _text
from .workspace import Workspace

TRASH='.qentl-trash'
MAX_TRASH_ENTRIES=20
MAX_TRASH_BYTES=100*1024*1024
SHA=re.compile(r'[a-f0-9]{64}')


class FileConflict(BlochAIError):
    pass


def digest(raw):return hashlib.sha256(raw).hexdigest()
def code_id(path):return 'code:'+digest(path.encode())[:16]


def source_path(value,kind='code'):
    # Imported/synced namespaces add components to the user's portable path.
    # Validate each component with the same rules without reapplying the import
    # envelope's shorter whole-path/depth limit to an already-visible file.
    if not isinstance(value,str) or not 1<=len(value)<=360:raise BlochAIError('Use a relative project source path of at most 360 characters.')
    parts=value.split('/')
    value='/'.join(_path('project/'+part)[8:] for part in parts)
    parts=value.split('/')
    reason=_skip_reason(parts,0)
    if reason and reason!='depth_limit':raise BlochAIError('Choose a supported, non-hidden source path outside credentials, dependencies and build folders.')
    if len(parts)>8:raise BlochAIError('Use at most eight path components.')
    if Path(value).suffix.lower() not in CODE_EXTENSIONS and parts[-1] not in ('Dockerfile','Makefile'):
        raise BlochAIError('Choose a supported UTF-8 source extension.')
    if kind=='note':
        if parts[0]!='knowledge' or len(parts)<2 or Path(value).suffix.lower()!='.md':
            raise BlochAIError('Move a managed note only within knowledge/ and keep the .md extension.')
    elif parts[0] in ('uploads','knowledge'):
        raise BlochAIError('Managed attachments and notes have their own protected file areas.')
    return value


class FileOperations:
    def __init__(self,catalog,project,secret_values=()):
        self.catalog,self.project,self.secrets=catalog,project,secret_values
        self.folder=catalog.folder(project)
        self.workspace=Workspace(self.folder,lambda *_:False,allow_commands=False)
        self.knowledge=KnowledgeStore(catalog,project)
        self.trash=self.folder/TRASH

    def _destination(self,relative,allow_existing=False):
        path=self.workspace.path(relative)
        current=self.folder
        for component in relative.split('/'):
            if current.exists():
                for child in current.iterdir():
                    if child.name.casefold()==component.casefold() and child.name!=component:
                        raise FileConflict('The destination collides with a filename that differs only in case.')
            current=current/component
            if current!=path and current.exists() and not current.is_dir():raise FileConflict('A destination parent is already a file.')
        if path.exists() and not allow_existing:raise FileConflict('The destination already exists. No file was overwritten.')
        return path

    def _raw(self,path,maximum=20*1024*1024):
        checked=self.workspace.path(path)
        if not checked.is_file() or checked.stat().st_size>maximum:raise BlochAIError('The selected file is missing or exceeds the operation limit.')
        return checked.read_bytes()

    def _selected(self,node):
        if not isinstance(node,str):raise FileNotFoundError('Select a file node in this project.')
        notes=self.knowledge.records();linked=[]
        if re.fullmatch(r'code:[a-f0-9]{16}',node):
            row=next((item for item in self.catalog.code_files(self.project)['files'] if item['id']==node),None)
            if not row:raise FileNotFoundError('Source file not found.')
            source_path(row['path']);raw=self._raw(row['path'],1_000_000)
            files={row['path']:raw};kind='code';hint=row['path']
        elif UPLOAD_ID.fullmatch(node):
            row=next((item for item in notes if item['id']==node),None)
            if not row:raise FileNotFoundError('Markdown note not found.')
            source_path(row['path'],'note');files={row['path']:self._raw(row['path'],MAX_FILE_BYTES)}
            kind='note';hint=row['path']
        elif re.fullmatch(r'source:[a-f0-9]{16}',node):
            row=self.catalog.upload_record(self.project,node[7:]);files={};kind='upload'
            prefix='uploads/'+row['id']+'/'
            for field in ('path','text_path','preview_path'):
                if row.get(field):
                    if not row[field].startswith(prefix):raise BlochAIError('Attachment file metadata leaves its managed bundle.')
                    files[row[field]]=self.catalog.checked_bytes(self.project,row,field)
            bundle=self.workspace.path(prefix.rstrip('/'),directory=True)
            actual=set()
            for directory,dirs,names in os.walk(bundle,followlinks=False):
                if len(actual)+len(dirs)+len(names)>20:raise BlochAIError('Attachment bundle contains unexpected files.')
                for name in dirs:
                    if (Path(directory)/name).is_symlink():raise BlochAIError('Attachment bundles cannot contain links.')
                for name in names:
                    relative=(Path(directory)/name).relative_to(self.folder).as_posix()
                    self.workspace.path(relative);actual.add(relative)
            if actual!=set(files):raise BlochAIError('Attachment bundle changed outside the managed file workflow.')
            linked=[item for item in notes if row['id'] in item['source_ids']]
            hint=row.get('display_path',row['name'])
        else:raise FileNotFoundError('Choose a file, note or attachment node; folders and symbols are not files.')
        edges=self.knowledge.connections()
        linked_files={item['path']:self._raw(item['path'],MAX_FILE_BYTES) for item in linked}
        revision=digest(json.dumps({'row':row,'files':{path:digest(raw) for path,raw in files.items()},
                                   'linked':linked,'linked_files':{path:digest(raw) for path,raw in linked_files.items()},
                                   'edges':edges},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
        public={'node_id':node,'kind':kind,'title':row.get('title',row.get('name',row['path'])),
                'path':row['path'],'revision':revision,'move_mode':'path','destination_hint':hint}
        return {'item':public,'row':row,'files':files,'linked':linked,'linked_files':linked_files,'edges':edges}

    def inspect(self,node):
        selected=self._selected(node)
        return {'item':selected['item'],'capabilities':{'move':True,'trash':True},
                'linked_notes':[{'id':row['id'],'title':row['title']} for row in selected['linked']]}

    def _check(self,node,revision):
        if not isinstance(revision,str) or not SHA.fullmatch(revision):raise BlochAIError('Inspect the current file revision before changing it.')
        value=self._selected(node)
        if value['item']['revision']!=revision:raise FileConflict('The file, linked notes or associations changed. Reopen it before applying this operation.')
        return value

    @staticmethod
    def _write(path,raw):
        private_directory(path.parent)
        fd,temp=tempfile.mkstemp(prefix='.qentl-file-',dir=str(path.parent))
        try:
            with os.fdopen(fd,'wb') as stream:stream.write(raw)
            os.replace(temp,path)
        finally:
            if os.path.exists(temp):os.unlink(temp)

    def _commit(self,moves,writes):
        """File moves and small metadata/note edits rollback together on failure."""
        # Metadata rollback can require both its old and new byte copies. File
        # payloads are renamed on the same filesystem, never duplicated here.
        maximum=current_policy()['max_metadata_bytes']
        if any(len(raw)>maximum or path.exists() and path.stat().st_size>maximum for path,raw in writes.items()):
            raise BlochAIError('Managed metadata exceeds its bounded operation limit.')
        ensure_space(self.folder,0,extra_bytes=sum(len(raw)+(path.stat().st_size if path.exists() else 0) for path,raw in writes.items())+65536)
        before={path:path.read_bytes() if path.exists() else None for path in writes}
        completed=[]
        try:
            for source,target in moves:
                if target.exists():raise FileConflict('A destination appeared during the change. No existing file was overwritten.')
                private_directory(target.parent);source.rename(target);completed.append((source,target))
            for path,raw in writes.items():self._write(path,raw)
        except BaseException:
            rollback_failed=False
            # Recover payloads before metadata: a second disk/permission error
            # while rewriting an index must never strand the only byte copy in
            # a directory the caller thinks is safe to clean up.
            for source,target in reversed(completed):
                try:
                    if source.exists():raise FileConflict('Rollback destination changed.')
                    private_directory(source.parent);target.rename(source)
                except BaseException:rollback_failed=True
            for path,raw in before.items():
                try:
                    if raw is None:
                        if path.exists():path.unlink()
                    else:self._write(path,raw)
                except BaseException:rollback_failed=True
            if rollback_failed:raise BlochAIError('File bytes were preserved, but metadata recovery needs operator review. Do not retry publication until it is reconciled.') from None
            raise

    @staticmethod
    def _json(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()

    @staticmethod
    def _snapshot(paths):
        result={}
        for path in paths:
            if path.is_symlink() or path.exists() and (not path.is_file() or path.stat().st_nlink!=1 or path.stat().st_size>current_policy()['max_metadata_bytes']):raise FileConflict('A managed metadata path changed or exceeds its bounded size.')
            result[path]=digest(path.read_bytes()) if path.exists() else None
        return result

    def _unchanged(self,snapshot):
        if self._snapshot(snapshot)!=snapshot:raise FileConflict('Project metadata changed before publication. No files were overwritten.')

    def create(self,path,content,before_publish=lambda:None):
        relative=source_path(path)
        if not isinstance(content,str):raise BlochAIError('Provide UTF-8 source text.')
        try:raw=content.encode('utf-8')
        except UnicodeError:raise BlochAIError('Provide valid UTF-8 source text.') from None
        if len(raw)>MAX_FILE_BYTES or _text(raw,self.secrets):raise BlochAIError('Use at most 200 KB of UTF-8 text without credentials or binary content.')
        files=self.catalog.code_files(self.project)
        if files['truncated'] or len(files['files'])>=current_policy()['max_source_files']:raise BlochAIError('The project has reached its source-file limit.')
        self._destination(relative);before_publish();target=self._destination(relative)
        ensure_space(self.folder,len(raw),extra_bytes=65536)
        private_directory(target.parent)
        with target.open('xb') as stream:stream.write(raw)
        target.chmod(0o600)
        return {'item':self._selected(code_id(relative))['item']}

    def _symbols(self,path,raw):
        from .code_graph import analyze,node_id
        try:analysis=analyze(path,raw.decode('utf-8'))
        except UnicodeError:return {}
        return {node_id('symbol',path+':'+row['qualified']+':'+str(row['line'])):row for row in analysis['symbols']}

    def move(self,node,destination,revision,before_publish=lambda:None):
        selected=self._check(node,revision);item,row=selected['item'],selected['row'];kind=item['kind']
        if kind=='upload':
            portable=_path('original/'+destination)[9:] if isinstance(destination,str) else _path(destination)
            if any(part.startswith('.') for part in portable.split('/')):raise BlochAIError('Attachment destinations cannot be hidden.')
            if Path(portable).suffix.lower()!=Path(row['name']).suffix.lower():raise BlochAIError('Keep the attachment original extension.')
            # Workspace rules additionally reject credentials and linked paths.
            relative='uploads/'+row['id']+'/original/'+portable
            if len(portable.split('/'))>6:raise BlochAIError('Attachment folders support at most six components.')
        else:
            relative=source_path(destination,kind)
            if Path(relative).suffix.lower()!=Path(row['path']).suffix.lower():raise BlochAIError('Keep the original file extension when moving it.')
        if relative==row['path']:raise FileConflict('Choose a different destination.')
        target=self._destination(relative)
        writes={};new_node=node
        if kind=='code':
            new_node=code_id(relative);mapping={node:new_node}
            from .code_graph import node_id
            for identifier,symbol in self._symbols(row['path'],selected['files'][row['path']]).items():
                mapping[identifier]=node_id('symbol',relative+':'+symbol['qualified']+':'+str(symbol['line']))
            edges=[{**edge,'source':mapping.get(edge['source'],edge['source']),'target':mapping.get(edge['target'],edge['target'])} for edge in selected['edges']]
            writes[self.knowledge.connections_index]=self._json({'edges':edges})
        elif kind=='note':
            rows=[{**entry,'path':relative,'updated_at':time.time()} if entry['id']==node else entry for entry in self.knowledge.records()]
            writes[self.knowledge.index]=self._json({'notes':rows})
        else:
            name=Path(relative).name;metadata=self.catalog.metadata(self.project)
            metadata['uploads']=[{**entry,'path':relative,'name':name,'display_path':portable} if entry['id']==row['id'] else entry for entry in metadata['uploads']]
            writes[self.catalog.state/(self.project+'.json')]=self._json(metadata)
            old='Attachments/'+row['id']+'/'+quote(row['name'],safe='')
            new='Attachments/'+row['id']+'/'+quote(name,safe='')
            updated=set()
            for note in selected['linked']:
                raw=selected['linked_files'][note['path']];text=raw.decode('utf-8')
                changed=re.sub(re.escape(old)+r'(?=[)#?\s]|$)',lambda _:new,text)
                if changed!=text:writes[self.workspace.path(note['path'])]=changed.encode();updated.add(note['id'])
            if updated:
                writes[self.knowledge.index]=self._json({'notes':[{**entry,'updated_at':time.time()} if entry['id'] in updated else entry for entry in self.knowledge.records()]})
        snapshot=self._snapshot(writes)
        before_publish();self._check(node,revision);self._destination(relative);self._unchanged(snapshot)
        self._commit([(self.workspace.path(row['path']),target)],writes)
        return {'item':self._selected(new_node)['item']}

    def _trash_root(self,create=False):
        if self.trash.is_symlink():raise BlochAIError('Invalid project trash directory.')
        if create:private_directory(self.trash)
        return self.trash

    def _manifest(self,identifier):
        if not isinstance(identifier,str) or not UPLOAD_ID.fullmatch(identifier):raise FileNotFoundError('Trash entry not found.')
        path=self._trash_root()/identifier/'manifest.json'
        if path.parent.is_symlink() or path.is_symlink() or not path.is_file() or path.stat().st_nlink!=1 or path.stat().st_size>1_000_000:
            raise FileNotFoundError('Trash entry not found or unavailable.')
        data=json.loads(path.read_text(encoding='utf-8'))
        if data.get('id')!=identifier or data.get('owner')!=self.catalog.owner or data.get('project')!=self.project:raise BlochAIError('Invalid trash scope.')
        return data

    @staticmethod
    def _entry(data):
        return {key:data[key] for key in ('id','title','kind','path','created_at','bytes','linked_notes')}

    def list_trash(self):
        root=self._trash_root();entries=[]
        if root.exists():
            children=list(root.iterdir())
            if len(children)>MAX_TRASH_ENTRIES:raise BlochAIError('Project trash exceeds its inspection limit.')
            for path in children:
                if not UPLOAD_ID.fullmatch(path.name):raise BlochAIError('An incomplete trash operation needs operator review.')
                entries.append(self._entry(self._manifest(path.name)))
        return {'entries':sorted(entries,key=lambda row:row['created_at'],reverse=True),
                'limits':{'entries':MAX_TRASH_ENTRIES,'bytes':MAX_TRASH_BYTES}}

    def remove(self,node,revision,include_linked_notes=False,before_publish=lambda:None):
        if type(include_linked_notes) is not bool:raise BlochAIError('Confirm whether linked notes are included.')
        selected=self._check(node,revision);item,row=selected['item'],selected['row'];kind=item['kind']
        if selected['linked'] and not include_linked_notes:raise FileConflict('This attachment has linked Markdown notes. Explicitly include those notes in the restorable trash entry, or keep the attachment.')
        notes=selected['linked'] if kind=='upload' else [row] if kind=='note' else []
        files={**selected['files'],**selected['linked_files']};size=sum(map(len,files.values()))
        entries=self.list_trash()['entries']
        if len(entries)>=MAX_TRASH_ENTRIES or sum(entry['bytes'] for entry in entries)+size>MAX_TRASH_BYTES:
            raise FileConflict('Trash is full (20 entries / 100 MiB). Restore entries to make room; no entries were purged.')
        removed={node,*[note['id'] for note in notes]}
        if kind=='code':removed.update(self._symbols(row['path'],files[row['path']]))
        edges=[edge for edge in selected['edges'] if edge['source'] in removed or edge['target'] in removed]
        writes={self.knowledge.connections_index:self._json({'edges':[edge for edge in selected['edges'] if edge not in edges]})}
        if notes:writes[self.knowledge.index]=self._json({'notes':[entry for entry in self.knowledge.records() if entry['id'] not in removed]})
        if kind=='upload':
            metadata=self.catalog.metadata(self.project);metadata['uploads']=[entry for entry in metadata['uploads'] if entry['id']!=row['id']]
            writes[self.catalog.state/(self.project+'.json')]=self._json(metadata)
        identifier=secrets.token_hex(8);destination=self._trash_root(create=True)/identifier
        private_directory(destination)
        manifest={'id':identifier,'owner':self.catalog.owner,'project':self.project,'node_id':node,
                  'title':item['title'],'kind':kind,'path':row['path'],'created_at':time.time(),'bytes':size,
                  'linked_notes':[{'id':note['id'],'title':note['title']} for note in notes if kind=='upload'],
                  'row':row,'notes':notes,'edges':edges,
                  'files':[{'path':path,'stored':str(index),'sha256':digest(raw),'bytes':len(raw)} for index,(path,raw) in enumerate(files.items())]}
        try:
            save_json(destination/'manifest.json',manifest)
            snapshot=self._snapshot(writes)
            before_publish();self._check(node,revision);self._unchanged(snapshot)
            moves=[(self.workspace.path(entry['path']),destination/entry['stored']) for entry in manifest['files']]
            self._commit(moves,writes)
        except BaseException:
            # Never discard a payload if rollback itself encountered an I/O
            # failure. Its manifest and remaining bytes are recovery material.
            if not any(path.name!='manifest.json' for path in destination.iterdir()):shutil.rmtree(destination)
            raise
        return {'entry':self._entry(manifest)}

    def restore(self,identifier,before_publish=lambda:None):
        manifest=self._manifest(identifier);kind=manifest['kind'];row=manifest['row']
        entries=manifest.get('files')
        if (kind not in ('code','note','upload') or not isinstance(row,dict)
                or not isinstance(entries,list) or not 1<=len(entries)<=MAX_NOTES+3):
            raise BlochAIError('Invalid trash payload manifest.')
        total=0;stored=set();paths=set()
        for entry in entries:
            if (not isinstance(entry,dict) or not isinstance(entry.get('stored'),str)
                    or not re.fullmatch(r'[0-9]{1,3}',entry['stored'])
                    or not isinstance(entry.get('path'),str)
                    or not isinstance(entry.get('sha256'),str) or not SHA.fullmatch(entry['sha256'])
                    or type(entry.get('bytes')) is not int or entry['bytes']<0
                    or entry['stored'] in stored or entry['path'] in paths):
                raise BlochAIError('Invalid trash payload manifest.')
            maximum=(1_000_000 if kind=='code' else MAX_FILE_BYTES if entry['path'].startswith('knowledge/') or kind=='note'
                     else current_policy()['attachment_file_bytes'])
            if entry['bytes']>maximum:raise BlochAIError('Trash payload exceeds its original per-file operation limit.')
            total+=entry['bytes'];stored.add(entry['stored']);paths.add(entry['path'])
        if total>MAX_TRASH_BYTES or type(manifest.get('bytes')) is not int or total!=manifest['bytes']:
            raise BlochAIError('Invalid trash payload byte count.')
        moves=[]
        for entry in manifest['files']:
            if not re.fullmatch(r'[0-9]{1,3}',entry['stored']):raise BlochAIError('Invalid trash payload.')
            source=self.trash/identifier/entry['stored'];target=self._destination(entry['path'])
            if source.is_symlink() or not source.is_file() or source.stat().st_nlink!=1 or source.stat().st_size!=entry['bytes']:
                raise BlochAIError('Trash payload is missing or changed.')
            raw=source.read_bytes()
            if digest(raw)!=entry['sha256']:raise BlochAIError('Trash payload is missing or changed.')
            moves.append((source,target))
        notes=self.knowledge.records();uploads=self.catalog.metadata(self.project);writes={}
        restored_notes=manifest['notes']
        if len(notes)+len(restored_notes)>MAX_NOTES:raise FileConflict('Restoring these notes exceeds the project note limit.')
        for note in restored_notes:
            if any(existing['id']==note['id'] or key(existing['title'])==key(note['title']) for existing in notes):raise FileConflict('A note identity or title already exists; restore did not overwrite it.')
        if kind=='code':
            sources=self.catalog.code_files(self.project)
            if sources['truncated'] or len(sources['files'])>=current_policy()['max_source_files']:raise FileConflict('Source-file limit reached.')
        if kind=='upload':
            policy=current_policy();maximum=policy['attachment_total_bytes']
            if (type(row.get('size')) is not int or not 0<=row['size']<=policy['attachment_file_bytes']
                    or any(item['id']==row['id'] for item in uploads['uploads']) or len(uploads['uploads'])>=policy['max_attachments']
                    or maximum is not None and sum(item['size'] for item in uploads['uploads'])+row['size']>maximum):
                raise FileConflict('The attachment identity or capacity conflicts with restore.')
            uploads['uploads'].append(row);writes[self.catalog.state/(self.project+'.json')]=self._json(uploads)
        available={item['id'] for item in uploads['uploads']}
        if any(source not in available for note in restored_notes for source in note['source_ids']):raise FileConflict('Restore the other source attachments referenced by these notes first.')
        if restored_notes:writes[self.knowledge.index]=self._json({'notes':notes+restored_notes})
        edges=self.knowledge.connections();known={edge['id'] for edge in edges}
        if any(edge['id'] in known for edge in manifest['edges']) or len(edges)+len(manifest['edges'])>1000:raise FileConflict('Graph association identity or capacity conflicts with restore.')
        writes[self.knowledge.connections_index]=self._json({'edges':edges+manifest['edges']})
        snapshot=self._snapshot(writes)
        before_publish();self._unchanged(snapshot)
        for entry in manifest['files']:
            self._destination(entry['path'])
            source=self.trash/identifier/entry['stored']
            if (source.is_symlink() or not source.is_file() or source.stat().st_nlink!=1
                    or source.stat().st_size!=entry['bytes'] or digest(source.read_bytes())!=entry['sha256']):
                raise FileConflict('Trash payload changed before restoration. Nothing was published.')
        self._commit(moves,writes)
        shutil.rmtree(self.trash/identifier)
        return {'item':self._selected(manifest['node_id'])['item']}
