"""Explicit public GitHub snapshots, pinned before bounded inert-file import."""
from __future__ import annotations

import base64
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import http.client
import io
import json
from pathlib import Path
import re
import stat
import struct
import threading
import time
from urllib.parse import quote,urlsplit
import zipfile

from .config import BlochAIError
from .folder_import import _path,_skip_reason,MAX_FILES,MAX_FILE_BYTES,MAX_DECODED_BYTES,import_folder
from .remote_sync import _text
from .safe_web import _resolve,_public_addresses,_Endpoint,_PinnedHTTPSConnection,_remaining,_headers
from .store import now,scrub

API_VERSION='2026-03-10'
TOTAL_TIMEOUT=60.0
MAX_ARCHIVE_BYTES=20*1024*1024
MAX_ARCHIVE_ENTRIES=4000
MAX_RATIO=200
SOURCE_MARKER='.qentl-source.json'
_SLOTS=threading.BoundedSemaphore(2)
_NAME=re.compile(r'[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,98}[A-Za-z0-9_-])?')
_SHA=re.compile(r'[a-f0-9]{40}')


def parse_repository_url(url):
    if not isinstance(url,str) or len(url)>600 or not url.isascii() or re.search(r'[\s\\\x00-\x1f\x7f]',url):
        raise BlochAIError('Supply one explicit public HTTPS GitHub repository URL.')
    try:parsed=urlsplit(url)
    except ValueError:raise BlochAIError('Invalid GitHub repository URL.') from None
    if parsed.scheme!='https' or parsed.netloc!='github.com' or parsed.query or parsed.fragment:
        raise BlochAIError('Use https://github.com/owner/repository without credentials, query, fragment or port.')
    parts=parsed.path.rstrip('/').split('/')[1:]
    if len(parts)<2 or not _NAME.fullmatch(parts[0]) or not _NAME.fullmatch(parts[1]) or '..' in parts[0] or '..' in parts[1]:
        raise BlochAIError('Use a plain GitHub owner/repository URL.')
    owner,repo=parts[:2]
    if repo.endswith('.git'):repo=repo[:-4]
    if not _NAME.fullmatch(repo):raise BlochAIError('Invalid GitHub repository name.')
    ref=None
    if len(parts)>2:
        if len(parts)<4 or parts[2]!='tree':raise BlochAIError('Use the repository root or /tree/ref URL; individual files and subfolders are not imported separately.')
        ref='/'.join(parts[3:])
        if (len(ref)>200 or not re.fullmatch(r'[A-Za-z0-9_./-]+',ref) or '..' in ref
                or any(not part or part.startswith('.') or part.endswith(('.','.lock')) for part in ref.split('/'))):
            raise BlochAIError('Use an unencoded branch, tag or commit ref. A /tree/ suffix is treated entirely as the ref.')
    canonical='https://github.com/'+owner+'/'+repo
    return {'url':canonical+('/tree/'+ref if ref else ''),'owner':owner,'name':repo,'requested_ref':ref}


def requested_repository_urls(prompt):
    """URL grants come only from direct user prose, never quoted/tool content."""
    if not isinstance(prompt,str):return ()
    lines=[];fence=None
    for line in prompt.splitlines():
        stripped=line.lstrip()
        if stripped.startswith(('```','~~~')):
            mark=stripped[:3];fence=mark if fence is None else None if fence==mark else fence;continue
        if not fence and not stripped.startswith('>'):lines.append(line)
    direct=re.sub(r'`[^`]*`|"[^"\n]*"','', '\n'.join(lines));urls=[]
    for match in re.finditer(r'https://[^\s<>"\x00-\x1f]+',direct):
        try:value=parse_repository_url(match.group().rstrip('.,;:!?)]}'))['url']
        except BlochAIError:continue
        if value not in urls:urls.append(value)
        if len(urls)>=4:break
    return tuple(urls)


def policy():
    return {'mode':'public_github_snapshot','private_repositories':False,'credentials':False,
            'explicit_user_url_required':True,'commit_pinned':True,'training_allowed':False,'executes_code':False,
            'submodules':False,'lfs_downloads':False,'redirects':False,
            'limits':{'source_files':MAX_FILES,'source_file_bytes':MAX_FILE_BYTES,
                      'expanded_archive_bytes':MAX_DECODED_BYTES,'download_bytes':MAX_ARCHIVE_BYTES,
                      'archive_entries':MAX_ARCHIVE_ENTRIES,'timeout_seconds':TOTAL_TIMEOUT},
            'note':'Public source snapshot only. Existing copyright/license terms remain applicable; import is not training permission.'}


@contextmanager
def _transport(endpoint,deadline,accept):
    connection=_PinnedHTTPSConnection(endpoint,deadline)
    timer=threading.Timer(_remaining(deadline),connection.abort);timer.daemon=True;timer.start()
    try:
        connection.request('GET',endpoint.path,headers={'Host':endpoint.host,'User-Agent':'Qentl-Public-Repository-Importer/1.0',
            'Accept':accept,'X-GitHub-Api-Version':API_VERSION,'Accept-Encoding':'identity','Connection':'close'})
        response=connection.getresponse()
        try:yield response
        finally:response.close()
    finally:timer.cancel();connection.abort();connection.close()


def _download(host,path,limit,deadline,accept,mimes,resolver,transport):
    if host not in ('api.github.com','codeload.github.com'):raise BlochAIError('Repository fetch destination is not permitted.')
    addresses=_public_addresses(resolver(host,deadline))
    with transport(_Endpoint(host,path,addresses[0]),deadline,accept) as response:
        if response.status==404:raise BlochAIError('Public repository or ref not found. Private repositories require a future authenticated GitHub integration.')
        if response.status in (403,429):raise BlochAIError('GitHub public access is rate limited or unavailable. Retry later; no credentials are sent.')
        if response.status!=200:raise BlochAIError('GitHub did not return HTTP 200. Redirects are not followed; use the current canonical repository URL.')
        headers=_headers(response)
        mime=headers.get('content-type','').split(';',1)[0].strip().lower()
        if mime not in mimes or headers.get('content-encoding','identity').strip().lower() not in ('','identity'):
            raise BlochAIError('GitHub returned an unsupported response type or content encoding.')
        if headers.get('transfer-encoding','').lower() not in ('','chunked') or 'transfer-encoding' in headers and 'content-length' in headers:
            raise BlochAIError('GitHub returned ambiguous response framing.')
        declared=headers.get('content-length')
        if declared is not None and (not re.fullmatch(r'[0-9]{1,9}',declared) or int(declared)>limit):raise BlochAIError('Repository response exceeds the download limit.')
        raw=bytearray()
        while True:
            _remaining(deadline);part=response.read1(min(65536,limit+1-len(raw)))
            if not part:break
            raw.extend(part)
            if len(raw)>limit:raise BlochAIError('Repository response exceeds the download limit.')
        _remaining(deadline)
        if not raw or declared is not None and len(raw)!=int(declared):raise BlochAIError('GitHub returned an incomplete repository response.')
        return bytes(raw)


@dataclass(frozen=True)
class RepositorySnapshot:
    repository: dict
    files: tuple
    skipped: tuple


def _archive(raw,repository,deadline):
    prepared=[];skipped=[];licenses=[];license_bytes=0;names=set();nodes={};total=0
    prefix=repository['name']+'-'+repository['commit']
    try:
        # Bound central-directory metadata before ZipFile eagerly builds a
        # Python object for each member. ZIP64/multipart archives are unnecessary
        # for the small snapshot limit and are rejected.
        offset=raw.rfind(b'PK\x05\x06',max(0,len(raw)-65557))
        if offset<0 or len(raw)-offset<22:raise BlochAIError('Repository ZIP has no valid end record.')
        _,disk,central_disk,on_disk,total_entries,central_size,central_offset,comment=struct.unpack('<4s4H2IH',raw[offset:offset+22])
        if (disk or central_disk or on_disk!=total_entries or total_entries>MAX_ARCHIVE_ENTRIES
                or central_size>4*1024*1024 or central_offset+central_size!=offset or offset+22+comment!=len(raw)):
            raise BlochAIError('Repository ZIP central directory exceeds its bounded single-volume format.')
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            members=archive.infolist()
            if len(members)>MAX_ARCHIVE_ENTRIES:raise BlochAIError('Repository ZIP contains too many entries.')
            for entry in members:
                _remaining(deadline)
                name=entry.filename
                if (entry.orig_filename!=name or not name.startswith(prefix+'/') or '\\' in name
                        or '\0' in name or entry.flag_bits&1 or entry.compress_type not in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED)):
                    raise BlochAIError('Repository ZIP has invalid paths, encryption or unsupported compression.')
                if name==prefix+'/' and entry.is_dir():continue
                relative=name[len(prefix)+1:].rstrip('/')
                # Traversal and case-fold aliases invalidate the archive rather
                # than being extracted or partially accepted.
                portable=_path(repository['name']+'/'+relative)
                parts=portable.split('/')
                if portable in names:raise BlochAIError('Repository ZIP repeats a path.')
                names.add(portable)
                for index in range(1,len(parts)+1):
                    path='/'.join(parts[:index]);kind='directory' if index<len(parts) or entry.is_dir() else 'file';fold=path.casefold()
                    if fold in nodes and nodes[fold]!=(path,kind):raise BlochAIError('Repository ZIP paths collide after normalization.')
                    nodes[fold]=(path,kind)
                mode=(entry.external_attr>>16)&0xffff;file_type=stat.S_IFMT(mode)
                if entry.is_dir():
                    if entry.file_size:raise BlochAIError('Repository ZIP directory contains payload bytes.')
                    continue
                total+=entry.file_size
                if total>MAX_DECODED_BYTES or entry.file_size>max(1,entry.compress_size)*MAX_RATIO:
                    raise BlochAIError('Repository ZIP exceeds expanded-size or compression-ratio bounds.')
                if file_type==stat.S_IFLNK:
                    skipped.append({'path':portable,'reason':'symlink_not_imported'});continue
                if file_type not in (0,stat.S_IFREG):raise BlochAIError('Repository ZIP contains a non-regular filesystem object.')
                reason=_skip_reason(parts,entry.file_size)
                license_file=bool(re.fullmatch(r'(?i)(LICENSE|LICENCE|COPYING|NOTICE)(?:\.[A-Za-z0-9_-]+)?',parts[-1]))
                if reason and not (license_file and reason=='unsupported_type'):
                    skipped.append({'path':portable,'reason':reason});continue
                with archive.open(entry) as stream:data=stream.read(MAX_FILE_BYTES+1)
                if len(data)!=entry.file_size or len(data)>MAX_FILE_BYTES:raise BlochAIError('Repository ZIP member size differs from its declared bound.')
                reason=_text(data)
                if not reason and data.startswith(b'version https://git-lfs.github.com/spec/v1'):reason='lfs_pointer_not_downloaded'
                if reason:skipped.append({'path':portable,'reason':reason});continue
                if license_file:
                    license_bytes+=len(data)
                    if license_bytes>200000 or len(licenses)>=16:raise BlochAIError('Repository license notices exceed the bounded provenance record.')
                    licenses.append({'path':portable,'sha256':hashlib.sha256(data).hexdigest(),'text':data.decode('utf-8')})
                if _skip_reason(parts,entry.file_size)=='unsupported_type':
                    skipped.append({'path':portable,'reason':'license_preserved_in_source_record'});continue
                if len(prepared)>=MAX_FILES:raise BlochAIError('Repository has more than 500 supported source files; import a smaller repository.')
                prepared.append({'path':portable,'content_base64':base64.b64encode(data).decode('ascii')})
    except BlochAIError:raise
    except (zipfile.BadZipFile,RuntimeError,ValueError,UnicodeError,NotImplementedError,struct.error) as exc:
        raise BlochAIError('Cannot safely inspect this repository ZIP; nothing was imported.') from exc
    if not prepared:raise BlochAIError('The repository has no supported UTF-8 source files within the import limits.')
    return tuple(prepared),tuple(skipped),licenses


def fetch_repository(url):
    return _fetch_repository(url,resolver=_resolve,transport=_transport)


def _fetch_repository(url,*,resolver,transport):
    requested=parse_repository_url(url)
    if not _SLOTS.acquire(blocking=False):raise BlochAIError('Other public repository imports are in progress. Retry shortly.')
    try:
        deadline=time.monotonic()+TOTAL_TIMEOUT
        path='/repos/'+requested['owner']+'/'+requested['name']
        raw=_download('api.github.com',path,262144,deadline,'application/vnd.github+json',{'application/json'},resolver,transport)
        try:metadata=json.loads(raw)
        except (ValueError,UnicodeError,RecursionError):raise BlochAIError('GitHub repository metadata is invalid.') from None
        if (not isinstance(metadata,dict) or metadata.get('private') is not False
                or not isinstance(metadata.get('full_name'),str)
                or metadata['full_name'].casefold()!=(requested['owner']+'/'+requested['name']).casefold()):
            raise BlochAIError('GitHub did not confirm the exact requested public repository.')
        canonical=parse_repository_url('https://github.com/'+metadata['full_name'])
        ref=requested['requested_ref'] or metadata.get('default_branch')
        if not isinstance(ref,str) or not ref:raise BlochAIError('GitHub did not provide a usable repository branch.')
        # Treat a branch containing slashes as one ref, never a second API URL.
        parse_repository_url(canonical['url']+'/tree/'+str(ref))
        path='/repos/'+canonical['owner']+'/'+canonical['name']
        commit_raw=_download('api.github.com',path+'/commits/'+quote(ref,safe=''),512,deadline,
                            'application/vnd.github.sha',{'application/vnd.github.sha','text/plain'},resolver,transport)
        try:commit=commit_raw.decode('ascii').strip()
        except UnicodeError:raise BlochAIError('GitHub returned an invalid pinned commit.') from None
        if not _SHA.fullmatch(commit):raise BlochAIError('GitHub returned an invalid pinned commit.')
        if _SHA.fullmatch(ref) and ref!=commit:raise BlochAIError('GitHub returned a different commit from the explicitly requested snapshot.')
        archive=_download('codeload.github.com','/'+canonical['owner']+'/'+canonical['name']+'/zip/'+commit,
                          MAX_ARCHIVE_BYTES,deadline,'application/zip',{'application/zip','application/x-zip-compressed'},resolver,transport)
        license_meta=metadata.get('license');license_record=None
        if isinstance(license_meta,dict):
            spdx,name=license_meta.get('spdx_id'),license_meta.get('name')
            if isinstance(spdx,str) and len(spdx)<=80 and isinstance(name,str) and len(name)<=200:
                license_record={'spdx_id':spdx,'name':name,'url':canonical['url']+'/tree/'+commit,
                                'basis':'GitHub repository metadata; review retained license notices before reuse.'}
        repository={**canonical,'requested_ref':requested['requested_ref'],'resolved_ref':ref,'commit':commit,
                    'commit_url':canonical['url']+'/commit/'+commit,'archive_sha256':hashlib.sha256(archive).hexdigest(),
                    'license':license_record,'retrieved_at':now(),'training_allowed':False,'executed_code':False}
        files,skipped,licenses=_archive(archive,repository,deadline)
        repository['license_files']=licenses
        return RepositorySnapshot(repository,files,skipped)
    except BlochAIError:raise
    except (OSError,http.client.HTTPException,ValueError,UnicodeError) as exc:
        raise BlochAIError('Cannot securely retrieve this public GitHub snapshot right now.') from exc
    finally:_SLOTS.release()


def publish_repository(catalog,project,snapshot,*,before_publish=lambda:None,secret_values=()):
    if not isinstance(snapshot,RepositorySnapshot):raise BlochAIError('Use a validated public repository snapshot.')
    receipt={'schema':'qentl-public-repository-v1','repository':snapshot.repository,
             'training_allowed':False,'untrusted_content':True,'execution':False}
    if scrub(receipt,secret_values)!=receipt:raise BlochAIError('Repository provenance contains protected credentials; no files were imported.')
    result=import_folder(catalog,project,list(snapshot.files),before_publish=before_publish,
                         secret_values=secret_values,source_metadata=receipt)
    result['skipped']=list(snapshot.skipped)+result['skipped']
    if not result['files_imported']:raise BlochAIError('No repository files remain after private-content filters. Nothing was imported.')
    return {'repository':snapshot.repository,'import':result,'source_record':receipt}


def source_records(catalog,project,include_notices=False):
    folder=catalog.folder(project);imports=folder/'imports';records=[];retained_bytes=0
    if imports.is_symlink():raise BlochAIError('Invalid repository provenance directory.')
    if not imports.exists():return records
    children=list(imports.iterdir())
    if len(children)>500:raise BlochAIError('Repository provenance exceeds its inspection limit.')
    for child in children:
        path=child/SOURCE_MARKER
        if child.is_symlink() or not child.is_dir():continue
        if not path.exists():continue
        if path.is_symlink() or not path.is_file() or path.stat().st_nlink!=1 or path.stat().st_size>300000:
            raise BlochAIError('Invalid repository provenance record.')
        try:data=json.loads(path.read_text(encoding='utf-8'))
        except (ValueError,UnicodeError,RecursionError):raise BlochAIError('Invalid repository provenance record.') from None
        if data.get('schema')!='qentl-public-repository-v1':raise BlochAIError('Unknown repository provenance schema.')
        if not include_notices:
            repository=dict(data['repository'])
            repository['license_files']=[{key:value for key,value in row.items() if key!='text'} for row in repository.get('license_files',[])]
            data={**data,'repository':repository}
        retained_bytes+=len(json.dumps(data).encode())
        if retained_bytes>MAX_DECODED_BYTES:raise BlochAIError('Repository provenance export exceeds its 20 MiB limit.')
        records.append({'path':child.relative_to(folder).as_posix(),**data})
    return records
