"""Portable document generators from bounded, declarative specifications.

No model-provided Python, macros, external workbook links or HTML is executed.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import re
import threading
import zipfile
from decimal import Decimal, InvalidOperation
from xml.sax.saxutils import escape

from .config import BlochAIError
from .workspace import clean_text


def text(value, limit=2000):
    if not isinstance(value, str) or len(value)>limit or "\x00" in value:
        raise BlochAIError(f"Text must contain at most {limit} characters.")
    return clean_text(value)


def sections(spec):
    title = text(spec.get("title", "Qentl"), 100)
    items = spec.get("sections", [])
    if not isinstance(items, list) or not 1<=len(items)<=40:
        raise BlochAIError("Provide 1..40 sections with heading and body.")
    return title, [(text(row["heading"], 100), text(row["body"], 1200)) for row in items]


_PDF_FONT_LOCK = threading.Lock()


def _qentl_pdf_fonts(content):
    """Use the packaged ReportLab font files; never open a model-selected asset."""
    import reportlab
    from pathlib import Path
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    root = Path(reportlab.__file__).parent / 'fonts'
    with _PDF_FONT_LOCK:
        for name, filename in (('QentlText', 'Vera.ttf'), ('QentlBold', 'VeraBd.ttf')):
            if name not in pdfmetrics.getRegisteredFontNames():
                pdfmetrics.registerFont(TTFont(name, str(root / filename)))
        pdfmetrics.registerFontFamily('QentlText', normal='QentlText', bold='QentlBold', italic='QentlText', boldItalic='QentlBold')
    supported = pdfmetrics.getFont('QentlText').face.charToGlyph
    if any(ord(character) not in supported for value in content for character in value if not character.isspace()):
        raise BlochAIError('The Qentl PDF font cannot display a character in this text. Use supported Latin text instead of missing-glyph symbols.')
    return 'QentlText', 'QentlBold'


def _generate_qentl_pdf(spec):
    """Fixed local Qentl identity, searchable text and conservative pagination."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable
    from pypdf import PdfReader
    title, items = sections(spec)
    subtitle = text(spec.get('subtitle', ''), 240)
    regular, bold = _qentl_pdf_fonts([title, subtitle] + [value for row in items for value in row])
    ink, cyan = colors.HexColor('#05090D'), colors.HexColor('#61DAF2')
    body_color, accent = colors.HexColor('#202C33'), colors.HexColor('#00677A')
    styles = {
        'eyebrow': ParagraphStyle('QentlEyebrow', fontName=bold, fontSize=8, leading=11, textColor=accent, spaceAfter=10),
        'title': ParagraphStyle('QentlTitle', fontName=bold, fontSize=24, leading=30, textColor=ink, spaceAfter=12, keepWithNext=True),
        'subtitle': ParagraphStyle('QentlSubtitle', fontName=regular, fontSize=10, leading=15, textColor=body_color, spaceAfter=14),
        'heading': ParagraphStyle('QentlHeading', fontName=bold, fontSize=12, leading=17, textColor=accent, spaceBefore=16, spaceAfter=7, keepWithNext=True),
        'body': ParagraphStyle('QentlBody', fontName=regular, fontSize=10, leading=16, textColor=body_color, spaceAfter=8, splitLongWords=True, allowWidows=0, allowOrphans=0),
    }
    stream = io.BytesIO()
    doc = SimpleDocTemplate(stream, pagesize=A4, title=title, author='Qentl by Bloch Inc.',
                            subject=subtitle, creator='Qentl document generator',
                            leftMargin=54, rightMargin=54, topMargin=116, bottomMargin=58)
    body = [Paragraph('QENTL / DOCUMENTO', styles['eyebrow']), Paragraph(escape(title), styles['title'])]
    if subtitle:
        body.append(Paragraph(escape(subtitle), styles['subtitle']))
    body.extend([HRFlowable(width='100%', thickness=.7, color=colors.HexColor('#C9DAE0')), Spacer(1, 4)])
    for heading, content in items:
        body.extend([Paragraph(escape(heading), styles['heading']),
                     Paragraph(escape(content).replace('\n', '<br/>'), styles['body'])])

    def page_frame(canvas, document):
        canvas.saveState()
        width, height = document.pagesize
        canvas.setFillColor(ink)
        canvas.rect(0, height-87, width, 87, stroke=0, fill=1)
        canvas.setFillColor(cyan)
        canvas.rect(0, height-89, width, 2, stroke=0, fill=1)
        # The same geometric Bloch mark used in the workspace, drawn as vectors.
        canvas.setStrokeColor(cyan)
        canvas.setLineWidth(1.1)
        x, y, scale = 54, height-61, 1.05
        for points in (((4,8),(16,2),(28,8),(28,24),(16,30),(4,24),(4,8)),
                       ((4,8),(16,14),(28,8)),((16,14),(16,30)),((4,16),(16,22),(28,16))):
            path = canvas.beginPath()
            path.moveTo(x+points[0][0]*scale, y+(32-points[0][1])*scale)
            for px, py in points[1:]:
                path.lineTo(x+px*scale, y+(32-py)*scale)
            canvas.drawPath(path)
        canvas.setFillColor(colors.white)
        canvas.setFont(bold, 22)
        canvas.drawString(96, height-43, 'QENTL')
        canvas.setFont(regular, 8)
        canvas.setFillColor(colors.HexColor('#C8D6DE'))
        canvas.drawString(97, height-58, 'by Bloch Inc.')
        canvas.setFillColor(cyan)
        canvas.setFont(regular, 9)
        canvas.drawRightString(width-54, height-47, 'qentl.ai')
        # Fixed, decorative constellation. No document data becomes graphics code.
        canvas.setStrokeColor(colors.HexColor('#214A58'))
        canvas.setLineWidth(.5)
        points = [(width-236,height-34),(width-213,height-56),(width-184,height-28),(width-164,height-60)]
        for first, second in zip(points, points[1:]):
            canvas.line(*first, *second)
        canvas.setFillColor(cyan)
        for px, py in points:
            canvas.circle(px, py, 1.7, stroke=0, fill=1)
        canvas.setStrokeColor(colors.HexColor('#CFDDE2'))
        canvas.line(54, 43, width-54, 43)
        canvas.setFont(regular, 7.5)
        canvas.setFillColor(colors.HexColor('#43545E'))
        canvas.drawString(54, 29, 'QENTL  |  by Bloch Inc.  |  qentl.ai')
        canvas.drawRightString(width-54, 29, f'{document.page:02d}')
        canvas.restoreState()

    doc.build(body, onFirstPage=page_frame, onLaterPages=page_frame)
    data = stream.getvalue()
    pdf = PdfReader(io.BytesIO(data))
    if not pdf.pages or not all(page.extract_text().strip() for page in pdf.pages):
        raise BlochAIError('PDF text validation failed.')
    return data, {'pages': len(pdf.pages), 'text_verified': True, 'brand': 'qentl',
                  'page_size': 'A4', 'fonts_embedded': True, 'visual_review': 'required for publication'}


def generate_pdf(spec):
    brand = spec.get('brand')
    if brand is not None:
        if brand != 'qentl':
            raise BlochAIError("The PDF brand must be 'qentl' or omitted.")
        return _generate_qentl_pdf(spec)
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from pypdf import PdfReader
    title, items = sections(spec)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle("BlochTitle", parent=styles["Title"], textColor=colors.HexColor("#123343"), spaceAfter=24))
    styles["BodyText"].leading = 16
    stream = io.BytesIO()
    doc = SimpleDocTemplate(stream, title=title, author="Qentl by Bloch Inc.", leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54)
    body = [Paragraph(escape(title), styles["BlochTitle"])]
    for heading, content in items:
        body.extend([Paragraph(escape(heading), styles["Heading2"]),
                     Paragraph(escape(content).replace("\n", "<br/>"), styles["BodyText"]), Spacer(1, 14)])
    def footer(canvas, document):
        canvas.setFont("Helvetica", 9)
        canvas.setFillColor(colors.HexColor("#536877"))
        canvas.drawString(54, 28, "QENTL by Bloch Inc.")
        canvas.drawRightString(document.pagesize[0]-54, 28, str(document.page))
    doc.build(body, onFirstPage=footer, onLaterPages=footer)
    data = stream.getvalue()
    pdf = PdfReader(io.BytesIO(data))
    if not pdf.pages or not all(page.extract_text().strip() for page in pdf.pages):
        raise BlochAIError("PDF text validation failed.")
    return data, {"pages":len(pdf.pages), "text_verified":True, "visual_review":"required for publication"}


def generate_pptx(spec):
    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.util import Inches, Pt
    title, items = sections(spec)
    presentation = Presentation()
    presentation.slide_width = Inches(13.333)
    presentation.slide_height = Inches(7.5)
    slides = [(title, spec.get("subtitle", ""))]
    # Conservative pagination avoids tiny text or silently clipped paragraphs.
    for heading, content in items:
        import textwrap
        lines = []
        for paragraph in content.splitlines():
            lines.extend(textwrap.wrap(paragraph, 68) or [""])
        for start in range(0, len(lines) or 1, 7):
            slides.append((heading + (" (continued)" if start else ""), "\n".join(lines[start:start+7])))
    for index, (heading, body) in enumerate(slides):
        slide = presentation.slides.add_slide(presentation.slide_layouts[6])
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = RGBColor.from_string("102C3A")
        for x,y,w,h,content,size,color in [(.7,.65,11.9,1.3,heading,32,"F3F7F5"),
                                         (.7,2.05,11.7,4.4,text(body,1200),24,"CDE1E5"),
                                         (.7,6.85,11.9,.3,f"QENTL by Bloch Inc.                               {index+1:02d}",11,"78C6B1")]:
            shape = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
            frame = shape.text_frame
            frame.word_wrap = True
            for n, line in enumerate(content.split("\n")):
                paragraph = frame.paragraphs[0] if n==0 else frame.add_paragraph()
                paragraph.text = line
                paragraph.font.name = "Aptos"
                paragraph.font.size = Pt(size)
                paragraph.font.color.rgb = RGBColor.from_string(color)
                paragraph.space_after = Pt(10)
    stream = io.BytesIO()
    presentation.save(stream)
    data = stream.getvalue()
    reopened = Presentation(io.BytesIO(data))
    if len(reopened.slides)!=len(slides):
        raise BlochAIError("Slide verification failed.")
    return data, {"slides":len(slides), "structure_verified":True, "visual_review":"required for publication"}


def generate_xlsx(spec):
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    sheets = spec.get("sheets", [])
    if not isinstance(sheets, list) or not 1<=len(sheets)<=12:
        raise BlochAIError("Provide 1..12 sheets with name, columns and rows.")
    book = Workbook()
    book.remove(book.active)
    names = set()
    for sheet in sheets:
        name = text(sheet["name"],31)
        if not name.strip() or re.search(r"[\[\]:*?/\\]", name) or name.casefold() in names:
            raise BlochAIError("Worksheet names must be unique and valid.")
        names.add(name.casefold())
        columns, rows = sheet["columns"], sheet["rows"]
        if not isinstance(columns,list) or not 1<=len(columns)<=30 or not isinstance(rows,list) or len(rows)>5000:
            raise BlochAIError("Use 1..30 columns and at most 5,000 rows per sheet.")
        ws = book.create_sheet(name)
        ws.append([text(c,100) for c in columns])
        for row in rows:
            if not isinstance(row,list) or len(row)!=len(columns):
                raise BlochAIError("Each row must match the number of columns.")
            for value in row:
                if value is not None and type(value) not in (str,int,float,bool):
                    raise BlochAIError("Cells accept text, finite numbers, booleans or null.")
                if isinstance(value,float) and not math.isfinite(value):
                    raise BlochAIError("Excel numbers must be finite.")
                if isinstance(value,str):
                    text(value,4000)
            ws.append(row)
        # Model-provided strings remain literal, including '=...', preventing
        # formula injection or remote-workbook requests when opened in Excel.
        for row in ws:
            for cell in row:
                if isinstance(cell.value,str):
                    cell.data_type = "s"
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                if cell.row==1:
                    cell.fill = PatternFill("solid", fgColor="123343")
                    cell.font = Font(color="FFFFFF", bold=True)
                elif cell.row%2==0:
                    cell.fill = PatternFill("solid", fgColor="EDF5F3")
                if isinstance(cell.value,(int,float)) and not isinstance(cell.value,bool):
                    cell.number_format = "#,##0.00" if isinstance(cell.value,float) else "#,##0"
        # Explicit summary operations use generator-authored formulas only.
        totals = sheet.get("totals", [])
        if not isinstance(totals,list) or any(type(c) is not int or not 1<=c<=len(columns) for c in totals):
            raise BlochAIError("Totals must be a list of 1-based numeric column indexes.")
        if totals and rows:
            for col in totals:
                if any(row[col-1] is not None and type(row[col-1]) not in (int,float) for row in rows):
                    raise BlochAIError("Sum columns must contain only numbers or blanks.")
                letter = get_column_letter(col)
                cell = ws.cell(len(rows)+2,col,f"=SUM({letter}2:{letter}{len(rows)+1})")
                cell.font = Font(bold=True, color="123343")
                cell.number_format = "#,##0.00"
        for i, column in enumerate(columns,1):
            width=max([len(str(column))]+[len(str(row[i-1] or "")) for row in rows[:100]])
            ws.column_dimensions[get_column_letter(i)].width=min(50,max(14,width+3))
        ws.row_dimensions[1].height=30
        ws.freeze_panes="A2"
        ws.auto_filter.ref=f"A1:{get_column_letter(len(columns))}{len(rows)+1}"
    stream=io.BytesIO(); book.save(stream); data=stream.getvalue()
    reopened=load_workbook(io.BytesIO(data),read_only=True,data_only=False)
    if reopened.sheetnames!=book.sheetnames:
        raise BlochAIError("Workbook verification failed.")
    reopened.close()
    return data,{"sheets":book.sheetnames,"structure_verified":True,
                 "formulas":"Generator SUM formulas recalculate in Excel; model strings are literal text."}


GENERATORS={"pdf":generate_pdf,"pptx":generate_pptx,"xlsx":generate_xlsx}


def create_artifact(workspace, kind, path, spec=None, spec_path=None):
    if kind not in GENERATORS or not isinstance(path,str) or not path.lower().endswith("."+kind):
        raise BlochAIError("Choose pdf, pptx or xlsx and its matching file extension.")
    if (spec is None)==(spec_path is None):
        raise BlochAIError("Supply either spec or a project JSON spec_path.")
    if spec_path is not None:
        source=workspace.path(spec_path)
        if not source.is_file() or source.stat().st_size>500_000:
            raise BlochAIError("Use a JSON specification below 500 KB.")
        spec=json.loads(source.read_text(encoding="utf-8"))
    if not isinstance(spec,dict) or len(json.dumps(spec,allow_nan=False))>500_000:
        raise BlochAIError("Use a JSON object below 500 KB.")
    forecast=getattr(workspace,'forecast_result',None)
    if forecast is not None:
        from .forecast_documents import attach_forecast
        spec=attach_forecast(spec,kind,forecast)
    target=workspace.path(path)
    if target.exists():
        raise BlochAIError("Choose a new artifact name; existing files are never overwritten.")
    if not workspace.approve("create_artifact",f"Create {path}\n"+json.dumps(spec,ensure_ascii=False,indent=2)):
        return {"path":path,"denied":True}
    try:
        data, checks=GENERATORS[kind](spec)
    except ImportError as exc:
        raise BlochAIError("Install the BlochAI artifacts extra: pip install 'blockai[artifacts]'.") from exc
    except (KeyError,TypeError,ValueError) as exc:
        raise BlochAIError("Invalid artifact specification. Use the documented schema.") from exc
    if forecast is not None:
        checks={**checks,'calculation_result_sha256':forecast['result_sha256'],
                'monte_carlo_trials_executed':forecast['actual_trials'],
                'financial_inputs_verified':False}
    from .project_lock import project_write_lock
    with project_write_lock(workspace.root):
        try:info=workspace.root.stat()
        except OSError as exc:raise BlochAIError('The project was deleted before artifact publication.') from exc
        if workspace.root.is_symlink() or (info.st_dev,info.st_ino)!=workspace._generation:
            raise BlochAIError('The project was replaced before artifact publication.')
        if workspace._mutation_guard:workspace._mutation_guard()
        target=workspace.path(path)
        target.parent.mkdir(parents=True,exist_ok=True)
        # Exclusive creation also protects an intervening writer during approval.
        with target.open("xb") as output:
            output.write(data)
    return {"path":path,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"checks":checks}


def inspect_table(workspace, path, sheet=None):
    source=workspace.path(path)
    if not source.is_file() or source.stat().st_size>5_000_000:
        raise BlochAIError("Use a CSV or XLSX smaller than 5 MB.")
    if source.suffix.lower()==".csv":
        with source.open(encoding="utf-8-sig",newline="") as stream:
            rows=list(csv.reader(stream))[:10002]
    elif source.suffix.lower()==".xlsx":
        from openpyxl import load_workbook
        with zipfile.ZipFile(source) as zipped:
            if sum(info.file_size for info in zipped.infolist())>20_000_000:
                raise BlochAIError("Workbook expanded size exceeds 20 MB.")
        book=load_workbook(source,read_only=True,data_only=True,keep_links=False)
        try:
            page=book[sheet] if sheet else book.active
            rows=[]
            for row in page.iter_rows(values_only=True):
                rows.append(list(row))
                if len(rows)>10001:
                    break
        finally:
            book.close()
    else:
        raise BlochAIError("inspect_table supports CSV and XLSX.")
    if not rows or len(rows)>10001 or len(rows[0])>100:
        raise BlochAIError("Use a table with a header, at most 10,000 data rows and 100 columns.")
    columns=[]
    for i,header in enumerate(rows[0]):
        values=[row[i] if i<len(row) else None for row in rows[1:]]
        numbers=[]; missing=0; nonnumeric=0
        for value in values:
            if value in (None, ""):
                missing+=1; continue
            try:
                number=Decimal(str(value))
                if not number.is_finite():
                    raise InvalidOperation
                numbers.append(number)
            except (InvalidOperation,ValueError):
                nonnumeric+=1
        result={"column":str(header),"missing":missing,"numeric":len(numbers),"nonnumeric":nonnumeric}
        if numbers:
            result.update(sum=str(sum(numbers)),min=str(min(numbers)),max=str(max(numbers)),mean=str(sum(numbers)/len(numbers)))
        columns.append(result)
    return {"path":path,"sha256":hashlib.sha256(source.read_bytes()).hexdigest(),"rows":len(rows)-1,"columns":columns,
            "sample":rows[:6],"method":"Descriptive statistics over nonmissing numeric cells; no causal inference. XLSX formulas use cached values."}
