"""Reviewable code edits with immutable before/after evidence and stale-write checks."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import secrets
import time

from .config import BlochAIError, save_json
from .knowledge import NoteConflict
from .workspace import Workspace


class CodeReview:
    def __init__(self,projects,project):
        self.projects=projects;self.project=project
        projects.folder(project)
        self.directory=projects.state.parent/'code-history'/project

    def records(self,code_id):
        rows=[]
        for path in self.directory.glob('*.json'):
            if path.is_symlink() or path.stat().st_size>2_000_000:continue
            row=json.loads(path.read_text(encoding='utf-8'))
            if row.get('code_id')==code_id:rows.append(row)
        return sorted(rows,key=lambda row:row['created_at'],reverse=True)

    def propose(self,code_id,content,revision,closed_scope=None):
        current=self.projects.read_code(self.project,code_id)
        if closed_scope:closed_scope.assert_writable(current['path'])
        if not isinstance(content,str) or '\x00' in content or len(content.encode())>100000:
            raise BlochAIError('A edição deve conter até 100 KB de código UTF-8.')
        if revision!=current['sha256']:raise NoteConflict('O código mudou desde que você abriu a página. Reabra antes de revisar a alteração.')
        if content==current['content']:raise BlochAIError('Nenhuma alteração para revisar.')
        rows=self.records(code_id)
        if len(rows)>=200:raise BlochAIError('Este arquivo atingiu 200 revisões. Arquive o histórico antes de criar outra revisão.')
        identifier=secrets.token_hex(8)
        diff=''.join(difflib.unified_diff(current['content'].splitlines(True),content.splitlines(True),fromfile=current['path'],tofile=current['path']))
        row={'id':identifier,'code_id':code_id,'path':current['path'],'before':current['content'],'after':content,
             'base_sha256':current['sha256'],'after_sha256':hashlib.sha256(content.encode()).hexdigest(),
             'diff':diff,'created_at':time.time(),'status':'proposed'}
        if closed_scope:row['closed_scope']=closed_scope.provenance()
        save_json(self.directory/(identifier+'.json'),row)
        return {'id':identifier,'diff':diff,'base_sha256':current['sha256'],'path':current['path'],
                **({'closed_scope':row['closed_scope']} if closed_scope else {})}

    def change(self,code_id,identifier):
        if not isinstance(identifier,str) or not re.fullmatch(r'[a-f0-9]{16}',identifier):raise FileNotFoundError('Revisão não encontrada.')
        row=next((row for row in self.records(code_id) if row['id']==identifier),None)
        if not row:raise FileNotFoundError('Revisão não encontrada.')
        return row

    def propose_patch(self,code_id,response,revision,closed_scope=None):
        def unique(pairs):
            result={}
            for key,value in pairs:
                if key in result:raise ValueError('Duplicate field')
                result[key]=value
            return result
        try:patch=json.loads(response,object_pairs_hook=unique)
        except (TypeError,ValueError) as exc:raise BlochAIError('O modelo não retornou uma alteração válida. Nenhum arquivo foi modificado.') from exc
        if not isinstance(patch,dict) or set(patch)!={'old','new','explanation'} or any(not isinstance(value,str) for value in patch.values()) or not patch['old'] or len(patch['explanation'])>2000:
            raise BlochAIError('A sugestão precisa indicar um trecho exato e sua substituição. Nenhuma edição foi aplicada.')
        current=self.projects.read_code(self.project,code_id)
        if revision!=current['sha256']:raise NoteConflict('O arquivo mudou durante a sugestão. Reabra e peça uma nova revisão.')
        if current['content'].count(patch['old'])!=1:raise BlochAIError('O trecho sugerido não corresponde a um único trecho do arquivo. Nenhuma edição foi aplicada.')
        result=self.propose(code_id,current['content'].replace(patch['old'],patch['new'],1),revision,closed_scope)
        return {**result,'explanation':patch['explanation'],'code_id':code_id}

    def apply(self,code_id,identifier,approved):
        if approved is not True:raise BlochAIError('Revise a comparação antes de aplicar a alteração.')
        row=self.change(code_id,identifier)
        if row['status']!='proposed' or time.time()-row['created_at']>600:raise NoteConflict('Esta comparação expirou ou já foi aplicada. Gere uma nova comparação.')
        current=self.projects.read_code(self.project,code_id)
        if current['sha256']!=row['base_sha256']:raise NoteConflict('O código mudou depois da comparação. A edição não foi aplicada.')
        check_scope=None
        if row.get('closed_scope'):
            from .closed_scope import ClosedScopeStore
            proof=row['closed_scope']
            scope=ClosedScopeStore(self.projects,self.project).require(proof.get('requirement_id'),proof.get('revision'))
            if scope.provenance()!=proof:raise BlochAIError('The approved scope changed. Request a new code suggestion.')
            check_scope=lambda:scope.assert_writable(row['path'])
            check_scope()
        workspace=Workspace(self.projects.folder(self.project),lambda *_:True,mutation_guard=check_scope)
        workspace.read_file(row['path'])
        if workspace.observed[str(workspace.path(row['path']))]!=row['base_sha256']:raise NoteConflict('O arquivo mudou durante a revisão.')
        row['status']='applying';save_json(self.directory/(identifier+'.json'),row)
        try:
            result=workspace.write_file(row['path'],row['after'])
        except Exception:
            row['status']='not_applied';save_json(self.directory/(identifier+'.json'),row);raise
        row['status']='applied';row['applied_at']=time.time();save_json(self.directory/(identifier+'.json'),row)
        return {'file':self.projects.read_code(self.project,code_id),'change_id':identifier,'result':result,'tests_run':False}

    def history(self,code_id):
        self.projects.read_code(self.project,code_id)
        return [{key:row[key] for key in ('id','path','created_at','status','base_sha256','after_sha256')} for row in self.records(code_id)]
