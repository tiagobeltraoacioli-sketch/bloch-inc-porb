"""Explicit project grants within one workbench deployment, never account sharing.

The database is authoritative; client aliases, invitation codes and list rows are
not grants. No email is sent and no project is uploaded by this module.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import re
import secrets
import sqlite3
import time

from .config import BlochAIError, private_directory, state_home
from .projects import ProjectStore

ALIAS = re.compile(r"shared-([a-f0-9]{32})")
MAX_COLLABORATORS = 50
INVITE_SECONDS = 72 * 3600
TOKEN = re.compile(r"[A-Za-z0-9_-]{43}")

# Deliberately excludes task prompts, code history, job traces, CLI paths,
# account settings, bulk exports, deletion and collaborator administration.
SHARED_READ = re.compile(r"/(?:knowledge|uploads(?:/[a-f0-9]{16}(?:/(?:download|preview|view))?)?|notes/[a-f0-9]{16}(?:/download)?|code/code:[a-f0-9]{16}|revision|closed-scope|github-imports|file-actions/(?:item|trash))")
SHARED_WRITE = re.compile(r"/(?:notes(?:/[a-f0-9]{16})?|code(?:/code:[a-f0-9]{16}/(?:check|preview|apply))?|connections(?:/[a-f0-9]{16}/delete)?|convert|uploads|folder-imports?|github-import|web-source|file-actions/(?:create|move|trash(?:/[a-f0-9]{16}/restore)?))")


class AccessDenied(BlochAIError):
    """Do not disclose whether an inaccessible project exists."""


class EditorRequired(BlochAIError):
    pass


def principal(identity):
    if not isinstance(identity, dict):
        raise BlochAIError('A sessão Qentl deve informar usuário e organização para colaborar.')
    user = identity.get('user', {})
    organization = identity.get('organization', {})
    if not isinstance(user, dict) or not isinstance(organization, dict):
        raise BlochAIError('A sessão Qentl deve informar usuário e organização para colaborar.')
    email = user.get('email')
    # Rednblue's /auth/session currently returns user.email without user.id.
    # Match web.identity_key and CLI identity_owner exactly; this is the fresh
    # authoritative identity, never a client-supplied alias or default tenant.
    uid, org = user.get('id') or email, organization.get('id')
    if (not isinstance(uid, str) or not 1 <= len(uid) <= 254
            or not isinstance(org, str) or not 1 <= len(org) <= 254):
        raise BlochAIError('A sessão Qentl deve informar usuário e organização para colaborar.')
    return {'user': uid, 'organization': org, 'email': normalize_email(email),
            'owner': hashlib.sha256((uid+'\0'+org).encode()).hexdigest()[:24]}


def normalize_email(email):
    if (not isinstance(email, str) or len(email) > 254 or email != email.strip()
            or not re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@[A-Za-z0-9](?:[A-Za-z0-9.-]{0,251}[A-Za-z0-9])?", email)
            or '..' in email):
        raise BlochAIError('Informe um email válido, igual ao login Qentl do convidado.')
    return email.casefold()


class CollaborationStore:
    def __init__(self, root):
        self.root = root
        self.directory = state_home()/'collaboration'
        self.path = self.directory/'projects.sqlite3'

    @contextmanager
    def database(self, write=False):
        private_directory(self.directory)
        if self.path.is_symlink() or (self.path.exists() and self.path.stat().st_nlink != 1):
            raise BlochAIError('Registro de colaboração inválido.')
        # Create privately before SQLite opens it, including on permissive umasks.
        try:
            import os
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.close(fd)
        except FileExistsError:
            pass
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        try:
            db.execute('PRAGMA foreign_keys=ON')
            db.execute('PRAGMA secure_delete=ON')
            if db.execute('PRAGMA user_version').fetchone()[0] != 1:
                db.executescript('''
                CREATE TABLE IF NOT EXISTS projects (
                    id TEXT PRIMARY KEY, owner TEXT NOT NULL, project TEXT NOT NULL,
                    organization TEXT NOT NULL, owner_user TEXT NOT NULL,
                    generation TEXT NOT NULL, UNIQUE(owner, project));
                CREATE TABLE IF NOT EXISTS invitations (
                    id TEXT PRIMARY KEY, project TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    email TEXT NOT NULL, role TEXT NOT NULL, digest TEXT UNIQUE NOT NULL,
                    expires REAL NOT NULL, created REAL NOT NULL, consumed INTEGER NOT NULL DEFAULT 0,
                    revoked INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS members (
                    id TEXT PRIMARY KEY, project TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    actor TEXT NOT NULL, user TEXT NOT NULL, email TEXT NOT NULL,
                    role TEXT NOT NULL, created REAL NOT NULL, revoked INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(project, actor));
                CREATE INDEX IF NOT EXISTS member_actor ON members(actor);
                PRAGMA user_version=1;
            ''')
            if write:
                db.execute('BEGIN IMMEDIATE')
                db.execute('DELETE FROM invitations WHERE expires<=? OR consumed=1 OR revoked=1',(time.time(),))
            yield db
            db.commit()
        except sqlite3.Error as exc:
            db.rollback()
            raise BlochAIError('Não foi possível atualizar a colaboração. Tente novamente.') from exc
        finally:
            db.close()

    def generation(self, owner, project):
        catalog = ProjectStore(self.root, owner)
        folder = catalog.folder(project)
        info = folder.stat()
        created = catalog.metadata(project,require_persisted=True)['created_at']
        return f'{info.st_dev}:{info.st_ino}:{created}'

    def _current(self, row):
        try:
            return row['generation'] == self.generation(row['owner'], row['project'])
        except (OSError, BlochAIError, KeyError, ValueError):
            return False

    def _owned(self, db, actor, project):
        if ALIAS.fullmatch(project):
            raise AccessDenied('Projeto não encontrado.')
        ProjectStore(self.root,actor['owner']).folder(project)
        row = db.execute('SELECT * FROM projects WHERE owner=? AND project=?', (actor['owner'], project)).fetchone()
        if not row:return None
        generation = self.generation(actor['owner'], project)
        if row and row['generation'] != generation:
            return None
        if row and (row['organization'] != actor['organization'] or row['owner_user'] != actor['user']):
            raise AccessDenied('Projeto não encontrado.')
        return row

    def _ensure_owned(self, db, actor, project):
        if ALIAS.fullmatch(project):
            raise AccessDenied('Projeto não encontrado.')
        generation = self.generation(actor['owner'], project)
        row = db.execute('SELECT * FROM projects WHERE owner=? AND project=?', (actor['owner'], project)).fetchone()
        if row and row['generation'] != generation:
            db.execute('DELETE FROM projects WHERE id=?', (row['id'],))
            row = None
        if row is None:
            db.execute('INSERT INTO projects VALUES (?,?,?,?,?,?)',
                       (secrets.token_hex(16), actor['owner'], project, actor['organization'], actor['user'], generation))
        return self._owned(db, actor, project)

    def invite(self, identity, project, email, role):
        actor = principal(identity)
        email = normalize_email(email)
        if role not in ('viewer', 'editor'):
            raise BlochAIError('Escolha viewer ou editor.')
        if email == actor['email']:
            raise BlochAIError('O proprietário já tem acesso ao projeto.')
        # Acquire the physical project lock before opening an ACL transaction,
        # never from generation() (also used while a caller holds its job guard).
        ProjectStore(self.root,actor['owner']).persist_metadata(project)
        token = secrets.token_urlsafe(32)
        now = time.time()
        with self.database(True) as db:
            row = self._ensure_owned(db, actor, project)
            sid = row['id']
            count = db.execute('SELECT count(*) FROM members WHERE project=? AND revoked=0', (sid,)).fetchone()[0]
            pending = db.execute('SELECT count(*) FROM invitations WHERE project=? AND consumed=0 AND revoked=0 AND expires>?', (sid, now)).fetchone()[0]
            if count + pending >= MAX_COLLABORATORS:
                raise BlochAIError('Limite de 50 colaboradores e convites pendentes por projeto.')
            if db.execute('SELECT 1 FROM members WHERE project=? AND email=? AND revoked=0', (sid,email)).fetchone():
                raise BlochAIError('Este email já participa do projeto. Revogue o acesso antes de mudar o papel.')
            db.execute('DELETE FROM invitations WHERE project=? AND email=?', (sid,email))
            identifier = secrets.token_hex(16)
            db.execute('INSERT INTO invitations(id,project,email,role,digest,expires,created) VALUES(?,?,?,?,?,?,?)',
                       (identifier,sid,email,role,hashlib.sha256(token.encode()).hexdigest(),now+INVITE_SECONDS,now))
        return {'id':identifier,'email':email,'role':role,'token':token,'expires_at':now+INVITE_SECONDS,
                'deployment_scope':'same_workspace','email_sent':False}

    def accept(self, identity, token):
        actor = principal(identity)
        if not isinstance(token,str) or not TOKEN.fullmatch(token):
            raise BlochAIError('Convite inválido, expirado ou indisponível para esta conta.')
        with self.database(True) as db:
            invite = db.execute('SELECT * FROM invitations WHERE digest=?', (hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
            row = db.execute('SELECT * FROM projects WHERE id=?', (invite['project'],)).fetchone() if invite else None
            if (not invite or not row or invite['consumed'] or invite['revoked'] or invite['expires'] <= time.time()
                    or invite['email'] != actor['email'] or row['organization'] != actor['organization']
                    or row['owner'] == actor['owner'] or not self._current(row)):
                raise BlochAIError('Convite inválido, expirado ou indisponível para esta conta.')
            existing = db.execute('SELECT id FROM members WHERE project=? AND actor=?',(row['id'],actor['owner'])).fetchone()
            identifier = existing['id'] if existing else secrets.token_hex(16)
            db.execute('INSERT OR REPLACE INTO members VALUES(?,?,?,?,?,?,?,0)',
                       (identifier,row['id'],actor['owner'],actor['user'],actor['email'],invite['role'],time.time()))
            db.execute('DELETE FROM invitations WHERE id=?',(invite['id'],))
            return self._public(row, invite['role'],identity['organization'].get('role'))

    def _resolve(self, db, identity, alias, write=False):
        actor = principal(identity)
        matched = ALIAS.fullmatch(alias) if isinstance(alias,str) else None
        row = db.execute('SELECT * FROM projects WHERE id=?',(matched.group(1),)).fetchone() if matched else None
        member = db.execute('SELECT * FROM members WHERE project=? AND actor=? AND revoked=0',
                            (row['id'],actor['owner'])).fetchone() if row else None
        if (not row or not member or member['user'] != actor['user'] or member['email'] != actor['email']
                or row['organization'] != actor['organization'] or not self._current(row)
                or member['role'] not in ('viewer','editor')):
            raise AccessDenied('Projeto não encontrado.')
        if write and member['role'] != 'editor':
            raise EditorRequired('O acesso viewer permite somente leitura.')
        return {'owner':row['owner'],'project':row['project'],'role':member['role'],'alias':alias}

    def resolve(self, identity, alias, write=False):
        with self.database() as db:
            return self._resolve(db,identity,alias,write)

    @contextmanager
    def publication(self, identity, alias):
        # Revocation and publication serialize even across app processes.
        with self.database(True) as db:
            yield self._resolve(db,identity,alias,True)

    def _public(self,row,role,organization_role):
        catalog = ProjectStore(self.root,row['owner'])
        item = catalog.public_project(catalog.metadata(row['project']))
        return {**item,'id':'shared-'+row['id'],'shared':True,'role':role,
                'capabilities':{'read':True,'write':role=='editor' and organization_role in ('owner','admin','analyst'),
                                'manage':False,'ai':False,'cli':False,'export':False}}

    def shared(self,identity):
        actor=principal(identity)
        with self.database() as db:
            rows=db.execute('SELECT projects.*,members.role FROM projects JOIN members ON projects.id=members.project '
                            'WHERE members.actor=? AND members.user=? AND members.email=? AND members.revoked=0 AND projects.organization=? '
                            'ORDER BY members.created DESC LIMIT 501',
                            (actor['owner'],actor['user'],actor['email'],actor['organization'])).fetchall()
            if len(rows)>500:raise BlochAIError('A lista de colaborações excedeu o limite.')
            return [self._public(row,row['role'],identity['organization'].get('role')) for row in rows if self._current(row)]

    def collaborators(self,identity,project):
        actor=principal(identity)
        with self.database() as db:
            row=self._owned(db,actor,project)
            if not row:return {'members':[],'invitations':[],'deployment_scope':'same_workspace'}
            members=[dict(item) for item in db.execute('SELECT id,email,role,created AS created_at FROM members WHERE project=? AND revoked=0',(row['id'],))]
            invitations=[dict(item) for item in db.execute('SELECT id,email,role,expires AS expires_at FROM invitations WHERE project=? AND consumed=0 AND revoked=0 AND expires>?',(row['id'],time.time()))]
            return {'members':members,'invitations':invitations,'deployment_scope':'same_workspace'}

    def revoke(self,identity,project,identifier):
        actor=principal(identity)
        if not isinstance(identifier,str) or not re.fullmatch(r'[a-f0-9]{32}',identifier):
            raise AccessDenied('Colaborador não encontrado.')
        with self.database(True) as db:
            row=self._owned(db,actor,project)
            if not row:raise AccessDenied('Colaborador não encontrado.')
            found=False
            for table in ('members','invitations'):
                found=db.execute(f'DELETE FROM {table} WHERE project=? AND id=?',(row['id'],identifier)).rowcount>0 or found
            if not found:raise AccessDenied('Colaborador não encontrado.')
        return {'revoked':True}

    def forget(self,owner,project):
        if not self.path.exists():return
        with self.database(True) as db:
            db.execute('DELETE FROM projects WHERE owner=? AND project=?',(owner,project))

    def export(self,owner,project):
        if not self.path.exists():return {'members':[],'invitations':[]}
        with self.database() as db:
            row=db.execute('SELECT * FROM projects WHERE owner=? AND project=?',(owner,project)).fetchone()
            if not row or not self._current(row):return {'members':[],'invitations':[]}
            return {
                'members':[dict(item) for item in db.execute('SELECT id,email,role,created AS created_at FROM members WHERE project=? AND revoked=0',(row['id'],))],
                'invitations':[dict(item) for item in db.execute('SELECT id,email,role,expires AS expires_at FROM invitations WHERE project=? AND consumed=0 AND revoked=0 AND expires>?',(row['id'],time.time()))],
                'deployment_scope':'same_workspace', 'invitation_credentials_included':False}
