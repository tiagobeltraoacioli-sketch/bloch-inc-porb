"""Bounded arithmetic over supplied assumptions; no data retrieval or execution.

Growth is an independent normal draw per simulated year, floored at -100% so
revenue cannot become negative. This is an illustrative model, not verified
company history, financial advice, a fitted forecast, or machine learning.
"""
from __future__ import annotations

import hashlib
import json
import math
import random

from .config import BlochAIError


MAX_YEARS = 10
MAX_TRIALS = 10000
MAX_STEPS = MAX_YEARS * MAX_TRIALS
MAX_AMOUNT = 1_000_000_000_000_000
_REQUIRED = {'initial_annual_revenue', 'growth_mean', 'growth_stddev',
             'years', 'trials', 'seed'}
_OPTIONAL = {'margin', 'annual_cost', 'regression_series'}


def _number(value, name, low, high):
    if type(value) not in (int, float):
        raise BlochAIError(name + ' must be an explicit finite number.')
    try:
        number = float(value)
    except (OverflowError, ValueError):
        raise BlochAIError(name + ' is outside the supported numeric range.') from None
    if not math.isfinite(number) or not low <= number <= high:
        raise BlochAIError(name + ' is outside the supported finite range.')
    return number


def _integer(value, name, low, high):
    if type(value) is not int or not low <= value <= high:
        raise BlochAIError(name + ' must be an integer in ' + str(low) + '..' + str(high) + '.')
    return value


def _digest(value):
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'),
                     ensure_ascii=True, allow_nan=False).encode('ascii')
    return hashlib.sha256(raw).hexdigest()


def _percentiles(values):
    ordered = sorted(values)
    def quantile(fraction):
        position = (len(ordered) - 1) * fraction
        lower = math.floor(position)
        upper = math.ceil(position)
        weight = position - lower
        return ordered[lower] * (1.0 - weight) + ordered[upper] * weight
    return {'p10': quantile(.10), 'p50': quantile(.50), 'p90': quantile(.90)}


def _regression(series):
    count = len(series)
    x_mean = (count - 1) / 2
    y_mean = math.fsum(series) / count
    xx = math.fsum((index - x_mean) ** 2 for index in range(count))
    centered = [value - y_mean for value in series]
    scale = max(abs(value) for value in centered)
    normalized = [value / scale for value in centered] if scale else [0.0] * count
    scaled_slope = math.fsum((index - x_mean) * value for index, value in enumerate(normalized)) / xx
    slope = scaled_slope * scale
    intercept = y_mean - slope * x_mean
    # Scaling before squaring avoids falsely calling tiny finite series constant.
    total_squares = math.fsum(value ** 2 for value in normalized)
    residual_squares = math.fsum((value - scaled_slope * (index - x_mean)) ** 2
                                 for index, value in enumerate(normalized))
    return {
        'method': 'ordinary_least_squares_with_intercept',
        'x': 'supplied_series_index_starting_at_zero',
        'observations': count,
        'slope': slope,
        'intercept': intercept,
        'r2': None if total_squares == 0 else max(0.0, min(1.0, 1 - residual_squares / total_squares)),
        'r2_defined': total_squares != 0,
        'input_status': 'supplied_unverified_series',
        'used_to_calibrate_simulation': False,
    }


def simulate_forecast(spec):
    """Return actual bounded Monte Carlo calculations, never inferred inputs.

    Required: initial_annual_revenue, growth_mean and growth_stddev as decimal
    rates, years 1..10, trials 100..10000, seed 0..2**32-1. Optional margin 0..1
    or constant annual_cost (mutually exclusive). Amounts must be 0..10**15.
    Optional regression_series contains 2..100 supplied revenue observations;
    its separate OLS calculation does not set or alter Monte Carlo assumptions.
    All monetary values retain the units supplied by the caller.
    """
    if not isinstance(spec, dict) or not _REQUIRED <= set(spec) or set(spec) - _REQUIRED - _OPTIONAL:
        raise BlochAIError('Supply exactly the required forecast assumptions and supported optional fields.')
    if 'margin' in spec and 'annual_cost' in spec:
        raise BlochAIError('Specify either margin or annual_cost, never both.')
    years = _integer(spec['years'], 'years', 1, MAX_YEARS)
    trials = _integer(spec['trials'], 'trials', 100, MAX_TRIALS)
    seed = _integer(spec['seed'], 'seed', 0, 2**32 - 1)
    initial = _number(spec['initial_annual_revenue'], 'initial_annual_revenue', 0, MAX_AMOUNT)
    mean = _number(spec['growth_mean'], 'growth_mean', -1, 5)
    deviation = _number(spec['growth_stddev'], 'growth_stddev', 0, 2)
    assumptions = {'initial_annual_revenue': initial, 'growth_mean': mean,
                   'growth_stddev': deviation, 'years': years, 'trials': trials, 'seed': seed}
    margin = _number(spec['margin'], 'margin', 0, 1) if 'margin' in spec else None
    cost = _number(spec['annual_cost'], 'annual_cost', 0, MAX_AMOUNT) if 'annual_cost' in spec else None
    if margin is not None: assumptions['margin'] = margin
    if cost is not None: assumptions['annual_cost'] = cost
    series = None
    if 'regression_series' in spec:
        source = spec['regression_series']
        if not isinstance(source, list) or not 2 <= len(source) <= 100:
            raise BlochAIError('regression_series must contain 2..100 supplied observations.')
        series = [_number(value, 'regression_series observation', 0, MAX_AMOUNT) for value in source]
        assumptions['regression_series'] = series

    generator = random.Random(seed)  # Isolated from the process-global RNG.
    annual_revenue = [[] for _ in range(years)]
    annual_profit = [[] for _ in range(years)] if margin is not None or cost is not None else None
    cumulative_revenue, cumulative_profit = [], []
    floored_draws = 0
    for _ in range(trials):
        revenue = initial
        path_revenue, path_profit = [], []
        for index in range(years):
            growth = generator.gauss(mean, deviation)
            if growth < -1:
                growth = -1.0
                floored_draws += 1
            revenue *= 1 + growth
            if not math.isfinite(revenue):
                raise BlochAIError('Forecast arithmetic exceeded its finite numeric range; no result was produced.')
            annual_revenue[index].append(revenue)
            path_revenue.append(revenue)
            if annual_profit is not None:
                profit = revenue * margin if margin is not None else revenue - cost
                annual_profit[index].append(profit)
                path_profit.append(profit)
        cumulative_revenue.append(math.fsum(path_revenue))
        if annual_profit is not None: cumulative_profit.append(math.fsum(path_profit))

    annual = []
    for index in range(years):
        row = {'year': index + 1, 'revenue': _percentiles(annual_revenue[index])}
        if annual_profit is not None: row['profit'] = _percentiles(annual_profit[index])
        annual.append(row)
    totals = {'revenue': _percentiles(cumulative_revenue)}
    if annual_profit is not None: totals['profit'] = _percentiles(cumulative_profit)
    result = {
        'schema': 'qentl-illustrative-forecast-v1',
        'status': 'illustrative_unverified_inputs',
        'assumptions': assumptions,
        'actual_trials': trials,
        'actual_simulated_years': years * trials,
        'annual': annual,
        'totals': totals,
        'method': {
            'simulation': 'independent_normal_annual_growth_monte_carlo',
            'growth_rates': 'decimal; 0.05 means 5 percent',
            'revenue_update': 'previous_annual_revenue * (1 + max(-1, sampled_growth))',
            'revenue_base': 'initial_annual_revenue is year zero; outputs start at year one',
            'growth_floor': -1.0,
            'floored_draws': floored_draws,
            'floor_effect': 'Flooring changes the normal distribution; mean/stddev describe draws before flooring.',
            'quantiles': 'linear interpolation at (sample_count - 1) * probability',
            'totals': 'quantiles of each complete path cumulative amount; no discounting or sum of annual quantiles',
            'profit': 'revenue times constant margin' if margin is not None else 'revenue minus constant annual cost' if cost is not None else 'not calculated; no margin or cost supplied',
            'units': 'same monetary units as supplied; no currency or inflation inference',
            'random_generator': 'Python random.Random(seed).gauss; same implementation and platform reproduce results',
            'seed': seed,
            'max_simulated_years': MAX_STEPS,
            'historical_data_verified': False,
            'machine_learning_training': False,
            'regression_calibrates_simulation': False,
        },
        'regression': _regression(series) if series is not None else None,
        'input_sha256': _digest(assumptions),
    }
    result['result_sha256'] = _digest(result)
    return result
