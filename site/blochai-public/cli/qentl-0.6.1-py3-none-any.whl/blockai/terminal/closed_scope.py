"""Human-approved Markdown contracts for bounded project development.

Path and revision enforcement is mechanical. Semantic acceptance of generated
content remains a human review responsibility, never an inferred model verdict.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import PurePosixPath
import re
import time
import uuid

from .config import BlochAIError, save_json
from .file_permissions import is_private
from .project_lock import project_write_lock
from .workspace import Workspace

MAX_SOURCE_CHARS = 24000
MAX_REVISIONS = 100
REQUIREMENT_ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,47}')


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


class ClosedScopeStore:
    def __init__(self, projects, project):
        self.projects, self.project = projects, project
        self.folder = projects.folder(project)
        info = self.folder.stat()
        self.generation = (info.st_dev, info.st_ino)
        self.directory = projects.state.parent / 'closed-scopes' / project

    def _project(self):
        try:
            current = self.projects.folder(self.project)
            info = current.stat()
            if (info.st_dev, info.st_ino) != self.generation:
                raise BlochAIError('The project changed. Open its current approved scope again.')
        except (FileNotFoundError, OSError) as exc:
            raise BlochAIError('The approved scope project is no longer available.') from exc
        if any(path.is_symlink() for path in (self.directory, self.directory.parent, self.directory / 'revisions',
                                             self.projects.state.parent, self.projects.state.parent.parent)):
            raise BlochAIError('Invalid private scope state.')

    def _read(self, path, maximum):
        if not path.exists():
            return None
        if not is_private(path) or path.stat().st_size > maximum:
            raise BlochAIError('Invalid private scope state.')
        try:
            value = json.loads(path.read_text(encoding='utf-8'))
        except (ValueError, OSError, RecursionError) as exc:
            raise BlochAIError('Invalid private scope state.') from exc
        if not isinstance(value, dict):
            raise BlochAIError('Invalid private scope state.')
        return value

    def _current(self):
        self._project()
        current = self._read(self.directory / 'current.json', 4096)
        if current is None:
            return None, None
        revision = current.get('revision')
        if (not isinstance(revision, str) or not re.fullmatch(r'[a-f0-9]{32}', revision)
                or current.get('status') not in ('approved', 'revoked')
                or current.get('owner') != self.projects.owner or current.get('project') != self.project):
            raise BlochAIError('Invalid private scope state.')
        contract = self._read(self.directory / 'revisions' / (revision + '.json'), 250000)
        if not contract or contract.get('revision') != revision or contract.get('owner') != self.projects.owner or contract.get('project') != self.project:
            raise BlochAIError('Approved scope revision is unavailable.')
        checksum = digest({key: value for key, value in contract.items() if key != 'sha256'})
        if checksum != contract.get('sha256') or checksum != current.get('sha256'):
            raise BlochAIError('Approved scope integrity failed. Review and approve the source documents again.')
        return current, contract

    def _path(self, value):
        if (not isinstance(value, str) or not 1 <= len(value) <= 180
                or any(ord(char) < 32 for char in value) or '\\' in value
                or any(part in ('', '.', '..') or part.startswith('.') for part in value.split('/'))):
            raise BlochAIError('Use explicit portable project file or folder paths, without parent traversal.')
        return Workspace(self.folder, lambda *_: False).path(value, directory=True).relative_to(self.folder.resolve()).as_posix()

    def _source_index(self):
        from .knowledge import KnowledgeStore
        self._project()
        rows = {row['path']: {'path': row['path'], 'title': row['title'], 'kind': 'code'}
                for row in self.projects.code_files(self.project)['files']
                if row['path'].lower().endswith('.md')}
        for row in KnowledgeStore(self.projects, self.project).records():
            if row['path'].lower().endswith('.md'):
                rows[row['path']] = {'path': row['path'], 'title': row['title'], 'kind': 'knowledge'}
        return rows

    def _source(self, path, index):
        path = self._path(path)
        if path not in index:
            raise BlochAIError('Choose an existing project Markdown file or managed Markdown note.')
        file = Workspace(self.folder, lambda *_: False).path(path)
        if not file.is_file() or file.stat().st_size > MAX_SOURCE_CHARS * 4:
            raise BlochAIError('Scope documents exceed the 24,000-character review limit.')
        raw = file.read_bytes()
        try:
            content = raw.decode('utf-8')
        except UnicodeError as exc:
            raise BlochAIError('Approved scope documents must contain UTF-8 Markdown.') from exc
        if '\x00' in content or not content.strip() or len(content) > MAX_SOURCE_CHARS:
            raise BlochAIError('Choose nonempty Markdown scope documents totaling at most 24,000 characters.')
        return {**index[path], 'sha256': hashlib.sha256(raw).hexdigest(), 'chars': len(content), 'content': content}

    def sources(self):
        index = self._source_index()
        result = []
        for path, item in sorted(index.items())[:200]:
            try:
                row = self._source(path, index)
                result.append({key: value for key, value in row.items() if key != 'content'} | {'eligible': True})
            except (BlochAIError, OSError):
                result.append({**item, 'sha256': None, 'chars': None, 'eligible': False})
        return result

    def preview(self, source_paths):
        if (not isinstance(source_paths, list) or not 1 <= len(source_paths) <= 8
                or any(not isinstance(path, str) for path in source_paths)
                or len({path.casefold() for path in source_paths}) != len(source_paths)):
            raise BlochAIError('Choose 1 to 8 distinct Markdown scope documents.')
        index = self._source_index()
        rows = [self._source(path, index) for path in source_paths]
        if sum(row['chars'] for row in rows) > MAX_SOURCE_CHARS:
            raise BlochAIError('The complete selected Markdown exceeds 24,000 characters; split the scope explicitly.')
        return {'sources': rows, 'source_digests': {row['path']: row['sha256'] for row in rows},
                'total_chars': sum(row['chars'] for row in rows)}

    def _allowed(self, paths):
        if not isinstance(paths, list) or not 1 <= len(paths) <= 64:
            raise BlochAIError('Approve 1 to 64 explicit writable files or folders.')
        result, seen = [], set()
        for row in paths:
            if not isinstance(row, dict) or set(row) != {'path', 'kind'} or row['kind'] not in ('file', 'folder'):
                raise BlochAIError('Each writable location needs a path and file/folder kind.')
            path = self._path(row['path'])
            if PurePosixPath(path).parts[0].casefold() in ('uploads', 'knowledge') or path.casefold() in seen:
                raise BlochAIError('Managed references are read-only and writable paths must be distinct.')
            file = self.folder / path
            if file.exists() and (file.is_dir() != (row['kind'] == 'folder')):
                raise BlochAIError('A writable path kind does not match the current project.')
            seen.add(path.casefold())
            result.append({'path': path, 'kind': row['kind']})
        return result

    def _requirements(self, value, sources):
        if value is None or value == []:
            return [{'id': 'REQ-' + str(i + 1).zfill(3), 'text': 'Implement the approved requirements in ' + row['path']}
                    for i, row in enumerate(sources)]
        if not isinstance(value, list) or not 1 <= len(value) <= 64:
            raise BlochAIError('Use at most 64 requirement IDs.')
        seen, total = set(), 0
        for item in value:
            if (not isinstance(item, dict) or set(item) != {'id', 'text'}
                    or not isinstance(item['id'], str) or not REQUIREMENT_ID.fullmatch(item['id'])
                    or item['id'].casefold() in seen or not isinstance(item['text'], str)
                    or not 1 <= len(item['text'].strip()) <= 1000 or '\x00' in item['text']):
                raise BlochAIError('Use distinct requirement IDs with descriptions of 1 to 1,000 characters.')
            seen.add(item['id'].casefold())
            total += len(item['text'])
        if total > 8000:
            raise BlochAIError('Requirement descriptions must total at most 8,000 characters.')
        return value

    def approve(self, source_paths, allowed_paths, requirements=None, *, source_digests, expected_revision, actor):
        if actor != self.projects.owner:
            raise BlochAIError('Only this project owner can approve its closed scope.')
        with project_write_lock(self.folder):
            current, previous = self._current()
            if expected_revision != (current['revision'] if current else None):
                raise BlochAIError('The scope version changed. Review the current version first.')
            preview = self.preview(source_paths)
            if source_digests != preview['source_digests']:
                raise BlochAIError('A scope document changed after preview. Read it again before approval.')
            paths = self._allowed(allowed_paths)
            reserved = {path.casefold() for path in preview['source_digests']}
            if any(row['kind'] == 'file' and row['path'].casefold() in reserved for row in paths):
                raise BlochAIError('Approved Markdown scope sources must remain read-only to agents.')
            requirements = self._requirements(requirements, preview['sources'])
            version = previous['version'] + 1 if previous else 1
            if version > MAX_REVISIONS:
                raise BlochAIError('This project reached its 100 reviewed scope versions.')
            revision = uuid.uuid4().hex
            contract = {'schema': 'qentl-closed-scope-v1', 'owner': actor, 'project': self.project,
                        'revision': revision, 'version': version, 'approved_at': time.time(),
                        'source_paths': source_paths, 'sources': preview['sources'], 'allowed_paths': paths,
                        'requirements': requirements, 'training_allowed': False}
            contract['sha256'] = digest(contract)
            save_json(self.directory / 'revisions' / (revision + '.json'), contract)
            save_json(self.directory / 'current.json', {'schema': 'qentl-closed-scope-pointer-v1',
                      'owner': actor, 'project': self.project, 'revision': revision,
                      'sha256': contract['sha256'], 'status': 'approved'})
            return self.status()

    def revoke(self, *, expected_revision, actor):
        if actor != self.projects.owner:
            raise BlochAIError('Only this project owner can revoke its closed scope.')
        with project_write_lock(self.folder):
            current, _ = self._current()
            if not current or current['revision'] != expected_revision:
                raise BlochAIError('The scope version changed. Review the current version first.')
            save_json(self.directory / 'current.json', {**current, 'status': 'revoked', 'revoked_at': time.time()})
            return self.status()

    def _check_sources(self, contract):
        preview = self.preview(contract['source_paths'])
        if preview['source_digests'] != {row['path']: row['sha256'] for row in contract['sources']}:
            raise BlochAIError('An approved Markdown source changed. Owner review and a new approved scope are required.')

    def status(self):
        current, contract = self._current()
        if not current:
            return {'state': 'missing', 'revision': None, 'version': 0, 'contract': None}
        state = current['status']
        if state == 'approved':
            try:
                self._check_sources(contract)
            except (BlochAIError, FileNotFoundError, OSError):
                state = 'stale'
        return {'state': state, 'revision': current['revision'], 'version': contract['version'], 'contract': contract}

    def require(self, requirement_id, revision=None):
        status = self.status()
        if status['state'] != 'approved':
            raise BlochAIError('Project development requires a current closed Markdown scope approved by its owner.')
        if revision is not None and revision != status['revision']:
            raise BlochAIError('The approved scope changed. Select the current revision and requirement.')
        contract = status['contract']
        if not isinstance(requirement_id, str) or requirement_id not in {row['id'] for row in contract['requirements']}:
            raise BlochAIError('Select a requirement ID from the current approved Markdown scope.')
        return ClosedScopeGuard(self, contract, requirement_id)


class ClosedScopeGuard:
    def __init__(self, store, contract, requirement_id):
        self.store = store
        self.contract = json.loads(json.dumps(contract))
        self.requirement_id = requirement_id

    def check(self):
        current, contract = self.store._current()
        if (not current or current['status'] != 'approved' or current['revision'] != self.contract['revision']
                or contract['sha256'] != self.contract['sha256']):
            raise BlochAIError('This task scope was revoked or replaced. Start a new task with the approved revision.')
        self.store._check_sources(contract)

    def assert_writable(self, path):
        self.check()
        relative = self.store._path(path)
        if relative.casefold() in {row['path'].casefold() for row in self.contract['sources']}:
            raise BlochAIError('Agents cannot alter their approved Markdown scope sources. Propose a change request.')
        if PurePosixPath(relative).parts[0].casefold() in ('knowledge', 'uploads'):
            raise BlochAIError('Managed references are read-only to development agents.')
        for item in self.contract['allowed_paths']:
            if ((item['kind'] == 'file' and relative == item['path'])
                    or (item['kind'] == 'folder' and relative.startswith(item['path'] + '/'))):
                return
        raise BlochAIError('This write is outside the closed approved Markdown scope. Propose a scope change for owner approval.')

    def provenance(self):
        return {key: self.contract[key] for key in ('revision', 'version', 'sha256')} | {'requirement_id': self.requirement_id}

    def bind_messages(self, messages):
        """Bind complete approved text to every generation, including delegates."""
        scope = self.prompt()
        result = [dict(row) for row in messages]
        if result and result[0].get('role') == 'system':
            content = result[0].get('content', '')
            if not isinstance(content, str):
                raise BlochAIError('Project scope requires text system instructions.')
            if scope not in content:
                result[0]['content'] = content + scope
        else:
            result.insert(0, {'role': 'system', 'content': scope})
        return result

    def prompt(self):
        self.check()
        header = ('\n\nCLOSED HUMAN-APPROVED PROJECT SCOPE\n'
                  'Follow the complete approved Markdown below and the selected requirement. '
                  'Do not expand scope or alter its source documents. If the task needs another feature or path, '
                  'propose a change request for owner approval and stop that change. '
                  'All requirements remain constraints; the selected ID identifies this task. '
                  'Tool access and platform safety rules still apply. Human review determines semantic acceptance.\n')
        header += json.dumps({'provenance': self.provenance(), 'allowed_paths': self.contract['allowed_paths'],
                              'requirements': self.contract['requirements']}, ensure_ascii=False)
        for source in self.contract['sources']:
            header += '\n\nAPPROVED MARKDOWN: ' + source['path'] + '\n' + source['content']
        return header + '\n\nEND CLOSED PROJECT SCOPE\n'
