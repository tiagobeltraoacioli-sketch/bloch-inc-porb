"""Explicit exports of verified generated documents to the OS Downloads folder."""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import os
from pathlib import Path,PurePosixPath,PureWindowsPath
import re
import stat

from .config import BlochAIError
from .workspace import Workspace

MAX_DOCUMENT_BYTES=20_000_000
FORMATS={'.pdf','.pptx','.xlsx'}


@dataclass(frozen=True)
class VerifiedDocument:
    name: str
    data: bytes
    sha256: str
    source: str


def receipt_name(receipt):
    if not isinstance(receipt,dict) or not isinstance(receipt.get('path'),str) or not re.fullmatch(r'[a-f0-9]{64}',str(receipt.get('sha256',''))):
        raise BlochAIError('A verified generated-document receipt is required.')
    path=receipt['path'];parts=PurePosixPath(path).parts
    if (len(parts)!=3 or parts[0]!='artifacts' or not re.fullmatch(r'[a-f0-9]{16}',parts[1])
            or path!='/'.join(parts) or '\\' in path):
        raise BlochAIError('Only this session’s generated artifact receipts can be exported.')
    name=parts[2]
    if (len(name.encode('utf-8'))>180 or Path(name).suffix.casefold() not in FORMATS or PureWindowsPath(name).is_reserved()
            or name.endswith((' ','.')) or any(ord(char)<32 or char in '<>:"/\\|?*' for char in name)):
        raise BlochAIError('Use a portable PDF, PPTX or XLSX document filename.')
    return name


def verified_document(receipt,data):
    name=receipt_name(receipt)
    if not isinstance(data,bytes) or not 1<=len(data)<=MAX_DOCUMENT_BYTES or hashlib.sha256(data).hexdigest()!=receipt['sha256']:
        raise BlochAIError('The generated document changed or exceeds the export size limit.')
    return VerifiedDocument(name,data,receipt['sha256'],receipt['path'])


def local_document(root,receipt):
    receipt_name(receipt)
    workspace=Workspace(Path(root),lambda *_:False,allow_commands=False)
    path=workspace.path(receipt['path'])
    fd=None
    try:
        fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0))
        info=os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_size>MAX_DOCUMENT_BYTES:
            raise BlochAIError('The generated document is not a regular private artifact.')
        with os.fdopen(fd,'rb') as stream:
            fd=None;data=stream.read(MAX_DOCUMENT_BYTES+1)
        after=workspace.path(receipt['path']).stat()
        if (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):
            raise BlochAIError('The generated document changed during export.')
        return verified_document(receipt,data)
    except OSError as exc:raise BlochAIError('The generated document is unavailable; nothing was exported.') from exc
    finally:
        if fd is not None:os.close(fd)


def downloads_directory():
    if os.name!='nt':return Path.home()/'Downloads'
    import ctypes
    import uuid
    # FOLDERID_Downloads resolves the user's actual Windows known folder.
    shell=ctypes.WinDLL('shell32',use_last_error=True);ole=ctypes.WinDLL('ole32')
    pointer=ctypes.c_void_p();guid=(ctypes.c_ubyte*16).from_buffer_copy(uuid.UUID('374DE290-123F-4565-9164-39C4925E467B').bytes_le)
    shell.SHGetKnownFolderPath.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)]
    shell.SHGetKnownFolderPath.restype=ctypes.c_long
    ole.CoTaskMemFree.argtypes=[ctypes.c_void_p]
    if shell.SHGetKnownFolderPath(ctypes.byref(guid),0,None,ctypes.byref(pointer))!=0:
        raise BlochAIError('Windows did not provide a Downloads folder.')
    try:return Path(ctypes.wstring_at(pointer))
    finally:ole.CoTaskMemFree(pointer)


def _directory_info(path):
    try:info=path.lstat()
    except OSError as exc:raise BlochAIError('Downloads must be an existing directory.') from exc
    if path.is_symlink() or not stat.S_ISDIR(info.st_mode) or getattr(info,'st_file_attributes',0)&0x400:
        raise BlochAIError('A symbolic link or reparse point cannot be used as Downloads.')
    return info


@contextmanager
def _windows_directory_guard(path):
    import ctypes
    from ctypes import wintypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
    kernel.CreateFileW.restype=wintypes.HANDLE
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    handle=kernel.CreateFileW(str(path),0,3,None,3,0x02000000|0x00200000,None)
    if handle==ctypes.c_void_p(-1).value:raise BlochAIError('Downloads could not be locked for export.')
    try:yield
    finally:kernel.CloseHandle(handle)


def export_download(document,approve):
    if not isinstance(document,VerifiedDocument):raise BlochAIError('Export requires a verified generated document.')
    # Validate even a programmatic caller's record before offering publication.
    verified_document({'path':document.source,'sha256':document.sha256},document.data)
    if receipt_name({'path':document.source,'sha256':document.sha256})!=document.name:raise BlochAIError('Document receipt filename changed.')
    folder=downloads_directory();before=_directory_info(folder)
    target=folder/document.name
    if target.exists() or target.is_symlink():raise BlochAIError('Downloads already contains '+document.name+'. No file was overwritten.')
    if not approve('export_download',f'Copy verified document to {target}\n{len(document.data)} bytes; SHA256 {document.sha256}\nExisting files will not be replaced.'):
        return {'denied':True,'name':document.name}
    def same_directory():
        current=_directory_info(folder)
        if (before.st_dev,before.st_ino)!=(current.st_dev,current.st_ino):raise BlochAIError('Downloads changed during approval; nothing was exported.')
    same_directory()
    fd=None;directory_fd=None
    try:
        if os.name=='nt':
            with _windows_directory_guard(folder):
                same_directory()
                fd=os.open(target,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_BINARY,0o600)
                same_directory()
                with os.fdopen(fd,'wb') as stream:
                    fd=None;stream.write(document.data);stream.flush();os.fsync(stream.fileno())
        else:
            directory_fd=os.open(folder,os.O_RDONLY|os.O_DIRECTORY|getattr(os,'O_NOFOLLOW',0))
            info=os.fstat(directory_fd)
            if (before.st_dev,before.st_ino)!=(info.st_dev,info.st_ino):raise BlochAIError('Downloads changed during export.')
            fd=os.open(document.name,os.O_CREAT|os.O_EXCL|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),0o600,dir_fd=directory_fd)
            with os.fdopen(fd,'wb') as stream:
                fd=None;stream.write(document.data);stream.flush();os.fsync(stream.fileno())
    except FileExistsError as exc:raise BlochAIError('Downloads already contains this filename; nothing was overwritten.') from exc
    except OSError as exc:raise BlochAIError('Document export failed. Inspect Downloads before retrying; an incomplete file may exist.') from exc
    finally:
        if fd is not None:os.close(fd)
        if directory_fd is not None:os.close(directory_fd)
    return {'path':str(target),'sha256':document.sha256,'bytes':len(document.data)}
