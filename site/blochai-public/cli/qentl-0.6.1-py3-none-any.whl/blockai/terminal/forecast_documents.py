"""Attach actual calculation evidence to documents independently of model prose."""
import copy
import hashlib
import json

from .config import BlochAIError


def attach_forecast(spec, kind, result):
    evidence={key:value for key,value in result.items() if key!='result_sha256'}
    digest=hashlib.sha256(json.dumps(evidence,sort_keys=True,separators=(',', ':'),ensure_ascii=True,allow_nan=False).encode('ascii')).hexdigest()
    if result.get('schema')!='qentl-illustrative-forecast-v1' or result.get('result_sha256')!=digest:
        raise BlochAIError('The calculation evidence could not be verified. Run simulate_forecast again.')
    output=copy.deepcopy(spec)
    assumptions=result['assumptions']
    inputs=[['Status','ILLUSTRATIVE SCENARIO; INPUTS NOT VERIFIED'],['Method','Independent normal growth; floor -100%; no discounting'],
            ['Units','Same monetary units as supplied; no currency inference'],
            ['Trials executed',result['actual_trials']],['Seed',assumptions['seed']],
            ['Result SHA256',digest],['ML training','Not performed'],
            ['Regression calibration','Separate OLS; never used to calibrate simulation']]
    inputs.extend([key,value if not isinstance(value,list) else json.dumps(value)] for key,value in assumptions.items())
    annual=[[row['year'],row['revenue']['p10'],row['revenue']['p50'],row['revenue']['p90']] for row in result['annual']]
    if 'profit' in result['annual'][0]:
        columns=['Year','Revenue P10','Revenue P50','Revenue P90','Profit P10','Profit P50','Profit P90']
        for values,row in zip(annual,result['annual']):values.extend(row['profit'][key] for key in ('p10','p50','p90'))
    else:columns=['Year','Revenue P10','Revenue P50','Revenue P90']
    if kind=='xlsx':
        sheets=output.get('sheets')
        if not isinstance(sheets,list):raise BlochAIError('Supply document sheets before attaching calculation evidence.')
        reserved={'qentl_inputs','qentl_monte_carlo','qentl_regression','qentl_totals'}
        if any(str(sheet.get('name','')).casefold() in reserved for sheet in sheets if isinstance(sheet,dict)):
            raise BlochAIError('Qentl calculation worksheet names are reserved for real calculation evidence.')
        sheets.extend([{'name':'Qentl_Inputs','columns':['Input or method','Value'],'rows':inputs},
                       {'name':'Qentl_Monte_Carlo','columns':columns,'rows':annual},
                       {'name':'Qentl_Totals','columns':['Cumulative metric','P10','P50','P90'],
                        'rows':[[key]+[row[p] for p in ('p10','p50','p90')] for key,row in result['totals'].items()]}])
        if result['regression']:
            sheets.append({'name':'Qentl_Regression','columns':['Metric','Value'],'rows':[[key,value] for key,value in result['regression'].items()]})
    else:
        rows=output.get('sections')
        if not isinstance(rows,list):raise BlochAIError('Supply document sections before attaching calculation evidence.')
        # These sections are written by the application from arithmetic evidence.
        rows.append({'heading':'Calculation evidence / illustrative inputs',
                     'body':'These are computed illustrative scenarios, not verified company revenue, market data or model accuracy. '
                     f"Executed {result['actual_trials']} Monte Carlo trials with seed {assumptions['seed']}; independent normal annual growth, floored at -100%. "
                     'No discounting or ML training. Units remain those supplied. Result SHA256: '+digest})
        values=['{}: {}'.format(key,format(value,'.8g') if type(value) in (int,float) else value)
                for key,value in assumptions.items() if key!='regression_series']
        rows.append({'heading':'Simulation assumptions','body':'\n'.join(values)})
        revenue_lines=['Year {}: P10={:.8g}; P50={:.8g}; P90={:.8g}'.format(row['year'],*(row['revenue'][key] for key in ('p10','p50','p90'))) for row in result['annual']]
        rows.append({'heading':'Calculated annual revenue quantiles','body':'\n'.join(revenue_lines)})
        if 'profit' in result['annual'][0]:
            profit_lines=['Year {}: P10={:.8g}; P50={:.8g}; P90={:.8g}'.format(row['year'],*(row['profit'][key] for key in ('p10','p50','p90'))) for row in result['annual']]
            rows.append({'heading':'Calculated annual profit quantiles','body':'\n'.join(profit_lines)})
        totals=result['totals']['revenue']
        summary='Cumulative revenue across complete simulated paths: '+ '; '.join(key+'='+format(value,'.8g') for key,value in totals.items())+'.'
        if result['regression']:
            regression=result['regression']
            summary+=' Separate OLS on {} unverified observations: slope={:.8g}; intercept={:.8g}; R2={}. It does not calibrate this Monte Carlo model.'.format(regression['observations'],regression['slope'],regression['intercept'],format(regression['r2'],'.8g') if regression['r2'] is not None else 'undefined for a constant series')
        else:summary+=' No regression was executed because no input series was supplied.'
        rows.append({'heading':'Totals and regression evidence','body':summary})
    return output
