"""Read-only, master-only projection of bounded synthetic capability measurements."""
from __future__ import annotations

import json
from datetime import datetime, timezone
import math
import os
import re
import stat

from fastapi import HTTPException, Request
from starlette.concurrency import run_in_threadpool

from .config import state_home
from .training_control import MASTER_EMAIL

SCHEMA = 'qentl-capability-dashboard-v1'
DIMENSIONS = ('programming', 'deduction', 'induction', 'inference', 'critique')
MAX_REPORT_BYTES = 1_000_000
LIMITATION = 'Experimental small fixed suite; no equivalence to human IQ or general intelligence.'


def _text(value, maximum=160):
    if not isinstance(value, str) or not value or len(value) > maximum or any(ord(c) < 32 for c in value):
        raise ValueError('Invalid measurement label.')
    return value


def _integer(value, maximum):
    if type(value) is not int or not 0 <= value <= maximum:
        raise ValueError('Invalid measurement count.')
    return value


def _timestamp(value):
    value = _text(value, 40)
    if not re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,6})?(?:Z|\+00:00)', value):
        raise ValueError('A UTC observation date is required.')
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.utcoffset() != timezone.utc.utcoffset(parsed):
        raise ValueError('A UTC observation date is required.')
    return value


def _digest(value, length=64):
    if not isinstance(value, str) or not re.fullmatch('[a-f0-9]{' + str(length) + '}', value):
        raise ValueError('Invalid measurement digest.')
    return value


def _score(value, passed, cases, complete):
    if not complete:
        if value is not None:
            raise ValueError('Incomplete evaluations cannot carry a score.')
        return None
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 100:
        raise ValueError('Invalid measured score.')
    expected = 100 * passed / cases
    if abs(value - expected) > .011:
        raise ValueError('Score does not match the measured count.')
    return round(expected, 2)


def _row(value):
    if not isinstance(value, dict):
        raise ValueError('Invalid measurement row.')
    cases = _integer(value.get('cases'), 20)
    if cases != 20 or value.get('status') not in ('completed', 'incomplete'):
        raise ValueError('Unsupported evaluation suite.')
    complete = value['status'] == 'completed'
    passed = _integer(value.get('passed'), cases)
    completed = _integer(value.get('completed_cases'), cases)
    errors = _integer(value.get('error_cases'), cases)
    if passed > completed or completed + errors != cases or (complete and errors):
        raise ValueError('Inconsistent evaluation counts.')
    dimensions = value.get('dimensions')
    if not isinstance(dimensions, dict) or set(dimensions) != set(DIMENSIONS):
        raise ValueError('Incomplete evaluation dimensions.')
    projected = {}
    for name in DIMENSIONS:
        item = dimensions[name]
        if not isinstance(item, dict) or item.get('cases') != 4:
            raise ValueError('Invalid dimension count.')
        count = _integer(item.get('passed'), 4)
        # Individual dimensions may finish before a different dimension fails.
        score = _score(item.get('score'), count, 4, item.get('score') is not None)
        if complete and score is None:
            raise ValueError('Completed evaluation lacks a dimension score.')
        projected[name] = {'passed': count, 'cases': 4, 'score': score}
    if sum(item['passed'] for item in projected.values()) != passed:
        raise ValueError('Dimension counts do not match the evaluation.')
    return {'id': _digest(value.get('id'), 32), 'model': _text(value.get('model')),
            'model_revision': _digest(value.get('model_revision')),
            'evaluated_at': _timestamp(value.get('evaluated_at')),
            'suite_version': _text(value.get('suite_version'), 80), 'status': value['status'],
            'score': _score(value.get('score'), passed, cases, complete),
            'passed': passed, 'cases': cases, 'completed_cases': completed, 'error_cases': errors,
            'dimensions': projected}


def sanitize_report(value):
    if not isinstance(value, dict) or value.get('schema') != SCHEMA:
        raise ValueError('Invalid capability report schema.')
    versions, history = value.get('versions'), value.get('history')
    if not isinstance(versions, list) or len(versions) > 16 or not isinstance(history, list) or len(history) > 270:
        raise ValueError('Capability report exceeds bounded history.')
    projected_versions = []
    for version in versions:
        if not isinstance(version, dict) or version.get('cases') != 20 or version.get('metric') != 'experimental_percent_correct':
            raise ValueError('Unsupported capability suite.')
        projected_versions.append({'id': _text(version.get('id'), 80),
            'sha256': _digest(version.get('sha256')), 'cases': 20,
            'description': _text(version.get('description'), 320), 'metric': 'experimental_percent_correct'})
    known = {item['id'] for item in projected_versions}
    if len(known) != len(projected_versions):
        raise ValueError('Duplicated suite version identifier.')
    rows = [_row(item) for item in history]
    if any(item['suite_version'] not in known for item in rows) or len({item['id'] for item in rows}) != len(rows):
        raise ValueError('Unrecognized or duplicated evaluation.')
    rows.sort(key=lambda item: (item['evaluated_at'], item['id']))
    latest = {}
    for row in rows:
        latest[row['model']] = row
    # Recompute latest from validated observations; never trust an arbitrary nested payload.
    return {'schema': SCHEMA, 'can_view': True, 'available': bool(rows),
            'updated_at': _timestamp(value.get('updated_at')), 'versions': projected_versions,
            'history': rows, 'latest_by_model': latest, 'limitations': LIMITATION}


def load_dashboard():
    path = state_home() / 'capability-evaluations' / 'status.json'
    try:
        if path.parent.is_symlink() or path.is_symlink():
            raise ValueError('Report links are not permitted.')
        fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0))
        with os.fdopen(fd, 'rb') as source:
            info = os.fstat(source.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > MAX_REPORT_BYTES:
                raise ValueError('Invalid report file.')
            raw = source.read(MAX_REPORT_BYTES + 1)
        if len(raw) > MAX_REPORT_BYTES:
            raise ValueError('Report exceeds byte limit.')
        return sanitize_report(json.loads(raw))
    except FileNotFoundError:
        return {'schema': SCHEMA, 'can_view': True, 'available': False, 'updated_at': None,
                'versions': [], 'history': [], 'latest_by_model': {}, 'limitations': LIMITATION}
    except (OSError, ValueError, TypeError, RecursionError):
        raise HTTPException(503, 'Capability measurements are unavailable or invalid. No score is asserted.') from None


def install_capability_routes(app, session):
    @app.get('/api/admin/capability-evaluations')
    async def capability_evaluations(request: Request):
        def read():
            # Fresh native authority on every read, independent of SSH/controller readiness.
            record = session(request, True)
            identity = record.get('identity', {})
            user, organization = identity.get('user', {}), identity.get('organization', {})
            if (identity.get('account_role') != 'master' or not isinstance(user, dict)
                    or not isinstance(user.get('email'), str) or user['email'].casefold() != MASTER_EMAIL
                    or not isinstance(organization, dict) or organization.get('role') not in ('owner', 'admin')
                    or not isinstance(organization.get('id'), str) or not organization['id']):
                raise HTTPException(403, 'Native Qentl master access is required.')
            return load_dashboard()
        return await run_in_threadpool(read)
