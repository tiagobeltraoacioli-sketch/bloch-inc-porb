"""Nó worker: conecta uma GPU à rede BlockAI.

Fluxo: detecta GPU → registra na cadeia → faz stake → loop {heartbeat,
pede trabalho, executa inferência, envia resultado assinado}.
"""
from __future__ import annotations

import logging
import json
import os
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from typing import Any, Dict, List, Optional

import httpx

from ..chain import KeyPair, Transaction, TxType
from ..chain.state import GpuInfo
from ..model.backend import InferenceBackend
from ..network.protocol import RuntimeReport, heartbeat_message
from .gpu import detect_gpu

log = logging.getLogger("blockai.worker")


class WorkerNode:
    def __init__(self, keypair: KeyPair, coordinator_url: str, backend: InferenceBackend, *,
                 models: Optional[List[str]] = None, stake: Optional[int] = None, gpu: Optional[GpuInfo] = None,
                 operator: str = "", poll_interval: float = 2.0, client: Optional[httpx.Client] = None):
        self.kp = keypair
        self.url = coordinator_url.rstrip("/")
        self.backend = backend
        self.models = models or ([backend.model_id] if getattr(backend, "model_id", None) else [])
        self.stake_target = stake
        self.gpu = gpu or detect_gpu()
        self.operator = operator
        self.poll_interval = poll_interval
        token = os.environ.get("BLOCKAI_WORKER_TOKEN", "")
        self._private = bool(token)
        self.http = client or httpx.Client(base_url=self.url, timeout=30.0,
                                           headers={"Authorization": "Bearer " + token} if token else {})
        self.completed = 0
        self._stop = False
        self._loaded = False
        self._busy = False
        self._drain_file = os.environ.get("BLOCHAI_DRAIN_FILE", "")

    def drain_request(self) -> str:
        """Optional operator maintenance request; never supplied by model output."""
        if not self._drain_file:
            return ""
        path = Path(self._drain_file)
        if not path.exists():
            Path(str(path) + ".ready").unlink(missing_ok=True)
            return ""
        if not path.is_absolute() or path.is_symlink() or path.stat().st_size > 128:
            raise RuntimeError("Invalid operator drain file")
        nonce = path.read_text().strip()
        if not nonce or any(c not in "0123456789abcdef" for c in nonce):
            raise RuntimeError("Invalid operator drain nonce")
        return nonce

    # ----- utilidades de cadeia ----------------------------------------------------
    def nonce(self) -> int:
        r = self.http.get(f"/nonce/{self.kp.address}")
        r.raise_for_status()
        return r.json()["nonce"]

    def send_tx(self, tx_type: TxType, payload: Dict[str, Any]) -> str:
        tx = Transaction.build(self.kp, tx_type, self.nonce(), payload)
        r = self.http.post("/tx", json=tx.model_dump(mode="json"))
        if r.status_code != 200:
            raise RuntimeError(f"{tx_type.value} rejeitada: {r.text}")
        return r.json()["hash"]

    def balance(self) -> int:
        return self.http.get(f"/balance/{self.kp.address}").json()["balance"]

    def my_node(self) -> Optional[Dict[str, Any]]:
        for n in self.http.get("/nodes").json():
            if n["address"] == self.kp.address:
                return n
        return None

    # ----- ciclo de vida -----------------------------------------------------------
    def register(self) -> None:
        info = self.http.get("/").json()
        params = info["params"]
        node = self.my_node()
        needs_register = (node is None or node["gpu"] != self.gpu.model_dump() or node["models"] != self.models
                          or node.get("operator", "") != self.operator)
        if needs_register:
            self.send_tx(TxType.NODE_REGISTER, {"gpu": self.gpu.model_dump(), "models": self.models,
                                                "operator": self.operator})
            log.info("nó %s registrado (%s, %d MB, operador=%s)", self.kp.address[:12], self.gpu.name,
                    self.gpu.memory_mb, self.operator or "-")
        current = (node or {}).get("stake", 0)
        target = self.stake_target if self.stake_target is not None else params["min_stake"]
        if current < target:
            need = target - current
            if self.balance() < need and params.get("dev_faucet"):
                self.http.post("/faucet", json={"address": self.kp.address, "amount": need})
            self.send_tx(TxType.STAKE, {"amount": need})
            log.info("stake de %d unidades depositado", need)

    def heartbeat(self) -> Dict[str, Any]:
        ts = time.time()
        ready = self._loaded and self.backend.is_ready() and not self.drain_request()
        runtime = RuntimeReport(backend=self.backend.name, model=getattr(self.backend, "model_id", ""),
                                ready=ready, gpu_inference=ready and self.backend.gpu_inference(), busy=self._busy)
        sig = self.kp.sign(heartbeat_message(ts, runtime))
        r = self.http.post("/nodes/heartbeat", json={"address": self.kp.address, "pubkey": self.kp.public_hex,
                                                     "timestamp": ts, "signature": sig,
                                                     "runtime": runtime.model_dump()})
        r.raise_for_status()
        return r.json()

    def fetch_work(self) -> Optional[Dict[str, Any]]:
        ts = time.time()
        r = self.http.get("/work", params={"node": self.kp.address, "timestamp": ts, "pubkey": self.kp.public_hex,
                                           "signature": self.kp.sign(f"work:{self.kp.address}:{ts}".encode())})
        if r.status_code == 204:
            return None
        r.raise_for_status()
        return r.json()

    def execute(self, work: Dict[str, Any]) -> str:
        if self.models and work["model"] not in self.models:
            raise RuntimeError("Assigned model is not loaded by this worker")
        if self.kp.address not in work.get("replicas", []):
            raise RuntimeError("Work item is not assigned to this worker")
        maximum = work.get("max_new_tokens")
        prompt = work.get("prompt")
        if (type(maximum) is not int or not 1 <= maximum <= (256 if self._private else 4096)
                or not isinstance(prompt, str) or not prompt.strip()
                or len(prompt) > (4000 if self._private else 16384)):
            raise RuntimeError("Work item exceeds worker inference limits")
        self._busy = True
        try:
            self.heartbeat()
            return self._execute_assigned(work)
        finally:
            self._busy = False
            try:
                self.heartbeat()
            except httpx.HTTPError:
                log.warning("Could not refresh presence after inference")

    def _execute_assigned(self, work: Dict[str, Any]) -> str:
        # Keep signed presence fresh while a real model is generating.
        with ThreadPoolExecutor(max_workers=1) as pool:
            generation = pool.submit(self.backend.generate, work["prompt"], int(work["max_new_tokens"]))
            while True:
                try:
                    res = generation.result(timeout=5.0)
                    break
                except FutureTimeout:
                    if generation.done():
                        raise
                    self.heartbeat()
        h = self.send_tx(TxType.TASK_RESULT, {
            "task_id": work["task_id"], "output": res.text, "output_hash": res.output_hash,
            "tokens_generated": res.tokens_generated, "latency_ms": res.latency_ms,
        })
        self.completed += 1
        log.info("tarefa %s concluída: %d tokens em %.0f ms", work["task_id"][:8], res.tokens_generated, res.latency_ms)
        return h

    def step(self) -> bool:
        """Um ciclo: heartbeat + (no máximo) uma tarefa. Devolve True se executou algo."""
        self.backend.prepare()
        drain_nonce = self.drain_request()
        self.heartbeat()
        work = self.fetch_work()
        if not work:
            nonce = self.drain_request()
            if nonce and nonce == drain_nonce:
                # The successful preceding heartbeat removes this worker from
                # scheduling. Drain already-assigned work before acknowledging.
                Path(self._drain_file + ".ready").write_text(json.dumps({"nonce":nonce,"pid":os.getpid(),"at":time.time()}))
            return False
        self.execute(work)
        return True

    def run(self, max_tasks: Optional[int] = None) -> None:
        self.backend.load()
        self._loaded = True
        self.register()
        log.info("worker %s online em %s (backend=%s)", self.kp.address[:12], self.url, self.backend.name)
        while not self._stop:
            try:
                did = self.step()
            except (httpx.HTTPError, RuntimeError, ValueError) as exc:
                log.warning("Worker request or inference failed (%s)", type(exc).__name__)
                did = False
            if max_tasks is not None and self.completed >= max_tasks:
                break
            if not did:
                time.sleep(self.poll_interval)

    def stop(self) -> None:
        self._stop = True
