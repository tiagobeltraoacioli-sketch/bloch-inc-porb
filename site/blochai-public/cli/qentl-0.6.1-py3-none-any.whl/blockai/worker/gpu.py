"""Detecção de GPU no nó worker (torch → nvidia-smi → fallback CPU).

Suporta selecionar uma GPU específica por índice, para o caso de uma
máquina com várias GPUs onde cada uma roda seu próprio processo worker
(ver `blockai/worker/node.py` e `scripts/fleet.sh`). Quando o processo já
está isolado a uma única GPU via `CUDA_VISIBLE_DEVICES` (a forma
recomendada — cada worker enxerga sempre "cuda:0"), `index` não é
necessário; ele existe para quando um único processo precisa relatar/optar
por uma GPU entre várias visíveis.
"""
from __future__ import annotations

import platform
import shutil
import subprocess
from typing import List, Optional

from ..chain.state import GpuInfo


def list_nvidia_gpus() -> List[GpuInfo]:
    """Enumera todas as GPUs NVIDIA visíveis via nvidia-smi (uma entrada por GPU física)."""
    if not shutil.which("nvidia-smi"):
        return []
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
            text=True, timeout=5)
    except (subprocess.SubprocessError, ValueError):
        return []
    gpus = []
    for line in out.splitlines():
        line = line.strip()
        if not line:
            continue
        name, mem = [x.strip() for x in line.split(",")[:2]]
        gpus.append(GpuInfo(name=name, memory_mb=int(float(mem)), count=1, backend="cuda"))
    return gpus


def detect_gpu(index: Optional[int] = None) -> GpuInfo:
    """Detecta a GPU do processo atual. `index` seleciona entre várias visíveis
    (0-based); se omitido, usa a GPU 0 do ponto de vista do processo — que é a
    única visível quando `CUDA_VISIBLE_DEVICES` já isola um dispositivo."""
    try:
        import torch  # type: ignore

        if torch.cuda.is_available():
            idx = index if index is not None else 0
            props = torch.cuda.get_device_properties(idx)
            return GpuInfo(name=props.name, memory_mb=int(props.total_memory // (1024 * 1024)),
                           count=1, backend="cuda")
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            return GpuInfo(name=f"Apple {platform.machine()} GPU (MPS)", memory_mb=_apple_unified_memory_mb(),
                           count=1, backend="mps")
    except ImportError:
        pass

    gpus = list_nvidia_gpus()
    if gpus:
        idx = index if index is not None else 0
        if idx < len(gpus):
            return gpus[idx]
        return gpus[0]
    return GpuInfo(name=f"CPU ({platform.processor() or platform.machine()})", memory_mb=0, count=1, backend="cpu")


def _apple_unified_memory_mb() -> int:
    try:
        out = subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True, timeout=2)
        return int(out.strip()) // (1024 * 1024)
    except (subprocess.SubprocessError, ValueError):
        return 0
