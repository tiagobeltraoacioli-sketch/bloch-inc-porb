"""BlockAI — IA descentralizada com Proof-of-Compute.

Uma rede onde nós com GPU se registram numa blockchain, recebem tarefas de
inferência do modelo (Qwen por padrão), executam-nas e são recompensados em
tokens BAI quando seus resultados atingem consenso com outros nós.
"""

__version__ = "0.1.0"
