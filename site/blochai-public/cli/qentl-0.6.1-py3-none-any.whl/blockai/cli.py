"""CLI da BlockAI: `blockai coordinator|worker|wallet|status ...`"""
from __future__ import annotations

import logging
import math
import os
import time
from typing import List, Optional

import httpx
import typer
import uvicorn
from rich.console import Console
from rich.table import Table

from .chain import ChainParams, KeyPair, Transaction, TxType
from .chain.state import fmt_bai
from .model.backend import get_backend, recommend_model
from .network.coordinator import Coordinator, create_app
from .network.gateway import GatewayConfig
from .worker.gpu import detect_gpu
from .worker.node import WorkerNode

app = typer.Typer(help="BlockAI — IA descentralizada com GPUs conectadas via blockchain (Proof-of-Compute).",
                  pretty_exceptions_show_locals=False)
console = Console()

DEFAULT_HOME = os.environ.get("BLOCKAI_HOME", os.path.expanduser("~/.blockai"))


def _keypath(name: str) -> str:
    return os.path.join(DEFAULT_HOME, f"{name}.key.json")


logging.basicConfig(level=os.environ.get("BLOCKAI_LOG", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s")


@app.command()
def coordinator(host: str = "127.0.0.1", port: int = 8000, block_interval: float = 3.0,
               key: str = typer.Option(None, help="Caminho da chave da autoridade (padrão: ~/.blockai/authority.key.json"),
               data: str = typer.Option(None, help="Arquivo da cadeia (padrão: ~/.blockai/chain.json)"),
               min_stake: float = 100.0, replication: int = 2):
    """Sobe o coordenador (API HTTP + produtor de blocos)."""
    os.makedirs(DEFAULT_HOME, exist_ok=True)
    kp = KeyPair.load_or_create(key or _keypath("authority"))
    params = ChainParams(min_stake=int(min_stake * 1_000_000), replication=replication)
    coord = Coordinator(kp, chain_path=data or os.path.join(DEFAULT_HOME, "chain.json"), params=params,
                        block_interval=block_interval)
    console.print(f"[bold green]BlockAI coordinator[/] autoridade=[cyan]{kp.address}[/] altura={coord.chain.height}")
    console.print(f"tesouro: {fmt_bai(coord.chain.state.balance(params.treasury))}")
    uvicorn.run(create_app(coord), host=host, port=port, log_level="info")


@app.command()
def gateway(host: str = "127.0.0.1", port: int = 8010, model: str = "Qwen/Qwen2.5-0.5B-Instruct", backend: str = "qwen",
            key: Optional[str] = None, data: Optional[str] = None, wallet_key: Optional[str] = None,
            replication: int = 2, task_timeout: float = 180.0, initial_budget: float = 1000.0,
            target_nodes: int = 13, target_vram_gb: int = 2,
            public_wallet_key: Optional[str] = None, public_initial_budget: float = 1000.0):
    """Run a private portal gateway with real inference and a separate worker token.

    BLOCKAI_PORTAL_TOKEN and BLOCKAI_WORKER_TOKEN are required secrets.
    Optional BLOCKAI_PUBLIC_TOKEN enables the closed public portal catalog with
    a separate persistent wallet and a one-time treasury-funded service budget.
    The new permissioned chain has no faucet or stake requirement. BAI here
    represents an internal service budget, not a payment or an external asset.
    """
    portal_token = os.environ.get("BLOCKAI_PORTAL_TOKEN", "")
    worker_token = os.environ.get("BLOCKAI_WORKER_TOKEN", "")
    public_token = os.environ.get("BLOCKAI_PUBLIC_TOKEN") or None
    if not 1 <= replication <= 7 or initial_budget <= 0 or task_timeout < 30:
        raise typer.BadParameter("Use replication 1..7, a positive budget and timeout >= 30 seconds")
    if public_token and (not math.isfinite(public_initial_budget) or public_initial_budget < 0.000001):
        raise typer.BadParameter("Public service budget must be finite and at least 0.000001")
    os.makedirs(DEFAULT_HOME, exist_ok=True)
    authority = KeyPair.load_or_create(key or _keypath("gateway-authority"))
    wallet = KeyPair.load_or_create(wallet_key or _keypath("gateway-wallet"))
    public_wallet = KeyPair.load_or_create(public_wallet_key or _keypath("gateway-public-wallet")) if public_token else None
    try:
        config = GatewayConfig(portal_token=portal_token, worker_token=worker_token, wallet=wallet,
                               model=model, backend=backend, target_nodes=target_nodes,
                               target_vram_gb=target_vram_gb, public_token=public_token, public_wallet=public_wallet)
        if public_wallet is not None and public_wallet.address == authority.address:
            raise ValueError("Public service wallet must not be the chain authority")
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    path = data or os.path.join(DEFAULT_HOME, "gateway-chain.json")
    existing = os.path.exists(path)
    params = ChainParams(chain_id="blochai-private", treasury=authority.address, min_stake=0,
                         replication=replication, default_model=model, dev_faucet=False)
    coord = Coordinator(authority, chain_path=path, params=params, block_interval=2.0, task_timeout=task_timeout)
    if coord.chain.params.default_model != model or coord.chain.params.dev_faucet:
        raise typer.BadParameter("Saved chain must use the configured model with dev_faucet disabled")
    if not existing:
        funding = Transaction.build(authority, TxType.TRANSFER, coord.chain.pending_nonce(authority.address),
                                    {"to": wallet.address, "amount": int(initial_budget * 1_000_000)})
        coord.chain.submit_tx(funding)
        coord.chain.produce_block()
    if public_wallet is not None:
        # Presence in balances is durable even when the budget reaches zero.
        # Enabling public mode on an existing ledger does not reset private jobs,
        # and restarting never replenishes an exhausted public budget.
        with coord.chain.lock:
            if public_wallet.address not in coord.chain.state.balances:
                funding = Transaction.build(authority, TxType.TRANSFER, coord.chain.pending_nonce(authority.address),
                                            {"to": public_wallet.address, "amount": int(public_initial_budget * 1_000_000)})
                coord.chain.submit_tx(funding)
                coord.chain.produce_block()
    console.print(f"[bold green]BlochAI private gateway[/] model={model} backend={backend} height={coord.chain.height}")
    uvicorn.run(create_app(coord, gateway=config), host=host, port=port, log_level="info")


@app.command()
def worker(coordinator_url: str = "http://127.0.0.1:8000", backend: str = "mock", model: str = None,
          quantize: str = typer.Option(None, help="Quantização para o backend qwen: '4bit' ou '8bit' (exige GPU CUDA; essencial para modelos maiores em GPUs de 8 GB)"),
          key: str = typer.Option(None, help="Caminho da chave do nó (padrão: ~/.blockai/worker.key.json"),
          gpu_index: int = typer.Option(None, help="Índice da GPU a reportar/usar quando há mais de uma visível no processo (ex.: rodando sem isolar via CUDA_VISIBLE_DEVICES)"),
          operator: str = typer.Option("", help="Identificador do operador deste nó (ex.: seu nome/empresa); usado pelo escalonador para diversificar réplicas entre operadores distintos"),
          stake: float = None, max_tasks: int = None, poll_interval: float = 2.0):
    """Sobe um nó de GPU que se conecta ao coordenador e executa tarefas."""
    os.makedirs(DEFAULT_HOME, exist_ok=True)
    kp = KeyPair.load_or_create(key or _keypath("worker"))
    device = f"cuda:{gpu_index}" if gpu_index is not None else None
    options = {"device": device, "revision": os.environ.get("BLOCKAI_MODEL_REVISION") or None} if backend == "qwen" else {}
    if backend == "ollama":
        options = {"url": os.environ.get("BLOCKAI_OLLAMA_URL", "http://127.0.0.1:11434")}
    be = get_backend(backend, model_id=model, quantization=quantize, **options)
    gpu = detect_gpu(index=gpu_index)
    node = WorkerNode(kp, coordinator_url, be, models=[model] if model else [], gpu=gpu, operator=operator,
                      stake=int(stake * 1_000_000) if stake is not None else None, poll_interval=poll_interval)
    console.print(f"[bold green]BlockAI worker[/] endereço=[cyan]{kp.address}[/] gpu={node.gpu.name} "
                 f"({node.gpu.memory_mb} MB) backend={backend}{f' quantize={quantize}' if quantize else ''}")
    node.run(max_tasks=max_tasks)


@app.command()
def recommend(vram_gb: float, quantize: str = typer.Option(None, help="'4bit', '8bit' ou nenhum")):
    """Sugere o maior modelo Qwen2.5 que cabe numa GPU com a VRAM informada."""
    model = recommend_model(vram_gb, quantize)
    console.print(f"para {vram_gb:.1f} GB de VRAM (quantize={quantize or 'nenhum'}): [bold cyan]{model}[/]")


@app.command()
def wallet(name: str = "user"):
    """Cria (ou mostra) uma carteira local."""
    os.makedirs(DEFAULT_HOME, exist_ok=True)
    kp = KeyPair.load_or_create(_keypath(name))
    console.print(f"carteira [bold]{name}[/]: [cyan]{kp.address}[/]  (chave: {_keypath(name)})")


@app.command()
def status(coordinator_url: str = "http://127.0.0.1:8000"):
    """Mostra o estado da cadeia e os nós conectados."""
    r = httpx.get(coordinator_url + "/")
    info = r.json()
    console.print(f"cadeia [bold]{info['chain_id']}[/]  altura={info['height']}  mempool={info['mempool']}")
    console.print(f"tesouro: {fmt_bai(info['treasury_balance'])}  nós: {info['nodes_online']}/{info['nodes_registered']} online  tarefas: {info['tasks_total']}")

    nodes = httpx.get(coordinator_url + "/nodes").json()
    table = Table(title="Nós de GPU")
    for col in ("endereço", "operador", "gpu", "vram(mb)", "stake", "reputação", "concluídas", "online"):
        table.add_column(col)
    for n in nodes:
        table.add_row(n["address"][:16] + "…", n.get("operator") or "-", n["gpu"].get("name", "?"),
                     str(n["gpu"].get("memory_mb", 0)), fmt_bai(n["stake"]), f"{n['reputation']:.2f}",
                     str(n["tasks_completed"]), "🟢" if n["online"] else "⚪")
    console.print(table)


@app.command()
def faucet(address: str, amount: float = 1000.0, coordinator_url: str = "http://127.0.0.1:8000"):
    """Envia BAI de teste para um endereço (somente em modo dev)."""
    r = httpx.post(coordinator_url + "/faucet", json={"address": address, "amount": int(amount * 1_000_000)})
    r.raise_for_status()
    console.print(f"faucet enviado: tx {r.json()['hash']}")


@app.command()
def submit(prompt: str, name: str = "user", max_new_tokens: int = 64, model: str = None,
          replication: int = None, coordinator_url: str = "http://127.0.0.1:8000", wait: bool = True):
    """Envia um prompt para inferência na rede e (opcionalmente) aguarda o resultado."""
    kp = KeyPair.load_or_create(_keypath(name))
    with httpx.Client(base_url=coordinator_url, timeout=30.0) as http:
        nonce = http.get(f"/nonce/{kp.address}").json()["nonce"]
        payload = {"prompt": prompt, "max_new_tokens": max_new_tokens}
        if model:
            payload["model"] = model
        if replication:
            payload["replication"] = replication
        tx = Transaction.build(kp, TxType.TASK_SUBMIT, nonce, payload)

        fee = http.get("/fee", params={"max_new_tokens": max_new_tokens}).json()["fee"]
        bal = http.get(f"/balance/{kp.address}").json()["balance"]
        if bal < fee:
            info = http.get("/").json()
            if info["params"].get("dev_faucet"):
                http.post("/faucet", json={"address": kp.address, "amount": fee * 10})
            else:
                console.print(f"[red]saldo insuficiente[/]: tem {fmt_bai(bal)}, precisa {fmt_bai(fee)}")
                raise typer.Exit(1)

        r = http.post("/tx", json=tx.model_dump(mode="json"))
        if r.status_code != 200:
            console.print(f"[red]tarefa rejeitada[/]: {r.text}")
            raise typer.Exit(1)
        task_id = r.json()["hash"]
        console.print(f"tarefa enviada: [cyan]{task_id}[/]  taxa={fmt_bai(fee)}")

        if not wait:
            return
        with console.status("aguardando execução na rede..."):
            for _ in range(120):
                t = http.get(f"/tasks/{task_id}").json()
                if t["status"] in ("COMPLETED", "FAILED"):
                    break
                time.sleep(1.0)
        if t["status"] == "COMPLETED":
            console.print(f"[bold green]resultado:[/] {t['output']}")
        else:
            console.print(f"[bold red]tarefa falhou[/] (sem consenso); taxa reembolsada.")


if __name__ == "__main__":
    app()
